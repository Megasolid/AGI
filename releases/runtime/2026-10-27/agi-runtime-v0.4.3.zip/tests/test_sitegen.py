#!/usr/bin/env python3
"""test_sitegen.py - dashboard v3 site contract (GitHub UI, clickable cards, pages, task layouts).

Run: <venv-python> tests/test_sitegen.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import sitegen  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def main():
    d = sitegen.load_data()
    specs = sitegen.card_specs(d)
    check("at least 24 dashboard cards", len(specs) >= 24, len(specs))
    sections = {s["section"] for s in specs}
    check("five categories present",
          sections == {"RUNTIME", "SIGNALS", "AGENTS & TOOLS", "MEMORY & CACHE", "WORK & SYSTEM"}, sections)
    html = sitegen.build_dashboard(d, specs)
    check("dashboard links every card to its own page",
          all(("/cards/%s.html" % s["id"]) in html for s in specs))
    check("no double-escaped section headers", "&amp;amp;" not in html)
    check("running task renders as a full-row card with a board link",
          "tcard" in html and "Open live task board" in html)
    check("previous tasks use the 4-column grid", "grid four" in html)
    archive = [t for t in (d["tasks"].get("archive") or []) if isinstance(t, dict)]
    check("archive uses the 12-column grid (+ expandable when >12)",
          "grid twelve" in html and (len(archive) <= 12 or "show remaining" in html))
    check("performance section rebuilt as a table", "PERFORMANCE" in html and "<table>" in html)
    check("system heat section present", "SYSTEM HEAT" in html and "index chunks" in html)
    page = sitegen.build_card_page(d, specs[0])
    check("card page has breadcrumb + provenance + field table",
          "&larr; dashboard" in page and "PROVENANCE" in page and "<table>" in page)
    check("card page uses the shared design system", "--bg:#0d1117" in page)
    sysp = sitegen.build_system_page(d, specs)
    check("system page shows subsystem cards + maintenance ledgers",
          "SUBSYSTEM CARDS" in sysp and "MAINTENANCE LEDGER - OPEN" in sysp)
    maint = sitegen.build_maintenance_page(d)
    check("maintenance page shows open/parked/fixed", "OPEN" in maint and "FIXED" in maint)
    check("every page shares one stylesheet", all("--bg:#0d1117" in p for p in (html, page, sysp, maint)))
    check("dashboard presents maintenance tasks as unified cards",
          "MAINTENANCE &middot; TASKS" in html and "/cards/maint-" in html)
    check("running task card no longer carries a separate details button",
          "Task card details" not in html)
    maint_page = sitegen.build_maintenance_page(d)
    check("maintenance dashboard (part of system) renders unified task cards",
          "/cards/maint-" in maint_page and "OPEN - ACTIVE MAINTENANCE TASKS" in maint_page)
    inbox = sitegen.build_inbox_page(d)
    check("inbox page renders pending + settled sections",
          "PENDING DECISIONS" in inbox and "RECENTLY SETTLED" in inbox)
    maint_specs = sitegen._maint_specs(d)
    check("maintenance items each get a card page spec", len(maint_specs) >= 5
          and all(x["section"] == "MAINTENANCE" for x in maint_specs))
    # L3 housekeeping: the season pointer is NOT a maintenance task card
    maint_specs = sitegen._maint_specs(d)
    check("season pointer excluded from maintenance task cards",
          all("Season 2026-10-25 open" not in (x.get("title") or "") + str(x.get("full_text") or "")
              for x in maint_specs))
    maint_page = sitegen.build_maintenance_page(d)
    check("maintenance page shows the season strip, not a fake OPEN task",
          "SEASON STATUS - NOT A MAINTENANCE TASK" in maint_page
          and not (sitegen._season_pointer(d) and ('maint-open-1.html' in maint_page)))
    dash = sitegen.build_dashboard(d, sitegen.card_specs(d))
    check("dashboard shows the season strip + backups retention row",
          "SEASON STATUS" in dash and "backups</span>" in dash)
    n = sum(checks)
    print("test_sitegen: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

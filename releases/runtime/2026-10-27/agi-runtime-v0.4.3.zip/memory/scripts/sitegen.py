#!/usr/bin/env python3
"""sitegen - generate the AGI site: dashboard, per-card pages, AGI system dashboard, maintenance.

One design system (GitHub dark tokens + shared components) for every page; every dashboard card is a
link to its own page; the RUNNING task is a full-row card like the individual task card; PREVIOUS tasks
render in a 4-column grid and TASK ARCHIVE in a 12-column grid that expands to show all; PERFORMANCE and
SYSTEM HEAT are rebuilt for the new design.

Output (season RAM cache; served by board_serve.py over the loopback URL):
  <cache>/site/index.html          dashboard
  <cache>/site/cards/<id>.html     individual card pages
  <cache>/site/system.html         AGI system dashboard
  <cache>/site/maintenance.html    maintenance detail

usage: sitegen.py   (idempotent; called by dashboards.py at boot/stage)
"""
import json
import os
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
MEM = AGI / "memory"
STATE = AGI / "state"
SITE = None  # resolved at generate() time from cardkit.sandbox_cache()


# ---------------------------------------------------------------- data helpers
def jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def jlines(p):
    out = []
    try:
        for line in Path(p).read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                out.append(json.loads(line))
    except Exception:
        pass
    return out


def esc(v):
    return str(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def nid(kind, ident):
    try:
        sys.path.insert(0, str(MEM / "scripts"))
        import idkit
        return idkit.short(kind, ident)
    except Exception:
        return ""


def age(ts):
    try:
        from datetime import datetime
        t = datetime.fromisoformat(str(ts)).timestamp()
        d = max(0.0, time.time() - t)
    except Exception:
        return "?"
    if d < 90:
        return "%ds" % d
    if d < 5400:
        return "%.0fm" % (d / 60)
    if d < 172800:
        return "%.1fh" % (d / 3600)
    return "%.1fd" % (d / 86400)


def fmt_s(sec):
    sec = max(0, int(sec or 0))
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return ("%dh %02dm" % (h, m)) if h else ("%dm" % m if m else "%ds" % s)


# ---------------------------------------------------------------- design system
CSS = """
:root{color-scheme:dark;--bg:#0d1117;--panel:#161b22;--inset:#010409;--line:#30363d;--text:#e6edf3;
--muted:#8b949e;--blue:#58a6ff;--green:#3fb950;--amber:#d29922;--red:#f85149;--grey:#6e7681;
--mono:ui-monospace,SFMono-Regular,Consolas,monospace}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font:14px/1.55 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;padding:20px}
a{color:var(--blue);text-decoration:none}a:hover{text-decoration:underline}
.rack{max-width:1440px;margin:0 auto}
.hd{display:flex;align-items:center;gap:14px;flex-wrap:wrap;background:var(--panel);border:1px solid var(--line);
border-radius:10px;padding:12px 18px;margin-bottom:18px}
.hd h1{font-size:18px;font-weight:650;margin-right:4px}
.chip{border:1px solid var(--line);border-radius:999px;padding:2px 10px;font-size:12px;background:#21262d;color:var(--text);white-space:nowrap}
.chip .dot{width:8px;height:8px}
.chip.warn{border-color:#9e6a03;color:var(--amber)}
.chip.fail{border-color:#da3633;color:var(--red)}
.nav{margin-left:auto;display:flex;gap:6px;flex-wrap:wrap}
.nav a{border:1px solid var(--line);border-radius:6px;padding:5px 12px;font-weight:600;font-size:12px;background:#21262d;color:var(--text)}
.nav a:hover{background:#30363d;text-decoration:none}
.sect{margin:22px 0 10px;display:flex;align-items:baseline;gap:10px;border-bottom:1px solid var(--line);padding-bottom:7px}
.sect h2{font-size:12px;font-weight:650;color:var(--muted);letter-spacing:.06em;text-transform:uppercase}
.sect .meta{margin-left:auto;font-size:12px;color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px}
.grid.four{grid-template-columns:repeat(4,minmax(0,1fr))}
.grid.twelve{grid-template-columns:repeat(12,minmax(0,1fr))}
.card{display:block;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:13px 15px;color:inherit;
transition:border-color .12s,transform .12s}
a.card:hover{border-color:var(--blue);transform:translateY(-1px);text-decoration:none}
a.card:focus-visible{outline:2px solid var(--blue);outline-offset:2px}
.card.full{grid-column:1/-1}
.label{display:flex;align-items:center;gap:8px;font-size:12px;font-weight:650;color:var(--muted);margin-bottom:8px;letter-spacing:.02em}
.label .nid{color:var(--blue);font-weight:700;font-size:11px}
.label .ttl{margin-left:auto;color:var(--muted);font-weight:400;font-size:11px}
.dot{width:8px;height:8px;border-radius:50%;display:inline-block;flex:none;background:var(--grey)}
.dot.ok{background:var(--green)}.dot.warn{background:var(--amber)}.dot.fail{background:var(--red)}
.big{font-size:22px;font-weight:650;margin:2px 0 8px;overflow-wrap:anywhere}
.big.small{font-size:16px}
.row{display:flex;justify-content:space-between;gap:12px;font-size:12px;padding:4px 0;color:var(--muted);border-bottom:1px solid #21262d}
.row:last-child{border-bottom:none}
.row em{font-style:normal;color:var(--text);text-align:right;overflow-wrap:anywhere}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:0 18px}
.cardfoot{margin-top:8px;font-size:11px;color:var(--muted)}
.pill{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:2px 10px;font-size:11px;font-weight:650}
.pill.ok{border-color:#238636;color:var(--green);background:#2ea04318}
.pill.warn{border-color:#9e6a03;color:var(--amber);background:#d2992218}
.pill.fail{border-color:#da3633;color:var(--red);background:#f8514918}
.pill.info{border-color:#1f6feb;color:var(--blue);background:#1f6feb18}
.led{width:14px;height:14px;border-radius:50%;display:inline-block;background:var(--grey);flex:none}
.led.pending{background:var(--grey)}
.led.active{background:var(--amber);box-shadow:0 0 8px #d29922aa}
.led.passed{background:var(--green);box-shadow:0 0 6px #3fb95088}
.led.failed{background:var(--red);box-shadow:0 0 8px #f8514988}
.leds{display:flex;gap:5px;flex-wrap:wrap;align-items:center;margin:8px 0}
.prog{height:6px;background:#21262d;border-radius:999px;overflow:hidden;margin:8px 0 4px}
.prog i{display:block;height:100%;background:var(--green)}
.board{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:10px 0}
.cell{background:var(--inset);border:1px solid var(--line);border-radius:6px;padding:7px 10px}
.cell .k{font-size:10px;letter-spacing:.08em;color:var(--muted);text-transform:uppercase}
.cell .v{font-size:16px;font-weight:650;margin-top:2px}
.btn{display:inline-block;border:1px solid var(--line);border-radius:6px;padding:5px 12px;font-size:12px;font-weight:650;
background:#21262d;color:var(--text);margin:2px 4px 2px 0}
.btn.primary{background:#238636;border-color:#2ea043;color:#fff}
.btn:hover{background:#30363d;text-decoration:none}
.btn.primary:hover{background:#2ea043}
.tcard .thd{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:6px}
.tcard .thd .big{margin:0}
.steps{margin:8px 0 2px;display:flex;flex-direction:column;gap:5px}
.stp{display:grid;grid-template-columns:18px 1fr auto;gap:10px;align-items:center;font-size:12px;color:var(--muted)}
.stp.passed{color:var(--text)}
.stp.active{color:var(--amber)}
.stp.failed{color:var(--red)}
.stp .why{font-size:11px;color:var(--muted)}
table{width:100%;border-collapse:collapse;font-size:12px}
th,td{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left;vertical-align:top}
th{color:var(--muted);font-weight:650;background:var(--panel)}
tr:hover td{background:#161b2266}
.pb{height:7px;background:#21262d;border-radius:4px;overflow:hidden;min-width:60px}
.pb i{display:block;height:100%;background:var(--blue)}
.pb.green i{background:var(--green)}.pb.amber i{background:var(--amber)}.pb.red i{background:var(--red)}
.heat{display:flex;flex-direction:column;gap:6px}
.heat .hrow{display:grid;grid-template-columns:210px 1fr 44px;gap:10px;align-items:center;font-size:12px;color:var(--muted)}
.heat .hrow span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.heat .hbar{height:8px;background:#21262d;border-radius:4px;overflow:hidden}
.heat .hbar i{display:block;height:100%;background:linear-gradient(90deg,#1f6feb,#58a6ff)}
.mono{font-family:var(--mono);font-size:11px}
.ok{color:var(--green)}.warn{color:var(--amber)}.fail{color:var(--red)}.muted{color:var(--muted)}
.breadcrumb{font-size:12px;color:var(--muted);margin-bottom:12px}
.breadcrumb a{color:var(--blue)}
.foot{margin-top:24px;border-top:1px solid var(--line);padding-top:12px;color:var(--muted);font-size:11px;text-align:center}
details summary{cursor:pointer;color:var(--blue);font-size:12px;margin:8px 0}
ul.li{margin-left:20px;font-size:12px;color:var(--muted)}ul.li li{padding:2px 0}
.mini{padding:9px 11px}.mini .label{margin-bottom:4px;font-size:11px}.mini .nm{font-size:12px;color:var(--text)}
@media(max-width:1100px){.grid.four{grid-template-columns:repeat(2,1fr)}.grid.twelve{grid-template-columns:repeat(4,1fr)}
.board{grid-template-columns:repeat(3,1fr)}}
@media(max-width:640px){.grid.four,.grid.twelve{grid-template-columns:1fr}.board{grid-template-columns:1fr 1fr}}
@media print{.nav{display:none}body{background:#fff;color:#111}}
"""


def _page(title, body, subtitle=""):
    return ("<!doctype html><html><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1'>"
            "<title>%s</title><style>%s</style></head><body><div class='rack'>%s</div></body></html>"
            % (esc(title), CSS, body))


def _header(d, active="dashboard"):
    b = d["boot"]
    host = d["bootrec"].get("host") or {}
    net = (d["caps"].get("network") or {})
    mode = (d["tasks"].get("mode") or "normal").upper()
    pool = d["caps"].get("subagents") or {}
    stale_pool = bool(pool.get("stale"))
    bills = [x for x in d["bills"] if x.get("bill_status") == "active"]
    hs = (d["caps"].get("host_speed") or {})
    chips = [
        "<span class='chip'><span class='dot ok'></span>MODE: %s</span>" % esc(mode),
        "<span class='chip'><span class='dot %s'></span>%s</span>" % (
            "ok" if b.get("status") == "ready" else "warn", esc(b.get("model_name") or "model?")),
        "<span class='chip'>host: %s</span>" % esc((b.get("host_application") or {}).get("id") or "?"),
        "<span class='chip %s'>pool %s/%s%s</span>" % (
            "warn" if stale_pool else "", len(pool.get("pool_up") or []),
            len(pool.get("pool_up") or []) + len(pool.get("down") or []), " STALE" if stale_pool else ""),
        "<span class='chip %s'>bills: %d open</span>" % ("warn" if bills else "", len(bills)),
    ]
    if hs.get("declared_gen_tok_s") or hs.get("factor"):
        chips.append("<span class='chip'>~%s tok/s · factor %s</span>"
                     % (esc(hs.get("declared_gen_tok_s") or "?"), esc(hs.get("factor") or "?")))
    pending = 0
    try:
        st = d.get("steps") or {}
        acts = [json.loads(l) for l in (AGI / "state" / "taskboard_actions.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
        cur = int(json.loads((AGI / "state" / "taskboard_actions_cursor.json").read_text(encoding="utf-8")).get("last") or 0)
        pending = len([a for a in acts if int(a.get("n") or 0) > cur])
        if st.get("mode") == "proposal":
            pending += 1
    except Exception:
        pending = 1 if (d.get("steps") or {}).get("mode") == "proposal" else 0
    if pending:
        chips.append("<span class='chip warn'><span class='dot warn'></span>%d pending decision%s</span>"
                     % (pending, "" if pending == 1 else "s"))
    _sess = jload(STATE / "identity" / "session.json", {}) or {}
    _prof = ((jload(STATE / "identity" / "profiles.json", {}) or {}).get("profiles") or {}).get(_sess.get("profile") or "", {})
    if _sess.get("active"):
        _cls = "ok" if _sess.get("level") in ("device", "passkey") else "warn"
        chips.append("<span class='chip %s'><span class='dot %s'></span>%s · %s</span>"
                     % (_cls, _cls, esc(_prof.get("name") or _sess.get("profile")), esc(_sess.get("level"))))
    else:
        chips.append("<span class='chip warn'><span class='dot warn'></span>not signed in</span>")
    chips.append("<span class='chip'>generated %s</span>" % time.strftime("%H:%M:%S"))
    nav = "".join("<a href='%s'%s>%s</a>" % (u, " class='active'" if k == active else "", t)
                  for k, t, u in (("dashboard", "Dashboard", "/"), ("board", "Live Task", "/board"),
                                  ("inbox", "Inbox", "/inbox"), ("system", "System", "/system"),
                                  ("maintenance", "Maintenance", "/maintenance"),
                                  ("login", "Login", "/login")))
    return ("<div class='hd'><h1>AGI</h1>%s<div class='nav'>%s</div></div>" % ("".join(chips), nav))


# ---------------------------------------------------------------- card rendering
def card_html(spec, link=True):
    cid = spec.get("id") or "card"
    rows = "".join("<div class='row'><span>%s</span><em>%s</em></div>" % (esc(k), esc(v))
                   for k, v in spec.get("rows", []) if v not in (None, ""))
    extra = spec.get("extra") or ""
    num = spec.get("num") or ""
    nid_html = "<span class='nid'>%s</span>" % esc(num) if num else ""
    label = ("<div class='label'><span class='dot %s'></span>%s<span>%s</span>%s</div>"
             % (esc(spec.get("dot") or "ok"), nid_html, esc(spec.get("title") or cid),
                "<span class='ttl'>%s</span>" % esc(spec.get("sub")) if spec.get("sub") else ""))
    inner = ("%s<div class='big%s'>%s</div>%s%s%s"
             % (label, " small" if spec.get("small") else "", esc(spec.get("big", "")), rows, extra,
                "<div class='cardfoot'>open details &rarr;</div>" if link else ""))
    cls = "card full" if spec.get("full") else "card"
    if spec.get("mini"):
        cls += " mini"
    if link:
        return "<a class='%s' href='/cards/%s.html'>%s</a>" % (cls, esc(cid), inner)
    return "<div class='%s'>%s</div>" % (cls, inner)


def _task_card_html(d, t, full=True):
    """The individual task card look (LEDs + bill header), reused for the RUNNING task row."""
    cid = "task-" + str(t.get("id") or "task")
    done = str(t.get("status")).lower() in ("done", "closed")
    cps = t.get("checkpoints") or []
    rows = "".join("<div class='row'><span>%s</span><em>%s</em></div>" % (esc(k), esc(v)) for k, v in
                   (("status", t.get("status")), ("confidence", t.get("conf")),
                    ("opened", str(t.get("opened", ""))[:16]), ("closed", str(t.get("closed", ""))[:16]),
                    ("checkpoints", len(cps)), ("bill", t.get("bill_task"))))
    return ("<a class='card %s tcard' href='/cards/%s.html'><div class='thd'>"
            "<span class='dot %s'></span><span class='nid'>%s</span>"
            "<span class='big small'>%s</span>%s</div>%s</a>"
            % ("full" if full else "", esc(cid), "ok" if done else "warn", esc(t.get("num") or ""),
               esc(t.get("title") or cid),
               "<span class='pill %s'>%s</span>" % ("ok" if done else "warn", esc(str(t.get("status", "")).upper())),
               rows))


def _running_task_html(d):
    st = d["steps"]
    if not st or not st.get("steps"):
        return "<div class='card full'><div class='label'>no active task board</div><span class='muted'>start a task to see the live card here</span></div>"
    steps = st["steps"]
    passed = sum(1 for s in steps if s.get("status") == "passed")
    total = len(steps)
    active = sum(1 for s in steps if s.get("status") == "active")
    failed = sum(1 for s in steps if s.get("status") == "failed")
    overall = "FAILED" if failed else ("PASSED" if total and passed == total else ("RUNNING" if active or passed else "DRAFT"))
    pill_cls = {"PASSED": "ok", "FAILED": "fail", "RUNNING": "warn"}.get(overall, "info")
    bill = None
    for e in reversed(d["bills"]):
        if e.get("task") == st.get("bill_task"):
            bill = e
            break
    bill = bill or {}
    est = bill.get("est_s")
    started = bill.get("started_epoch")
    elapsed = (time.time() - started) if started else 0
    leds = "".join("<span class='led %s' title='%02d %s'></span>"
                   % (esc(s.get("status") or "pending"), int(s.get("n") or 0), esc(s.get("name") or ""))
                   for s in steps)
    prows = "".join(
        "<div class='stp %s'><span class='led %s'></span><span>%s</span><span class='why'>%s</span></div>"
        % (esc(s.get("status") or "pending"), esc(s.get("status") or "pending"),
           esc(str(s.get("n")).zfill(2) + " · " + str(s.get("name") or "")), esc(s.get("note") or ""))
        for s in steps)
    res = st.get("result") or {}
    res_html = ""
    if res:
        res_links = "".join("<a class='btn primary' href='%s'>%s</a>" % (esc(l.get("url")), esc(l.get("label") or "link"))
                            for l in (res.get("links") or []))
        res_html = ("<div style='margin:10px 0;padding:10px 12px;background:#0d2818;border:1px solid #238636;"
                    "border-radius:8px'><div style='font-size:11px;letter-spacing:.08em;color:var(--green);"
                    "font-weight:700;text-transform:uppercase'>RESULT</div>"
                    "<div style='font-size:13px;margin:5px 0 8px'>%s</div>%s</div>"
                    % (esc(res.get("summary") or ""), res_links))
    board = ("<div class='board'>"
             "<div class='cell'><div class='k'>est</div><div class='v'>%s</div></div>"
             "<div class='cell'><div class='k'>elapsed</div><div class='v'>%s</div></div>"
             "<div class='cell'><div class='k'>actual</div><div class='v'>%s</div></div>"
             "<div class='cell'><div class='k'>ratio</div><div class='v'>%s</div></div>"
             "<div class='cell'><div class='k'>bill</div><div class='v' style='font-size:12px'>%s</div></div>"
             "</div>" % (fmt_s(est) if est else "—", fmt_s(elapsed) if started else "—",
                         fmt_s(bill.get("actual_s")) if bill.get("actual_s") else "—",
                         "%.2f" % bill["ratio"] if bill.get("ratio") else "—",
                         esc(str(bill.get("bill_status") or "not started").replace("_", " "))))
    cps = st.get("checkpoints") or []
    extra_rows = ("<div class='row'><span>bill</span><em>%s</em></div>"
                  "<div class='row'><span>opened</span><em>%s</em></div>"
                  "<div class='row'><span>checkpoints</span><em>%s</em></div>"
                  % (esc(st.get("bill_task") or "-"), esc((st.get("started") or "")[:16]),
                     esc(len(cps))))
    return ("<div class='card full tcard'><div class='thd'><span class='dot %s'></span>"
            "<span class='nid'>%s</span><span class='big small'>%s</span>"
            "<span class='pill %s'>%s</span><span class='muted' style='font-size:12px'>%s/%s passed · %d active</span></div>"
            "<div class='leds'>%s</div><div class='prog'><i style='width:%d%%'></i></div>%s%s"
            "<div class='steps' style='margin-top:10px'>%s</div>%s"
            "<div style='margin-top:10px'><a class='btn primary' href='/board' target='_blank'>Open live task board</a>"
            "<a class='btn' href='/inbox'>Inbox</a></div></div>"
            % ({"PASSED": "ok", "FAILED": "fail"}.get(overall, "warn"), esc(st.get("task_id") or ""),
               esc(st.get("title") or "task"), pill_cls, overall,
               passed, total, active, leds, int(100 * passed / total) if total else 0, board, extra_rows, prows,
               res_html))


def _perf_section(d):
    runs = [r for r in d["runs"] if isinstance(r, dict)][-10:]
    if not runs:
        return "<div class='card full'><div class='label'>PERFORMANCE</div><span class='muted'>no check runs yet</span></div>"
    rows = []
    for r in reversed(runs):
        gen = float(r.get("gen_avg") or 0)
        prompt = float(r.get("prompt_avg") or 0)
        vram = float(r.get("vram_pct") or 0)
        net = float(r.get("net_s") or 0)
        gcls = "green" if gen >= 20 else ("amber" if gen >= 10 else "red")
        vcls = "red" if vram >= 90 else ("amber" if vram >= 75 else "green")
        rows.append(
            "<tr><td class='mono'>%s</td><td><span class='pill %s'>%s</span></td>"
            "<td><div style='display:flex;align-items:center;gap:8px'><div class='pb %s' style='flex:1'><i style='width:%d%%'></i></div><span class='mono'>%.1f</span></div></td>"
            "<td class='mono'>%.0f</td><td><div style='display:flex;align-items:center;gap:8px'><div class='pb %s' style='flex:1'><i style='width:%d%%'></i></div><span class='mono'>%.0f%%</span></div></td>"
            "<td class='mono'>%.2fs</td><td class='mono'>%.0f</td></tr>"
            % (esc(str(r.get("ts", ""))[5:16]),
               "ok" if r.get("status") == "PASS" else ("warn" if r.get("status") == "WARN" else "fail"),
               esc(r.get("status", "?")),
               gcls, min(100, gen / 30 * 100), gen, prompt, vcls, min(100, vram), vram, net,
               float(r.get("ctx_win") or 0)))
    body = ("<div class='card full'><div class='label'><span class='dot ok'></span>PERFORMANCE"
            "<span class='ttl'>last %d check runs · data %s old</span></div>"
            "<table><thead><tr><th>time</th><th>status</th><th>gen tok/s</th><th>prompt tok/s</th>"
            "<th>VRAM</th><th>net</th><th>ctx win</th></tr></thead><tbody>%s</tbody></table></div>"
            % (len(runs), age(runs[-1].get("ts")), "".join(rows)))
    return body


def _heat_section(d):
    chunks = d["chunks"] if isinstance(d["chunks"], list) else []
    if not chunks:
        return "<div class='card full'><div class='label'>SYSTEM HEAT</div><span class='muted'>no index chunks available</span></div>"
    counts = {}
    for c in chunks:
        src = str(c.get("source") or "?")
        top = src.split("/")[0] if "/" in src else src
        counts[top] = counts.get(top, 0) + 1
    total = sum(counts.values())
    top = sorted(counts.items(), key=lambda kv: -kv[1])[:10]
    rows = "".join("<div class='hrow'><span class='mono'>%s</span><div class='hbar'><i style='width:%d%%'></i></div><span>%d</span></div>"
                   % (esc(k), int(100 * v / max(total, 1)), v) for k, v in top)
    return ("<div class='card full'><div class='label'><span class='dot ok'></span>SYSTEM HEAT"
            "<span class='ttl'>%d index chunks · grouped by source area</span></div><div class='heat'>%s</div>"
            "<div class='cardfoot'>source: memory/index/chunks.json · embedding %s / %s dims</div></div>"
            % (total, rows, esc((d["prov"] or {}).get("backend") or "?"), esc((d["prov"] or {}).get("dimensions") or "?")))


def _season_pointer(d):
    """The maintenance 'open' field can carry a season status pointer (not a maintenance task)."""
    m = d["maint"] if isinstance(d["maint"], dict) else {}
    open_items = m.get("open") or []
    if isinstance(open_items, str):
        open_items = [open_items]
    for item in open_items:
        text = str(item.get("item") if isinstance(item, dict) else item)
        if text.startswith("Season ") or "season" in text[:12].lower():
            return text
    return ""


def _maint_tasks(items):
    """Drop the season pointer from maintenance task lists; keep real tasks."""
    out = []
    for item in items or []:
        text = str(item.get("item") if isinstance(item, dict) else item)
        if text.startswith("Season ") or "season" in text[:12].lower():
            continue
        out.append(item)
    return out


def _maint_specs(d):
    """Maintenance ledger entries as unified task-like cards (R11: maintenance is work too).

    The season pointer is NOT a maintenance task (review 2026-10-25, card #77): it is rendered as a
    season status strip by the dashboards and excluded from the task cards.
    """
    m = d["maint"] if isinstance(d["maint"], dict) else {}
    specs = []
    groups = (("open", _maint_tasks(m.get("open")), "warn", "OPEN"),
              ("parked", _maint_tasks(m.get("parked_tasks")), "warn", "PARKED"),
              ("fixed", _maint_tasks(m.get("fixed")), "ok", "DONE"))
    for kind, items, dot, label in groups:
        for i, item in enumerate(items):
            if isinstance(item, dict):
                text = str(item.get("item") or "")
                ts = str(item.get("ts") or "")
            else:
                text = str(item)
                ts = ""
            cid = "maint-%s-%d" % (kind, i + 1)
            title = text.split(" — ")[0].split(" - ")[0][:80]
            specs.append({"id": cid, "title": title or (label + " item %d" % (i + 1)),
                          "dot": dot if kind != "fixed" else "ok", "big": label,
                          "section": "MAINTENANCE", "kind": kind,
                          "rows": [("status", label), ("recorded", ts or "-"), ("source", "state/maintenance.json")],
                          "full_text": text, "ts": ts, "num": nid("card", cid)})
    return specs


def _maintenance_section(d):
    specs = _maint_specs(d)
    open_ = [s for s in specs if s["kind"] == "open"]
    parked = [s for s in specs if s["kind"] == "parked"]
    fixed = [s for s in specs if s["kind"] == "fixed"][-6:]
    def grid(items):
        return "".join(card_html(x) for x in items) or "<div class='card mini'><span class='muted'>none</span></div>"
    season = _season_pointer(d)
    season_line = ("<div class='card full mini'><span class='label'>SEASON STATUS</span> "
                   "<span class='nm' style='font-size:13px'>%s</span></div>" % esc(season)) if season else ""
    return (season_line + "<div class='sect'><h2>MAINTENANCE &middot; TASKS</h2>"
            "<span class='meta'>%d open · %d parked · %d fixed recorded &middot; "
            "<a href='/maintenance'>open maintenance dashboard &rarr;</a></span></div>"
            "<div class='grid'>%s</div>"
            "<div class='sect' style='margin-top:14px'><h2>PARKED CARRY-OVERS</h2></div>"
            "<div class='grid four'>%s</div>"
            "<div class='sect' style='margin-top:14px'><h2>RECENTLY FIXED</h2></div>"
            "<div class='grid'>%s</div>"
            % (len(open_), len(parked), len(specs) - len(open_) - len(parked), grid(open_), grid(parked), grid(fixed)))


def _tasks_sections(d):
    running = _running_task_html(d)
    archive = [t for t in (d["tasks"].get("archive") or []) if isinstance(t, dict)]
    archive = sorted(archive, key=lambda t: str(t.get("closed") or ""), reverse=True)
    for i, t in enumerate(archive):
        t["num"] = nid("task", t.get("id", ""))
    previous = archive[:4]
    rest = archive
    prev_html = "".join(_task_card_html(d, t, full=False) for t in previous) or \
        "<div class='card full'><div class='label'>no previous tasks yet</div></div>"
    def _mini_card(t):
        return ("<a class='card mini' href='/cards/task-%s.html'><div class='label'>%s</div><div class='nm'>%s</div>"
                "<div class='cardfoot'><span class='pill %s'>%s</span></div></a>"
                % (esc(t.get("id", "")), esc(t.get("num") or ""), esc(t.get("title") or t.get("id")),
                   "ok" if str(t.get("status")).lower() == "done" else "warn", esc(t.get("status", ""))))
    first_row = "".join(_mini_card(t) for t in rest[:12])
    hidden_rows = "".join(_mini_card(t) for t in rest[12:])
    out = [_ready_label("TASK LIST - RUNNING TASK"),
           "<div class='grid'>%s</div>" % running,
           "<div class='sect'><h2>PREVIOUS TASKS</h2><span class='meta'>4-column grid</span></div>",
           "<div class='grid four'>%s</div>" % prev_html,
           "<div class='sect'><h2>TASK ARCHIVE</h2><span class='meta'>%d tasks · 12-column grid · expandable</span></div>" % len(rest),
           "<div class='grid twelve'>%s</div>" % first_row,
           ("<details><summary>show remaining %d archived tasks</summary><div class='grid twelve' style='margin-top:8px'>%s</div></details>" % (len(rest) - 12, hidden_rows)) if hidden_rows else ""]
    return "".join(out)


def _ready_label(txt):
    return "<div class='sect'><h2>%s</h2></div>" % esc(txt)


# ---------------------------------------------------------------- data assembly
def load_data():
    d = {
        "boot": jload(STATE / "boot_card.json"),
        "bootrec": jload(STATE / "boot.json"),
        "caps": jload(STATE / "capabilities.json"),
        "env": jload(STATE / "env_probe.json"),
        "agents": jload(STATE / "agents_status.json"),
        "ledger": jload(STATE / "library_ledger.json"),
        "maint": jload(STATE / "maintenance.json"),
        "tasks": jload(STATE / "season_tasks.json"),
        "registry": jload(MEM / "scripts" / "registry.json"),
        "gate": jload(STATE / "boot_gate.json"),
        "timr": jload(STATE / "timr.json"),
        "hostspeed": jload(STATE / "host_speed.json"),
        "steps": jload(STATE / "task_steps.json"),
        "prov": jload(MEM / "index" / "provider.json"),
        "pill_summary": jload(STATE / "pill_consumption.json"),
        "backup_retention": jload(STATE / "backup_retention.json"),
        "backups_mb": round(sum(f.stat().st_size for f in (MEM / "backups").rglob("*") if f.is_file()) / 1048576.0, 1)
        if (MEM / "backups").is_dir() else 0,
        "chunks": jload(MEM / "index" / "chunks.json", []),
        "runs": jlines(STATE / "check_runs.jsonl"),
        "bills": jlines(MEM / "time" / "tasklog.jsonl"),
    }
    if not isinstance(d["chunks"], list) or not d["chunks"]:
        ch = jload(MEM / "index" / "clusters.json", [])
        if isinstance(ch, dict):
            ch = ch.get("chunks") or ch.get("items") or []
        d["chunks"] = ch if isinstance(ch, list) else []
    return d


def card_specs(d):
    """Every dashboard card as a data record; the same record feeds its own page."""
    specs = []
    b, e, c = d["boot"], d["env"], d["caps"]
    host = d["bootrec"].get("host") or {}
    net = c.get("network") or {}
    sh = c.get("shell") or {}
    reg = d["registry"].get("scripts", {})
    verified = sum(1 for v in reg.values() if str(v.get("status", "")).startswith("verified"))
    cand = sum(1 for v in reg.values() if v.get("status") == "candidate")
    gate = d["gate"].get("checks") or {}
    ledger = d["ledger"] if isinstance(d["ledger"], dict) else {}
    unread = sorted(k for k, v in ledger.items() if isinstance(v, dict) and v.get("status") == "unread")
    consumed = sum(1 for v in ledger.values() if isinstance(v, dict) and v.get("status") in ("consumed", "verified", "verified-in-use"))
    maint = d["maint"] if isinstance(d["maint"], dict) else {}
    timr = d["timr"] if isinstance(d["timr"], dict) else {}
    hs = d["hostspeed"] if isinstance(d["hostspeed"], dict) else {}
    agents = d["agents"].get("providers") or {}

    def add(cid, title, dot, big, rows, section, full=False, small=False, sub=None, extra="", sources=None):
        specs.append({"id": cid, "title": title, "dot": dot, "big": big, "rows": rows, "section": section,
                      "full": full, "small": small, "sub": sub, "extra": extra,
                      "num": nid("card", cid), "sources": sources or []})

    add("boot", "BOOT / BIOS", "ok" if b.get("status") == "ready" else "warn",
        str(b.get("status", "?")).upper(),
        [("verified scripts", b.get("verified_scripts")), ("integrity gate", "PASS" if d["gate"].get("ok") else "FAIL"),
         ("profile", b.get("profile")), ("host", (b.get("host_application") or {}).get("id")),
         ("RAM source", (b.get("ram") or {}).get("source")), ("boot time", "%s ms" % b.get("boot_dur_ms")),
         ("boot runs", b.get("boot_runs")), ("ts", b.get("ts"))], "RUNTIME",
        sources=["state/boot_card.json", "state/boot_gate.json"])
    add("model", "MODEL (universal adapter)", "ok" if (b.get("model_name") or "n/a") != "n/a" else "warn",
        str(b.get("model_name") or "n/a"),
        [("host app", (b.get("host_application") or {}).get("id")), ("profile", b.get("profile")),
         ("profile status", b.get("profile_status")), ("brain (host session)", host.get("session_model")),
         ("env-probe model", (e.get("model") or {}).get("name")), ("max context", c.get("max_context") or "unresolved")],
        "RUNTIME", sources=["state/boot_card.json", "state/env_probe.json"])
    shell_txt = "+".join(k for k in ("pwsh", "git_bash") if sh.get(k)) or "?"
    add("env", "ENV / CAPABILITIES", "ok" if c.get("fs", {}).get("read") and net.get("ok") else "warn", "READY",
        [("fs r/w", "%s/%s" % (c.get("fs", {}).get("read"), c.get("fs", {}).get("write"))),
         ("shell", shell_txt + (" (%s default)" % sh.get("bash_default_dialect") if sh.get("bash_default_dialect") else "")),
         ("network", net.get("external_https")), ("studio port", net.get("studio_api_port")),
         ("embedding", "%s / %s" % ((c.get("embedding") or {}).get("backend"), "ready" if (c.get("embedding") or {}).get("configured") else "off")),
         ("probed", c.get("probed_at"))], "RUNTIME", sources=["state/capabilities.json"])
    add("hostspeed", "HOST SPEED (calibrated)", "ok" if hs.get("derived", {}).get("factor") else "warn",
        "~%s tok/s" % (hs.get("declared_gen_tok_s") or "?"),
        [("declared by", hs.get("declared_by")), ("declared at", hs.get("declared_at")),
         ("est factor", (hs.get("derived") or {}).get("factor")),
         ("samples", (hs.get("derived") or {}).get("samples")),
         ("host/model", "%s/%s" % ((hs.get("derived") or {}).get("host"), (hs.get("derived") or {}).get("model"))),
         ("refreshed", (hs.get("derived") or {}).get("last_refresh"))], "RUNTIME",
        sources=["state/host_speed.json"])
    last_run = d["runs"][-1] if d["runs"] else {}
    add("check", "SYSTEM CHECK", "ok" if last_run.get("status") == "PASS" else ("warn" if last_run.get("status") == "WARN" else "fail"),
        str(last_run.get("status", "?")).upper(),
        [("last run", last_run.get("ts")), ("age", age(last_run.get("ts"))), ("model", last_run.get("model")),
         ("gen avg/last", "%s / %s" % (last_run.get("gen_avg"), last_run.get("gen_last"))),
         ("prompt avg", last_run.get("prompt_avg")), ("vram", "%s%% / util %s" % (last_run.get("vram_pct"), last_run.get("vram_util")))],
        "SIGNALS", sources=["state/check_runs.jsonl"])
    add("speed", "PROMPT / GEN SPEED", "ok" if last_run else "warn", "%s tok/s" % (last_run.get("gen_avg", "?")),
        [("prompt avg/last", "%s / %s" % (last_run.get("prompt_avg"), last_run.get("prompt_last"))),
         ("gen avg/last", "%s / %s" % (last_run.get("gen_avg"), last_run.get("gen_last"))),
         ("data age", age(last_run.get("ts"))), ("net", "%ss" % last_run.get("net_s"))],
        "SIGNALS", sources=["state/check_runs.jsonl"])
    add("vram", "VRAM / THERMALS", "warn" if float(last_run.get("vram_pct") or 0) >= 90 else "ok",
        "%s%%" % (last_run.get("vram_pct", "?")),
        [("temp", "%sC" % last_run.get("vram_temp", "?")), ("util", "%s%%" % last_run.get("vram_util", "?")),
         ("data age", age(last_run.get("ts")))], "SIGNALS", sources=["state/check_runs.jsonl"])
    add("mismatch", "MISMATCH / EVOLUTION", "warn" if float(timr.get("rate") or 0) > 1 else "ok",
        str(timr.get("rate", "?")),
        [("window boots", timr.get("window_boots")), ("gate violations", (timr.get("counters") or {}).get("gate_violations")),
         ("boot failures", (timr.get("counters") or {}).get("boot_failures")),
         ("refreshed", timr.get("ts"))], "SIGNALS", sources=["state/timr.json"])
    add("gate", "BOOT GATE", "ok" if d["gate"].get("ok") else "fail", "PASS" if d["gate"].get("ok") else "FAIL",
        [(k, "ok" if v.get("ok") else "FAIL") for k, v in gate.items()] + [("duration", "%s ms" % d["gate"].get("dur_ms"))],
        "SIGNALS", sources=["state/boot_gate.json"])
    # Trust Layer v0 (2026-10-26): PQC device key + signed objects + Merkle transparency log.
    tkey = jload(STATE / "keys" / "device.json", {}) or {}
    theads = sorted((STATE / "trust_log" / "heads").glob("*.json")) if (STATE / "trust_log" / "heads").exists() else []
    thead = jload(theads[-1], {}) if theads else {}
    tevents = 0
    _ev = STATE / "trust_log" / "events.jsonl"
    if _ev.exists():
        tevents = sum(1 for line in _ev.read_text(encoding="utf-8").splitlines() if line.strip())
    tenv = len(list((STATE / "pills").glob("*.envelope.json"))) if (STATE / "pills").exists() else 0
    _troot = str(thead.get("root_hex") or "-")
    add("trust", "TRUST LAYER (PQC)", "ok" if (tkey.get("key_id") and thead) else "warn",
        str(tkey.get("alg") or "UNKEYED"),
        [("key id", tkey.get("key_id")), ("key sealed", tkey.get("sealed")),
         ("log events", tevents), ("signed heads", "%d/%d" % (sum(1 for h in theads if (jload(h, {}) or {}).get("signature")), len(theads))),
         ("head tree size", thead.get("tree_size")), ("head root", (_troot[:24] + "...") if len(_troot) > 24 else _troot),
         ("pill envelopes", tenv)],
        "AGENTS & TOOLS", sources=["state/keys/device.json", "state/trust_log/", "state/pills/"])
    # Passport v0 (P2): member credential rooted in the user genome.
    psp = jload(STATE / "passport.json", {}) or {}
    gtree = jload(STATE / "genome" / "tree.json", {}) or {}
    _tpath = STATE / "genome" / "transitions.jsonl"
    ttrans = sum(1 for line in _tpath.read_text(encoding="utf-8").splitlines() if line.strip()) if _tpath.exists() else 0
    _proot = str(psp.get("user_genome_root") or "-")
    _caps = psp.get("capabilities") or {}
    add("passport", "PASSPORT / GENOME (L1)", "ok" if (psp and (STATE / "passport.json.sig").exists()) else "warn",
        str(psp.get("bundle_class") or "NONE").upper(),
        [("member", psp.get("member")), ("passport id", str(psp.get("passport_id"))[:8] + "..." if psp else None),
         ("generation", (psp.get("generation") or {}).get("gen")),
         ("genome epoch", psp.get("genome_epoch")),
         ("genome root", (_proot[:24] + "...") if len(_proot) > 24 else _proot),
         ("genome entries", gtree.get("leaf_count")), ("signed transitions", ttrans),
         ("activation", (psp.get("activation") or {}).get("state")),
         ("device key", (psp.get("device") or {}).get("key_id")),
         ("can reproduce", _caps.get("can_reproduce"))],
        "AGENTS & TOOLS", sources=["state/passport.json", "state/genome/"])
    # Bundle lattice (P3): master / official / custom manifests + policy.
    bdir = STATE / "bundles"
    bactive = (jload(bdir / "active.json", {}) or {}).get("active")
    bman = jload(bdir / f"{bactive}.json", {}) if bactive else {}
    bfiles = sorted(p for p in bdir.glob("*.json") if p.name != "active.json") if bdir.exists() else []
    _bcap = bman.get("capabilities") or {}
    add("bundles", "BUNDLE LATTICE (L2/L3)", "ok" if bman else "warn",
        str(bman.get("class") or "NONE").upper(),
        [("active bundle", bactive), ("class", bman.get("class")),
         ("genome mode", (bman.get("genome") or {}).get("mode")),
         ("core version", (bman.get("generation") or {}).get("core_version")),
         ("can reproduce", _bcap.get("can_reproduce")),
         ("can issue", ", ".join(_bcap.get("can_issue") or []) or "-"),
         ("pill genomes", ", ".join((bman.get("pill_policy") or {}).get("accept_genomes") or []) or "-"),
         ("issuer", (bman.get("issuer") or {}).get("kind")),
         ("manifests", len(bfiles))],
        "AGENTS & TOOLS", sources=["state/bundles/"])
    # Activation (P4): root ceremony + attestations + trust level.
    rrec = jload(STATE / "keys" / "root.json", {}) or {}
    adir = STATE / "activation"
    aatts = sorted((adir / "attestations").glob("*.json")) if (adir / "attestations").exists() else []
    alatest = jload(aatts[-1], {}) if aatts else {}
    ahb = jload(adir / "heartbeat.json", {}) or {}
    _alevel = "U2" if ahb else ("U1" if aatts else "U0")
    add("activation", "ACTIVATION / D-TOUCH (L1.5)", "ok" if (rrec and aatts) else "warn", _alevel,
        [("root key", rrec.get("alg")), ("root key id", rrec.get("root_key_id")),
         ("threshold", ("%s-of-%s" % (rrec["threshold"]["k"], rrec["threshold"]["n"])) if rrec.get("threshold") else None),
         ("shards", len(rrec.get("shards") or [])), ("attestations", len(aatts)),
         ("latest", alatest.get("attestation_id")), ("scope", alatest.get("scope")),
         ("expires", alatest.get("not_after")), ("heartbeat", ahb.get("issued_at"))],
        "AGENTS & TOOLS", sources=["state/keys/root.json", "state/activation/"])
    # Public relay (P5): mirror + contributions + reputation.
    pman = jload(STATE / "public" / "mirror" / "manifest.json", {}) or {}
    pimp = len(list((STATE / "public" / "imported").glob("*.json"))) if (STATE / "public" / "imported").exists() else 0
    pmer = ((jload(STATE / "public" / "merged.json", {}) or {}).get("pills") or {})
    deps = STATE / "contributions"
    pcon = len([x for x in deps.glob("*.json") if not x.name.endswith("endorsement.json")]) if deps.exists() else 0
    pend = len(list(deps.glob("*.endorsement.json"))) if deps.exists() else 0
    preps = ((jload(STATE / "public" / "contributors.json", {}) or {}).get("contributors") or {})
    _phead = pman.get("head") or {}
    add("public", "*.PUBLIC RELAY (P5)", "ok" if pman else "warn",
        str(len(pman.get("pills") or [])),
        [("mirror pills", len(pman.get("pills") or [])), ("mirror head size", _phead.get("tree_size")),
         ("exporter key", (pman.get("exporter") or {}).get("key_id")),
         ("imported pills", pimp), ("contributions", pcon),
         ("D endorsements", pend), ("merged pills", len(pmer)), ("contributors", len(preps))],
        "AGENTS & TOOLS", sources=["state/public/", "state/contributions/"])
    # Federation + release (P6/P7).
    fpeers = (jload(STATE / "public" / "peers.json", {}) or {}).get("peers") or {}
    frel = (jload(STATE / "release" / "index.json", {}) or {}).get("packages") or []
    falerts = [u for u, v in fpeers.items() if v.get("alerts")]
    add("relay", "FEDERATION / RELEASE (P6-P7)", "fail" if falerts else ("ok" if (fpeers or frel) else "warn"),
        str(len(frel)),
        [("peers", len(fpeers)), ("peer alerts", len(falerts)), ("release packages", len(frel)),
         ("last package", (frel[-1].get("package") if frel else None)),
         ("last package bytes", (frel[-1].get("bytes") if frel else None))],
        "AGENTS & TOOLS", sources=["state/public/peers.json", "state/release/"])
    # Official repo + install role (corrected model).
    rman = jload(STATE / "repo" / "AGI" / "repo.json", {}) or {}
    rpool = jload(STATE / "repo" / "AGI" / "pool" / "index.json", {}) or {}
    rinst = jload(STATE / "install.json", {}) or {}
    add("install", "OFFICIAL REPO / INSTALL (P8)", "ok" if rman else "warn",
        str(rinst.get("role") or "-").upper(),
        [("repo", "AGI" if rman else "not initialised"),
         ("distributed bundle", (rman.get("official") or {}).get("bundle_id")),
         ("bundle class", (rman.get("official") or {}).get("class")),
         ("pool pills", len(rpool.get("pills") or [])),
         ("install role", rinst.get("role")),
         ("role bundle", (rinst.get("bundle") or {}).get("id")),
         ("activation", (rinst.get("activation") or {}).get("level"))],
        "AGENTS & TOOLS", sources=["state/repo/AGI/", "state/install.json"])
    up = [k for k, v in agents.items() if isinstance(v, dict) and v.get("ok")]
    down = [k for k, v in agents.items() if not (isinstance(v, dict) and v.get("ok"))]
    add("agents", "AGENT POOL", "ok" if up else "warn", "%d/%d" % (len(up), len(agents)),
        [("up", ", ".join(up) or "-"), ("down", ", ".join(down) or "-"),
         ("snapshot", (c.get("subagents") or {}).get("snapshot_ts")),
         ("stale", (c.get("subagents") or {}).get("stale"))], "AGENTS & TOOLS")
    add("registry", "SCRIPT REGISTRY", "ok" if verified else "warn", str(verified),
        [("verified", "%d/%d" % (verified, len(reg))), ("candidate", cand),
         ("conformance", "PASS (boot gate)" if (gate.get("conformance_quick") or {}).get("ok") else "see boot gate"),
         ("registry", "memory/scripts/registry.json")], "AGENTS & TOOLS",
        sources=["memory/scripts/registry.json", "state/boot_gate.json"])
    add("core", "ADOPTED: AGI CORE", "ok", "GEN3",
        [("core_version", jload(AGI / "core_manifest.json").get("core_version")),
         ("dna_version", jload(AGI / "core_manifest.json").get("dna_version")),
         ("bundle", jload(AGI / "core_manifest.json").get("bundle_name")), ("status", "verified")],
        "AGENTS & TOOLS", sources=["core_manifest.json"])
    chrome_snap = agents.get("deepseek-browser") or {}
    add("plug-chrome", "PLUG: CHROME-MCP", "fail" if not chrome_snap.get("ok") else "ok",
        "DOWN" if not chrome_snap.get("ok") else "UP",
        [("detail", "deepseek-browser, kilo, pollinations" if not chrome_snap.get("ok") else "connected"),
         ("note", "3D/viewport bridge")], "AGENTS & TOOLS")
    add("plug-blender", "PLUG: MCP BLENDER", "ok", "EXT",
        [("type", "external MCP"), ("note", "3D viewport tools")], "AGENTS & TOOLS")
    add("plug-docs", "PLUG: MCP UNSLOTH DOCS", "ok", "EXT",
        [("type", "external MCP"), ("note", "search / getPage / ask")], "AGENTS & TOOLS")
    add("plug-hf", "PLUG: MCP HUGGINGFACE", "ok", "EXT",
        [("type", "external MCP"), ("note", "hub / fs / repo tools")], "AGENTS & TOOLS")
    add("plug-context7", "PLUG: MCP CONTEXT7", "ok", "EXT",
        [("type", "external MCP"), ("note", "external library docs")], "AGENTS & TOOLS")
    add("studio", "STUDIO API", "ok" if net.get("studio_http") == 200 else "warn",
        "up" if net.get("studio_http") == 200 else "?",
        [("port", net.get("studio_api_port")), ("http", net.get("studio_http")),
         ("note", "fastapi auth-gated")], "AGENTS & TOOLS", sources=["state/capabilities.json"])
    add("browser-tools", "BROWSER / HOST TOOLS", "ok", "LIVE",
        [("type", "studio built-in"), ("note", "navigate / type / drag / evaluate"),
         ("flags", "-H / --cloudflare")], "AGENTS & TOOLS")
    add("rag", "MEMORY / RAG", "warn" if unread else "ok", "%s chunks" % ((d["prov"] or {}).get("chunks") or 0),
        [("dimensions", (d["prov"] or {}).get("dimensions")), ("backend", (d["prov"] or {}).get("backend")),
         ("index built", str((d["prov"] or {}).get("generated", ""))[:19]),
         ("library unread", len(unread)), ("consumed docs", consumed)], "MEMORY & CACHE",
        sources=["memory/index/provider.json"])
    add("library", "KNOWLEDGE LIBRARY", "warn" if unread else "ok", str(len(ledger)),
        [("total", len(ledger)), ("new/unread", len(unread)), ("consumed", consumed),
         ("unread list", ", ".join(unread) or "-")], "MEMORY & CACHE", sources=["state/library_ledger.json"])
    man = jload(SITE.parent / "manifest.json") if SITE else {}
    add("cache", "CACHE CLUSTER (RAM)", "ok", str(man.get("version") or "RAM"),
        [("version", man.get("version")), ("season", (d["tasks"] or {}).get("season")),
         ("ram", (b.get("ram") or {}).get("root")), ("resolver", (b.get("ram") or {}).get("source"))],
        "MEMORY & CACHE")
    bills = [x for x in d["bills"] if x.get("bill_status") == "active"]
    last = d["bills"][-1] if d["bills"] else {}
    pills = d.get("pill_summary") or {}
    p_consumed = sum(1 for v in pills.values() if isinstance(v, dict) and v.get("status") == "consumed")
    p_pending = [k for k, v in pills.items() if isinstance(v, dict) and v.get("status") in ("pending", "failed")]
    add("taskbill", "TASKBILL", "warn" if bills else "ok", "%d OPEN" % len(bills),
        [("open bills", len(bills)), ("last bill", last.get("task")),
         ("last actual/est", ("%ss/%ss" % (last.get("actual_s"), last.get("est_s"))) if last and last.get("actual_s") else (("-/%ss" % last.get("est_s")) if last else "-")),
         ("host factor", ((d["hostspeed"] or {}).get("derived") or {}).get("factor")),
         ("pills consumed", "%d/%d" % (p_consumed, len(pills))),
         ("pills pending", ", ".join(p_pending) if p_pending else "none"),
         ("backups", "%s MB \u00b7 %s" % (round(d.get("backups_mb") or 0, 1),
                                            "retention applied " + str((d.get("backup_retention") or {}).get("ts") or "")[:10]
                                            if (d.get("backup_retention") or {}).get("ts") else "policy pending")),
         ("log", "memory/time/tasklog.jsonl")],
        "WORK & SYSTEM", sources=["memory/time/tasklog.jsonl", "state/host_speed.json"])
    add("system", "AGI SYSTEM DASHBOARD", "ok", "OPEN",
        [("contents", "subsystem cards + maintenance ledger"), ("source", "state/cards + state/maintenance.json")],
        "WORK & SYSTEM")
    return specs


# ---------------------------------------------------------------- page builders
def build_dashboard(d, specs):
    body = [_header(d, "dashboard")]
    body.append(_ready_label("RUNTIME"))
    body.append("<div class='grid'>%s</div>" % "".join(card_html(s) for s in specs if s["section"] == "RUNTIME"))
    body.append(_ready_label("SIGNALS"))
    body.append("<div class='grid'>%s</div>" % "".join(card_html(s) for s in specs if s["section"] == "SIGNALS"))
    body.append(_ready_label("AGENTS & TOOLS"))
    body.append("<div class='grid'>%s</div>" % "".join(card_html(s) for s in specs if s["section"] == "AGENTS & TOOLS"))
    body.append(_ready_label("MEMORY & CACHE"))
    body.append("<div class='grid'>%s</div>" % "".join(card_html(s) for s in specs if s["section"] == "MEMORY & CACHE"))
    body.append(_ready_label("WORK & SYSTEM"))
    body.append("<div class='grid'>%s</div>" % "".join(card_html(s) for s in specs if s["section"] == "WORK & SYSTEM"))
    body.append(_maintenance_section(d))
    body.append(_tasks_sections(d))
    body.append(_ready_label("PERFORMANCE"))
    body.append(_perf_section(d))
    body.append(_ready_label("SYSTEM HEAT"))
    body.append(_heat_section(d))
    body.append("<div class='foot'>AGI LIVE DASHBOARD v3 · GitHub UI design system · every card opens its own page "
                "· site generated %s · sources: state/ + memory/</div>" % time.strftime("%Y-%m-%d %H:%M:%S"))
    return _page("AGI · Dashboard", "".join(body))


def build_card_page(d, spec, kind="card"):
    cid = spec["id"]
    rows = "".join("<tr><td class='muted' style='width:220px'>%s</td><td>%s</td></tr>" % (esc(k), esc(v))
                   for k, v in spec.get("rows", []) if v not in (None, ""))
    sources = "".join("<li class='mono'>%s</li>" % esc(s) for s in spec.get("sources", []))
    body = ("<div class='breadcrumb'><a href='/'>&larr; dashboard</a> / %s</div>%s"
            "<div class='card full'><div class='label'><span class='dot %s'></span>"
            "<span class='nid'>%s</span><span>%s</span></div><div class='big'>%s</div>"
            "<table>%s</table>%s</div>"
            "<div class='card full'><div class='label'>PROVENANCE</div>"
            "<ul class='li'>%s<li>category: %s</li><li>page: /cards/%s.html</li></ul></div>"
            % ("<span class='mono'>" + esc(cid) + "</span>", _header(d, "dashboard"),
               esc(spec.get("dot") or "ok"), esc(spec.get("num") or ""), esc(spec.get("title") or cid),
               esc(spec.get("big", "")), rows, spec.get("extra") or "",
               sources or "<li>derived from dashboard state</li>", esc(spec.get("section")), esc(cid)))
    return _page("AGI · %s" % spec.get("title", cid), body)


def build_task_page(d, t):
    cid = "task-" + str(t.get("id") or "task")
    spec = {"id": cid, "title": t.get("title") or cid, "num": t.get("num") or nid("task", t.get("id", "")),
            "dot": "ok" if str(t.get("status")).lower() in ("done", "closed") else "warn",
            "big": str(t.get("status", "")).upper(), "section": "TASKS",
            "rows": [("id", t.get("id")), ("status", t.get("status")), ("opened", t.get("opened")),
                     ("closed", t.get("closed")), ("bill", t.get("bill_task")), ("confidence", t.get("conf")),
                     ("checkpoints", "\n".join("%s %s" % (c.get("ts"), c.get("note")) for c in (t.get("checkpoints") or []))),
                     ("pills", "; ".join(t.get("pills") or [])),
                     ("pill lifecycle", ((d.get("pill_summary") or {}).get("task:" + str(t.get("bill_task"))) or {}).get("status") or "not consumed")],
            "sources": ["state/season_tasks.json"]}
    return build_card_page(d, spec)


def build_system_page(d, specs):
    b = d["boot"]
    maint = d["maint"] if isinstance(d["maint"], dict) else {}
    open_items = maint.get("open") or []
    parked = maint.get("parked_tasks") or []
    fixed = maint.get("fixed") or []
    body = [_header(d, "system")]
    body.append("<div class='breadcrumb'><a href='/'>&larr; dashboard</a> / AGI system dashboard</div>")
    body.append("<div class='grid'>%s</div>" % card_html(
        {"id": "system-boot", "title": "BIOS / BOOT", "num": nid("card", "system-boot"),
         "dot": "ok" if b.get("status") == "ready" else "warn", "big": str(b.get("status", "?")).upper(),
         "rows": [("verified scripts", b.get("verified_scripts")), ("ts", b.get("ts")),
                  ("gate", "PASS" if d["gate"].get("ok") else "FAIL"), ("issues", len(b.get("issues") or []))]},
        link=False))
    body.append("<div class='grid'>%s</div>" % card_html(
        {"id": "system-maint", "title": "MAINTENANCE DASHBOARD", "num": nid("card", "system-maint"),
         "dot": "warn" if open_items or parked else "ok",
         "big": "%d open · %d parked" % (len(open_items), len(parked)),
         "rows": [("open", "; ".join(open_items)), ("recently fixed", len(fixed)),
                  ("link", "/maintenance")]}, link=False))
    body.append(_ready_label("SUBSYSTEM CARDS"))
    body.append("<div class='grid'>%s</div>" % "".join(card_html(s) for s in specs))
    body.append(_ready_label("MAINTENANCE LEDGER - OPEN"))
    body.append("<div class='card full'><ul class='li'>%s</ul></div>"
                % "".join("<li>%s</li>" % esc(x) for x in open_items) if open_items
                else "<div class='card full'><span class='muted'>no open items</span></div>")
    body.append(_ready_label("MAINTENANCE LEDGER - PARKED"))
    body.append("<div class='card full'><ul class='li'>%s</ul></div>"
                % "".join("<li>%s</li>" % esc(x) for x in parked) if parked
                else "<div class='card full'><span class='muted'>nothing parked</span></div>")
    body.append(_ready_label("MAINTENANCE LEDGER - RECENTLY FIXED"))
    body.append("<div class='card full'><ul class='li'>%s</ul></div>"
                % "".join("<li><span class='mono'>%s</span> %s</li>" % (esc(f.get("ts")), esc(f.get("item")))
                          for f in fixed[-12:]))
    body.append("<div class='foot'>AGI SYSTEM DASHBOARD · generated %s</div>" % time.strftime("%Y-%m-%d %H:%M:%S"))
    return _page("AGI · System dashboard", "".join(body))


def build_maintenance_page(d):
    maint = d["maint"] if isinstance(d["maint"], dict) else {}
    open_items = maint.get("open") or []
    parked = maint.get("parked_tasks") or []
    fixed = maint.get("fixed") or []
    body = [_header(d, "maintenance")]
    body.append("<div class='breadcrumb'><a href='/'>&larr; dashboard</a> / <a href='/system'>system</a> / maintenance</div>")
    specs = _maint_specs(d)
    def grid(kind):
        items = [x for x in specs if x["kind"] == kind]
        return "".join(card_html(x) for x in items) or "<div class='card mini'><span class='muted'>none</span></div>"
    body.append("<div class='breadcrumb'><a href='/'>dashboard</a> / <a href='/system'>system</a> / "
                "<span class='mono'>maintenance dashboard</span></div>")
    body.append("<div class='grid'>%s</div>" % card_html(
        {"id": "maint-summary", "title": "MAINTENANCE DASHBOARD", "num": nid("card", "maint-summary"),
         "dot": "warn" if (open_items or parked) else "ok",
         "big": "%d open · %d parked · %d fixed" % (len(open_items), len(parked), len(fixed)),
         "rows": [("source", "state/maintenance.json"), ("part of", "AGI system"),
                  ("task cards", "every item is a task card")]}, link=False))
    season = _season_pointer(d)
    if season:
        body.append(_ready_label("SEASON STATUS - NOT A MAINTENANCE TASK"))
        body.append("<div class='card full mini'><span class='nm' style='font-size:13px'>%s</span></div>"
                    % esc(season))
    body.append(_ready_label("OPEN - ACTIVE MAINTENANCE TASKS"))
    body.append("<div class='grid'>%s</div>" % grid("open"))
    body.append(_ready_label("PARKED CARRY-OVER TASKS"))
    body.append("<div class='grid four'>%s</div>" % grid("parked"))
    body.append(_ready_label("FIXED - COMPLETED MAINTENANCE TASKS"))
    body.append("<div class='grid'>%s</div>" % "".join(card_html(x) for x in reversed([x for x in specs if x["kind"] == "fixed"])))
    body.append("<div class='foot'><a href='/system'>&larr; AGI system dashboard</a> · "
                "<a href='/'>dashboard</a></div>")
    return _page("AGI · Maintenance dashboard", "".join(body))


# ---------------------------------------------------------------- entry point
def build_inbox_page(d):
    """Inbox: pending decisions, queued actions and recently settled decisions as unified cards."""
    st = d["steps"] if isinstance(d["steps"], dict) else {}
    acts = []
    try:
        acts = [json.loads(l) for l in (AGI / "state" / "taskboard_actions.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    except Exception:
        acts = []
    try:
        cursor = int(json.loads((AGI / "state" / "taskboard_actions_cursor.json").read_text(encoding="utf-8")).get("last") or 0)
    except Exception:
        cursor = 0
    pending = [a for a in acts if int(a.get("n") or 0) > cursor]
    settled = [a for a in acts if int(a.get("n") or 0) <= cursor][-8:]
    body = [_header(d, "inbox")]
    body.append("<div class='breadcrumb'><a href='/'>&larr; dashboard</a> / inbox</div>")
    body.append(_ready_label("PENDING DECISIONS"))
    if st.get("mode") == "proposal" and st.get("task_id"):
        body.append("<div class='grid'>%s</div>" % card_html(
            {"id": "inbox-proposal", "title": st.get("title") or st.get("task_id"),
             "num": nid("task", st.get("task_id")),
             "dot": "warn", "big": "AWAITING APPROVAL",
             "rows": [("task", st.get("task_id")), ("estimate", fmt_s(st.get("estimate_s"))),
                      ("steps", len(st.get("steps") or [])), ("action", "open the proposal card -> /board")]},
            link=False))
        body.append("<div style='margin-top:8px'><a class='btn primary' href='/board'>Open the proposal card</a></div>")
    elif pending:
        body.append("<div class='grid'>%s</div>" % "".join(
            "<div class='card mini'><div class='label'>%s</div><div class='nm'>%s</div>"
            "<div class='cardfoot'>queued %s</div></div>"
            % (esc("#%s" % a.get("n")), esc(a.get("type")), esc(a.get("ts"))) for a in pending))
    else:
        body.append("<div class='card mini'><span class='muted'>no pending decisions</span></div>")
    body.append(_ready_label("RECENTLY SETTLED"))
    if settled:
        body.append("<div class='grid'>%s</div>" % "".join(
            "<div class='card mini'><div class='label'>%s</div><div class='nm'>%s</div>"
            "<div class='cardfoot'>%s · consumed through #%d</div></div>"
            % (esc("#%s" % a.get("n")), esc(a.get("type")), esc(a.get("ts")), cursor) for a in reversed(settled)))
    else:
        body.append("<div class='card mini'><span class='muted'>nothing settled yet</span></div>")
    body.append("<div class='foot'>inbox reads state/task_steps.json + state/taskboard_actions.jsonl "
                "(decisions consumed through #%d)</div>" % cursor)
    return _page("AGI · Inbox", "".join(body))



def build_login(d=None):
    """Cold-boot login: three doors - default user, custom user/organization, admin.

    The page is a projection of state/: it shows the true session, the admin factor and the workspace,
    and the exact commands. Three doors, matching the identity/bundle model:
      1 default user  - anonymous profile, no authority;
      2 custom user   - personal profile or a workspace created/adopted during setup;
      3 admin login   - enrolled machine: device key; unknown machine: the memorised admin phrase.
    """
    prof = jload(STATE / "identity" / "profiles.json", {}) or {}
    sess = jload(STATE / "identity" / "session.json", {}) or {}
    active = (prof.get("profiles") or {}).get(sess.get("profile") or "", {}) if sess.get("active") else {}
    admin = jload(STATE / "identity" / "admin.json", {}) or {}
    enrolled = jload(STATE / "identity" / "enrolled.json", {}) or {}
    ws = jload(STATE / "workspace.json", {}) or {}

    def row(k, v, cmd=None):
        val = esc(v) if v not in (None, "") else "-"
        if cmd:
            return ("<div class='row'><span>%s</span><em>%s</em></div>" % (esc(k), esc(cmd)))
        return "<div class='row'><span>%s</span><em>%s</em></div>" % (esc(k), val)

    session_rows = [row("signed in as", active.get("name") or "nobody"),
                    row("level", sess.get("level") if sess.get("active") else "-"),
                    row("expires", sess.get("expires") if sess.get("active") else "-"),
                    row("device key", active.get("device_key_id")),
                    row("machine enrolled", "yes (" + str(enrolled.get("host")) + ")" if enrolled.get("enrolled_at") else "no"),
                    row("admin factor", "%d-word phrase" % admin.get("words") if admin.get("schema") else "not set up")]
    body = []
    body.append("<div class='sect'><h2>AGI LOGIN</h2></div>")
    body.append("<div class='card full'><div class='label'>SESSION</div>"
                + "".join(session_rows)
                + "<div class='cardfoot'>no password: presence is proved locally (device key), "
                  "organisation setups carry a workspace, the admin door carries the phrase.</div></div>")

    body.append("<div class='sect'><h2>1 · DEFAULT USER</h2></div><div class='card full'>"
                + row("use AGI anonymously", "no identity, no authority; a usable workspace for anyone")
                + row("command", "", "python memory/scripts/identity.py skip")
                + row("workspace", ws.get("name") or "none yet - the default profile works without one")
                + "</div>")

    body.append("<div class='sect'><h2>2 · CUSTOM USER / ORGANIZATION</h2></div><div class='card full'>"
                + row("personal profile", "a named member profile on this machine",
                      "python memory/scripts/identity.py create --name &lt;you&gt;")
                + row("workspace setup", "created/adopted during setup - AGI interviews you, classifies the "
                      "place, proposes policies and task presets, you confirm",
                      "python memory/scripts/workspace.py init")
                + row("current workspace", ws.get("name") or "not created yet")
                + row("sign in with that profile", "", "python memory/scripts/identity.py login --profile &lt;id&gt;")
                + "</div>")

    member = admin.get("member") or ""
    default_blob = ("https://raw.githubusercontent.com/Megasolid/AGI/main/recovery/%s.json" % member
                    if member else "")
    enrolled_row = ""
    if enrolled.get("enrolled_at"):
        enrolled_row = row("this machine is enrolled", "device key login, no phrase typing",
                           "python memory/scripts/identity.py login --profile " + str(active.get("profile_id")))
    restore_form = (
        "<div class='row'><span>restore with the admin phrase</span><em>type it here - it never leaves this "
        "machine and is never logged</em></div>"
        "<div style='padding:6px 10px'><input id='blobUrl' type='text' style='width:100%' value='" + default_blob
        + "' placeholder='recovery blob URL or path'></div>"
        "<div style='padding:6px 10px'><input id='phraseIn' type='password' autocomplete='off' "
        "style='width:100%' placeholder='six-word admin phrase'></div>"
        "<div style='padding:6px 10px'><label class='nm'><input id='tempAck' type='checkbox'> "
        "temporary session on this machine (do not enrol; wipe before leaving)</label></div>"
        "<div style='padding:6px 10px'><button id='btnRestore' type='button'>Restore and enrol this machine</button>"
        " <span id='restoreMsg' class='nm'></span></div>")
    setup_form = (
        "<div class='row'><span>first setup (no phrase exists yet)</span><em>AGI generates six words and shows "
        "them once; it never stores them</em></div>"
        "<div style='padding:6px 10px'><button id='btnSetup' type='button'>Create admin phrase</button>"
        " <span id='setupMsg' class='nm'></span></div>"
        "<pre id='phraseOut' style='display:none;padding:10px;background:var(--inset);border:1px solid "
        "var(--line);margin:8px 10px;white-space:pre-wrap'></pre>"
        "<div id='afterSetup' style='display:none;padding:6px 10px'>"
        "<label class='nm'><input id='ack' type='checkbox'> I have written or memorised the phrase</label><br>"
        "<input id='trainIn' type='password' autocomplete='off' style='width:60%%' "
        "placeholder='type the six words to verify'> <button id='btnTrain' type='button'>Verify</button>"
        " <button id='btnPublish' type='button'>Publish ciphertext</button>"
        " <span id='trainMsg' class='nm'></span></div>")
    temp = jload(STATE / "identity" / "temp_session.json", {}) or {}
    temp_banner = ""
    if temp.get("started"):
        temp_banner = ("<div class='card full'><div class='label'>TEMPORARY SESSION</div>"
                       + row("started", temp.get("started"))
                       + row("host", temp.get("host"))
                       + "<div style='padding:6px 10px'><button id='btnWipe' type='button'>"
                         "Wipe identity from this machine</button> <span id='wipeMsg' class='nm'></span></div>"
                       + "<div class='cardfoot'>this machine was not enrolled; wipe removes the restored key, "
                         "passport, genome and recovery blob and leaves the default profile.</div></div>")
    rotate_form = ""
    if admin.get("schema"):
        rotate_form = (
            "<div class='row'><span>rotate the phrase</span><em>needs the current phrase; the new one is shown "
            "once and the old one dies</em></div>"
            "<div style='padding:6px 10px'><input id='rotIn' type='password' autocomplete='off' style='width:60%' "
            "placeholder='current six-word phrase'> <button id='btnRotate' type='button'>Rotate</button>"
            " <span id='rotMsg' class='nm'></span></div>"
            "<pre id='rotOut' style='display:none;padding:10px;background:var(--inset);border:1px solid "
            "var(--line);margin:8px 10px;white-space:pre-wrap'></pre>"
            "<div id='afterRot' style='display:none;padding:6px 10px'><button id='btnRotPublish' type='button'>"
            "Publish the new ciphertext</button> <span id='rotPubMsg' class='nm'></span></div>")
    admin_block = (temp_banner + enrolled_row
                   + (restore_form if admin.get("schema") else setup_form)
                   + rotate_form
                   + row("root authority", "login is a session (U1); master/U3 still needs the D-touch 2-of-3 "
                         "shards", "python memory/scripts/activation.py status"))

    admin_js = """<script>
(function(){
  const H = {'Content-Type':'application/json','X-AGI-UI':'1'};
  const $ = (id) => document.getElementById(id);
  async function post(url, body){
    const r = await fetch(url, {method:'POST', headers:H, body:JSON.stringify(body)});
    let d = {}; try { d = await r.json(); } catch(e) {}
    return {status:r.status, d};
  }
  const setupBtn = $('btnSetup');
  if (setupBtn) setupBtn.onclick = async () => {
    $('setupMsg').textContent = 'generating...';
    const {status, d} = await post('/api/admin/setup', {confirm:true});
    if (d.phrase) {
      $('phraseOut').textContent = d.phrase;
      $('phraseOut').style.display = 'block';
      $('setupMsg').textContent = 'shown once - write it down or memorise it now';
      $('afterSetup').style.display = 'block';
    } else {
      $('setupMsg').textContent = d.error || ('failed (' + status + ')');
    }
  };
  const ack = $('ack');
  if (ack) ack.onchange = () => {
    const on = ack.checked;
    if ($('phraseOut')) $('phraseOut').style.display = on ? 'none' : 'block';
    if (on) $('phraseOut').textContent = 'phrase hidden (typed input still works)';
  };
  const trainBtn = $('btnTrain');
  if (trainBtn) trainBtn.onclick = async () => {
    const {status, d} = await post('/api/admin/train', {phrase:($('trainIn')||{}).value || ''});
    $('trainMsg').textContent = d.ok ? 'verified: it decrypts your profile' : (d.reason || 'not verified');
  };
  const pubBtn = $('btnPublish');
  if (pubBtn) pubBtn.onclick = async () => {
    const {status, d} = await post('/api/admin/publish', {push:false});
    $('trainMsg').textContent = d.ok ? ('ciphertext written: ' + d.path) : ('publish failed: ' + (d.error || status));
  };
  const resBtn = $('btnRestore');
  if (resBtn) resBtn.onclick = async () => {
    $('restoreMsg').textContent = 'restoring...';
    const temp = !!($('tempAck') && $('tempAck').checked);
    const {status, d} = await post('/api/admin/restore', {blob:$('blobUrl').value, phrase:$('phraseIn').value,
                                                          temp:temp});
    $('restoreMsg').textContent = d.ok ? ('restored profile ' + d.profile_id + (d.temporary ? ' (temporary)' : '') + ' — reloading')
                                       : ('failed: ' + (d.error || d.reason || status));
    if (d.ok) { $('phraseIn').value = ''; setTimeout(() => location.reload(), 900); }
  };
  const rotBtn = $('btnRotate');
  if (rotBtn) rotBtn.onclick = async () => {
    $('rotMsg').textContent = 'rotating...';
    const {status, d} = await post('/api/admin/rotate', {phrase:($('rotIn')||{}).value || ''});
    if (d.phrase) {
      $('rotOut').textContent = d.phrase; $('rotOut').style.display = 'block';
      $('rotMsg').textContent = 'new phrase shown once - write it down; old phrase is dead';
      $('afterRot').style.display = 'block';
    } else { $('rotMsg').textContent = d.error || ('failed (' + status + ')'); }
  };
  const rotPub = $('btnRotPublish');
  if (rotPub) rotPub.onclick = async () => {
    const {status, d} = await post('/api/admin/publish', {push:false});
    $('rotPubMsg').textContent = d.ok ? ('published: ' + d.path) : ('publish failed: ' + (d.error || status));
  };
  const wipeBtn = $('btnWipe');
  if (wipeBtn) wipeBtn.onclick = async () => {
    if (!confirm('Remove the restored identity material from this machine?')) return;
    const {status, d} = await post('/api/admin/wipe', {confirm:true});
    $('wipeMsg').textContent = d.ok ? 'wiped' : ('failed: ' + (d.error || status));
    if (d.ok) setTimeout(() => location.reload(), 900);
  };
})();
</script>"""
    body.append("<div class='sect'><h2>3 · ADMIN LOGIN</h2></div><div class='card full'>"
                + admin_block
                + "<div class='cardfoot'>the phrase is the only thing to remember, and it doubles as the "
                  "recovery kit: it decrypts your profile snapshot from the public repository. Nothing is "
                  "stored on the machine until you enrol it. The browser sends it only to this local "
                  "runtime (127.0.0.1) and the runtime never logs it.</div></div>")
    body.append(admin_js)

    body.append("<div class='sect'><h2></h2></div><div class='card full mini'><span class='label'>"
                "THE RULE</span> <span class='nm'>no unnecessary friction: default and custom doors never ask "
                "for a secret; only the admin door does, and only on a machine that has not been enrolled.</span></div>")
    return _page("AGI · Login", "".join(body))



def generate(verbose=True):
    """Generate the whole site into <RAM>/site. Returns a summary dict."""
    global SITE
    sys.path.insert(0, str(MEM / "scripts"))
    import cardkit
    cache = Path(os.path.dirname(cardkit.sandbox_cache()))
    SITE = cache / "site"
    cards_dir = SITE / "cards"
    cards_dir.mkdir(parents=True, exist_ok=True)
    d = load_data()
    specs = card_specs(d)
    written = []

    def put(rel, html):
        p = SITE / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(html, encoding="utf-8")
        written.append((rel, len(html)))

    put("index.html", build_dashboard(d, specs))
    put("login.html", build_login(d))
    for s in specs:
        put("cards/%s.html" % s["id"], build_card_page(d, s))
    for t in (d["tasks"].get("archive") or []):
        if isinstance(t, dict):
            t["num"] = nid("task", t.get("id", ""))
            put("cards/task-%s.html" % t.get("id"), build_task_page(d, t))
    st = d["steps"]
    if st.get("task_id"):
        t = {"id": st.get("task_id"), "title": st.get("title"), "status": "running",
             "bill_task": st.get("bill_task"), "conf": "", "opened": st.get("started"),
             "num": nid("task", st.get("task_id")), "checkpoints": [], "pills": []}
        put("cards/task-%s.html" % st.get("task_id"), build_task_page(d, t))
    put("system.html", build_system_page(d, specs))
    put("maintenance.html", build_maintenance_page(d))
    put("inbox.html", build_inbox_page(d))
    for ms in _maint_specs(d):
        page = {"id": ms["id"], "title": ms["title"], "dot": ms["dot"], "big": ms["big"],
                "section": "MAINTENANCE", "num": ms["num"],
                "rows": ms["rows"] + [("full text", ms.get("full_text") or "")],
                "sources": ["state/maintenance.json"]}
        put("cards/%s.html" % ms["id"], build_card_page(d, page))
    if verbose:
        print("sitegen: %d pages -> %s" % (len(written), SITE))
    return {"site": str(SITE), "pages": len(written)}


def main():
    try:
        print(json.dumps(generate(), indent=1))
        return 0
    except Exception as e:
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())

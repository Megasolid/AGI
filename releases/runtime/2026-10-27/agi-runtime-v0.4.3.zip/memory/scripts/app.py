#!/usr/bin/env python3
"""app.py - the AGI desktop shell: cold boot -> login state -> dashboard app window.

Design: the dashboard is already a served local UI. This launcher turns it into a desktop app:
it ensures the loopback server is up, opens the UI in an app window when a Chromium browser is
available (browser `--app=` mode, no tabs and no address bar), and otherwise falls back to the
default browser. The cold-boot sequence is:

    install -> boot (BIOS/S0-S8) -> app.py launch --login
        -> login screen (native device-key login, or SKIP -> default profile)
        -> dashboard

Nothing here opens a window while AGI works on a task: launching is an explicit user action (the
session rule "no window popups during work" still holds). `--dry-run` resolves and records
everything without opening anything, which is also what the selftest uses.

CLI
  app.py launch [--login] [--browser] [--dry-run] [--url <url>]
  app.py status
  app.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import json
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
APP_STATE = STATE / "app.json"
LOGIN_URL = "/login"

sys.path.insert(0, str(MEM / "scripts"))
import board_serve  # noqa: E402

SCHEMA = "agi-app/1"


def _jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _chromium():
    """Find a Chromium browser without hard-coding a machine path (C5)."""
    for name in ("msedge", "chrome", "chromium", "brave"):
        exe = shutil.which(name)
        if exe:
            return exe
    return None


def _root_url(url):
    # scheme://host:port from any local URL (board_serve.ensure() returns .../task_live.html)
    from urllib.parse import urlsplit
    u = urlsplit(url or "")
    if u.scheme and u.netloc:
        return u.scheme + "://" + u.netloc
    return (url or "http://127.0.0.1:8765").rstrip("/")


def _base_url():
    try:
        return _root_url(board_serve.ensure())
    except Exception:
        s = _jload(APP_STATE) or {}
        return _root_url(s.get("base_url") or "http://127.0.0.1:8765")


def launch(login=True, browser=False, dry_run=False, url=None):
    base = _base_url()
    target = url or (base + (LOGIN_URL if login else "/"))
    mode = "browser" if browser else "app"
    exe = None if browser else _chromium()
    opened = False
    if not dry_run:
        try:
            if exe:
                subprocess.Popen([exe, f"--app={target}"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                opened = True
            else:
                mode = "browser-fallback"
                opened = webbrowser.open(target)
        except Exception:
            mode = "browser-fallback"
            opened = webbrowser.open(target)
    rec = {"schema": SCHEMA, "launched_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
           "base_url": base, "url": target, "mode": mode, "browser": exe,
           "opened": bool(opened), "dry_run": bool(dry_run),
           "login_state": bool(login),
           "sequence": "boot -> app.py launch --login -> login screen (or skip) -> dashboard"}
    _jdump(APP_STATE, rec)
    return rec


def status():
    rec = _jload(APP_STATE) or {}
    ident = _jload(STATE / "identity" / "session.json") or {}
    return {"app": rec,
            "server": {"responding": bool(_jload(STATE / "board_serve.json"))},
            "session": {"active": ident.get("active"), "profile": ident.get("profile"),
                        "level": ident.get("level"), "expires": ident.get("expires")}}


def selftest():
    import tempfile

    global APP_STATE, LOGGING

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    saved = (APP_STATE,)
    tmp = Path(tempfile.mkdtemp(prefix="agi-app-test-"))
    try:
        APP_STATE = tmp / "state" / "app.json"
        rec = launch(login=True, dry_run=True, url="http://127.0.0.1:8765/login")
        check("dry run does not open a window", rec["opened"] is False and rec["dry_run"] is True)
        check("launch targets the login state", rec["url"].endswith("/login"))
        check("app state is written", APP_STATE.is_file())
        rec2 = launch(login=False, dry_run=True, url="http://127.0.0.1:8765/")
        check("skip path targets the dashboard", rec2["url"].endswith("/"))
        check("mode is recorded", rec2["mode"] in ("app", "browser", "browser-fallback"))
        check("sequence documented in state", "login screen" in rec2["sequence"])
        check("status reports the session block", "session" in status())
        check("chromium lookup never hard-codes a path",
              _chromium() is None or isinstance(_chromium(), str))
    finally:
        (APP_STATE,) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("app selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd == "launch":
        rec = launch(login="--login" in args, browser="--browser" in args,
                     dry_run="--dry-run" in args,
                     url=args[args.index("--url") + 1] if "--url" in args else None)
        print(json.dumps(rec, indent=1))
        return 0
    if cmd == "status":
        print(json.dumps(status(), indent=1))
        return 0
    if cmd == "selftest":
        return selftest()
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

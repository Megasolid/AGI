#!/usr/bin/env python3
"""dashv2 - vintage control-room dashboard renderer, live from state/.

Imported by dashboards.py (the only runner; registry gate). Design contract:
memory/knowledge/ui-dashboard.md. Sections: header(mode+alarms+data-age) /
SYSTEM / PLUGINS / CAPABILITIES / TASK LIST(+recall) / ARCHIVE / PERF CHARTS /
NERVE MAP / MAINTENANCE / footer(DNA gen).

2026-10-25 dashboard pass:
- self-located paths (no hardcoded skill root), RAM cache resolved from boot_card
- fixed TASKBILL source (memory/time/tasklog.jsonl) and CACHE CLUSTER card
- data-age / STALE badges everywhere a snapshot can age (perf, agents, boot)
- verified-script count, host/session model, RAG index and shell facts surfaced
"""
import datetime as _dt
import json
import os
import time
from pathlib import Path

AGI = str(Path(__file__).resolve().parents[2])   # memory/scripts/dashv2.py -> skill root
MEM = os.path.join(AGI, "memory")


def _read_json(p, d=None):
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {} if d is None else d


def _cache_dir():
    bc = _read_json(os.path.join(AGI, "state", "boot_card.json"))
    cand = ((bc.get("ram") or {}).get("cache")) if isinstance(bc, dict) else None
    if cand:
        return cand
    return os.path.join(AGI, "cache")


CACHE = _cache_dir()
WIN_DEFAULT = 64000
STALE_PERF = 86400      # perf snapshots older than 24h are stale
STALE_AGENTS = 3600     # agent-pool pings older than 1h are stale

try:  # stable recall numbers (#N) for cards / tasks / system parts
    import idkit as _idkit
except Exception:
    _idkit = None


def _nid(kind, ident):
    if _idkit is None:
        return ""
    try:
        return _idkit.short(kind, ident)
    except Exception:
        return ""


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def parse_ts(ts):
    s = str(ts or "").strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            d = _dt.datetime.strptime(s, fmt)
            if d.tzinfo is None:
                d = d.astimezone()
            return d.timestamp()
        except Exception:
            continue
    return None


def age_s(ts):
    t = parse_ts(ts)
    return None if t is None else max(0.0, time.time() - t)


def fmt_age(s):
    if s is None:
        return "?"
    if s < 120:
        return "%ds" % s
    if s < 7200:
        return "%.0fm" % (s / 60)
    if s < 172800:
        return "%.1fh" % (s / 3600)
    return "%.1fd" % (s / 86400)


def age_tag(ts, limit):
    """Return (age_label, stale_bool)."""
    a = age_s(ts)
    return fmt_age(a), (a is None or a > limit)


def jload(p, d=None):
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return {} if d is None else d


def open_bills():
    """Modern bill entries only: bill_status == 'active' (legacy rows have no status)."""
    bills = []
    try:
        for line in open(os.path.join(MEM, "time", "tasklog.jsonl"), encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                b = json.loads(line)
            except Exception:
                continue
            if b.get("bill_status") == "active":
                bills.append(b)
    except Exception:
        pass
    return bills


def load():
    g = lambda *a: os.path.join(*a)
    d = {"boot": jload(g(AGI, "state", "boot_card.json")),
         "bootrec": jload(g(AGI, "state", "boot.json")),
         "tasks": jload(g(AGI, "state", "season_tasks.json")),
         "caps": jload(g(AGI, "state", "capabilities.json")),
         "env": jload(g(AGI, "state", "env_probe.json")),
         "agents": jload(g(AGI, "state", "agents_status.json")),
         "led": jload(g(AGI, "state", "library_ledger.json")),
         "maint": jload(g(AGI, "state", "maintenance.json")),
         "steps": jload(g(AGI, "state", "task_steps.json")),
         "reg": jload(g(MEM, "scripts", "registry.json")),
         "prov": jload(g(MEM, "index", "provider.json")),
         "man": jload(g(CACHE, "manifest.json"))}
    for key, path in (("runs", g(AGI, "state", "check_runs.jsonl")),
                      ("bills", g(MEM, "time", "tasklog.jsonl"))):
        try:
            d[key] = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
        except Exception:
            d[key] = []
    d["bills"] = [b for b in d["bills"] if b.get("bill_status") == "active"]
    try:
        d["boot_runs"] = [json.loads(l) for l in open(g(AGI, "state", "boot_runs.jsonl"),
                                                       encoding="utf-8") if l.strip()]
    except Exception:
        d["boot_runs"] = []
    d["timr"] = jload(g(AGI, "state", "timr.json"))
    try:
        d["evo"] = [json.loads(l) for l in open(g(AGI, "state", "evolution_archive.jsonl"),
                                                 encoding="utf-8") if l.strip()]
    except Exception:
        d["evo"] = []
    return d


def dot(c):
    return f'<span class="dot {c}"></span>'


def rows(*p):
    out = ""
    for k, v in p:
        if v is None or v == "":
            continue
        out += f'<div class="row"><span>{esc(k)}</span><em>{esc(v)}</em></div>'
    return out


def card(title, c, big, body, full=False, cid=None):
    nid = _nid("card", cid or title.lower().replace(" ", "-").replace("/", "-"))
    nid_html = f'<span class="nid">{esc(nid)}</span>' if nid else ""
    return (f'<div class="card{" full" if full else ""}">'
            f'<div class="label">{dot(c)}{nid_html}{esc(title)}</div><div class="big">{big}</div>{body}</div>')


def sect(title, inner):
    return f'<div class="sect"><h2>{esc(title)}</h2></div><div class="grid">{inner}</div>'


def spark(vals, color="#33ff66", w=250, h=38):
    vals = [v for v in vals if isinstance(v, (int, float))]
    if len(vals) < 2:
        return "<i>n/a</i>"
    lo, hi = min(vals), max(vals)
    rng = (hi - lo) or 1.0
    pts = " ".join(f"{i * w / (len(vals) - 1):.0f},{h - (v - lo) / rng * (h - 6) - 3:.0f}" for i, v in enumerate(vals))
    return (f'<svg width="{w}" height="{h}"><polyline points="{pts}" fill="none" stroke="{color}" stroke-width="1.5"/>'
            f'<text x="2" y="9" font-size="9" fill="#8a8f7c">{hi:g}</text>'
            f'<text x="2" y="{h - 3}" font-size="9" fill="#8a8f7c">{lo:g}</text></svg>')


def header(d, ts):
    mode = str(d["tasks"].get("mode", "normal")).lower()
    cls = {"normal": "normal", "draft": "draft"}.get(mode, "maint")
    crit = 0 if d["caps"].get("network", {}).get("ok") else 1
    warn = len(d["maint"].get("open", []))
    b = d["boot"] if isinstance(d["boot"], dict) else {}
    br = d.get("bootrec") if isinstance(d.get("bootrec"), dict) else {}
    host = br.get("host") if isinstance(br.get("host"), dict) else (b.get("host") if isinstance(b.get("host"), dict) else {})
    brain = str(host.get("session_model") or (d["env"].get("model") or {}).get("name") or "unknown model")
    hostapp = str(host.get("application") or (b.get("host_application") or {}).get("id") or "unidentified")
    run = d["runs"][-1] if d["runs"] else {}
    age, stale = age_tag(run.get("ts"), STALE_PERF)
    aage, astale = age_tag(d["agents"].get("ts"), STALE_AGENTS)
    stale_src = []
    if stale:
        stale_src.append("perf " + age)
    if astale:
        stale_src.append("pool " + aage)
    fresh_chip = (f'<span class="chip stale">STALE: {esc(", ".join(stale_src))}</span>' if stale_src
                  else '<span class="chip fresh">data fresh</span>')
    chips = (f'<span class="chip">{esc(brain)}</span>'
             f'<span class="chip">host: {esc(hostapp)}</span>'
             f'{fresh_chip}'
             f'<span class="chip {"amber" if d.get("bills") else ""}">bills: {len(d.get("bills") or [])} open</span>')
    return (f'<div class="hd"><h1>AGI LIVE DASHBOARD</h1>'
            f'<span class="modeled {cls}">MODE: {esc(mode.upper())}</span>'
            f'<span class="alarm">{crit} CRIT &middot; <b class="a">{warn} WARN</b></span>'
            f'<span class="hchips">{chips}</span>'
            f'<span style="font-size:11px;color:#8a8f7c">generated {esc(ts)}</span></div>')


def system_cards(d):
    b, e, c = d["boot"], d["env"], d["caps"]
    ag, led, reg = d["agents"], d["led"], d["reg"]
    run = d["runs"][-1] if d["runs"] else {}
    age_label, perf_stale = age_tag(run.get("ts"), STALE_PERF)
    aage, agents_stale = age_tag(ag.get("ts"), STALE_AGENTS)
    out = []
    ram = b.get("ram") or {}
    br = d.get("bootrec") if isinstance(d.get("bootrec"), dict) else {}
    bruns = d.get("boot_runs") or []
    last_boot = bruns[-1] if bruns else {}
    hs = br.get("host") if isinstance(br.get("host"), dict) else {}
    bios_id = (b.get("host_application") or {}).get("id")
    hostapp = hs.get("application") or bios_id or "unidentified"
    hostapp_txt = hostapp + ("" if bios_id else " (bios: unidentified)")
    scripts = reg.get("scripts", {}) if isinstance(reg, dict) else {}
    nver = sum(1 for v in scripts.values() if str(v.get("status", "")).startswith("verified"))
    out.append(card("BOOT / BIOS", "ok" if b.get("status") == "ready" else "warn",
                    str(b.get("status", "?")).upper(),
                    rows(("DNA gen", 3), ("host application", hostapp_txt),
                         ("profile", b.get("profile")), ("gate", b.get("gate_side")),
                         ("verified scripts", f"{nver}/{len(scripts)}"), ("ts", b.get("ts")),
                         ("profile status", b.get("profile_status") or "?"),
                         ("selected model", b.get("model_name") or "?"),
                         ("integrity gate", ("PASS " + str((b.get("integrity") or {}).get("dur_ms", "?")) + " ms")
                          if (b.get("integrity") or {}).get("ok") else "FAIL"),
                         ("boot runs", f"{len(bruns)} (last {last_boot.get('dur_ms', '?')} ms)"),
                         ("last RAM adapter", last_boot.get("ram_source") or ram.get("source")),
                         ("RAM verified", ram.get("verified")),
                         ("RAM cache", ram.get("cache"))), cid="boot"))
    m = e.get("model") or {}
    br = d.get("bootrec") if isinstance(d.get("bootrec"), dict) else {}
    host = br.get("host") if isinstance(br.get("host"), dict) else {}
    brain = host.get("session_model") or m.get("name") or "n/a"
    ctx = m.get("context_length") or c.get("max_context") or "unknown (runtime-only)"
    out.append(card("MODEL (universal adapter)", "ok" if brain != "n/a" else "warn", esc(str(brain)),
                    rows(("brain (host session)", host.get("session_model") or "-"),
                         ("host app", host.get("application") or "-"),
                         ("env-probe model", m.get("name") or "n/a"),
                         ("selected model", b.get("model_name") or "-"),
                         ("profile (S5)", b.get("profile")),
                         ("profile status", b.get("profile_status") or "?"), ("context window", ctx)), cid="model"))
    net = c.get("network", {})
    sh = c.get("shell") or {}
    shell_txt = " + ".join(k for k in ("pwsh", "git_bash") if sh.get(k)) or "?"
    if sh.get("bash_default_dialect"):
        shell_txt += " (%s default)" % sh.get("bash_default_dialect")
    emb = c.get("embedding") or {}
    hs = c.get("host_speed") or {}
    hs_txt = "-"
    if hs.get("declared_gen_tok_s") or hs.get("factor"):
        hs_txt = ("~%s tok/s" % hs.get("declared_gen_tok_s")) if hs.get("declared_gen_tok_s") else "?"
        if hs.get("factor"):
            hs_txt += " · est factor %s (n=%s)" % (hs.get("factor"), hs.get("samples"))
    out.append(card("ENV / CAPABILITIES", "ok" if c.get("fs", {}).get("read") and net.get("ok") else "warn",
                    "READY",
                    rows(("fs r/w", f"{c.get('fs', {}).get('read')}/{c.get('fs', {}).get('write')}"),
                         ("shell", shell_txt), ("studio :8888", net.get("studio_8888_http")),
                         ("embedding", f"{emb.get('backend', '?')} / {'ready' if emb.get('configured') else 'off'}"),
                         ("max ctx", c.get("max_context") or "unresolved"),
                         ("host speed", hs_txt),
                         ("probed", c.get("probed_at") or "-"))))
    provs = ag.get("providers", {})
    up = [k for k, v in sorted(provs.items()) if isinstance(v, dict) and v.get("ok")]
    down = [k for k, v in sorted(provs.items()) if not (isinstance(v, dict) and v.get("ok"))]
    pool_dot = "warn" if (agents_stale or down) else "ok"
    out.append(card("AGENT POOL", pool_dot, f"{len(up)}/{len(provs)}",
                    rows(("up", ", ".join(up) or "-"), ("down", ", ".join(down) or "-"),
                         ("ping", f"{ag.get('ts', '?')} ({aage} ago{', STALE' if agents_stale else ''})")), cid="agents"))
    cnt = lambda p: sum(1 for v in scripts.values() if str(v.get("status", "")).startswith(p))
    out.append(card("SCRIPT REGISTRY", "ok" if cnt("verified") else "warn", str(cnt("verified")),
                    rows(("candidate", cnt("cand")), ("quarantined", cnt("quar")),
                         ("candidates", ", ".join(k for k, v in sorted(scripts.items())
                                                  if str(v.get("status", "")).startswith("cand")) or "-"),
                         ("conformance", "gen3 C1-C4 PASS 2026-10-19")), cid="registry"))
    docs = []
    kdir = os.path.join(MEM, "knowledge")
    try:
        docs = sorted(f for f in os.listdir(kdir) if f.endswith(".md"))
    except Exception:
        pass
    prov = d["prov"] or {}
    unread = sorted(n for n, v in led.items() if isinstance(v, dict) and v.get("status") == "unread")
    out.append(card("MEMORY / RAG", "warn" if unread else "ok",
                    f"{prov.get('chunks', '?')} chunks",
                    rows(("index", f"{prov.get('dimensions', '?')} dims / {prov.get('backend', '?')}"),
                         ("knowledge docs", len(docs)),
                         ("library unread", len(unread)),
                         ("unread", ", ".join(unread) or "-"),
                         ("index built", str(prov.get("generated", ""))[:19])), cid="library"))
    run_dot = {"OK": "ok", "WARN": "warn", "FAIL": "fail"}.get(str(run.get("status", "")).upper(), "warn")
    if perf_stale:
        run_dot = "warn"
    out.append(card("SYSTEM CHECK", run_dot, str(run.get("status", "?")).upper(),
                    rows(("last run", run.get("ts")), ("data age", age_label + (" STALE" if perf_stale else "")),
                         ("model", run.get("model")), ("ctx win", run.get("ctx_win")))))
    speed_dot = "warn" if perf_stale else "ok"
    out.append(card("PROMPT / GEN SPEED", speed_dot, f"{run.get('gen_avg', '?')} tok/s",
                    rows(("prompt avg/last", f"{run.get('prompt_avg')}/{run.get('prompt_last')}"),
                         ("gen avg/last", f"{run.get('gen_avg')}/{run.get('gen_last')}"),
                         ("data age", age_label + (" STALE" if perf_stale else "")))))
    out.append(card("VRAM / THERMALS", speed_dot, f"{run.get('vram_pct', '?')}%",
                    rows(("temp", run.get("vram_temp")), ("util", run.get("vram_util")),
                         ("net (s)", run.get("net_s")), ("data age", age_label + (" STALE" if perf_stale else "")))))
    timr = d.get("timr") or {}
    evo = d.get("evo") or []
    rate = timr.get("rate")
    last_evo = evo[-1] if evo else {}
    out.append(card("MISMATCH / EVOLUTION", "warn" if (isinstance(rate, (int, float)) and rate > 1) else "ok",
                    str(rate if rate is not None else "?"),
                    rows(("TIMR proxy / boot", f"{rate} over {timr.get('window_boots', '?')} boots"),
                         ("counters", ", ".join("%s=%s" % (k, v) for k, v in (timr.get("counters") or {}).items())),
                         ("evolution archive", f"{len(evo)} rows"),
                         ("last pair", "core v%s / %s / %s" % (last_evo.get("core_version"),
                                                               last_evo.get("host"),
                                                               str(last_evo.get("model") or "?")[:26])),
                         ("status", "L2 instruments (W5 phase-1); nothing gated on this yet")),
                    cid="mismatch-evolution"))
    try:
        nch = len([f for f in os.listdir(os.path.join(CACHE, "tasks")) if f.endswith(".md")])
    except Exception:
        nch = 0
    man_ver = (d["man"] or {}).get("version")
    out.append(card("CACHE CLUSTER (RAM)", "ok", str(man_ver or "RAM"),
                    rows(("season", d["tasks"].get("season")), ("task chunks", nch),
                         ("manifest", man_ver or "n/a"), ("root", CACHE),
                         ("rule", "fastboot reads state/ only"))))
    bills = d["bills"] if isinstance(d.get("bills"), list) else []
    if bills:
        bl = bills[-1]
        started = bl.get("started_epoch")
        el = None if started is None else max(0.0, time.time() - float(started))
        old = [b for b in bills if b.get("started_epoch") and
               time.time() - float(b.get("started_epoch")) > 7200]
        out.append(card("TASKBILL", "warn" if (old or len(bills) > 1) else "ok", f"{len(bills)} OPEN",
                        rows(("last task", str(bl.get("task", ""))[:60]),
                             ("est", f"{int(bl.get('est_s', 0))}s"),
                             ("elapsed", fmt_age(el) if el is not None else "-"),
                             ("open bills", ", ".join(str(b.get("task", ""))[:34] for b in bills[-3:])),
                             ("stale >2h", len(old) if old else "0"))))
    else:
        out.append(card("TASKBILL", "ok", "IDLE", rows(("open bill", 0), ("log", "memory/time/tasklog.jsonl"))))
    return "".join(out)


def plugins_cards(d):
    c, ag = d["caps"], d["agents"]
    net = c.get("network", {})
    down = (c.get("subagents", {}).get("down") or [])
    out = []
    out.append(card("ADOPTED: AGI CORE", "ok", "GEN3",
                    rows(("self", "this system"), ("root", "memdir (see boot card)"))))
    out.append(card("PLUG: CHROME-MCP", "fail" if down else "ok", "DOWN" if down else "UP",
                    rows(("port", 8899), ("detail", ", ".join(down) or "up"))))
    for name, note in (("PLUG: MCP BLENDER", "3D viewport tools"), ("PLUG: MCP UNSLOTH DOCS", "search / getPage / ask"),
                       ("PLUG: MCP HUGGINGFACE", "hub / fs / repo tools"), ("PLUG: MCP CONTEXT7", "external library docs")):
        out.append(card(name, "ok", "EXT", rows(("type", "external MCP"), ("note", note))))
    out.append(card("STUDIO API", "ok" if net.get("studio_8888_http") == 200 else "fail",
                    str(net.get("studio_8888_http", "?")),
                    rows(("port", 8888), ("flags", "-H / --cloudflare (since 2026.10.7)"))))
    out.append(card("BROWSER / HEART TOOLS", "ok", "LIVE",
                    rows(("type", "studio built-in"), ("note", "navigate / type / drag / evaluate"))))
    return "".join(out)


def caps_cards(d):
    led = d["led"]
    docs = []
    kdir = os.path.join(MEM, "knowledge")
    try:
        for f in sorted(os.listdir(kdir)):
            if f.endswith(".md"):
                docs.append((f, (led.get(f) or {}).get("status", "?")))
    except Exception:
        pass
    unread = [f for f, s in docs if s == "unread"]
    chips = "".join(f'<span class="chip{" amber" if s == "unread" else ""}">{esc(f[:-3])}</span>' for f, s in docs)
    out = []
    out.append(card("LEARNED SKILLS", "ok", "AGI + MCP",
                    '<span class="chip">agi</span><span class="chip">skill-creator</span>'
                    '<span class="chip">blender</span><span class="chip">docs</span>'
                    '<span class="chip">hf</span><span class="chip">context7</span>'))
    out.append(card("KNOWLEDGE BASE", "warn" if unread else "ok", str(len(docs)),
                    rows(("unread (amber)", ", ".join(unread) or "-")) + f'<div style="margin-top:6px">{chips}</div>'))
    return "".join(out)


def _step_leds(steps_state, task_id):
    """Compact per-step LED row for the active task (mirror of the live task board)."""
    st = steps_state or {}
    steps = st.get("steps") or []
    if not steps or st.get("task_id") != task_id:
        return ""
    dots = "".join(
        f'<span class="sdot {esc(s.get("status") or "pending")}" title="{int(s.get("n") or 0):02d} '
        f'{esc(s.get("name", ""))}"></span>' for s in steps)
    passed = sum(1 for s in steps if s.get("status") == "passed")
    return (f'<div class="sleds"><span class="sledlbl">steps</span>{dots}'
            f'<span class="sledcnt">{passed}/{len(steps)}</span>'
            f'<a class="live" href="task_live.html" target="_blank">LIVE TASK BOARD &#8599;</a></div>')


def task_card(t, steps=None):
    cps = t.get("checkpoints") or []
    done = str(t.get("status", "")).lower() in ("done", "closed", "archived")
    conf = t.get("conf")
    ck = "".join(f'<li>{esc(c.get("ts", ""))} {esc(c.get("note", ""))}</li>' for c in cps)
    pills = "".join(f"<i>{esc(p)}</i>" for p in (t.get("pills") or []))
    body = rows(("status", t.get("status")), ("confidence", conf),
                ("opened", str(t.get("opened", ""))[:19]), ("closed", str(t.get("closed", ""))[:19]),
                ("checkpoints", len(cps)))
    body += _step_leds(steps, t.get("id", ""))
    if ck:
        body += f'<ul class="ck">{ck}</ul>'
    if pills:
        body += f'<div class="pills" style="margin-top:4px">{pills}</div>'
    big = esc(str(conf)) if conf not in (None, "") else esc(str(t.get("status", "?")).upper())
    nid = _nid("task", t.get("id", ""))
    return (f'<div class="card full tcard" data-id="{esc(t.get("id", ""))}" data-num="{esc(nid)}">'
            f'<div class="label">{dot("ok" if done else "warn")}'
            f'<span class="nid">{esc(nid)}</span>'
            f'<span class="tid">{esc(t.get("id", ""))}</span>'
            f'<span class="ttl">{esc(t.get("title", ""))}</span></div>'
            f'<div class="big">{big}</div>{body}</div>')


def tasks_section(d):
    open_ = sorted([t for t in d["tasks"].get("open", []) if isinstance(t, dict)], key=lambda t: t.get("id", ""))
    cards = "".join(task_card(t, d.get("steps")) for t in open_) or '<div class="card full"><div class="label">no open tasks</div></div>'
    js = ('<script>var q=document.getElementById("q");'
          'q.oninput=function(){var s=q.value.toLowerCase();var n=0;'
          'document.querySelectorAll(".tcard").forEach(function(c){'
          'var hit=!s||c.dataset.id.indexOf(s)>=0||((c.dataset.num||"").indexOf(s)>=0);'
          'c.style.display=hit?"":"none";if(hit)n++;});'
          'document.getElementById("tn").textContent=n;};</script>')
    return (f'<div class="sect"><h2>TASK LIST - CURRENT SEASON</h2></div>'
            f'<div class="grid" style="margin-bottom:8px"><input id="q" placeholder="recall by #ID or task ID...">'
            f'<span style="font-size:11px;color:#8a8f7c">visible <b id="tn">{len(open_)}</b> &middot; IDs in state/id_registry.json</span></div>'
            f'<div class="grid">{cards}</div>{js}')


def archive_section(d):
    arch = sorted([t for t in d["tasks"].get("archive", []) if isinstance(t, dict)], key=lambda t: t.get("id", ""))
    cards = "".join(task_card(t, d.get("steps")) for t in arch) or '<div class="card full"><div class="label">no archived tasks</div></div>'
    return sect("TASK ARCHIVE (sorted by ID)", cards)


def perf_section(d):
    runs = d["runs"][-30:]
    age_label, stale = age_tag((runs[-1].get("ts") if runs else None), STALE_PERF)
    latest = runs[-1].get("ts") if runs else "-"
    grid = ""
    for label, color in (("PROMPT AVG (tok/s)", "#33ff66"), ("GEN AVG (tok/s)", "#ffb84d"),
                         ("VRAM (%)", "#7fb3ff"), ("TEMP (C)", "#ff5544")):
        vals = []
        for r in runs:
            v = r.get("prompt_avg") if "PROMPT" in label else r.get("gen_avg") if "GEN" in label \
                else r.get("vram_pct") if "VRAM" in label else r.get("vram_temp")
            if isinstance(v, str):
                try:
                    v = float(v.replace("\u00b0C", "").strip())
                except Exception:
                    continue
            if isinstance(v, (int, float)):
                vals.append(v)
        grid += f'<div class="card"><div class="label">{dot("warn" if stale else "ok")}{esc(label)}</div>{spark(vals, color)}</div>'
    trs = ""
    for r in runs[-8:][::-1]:
        st = str(r.get("status", "")).upper()
        cls = "fail" if st == "FAIL" else ""
        trs += (f'<tr class="{cls}"><td>{dot({"OK": "ok", "WARN": "warn", "FAIL": "fail"}.get(st, "warn"))}</td>'
                f'<td>{esc(r.get("ts", ""))}</td><td>{esc(str(r.get("model", ""))[:34])}</td>'
                f'<td>{r.get("prompt_avg")}</td><td>{r.get("gen_avg")}</td><td>{r.get("vram_pct")}%</td>'
                f'<td>{esc(r.get("vram_temp", ""))}</td></tr>')
    tbl = ('<table><tr><th></th><th>ts</th><th>model</th><th>prompt avg</th><th>gen avg</th>'
           '<th>vram</th><th>temp</th></tr>' + trs + "</table>")
    sub = (f'<span class="chip {"stale" if stale else "fresh"}">latest {esc(str(latest))} · {esc(age_label)} old'
           f'{"" if not stale else " · STALE - run core check to refresh"}</span>') if runs else \
          '<span class="chip stale">no check runs recorded</span>'
    grid_cls = "grid dim" if stale else "grid"
    tbl_cls = "grid dim" if stale else "grid"
    return (f'<div class="sect"><h2>PERFORMANCE CHARTS (last 30 runs) {sub}</h2></div>'
            f'<div class="{grid_cls}">{grid}</div>'
            f'<div class="{tbl_cls}"><div class="card full"><div class="label">{dot("warn" if stale else "ok")}LAST 8 RUNS</div>{tbl}</div></div>')


def nerve_section(d):
    dirs = {}
    total_n, total_b = 0, 0
    for root, dn, fn in os.walk(AGI):
        if r"\backups" in root or r"\__pycache__" in root:
            continue
        top = os.path.relpath(root, AGI).split(os.sep)[0]
        for f in fn:
            try:
                sz = os.path.getsize(os.path.join(root, f))
            except Exception:
                continue
            total_n += 1
            total_b += sz
            dirs.setdefault(top, [0, 0])
            dirs[top][0] += 1
            dirs[top][1] += sz
    mx = max((v[1] for v in dirs.values()), default=1) or 1
    cells = ""
    for k, (n, b) in sorted(dirs.items(), key=lambda kv: -kv[1][1]):
        a = 0.15 + 0.75 * (b / mx)
        cells += (f'<span class="heatcell" style="background:rgba(51,255,102,{a:.2f})" '
                  f'title="{n} files / {b // 1024}KB">{esc(k)}<br><b>{n}</b> \u00b7 {b // 1024}KB</span>')
    e = d["env"] if isinstance(d["env"], dict) else {}
    c = d["caps"] if isinstance(d["caps"], dict) else {}
    e_model = e.get("model") or {}
    win = e_model.get("context_length") or c.get("max_context") or WIN_DEFAULT
    win_known = bool(e_model.get("context_length") or c.get("max_context"))
    studio = e.get("root") or ""
    ctx_docs = [("SKILL.md", os.path.join(AGI, "SKILL.md")),
                ("MEMORY.md", os.path.join(MEM, "MEMORY.md")),
                ("AGENTS.md boot block", os.path.join(studio, "AGENTS.md") if studio else ""),
                ("chunk1_boot.md", os.path.join(CACHE, "chunk1_boot.md"))]
    ctx = ""
    for name, p in ctx_docs:
        try:
            sz = os.path.getsize(p) if p else 0
        except Exception:
            sz = 0
        pct = sz * 100.0 / win
        ring = ' ctxring' if pct >= 5 else ""
        ctx += (f'<span class="heatcell{ring}" style="background:rgba(255,184,77,{min(0.15 + pct / 25, 0.9):.2f})" '
                f'title="{esc(p or "n/a")}">{esc(name)}<br><b>{sz // 1024}KB</b> \u00b7 {pct:.1f}% win</span>')
    win_note = f"{win // 1024}K window" + ("" if win_known else " (assumed - max_context unresolved)")
    return sect("NERVE MAP - SYSTEM HEAT (every file = live node)",
                f'<div class="card full"><div class="label">{dot("ok")}DIR WEIGHTS ({total_n} nodes / {total_b // 1024}KB)</div>'
                f'<div style="margin:6px 0">{cells}</div>'
                f'<div class="label" style="margin-top:8px">{dot("warn")}CONTEXT LAYER (% of {esc(win_note)}, ring = &ge;5%)</div>'
                f'<div style="margin:6px 0">{ctx}</div></div>')


def maint_section(d):
    m = d["maint"]
    openli = "".join(f'<li class="amber">{esc(i)}</li>' for i in m.get("open", []))
    parked = m.get("parked_tasks", [])
    parkedli = "".join(f'<li>{esc(i)}</li>' for i in parked)
    fixed = [x for x in m.get("fixed", []) if isinstance(x, dict)][-6:]
    fxi = "".join(f'<li>{esc(x.get("ts", ""))} {esc(x.get("item", ""))}</li>' for x in reversed(fixed))
    return sect("MAINTENANCE (actionable alarms + event log)",
                f'<div class="card full"><div class="label">{dot("warn")}OPEN - ACTION REQUIRED ({len(m.get("open", []))})</div>'
                f'<ul class="maint">{openli}</ul>'
                f'<div class="label parked-label">{dot("neutral")}PARKED MAINTENANCE ARCHIVE ({len(parked)})</div>'
                f'<ul class="maint parked">{parkedli or "<li>none</li>"}</ul>'
                f'<div class="label" style="margin-top:8px">{dot("ok")}FIXED (event log, last 6)</div>'
                f'<ul class="maint">{fxi}</ul></div>')


def render(ts):
    d = load()
    css = open(os.path.join(os.path.dirname(__file__), "dashv2.css"), encoding="utf-8").read()
    run = d["runs"][-1] if d["runs"] else {}
    age_label, stale = age_tag(run.get("ts"), STALE_PERF)
    foot = (f"DNA v2 &middot; GENERATION 3 &middot; mode: {esc(str(d['tasks'].get('mode', 'normal')).upper())}"
            f" &middot; generated {esc(ts)} &middot; perf data: {esc(age_label)} old"
            f"{' (STALE)' if stale else ''}"
            f" &middot; sources: state/ boot_card + season_tasks + check_runs + maintenance")
    body = (header(d, ts)
            + sect("SYSTEM", system_cards(d))
            + sect("PLUGINS", plugins_cards(d))
            + sect("CAPABILITIES - SKILLS & KNOWLEDGE", caps_cards(d))
            + tasks_section(d)
            + archive_section(d)
            + perf_section(d)
            + nerve_section(d)
            + maint_section(d)
            + f'<div class="foot">{foot}</div>')
    return ("<html><head><meta charset='utf-8'><title>AGI LIVE DASHBOARD</title>"
            f"<style>{css}</style></head><body><div class='rack'>{body}</div></body></html>")

#!/usr/bin/env python3
"""Drive Claude Code headlessly as a coding sub-agent.

Usage:
  claude_worker.py --task "..." [--cwd DIR] [--resume SESSION_ID]
                   [--max-turns N] [--permission-mode acceptEdits|bypassPermissions]

Flow: ask `unsloth start claude --no-launch` for the current managed env + args,
then run `claude -p <task> --output-format json` with them. Prints a compact JSON
summary (result, session_id, turns) — pass session_id back via --resume to iterate.
"""
import argparse
import json
import os
import re
import shlex
import subprocess

try:
    from _silent import silent_run  # noqa: F401  (2026-10-19: no console popups)
except ImportError:
    silent_run = None

UNSLATH = r"C:\Users\D\.unsloth\studio\unsloth_studio\Scripts\unsloth.exe"
CLAUDE = r"C:\Users\D\.local\bin\claude.exe"


def get_launch(cwd: str):
    _run = silent_run if silent_run is not None else subprocess.run
    out = _run(
        [UNSLATH, "start", "claude", "--no-launch"],
        cwd=cwd, capture_output=True, text=True,
    ).stdout
    env, drop, args = {}, set(), None
    for line in out.splitlines():
        s = line.strip()
        m = re.match(r'\$env:(\w+)\s*=\s*"(.*)"\s*$', s)
        if m:
            env[m.group(1)] = m.group(2)
            continue
        m = re.match(r'Remove-Item Env:(\w+)', s)
        if m:
            drop.add(m.group(1))
            continue
        if s.startswith("claude "):
            args = shlex.split(s)[1:]
    full = {k: v for k, v in os.environ.items() if k not in drop}
    full.update(env)
    return full, (args or [])


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", required=True)
    ap.add_argument("--cwd", default=os.getcwd())
    ap.add_argument("--resume")
    ap.add_argument("--max-turns", type=int)
    ap.add_argument("--permission-mode", default="acceptEdits")
    a = ap.parse_args()

    env, args = get_launch(a.cwd)
    cmd = [CLAUDE] + args + ["-p", a.task, "--output-format", "json",
                             "--permission-mode", a.permission_mode]
    if a.resume:
        cmd += ["--resume", a.resume]
    if a.max_turns:
        cmd += ["--max-turns", str(a.max_turns)]

    _run = silent_run if silent_run is not None else subprocess.run
    r = _run(cmd, cwd=a.cwd, env=env, capture_output=True, text=True)
    try:
        d = json.loads(r.stdout)
        print(json.dumps({
            "ok": not d.get("is_error"),
            "result": (d.get("result") or "")[:1500],
            "session_id": d.get("session_id"),
            "turns": d.get("num_turns"),
        }, indent=1))
        return 0 if not d.get("is_error") else 1
    except (ValueError, AttributeError):
        print("RAW STDOUT:", r.stdout[-2000:])
        print("STDERR:", r.stderr[-2000:])
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""board_serve - loopback HTTP server for the live AGI task board (DSH built-in Browser panel).

Why: the Harness right-sidebar Browser accepts HTTP(S) loopback URLs and rejects file:
URLs, while the system Chrome launch is not what D wants. This singleton server publishes
the rendered RAM board at http://127.0.0.1:<port>/task_live.html, a small /api/state JSON,
and an INTERACTION QUEUE so the presented task card can be operated by D:

  POST /api/action   {type, step?, value?, note?, steps?} -> append to state/taskboard_actions.jsonl
  GET  /api/actions  [?since=N]                            -> the queue (for the agent)
  GET  /api/state                                          -> {seq, task_id, title, ..., url}
  GET  /task_live.html                                     -> the rendered board page

Action types: approve | review | cancel | archive | subtask | step_approve | step_input | note
The page POSTs from the same origin (no CORS problem); the agent consumes the queue from
state/taskboard_actions.jsonl via `taskcard.py actions [--consume]`.

Run windowless: the venv pythonw.exe is used for the detached child (D rule: background
never owns a console window).

usage:
  board_serve.py [--ensure]   # start the singleton if it is not already answering
  board_serve.py --serve      # internal: run the server in the foreground
  board_serve.py --stop       # stop a running server
  board_serve.py --actions [--since N]   # print queued user actions
"""
import json
import os
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
RECORD = STATE / "taskboard.json"
STEPS = STATE / "task_steps.json"
ACTIONS = STATE / "taskboard_actions.jsonl"
CURSOR = STATE / "taskboard_actions_cursor.json"
DEFAULT_PORT = 8765
VALID_ACTIONS = {"approve", "review", "cancel", "archive", "subtask",
                 "step_approve", "step_input", "note", "bridge_result"}
_LOCK = threading.Lock()


def port():
    try:
        return int(json.loads(RECORD.read_text(encoding="utf-8")).get("port") or DEFAULT_PORT)
    except Exception:
        return DEFAULT_PORT


def ram_root():
    sys.path.insert(0, str(AGI / "memory" / "scripts"))
    import cardkit
    return Path(os.path.dirname(cardkit.sandbox_cache()))


def state_payload():
    st = {}
    try:
        st = json.loads(STEPS.read_text(encoding="utf-8"))
    except Exception:
        pass
    seq = st.get("updated") or ""
    try:
        seq = "%s-%d" % (seq, (ram_root() / "task_live.html").stat().st_mtime_ns)
    except Exception:
        pass
    p = port()
    return {"seq": seq, "task_id": st.get("task_id"), "title": st.get("title"),
            "mode": st.get("mode") or "task", "decision": st.get("decision"),
            "steps": len(st.get("steps") or []),
            "url": "http://127.0.0.1:%d/task_live.html" % p, "port": p}


def read_actions(since=None):
    out = []
    try:
        lines = ACTIONS.read_text(encoding="utf-8").splitlines()
    except Exception:
        return out
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            a = json.loads(line)
        except Exception:
            continue
        if since is None or int(a.get("n") or 0) > int(since):
            out.append(a)
    return out


def append_action(payload):
    """Validate + persist one user action; returns the stored record."""
    a = dict(payload or {})
    kind = str(a.get("type") or "").strip()
    if kind not in VALID_ACTIONS:
        raise ValueError("unknown action type: %r" % kind)
    with _LOCK:
        existing = read_actions()
        a["n"] = (int(existing[-1].get("n") or 0) + 1) if existing else 1
        a["ts"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
        a["task_id"] = (state_payload() or {}).get("task_id")
        ACTIONS.parent.mkdir(parents=True, exist_ok=True)
        with open(ACTIONS, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(a, ensure_ascii=False) + "\n")
        try:
            rec = json.loads(RECORD.read_text(encoding="utf-8"))
        except Exception:
            rec = {}
        rec["last_action"] = {"n": a["n"], "type": kind, "ts": a["ts"]}
        RECORD.write_text(json.dumps(rec, indent=1), encoding="utf-8")
    return a


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_a):
        pass

    def _send(self, code, body, ctype, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self._send(204, b"", "text/plain")

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, indent=1, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _read_file(self, rel):
        root = ram_root()
        if rel == "task_live.html":
            p = root / "task_live.html"
        else:
            rel = rel.replace("\\", "/").lstrip("/")
            if ".." in rel.split("/"):
                return None, "bad path"
            p = root / "site" / rel
        try:
            return p.read_bytes(), None
        except Exception as e:
            return None, str(e)

    def _file(self, rel):
        body, err = self._read_file(rel)
        if body is None:
            return self._send(404, ("not generated yet: %s" % err).encode(), "text/plain; charset=utf-8")
        return self._send(200, body, "text/html; charset=utf-8")

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/api/state":
            return self._json(200, state_payload())
        if path == "/api/actions":
            since = None
            if "since=" in self.path:
                try:
                    since = int(self.path.split("since=")[1].split("&")[0])
                except Exception:
                    since = None
            return self._json(200, {"actions": read_actions(since)})
        # --- site routes (served from <RAM>/site by sitegen.py) ------------------
        if path in ("/", "/index.html"):
            return self._file("index.html")
        if path == "/system":
            return self._file("system.html")
        if path == "/maintenance":
            return self._file("maintenance.html")
        if path == "/inbox":
            return self._file("inbox.html")
        if path == "/board":
            return self._file("task_live.html")
        if path in ("/login", "/login.html"):
            return self._file("login.html")
        if path.startswith("/cards/") and path.endswith(".html"):
            return self._file("cards/" + path[len("/cards/"):])
        if path == "/task_live.html":
            return self._file("task_live.html")
        return self._send(404, b"not found", "text/plain")

    # ---- local admin factor API (the browser types the phrase; the AI never sees it) ----
    def _admin_post(self, path):
        if (self.headers.get("X-AGI-UI") or "") != "1":
            return self._json(403, {"ok": False, "error": "missing X-AGI-UI header (UI only)"})
        try:
            length = int(self.headers.get("Content-Length") or 0)
            payload = json.loads(self.rfile.read(length).decode("utf-8") or "{}") if length else {}
        except Exception as e:
            return self._json(400, {"ok": False, "error": str(e)[:200]})
        try:
            import adminfactor as af
            if path == "/api/admin/setup":
                if af.status().get("admin_factor"):
                    return self._json(409, {"ok": False, "error": "admin factor already exists: use restore or rotate"})
                if not payload.get("confirm"):
                    return self._json(400, {"ok": False, "error": "confirm=true is required to mint the phrase"})
                r = af.setup(show=False, reveal=True)
                return self._json(200, {"ok": True, "phrase": r.get("phrase"),
                                        "words": r.get("words"), "blob_sha256": r.get("blob_sha256")})
            if path == "/api/admin/train":
                r = af.check_phrase(payload.get("phrase") or "")
                return self._json(200 if r.get("ok") else 401, r)
            if path == "/api/admin/restore":
                phrase = payload.get("phrase") or ""
                if not phrase:
                    return self._json(400, {"ok": False, "error": "phrase required"})
                temp = bool(payload.get("temp"))
                r = af.restore(blob=payload.get("blob") or None, phrase=phrase,
                               enroll=bool(payload.get("enroll", not temp)),
                               ttl_hours=float(payload.get("ttl_hours") or (4 if temp else 12)),
                               temp=temp)
                return self._json(200, {"ok": True, "profile_id": r.get("profile_id"),
                                        "session": r.get("session"), "enrolled": r.get("enrolled"),
                                        "temporary": temp})
            if path == "/api/admin/rotate":
                phrase = payload.get("phrase") or ""
                if not phrase:
                    return self._json(400, {"ok": False, "error": "current phrase required"})
                r = af.rotate(phrase=phrase, reveal=True)
                return self._json(200, {"ok": True, "phrase": r.get("phrase"),
                                        "blob_sha256": r.get("blob_sha256"),
                                        "remember_to": r.get("remember_to")})
            if path == "/api/admin/wipe":
                if not payload.get("confirm"):
                    return self._json(400, {"ok": False, "error": "confirm=true is required to wipe identity material"})
                return self._json(200, af.wipe(confirm=True))
            if path == "/api/admin/publish":
                r = af.publish(push=bool(payload.get("push")))
                return self._json(200, {"ok": True, "path": r.get("path"), "sha256": r.get("sha256")})
            return self._json(404, {"ok": False, "error": "unknown admin endpoint"})
        except Exception as e:
            # never echo request bodies (they may contain the phrase)
            return self._json(400, {"ok": False, "error": type(e).__name__ + ": " + str(e)[:200]})

    def do_POST(self):
        path = self.path.split("?")[0]
        if path.startswith("/api/admin/"):
            return self._admin_post(path)
        if path != "/api/action":
            return self._json(404, {"ok": False, "error": "not found"})
        try:
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            payload = json.loads(raw.decode("utf-8") or "{}")
            a = append_action(payload)
        except Exception as e:
            return self._json(400, {"ok": False, "error": str(e)[:300]})
        bridge = bridge_forward(a)
        if bridge.get("ok"):
            try:
                append_action({"type": "bridge_result", "ref_n": a["n"], "bridge": bridge})
            except Exception:
                pass
        return self._json(200, {"ok": True, "n": a["n"], "type": a["type"], "ts": a["ts"],
                                "bridge": bridge})


# ---- phase-2 native click-to-resume bridge (2026-10-25) -------------------
BRIDGE_PATH = "/api/agi-resume3"
DECISION_LABEL = {"approve": "Approve", "review": "Review", "cancel": "Cancel"}


def _decision_label(kind):
    return DECISION_LABEL.get(str(kind or "").lower())


def _pick_pending(items, task_id):
    """Prefer the pending question that belongs to this task; otherwise the only/first one."""
    items = [i for i in (items or []) if isinstance(i, dict)]
    if not items:
        return None
    for item in items:
        if task_id and str(item.get("task_id")) == str(task_id):
            return item
    return items[0]


def _http_json(url, payload=None, timeout=2.5):
    import urllib.request
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers,
                                 method="POST" if payload is not None else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8") or "{}")


def bridge_forward(action):
    """Forward a card decision to the native resume bridge so the agent turn resumes immediately.

    Returns an evidence dict; never raises. When no bridge/question is available the action stays
    queued in state/taskboard_actions.jsonl and the scheduled fallback still applies.
    """
    label = _decision_label(action.get("type"))
    if not label:
        return {"attempted": False, "reason": "not a decision action"}
    base = (os.environ.get("DSH_WEB_URL") or "").rstrip("/")
    if not base:
        return {"attempted": False, "reason": "DSH_WEB_URL unavailable (fallback path)"}
    started = time.time()
    try:
        state = _http_json(base + BRIDGE_PATH + "/pending")
        item = _pick_pending(state.get("items"), action.get("task_id"))
        if not item:
            return {"attempted": True, "ok": False, "reason": "no pending question",
                    "latency_ms": int((time.time() - started) * 1000)}
        result = _http_json(base + BRIDGE_PATH, {
            "call_id": item.get("call_id"),
            "decision": label,
            "note": action.get("note") or "",
        })
        return {"attempted": True, "ok": True, "accepted": bool(result.get("accepted")),
                "decision": label, "call_id": item.get("call_id"),
                "latency_ms": int((time.time() - started) * 1000)}
    except Exception as e:
        return {"attempted": True, "ok": False, "error": str(e)[:200],
                "latency_ms": int((time.time() - started) * 1000)}


def _responding(p=None):
    p = p or port()
    try:
        s = socket.create_connection(("127.0.0.1", p), timeout=0.4)
        s.close()
        return True
    except Exception:
        return False


def _write_record(pid):
    STATE.mkdir(parents=True, exist_ok=True)
    old = {}
    try:
        old = json.loads(RECORD.read_text(encoding="utf-8"))
    except Exception:
        pass
    old.update({"pid": pid, "port": port(), "started": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "url": "http://127.0.0.1:%d/task_live.html" % port()})
    RECORD.write_text(json.dumps(old, indent=1), encoding="utf-8")


def serve():
    p = port()
    httpd = ThreadingHTTPServer(("127.0.0.1", p), Handler)
    _write_record(os.getpid())
    print("board_serve: http://127.0.0.1:%d/task_live.html" % p, flush=True)
    httpd.serve_forever()


def _interpreter():
    """Long-lived background server must never own a console window (D rule)."""
    exe = Path(sys.executable)
    pyw = exe.with_name("pythonw.exe")
    return str(pyw if pyw.is_file() else exe)


def ensure():
    """Return the board URL, starting the singleton server when needed."""
    if _responding():
        return "http://127.0.0.1:%d/task_live.html" % port()
    flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.Popen([_interpreter(), str(Path(__file__).resolve()), "--serve"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     stdin=subprocess.DEVNULL, close_fds=True, creationflags=flags)
    for _ in range(50):
        if _responding():
            return "http://127.0.0.1:%d/task_live.html" % port()
        time.sleep(0.1)
    raise RuntimeError("board server did not start on port %d" % port())


def stop():
    try:
        pid = int(json.loads(RECORD.read_text(encoding="utf-8")).get("pid") or 0)
    except Exception:
        pid = 0
    if pid:
        try:
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True)
        except Exception:
            pass
    print("board_serve: stopped pid", pid)


def main():
    args = sys.argv[1:]
    if "--serve" in args:
        serve()
        return 0
    if "--stop" in args:
        stop()
        return 0
    if "--actions" in args:
        since = None
        if "--since" in args:
            try:
                since = int(args[args.index("--since") + 1])
            except Exception:
                since = None
        acts = read_actions(since)
        print(json.dumps({"count": len(acts), "actions": acts}, indent=1))
        return 0
    try:
        print("board URL:", ensure())
    except Exception as e:
        print("board_serve: ERROR", e)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

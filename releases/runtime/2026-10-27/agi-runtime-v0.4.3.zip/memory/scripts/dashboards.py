#!/usr/bin/env python3
"""dashboards - stage the dashboard artifacts into the season cache (RAM) at boot.

There is exactly ONE dashboard: live_dashboard.html - the UPGRADED check_report:
it carries the system-check data (model / speeds / VRAM+thermals / network, from
state/check_runs.jsonl that report.py + check.sh write on every run) plus Boot,
Map status and Stats in the card grid, then TWO FULL-ROW sections below it:
  TASKS (this season) and TASK ARCHIVE - each task its own individual card,
  max 4 cards per row, sorted by ID.
The AGI SYSTEM MAP is a separate maintenance artifact (canonical copy in memory/),
staged alongside. Both artifacts are GENERATED during the boot sequence (S8)
and after any task mutation:
  - agi_system_map.html : copied byte-exact from memory/agi_system_map.html
  - live_dashboard.html : rendered from state/boot_card.json + state/season_tasks.json
    + state/check_runs.jsonl
usage: dashboards.py   (idempotent; safe to re-run any turn)
"""
import json, os, sys, datetime, shutil
from pathlib import Path

AGI = str(Path(__file__).resolve().parents[2])   # memory/scripts -> skill root (self-located, no hardcoded paths)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cardkit
CACHE = cardkit.sandbox_cache()                    # season sandbox cache = SHARED RAM pool with D (cwd-independent)

def jload(p, d=None):
    try:
        with open(p) as f: return json.load(f)
    except Exception:
        return d

def esc(s): return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

boot  = jload(os.path.join(AGI, "state", "boot_card.json"), {}) or {}
tasks = jload(os.path.join(AGI, "state", "season_tasks.json"), {}) or {}
ts    = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# --- check_report data: latest system-check run (report.py/check.sh append here) ---
runs = []
try:
    with open(os.path.join(AGI, "state", "check_runs.jsonl")) as f:
        for line in f:
            line = line.strip()
            if line:
                runs.append(json.loads(line))
except Exception:
    pass
run = runs[-1] if runs else {}

dst = os.path.join(CACHE, "dashboards")
os.makedirs(dst, exist_ok=True)

# --- 1. AGI SYSTEM MAP (maintenance artifact) - byte-exact stage from memdir -----
map_src = os.path.join(AGI, "memory", "agi_system_map.html")
map_dst = os.path.join(dst, "agi_system_map.html")
map_ok  = False
if os.path.exists(map_src):
    shutil.copyfile(map_src, map_dst)
    map_ok = True


# --- 2. LIVE DASHBOARD v2 (vintage control room, live from state/) ---------------
import dashv2
doc = dashv2.render(ts)
with open(os.path.join(dst, "live_dashboard.html"), "w", encoding="utf-8") as f:
    f.write(doc)

print(f"dashboards staged: map={'ok' if map_ok else 'MISSING'} ({os.path.getsize(map_dst) if map_ok else 0}B) "
      f"dashboard={len(doc)}B -> {dst}")

# --- 3. LIVE TASK BOARD (task card + bill + per-step LEDs) when a task is active ---
# 2026-10-25: boot/re-stage path also refreshes the big distance-readable board so the
# RAM copy is never stale after a reboot or a task mutation.
try:
    import taskcard
    if taskcard.load_steps():
        taskcard.cmd_render([])
except Exception as e:
    print("task board staging skipped:", e)

# --- 4. AGI SITE (dashboard v3 + per-card pages + system/maintenance) --------
# One GitHub-style design system, every card clickable; served by board_serve.py.
try:
    import sitegen
    summary = sitegen.generate(verbose=False)
    print(f"site staged: {summary['pages']} pages -> {summary['site']}")
except Exception as e:
    print("site staging skipped:", e)

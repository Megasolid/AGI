#!/usr/bin/env python3
"""taskcard - live task card + bill view with per-step LEDs (distance readable).

state/task_steps.json = SSOT for the ACTIVE task's step board:
  {"task_id", "title", "bill_task", "started", "updated",
   "steps": [{"n", "name", "status", "ts", "note"}]}
status: pending | active | passed | failed

Renderer: <season sandbox>/task_live.html (RAM root, meta-refresh 5 s, big LEDs readable
from across the room) + a mirror in <sandbox>/cache/dashboards/task_live.html so the live
dashboard task card can link to it. Every transition also logs a taskbill checkpoint, so the
bill evidence and the LEDs move together.

usage:
  taskcard.py init --card <task-id> --title "..." --bill "<bill task>" [--plan plan.json]
      (publishes the board on the loopback URL used by the Harness right-sidebar Browser panel:
       http://127.0.0.1:<port>/task_live.html - the system Chrome is NOT launched unless
       --open-system is passed)
  taskcard.py propose --card <id> --title "..." --bill "..." --est-s N --context bill.md
      [--steps "W1|W2|..."] [--needs "2:question;5:question"]
      (presents the bill as an interactive proposal card: full context, per-step approve
       checkboxes + inputs, buttons Approve / Review / Cancel / Archive / Subtask)
  taskcard.py actions [--consume] [--since N]   # read the user's queued decisions/inputs
  taskcard.py result --summary "..." [--link "label=url" ...]   # result block on the card
  taskcard.py step --n 3 --status active|passed|failed [--note "..."]
  taskcard.py render
  taskcard.py open      # re-publish + print the loopback board URL
  taskcard.py status
"""
import json
import os
import sys
from datetime import datetime

AGI = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # self-located
STATE = os.path.join(AGI, "state")
STEPS_PATH = os.path.join(STATE, "task_steps.json")
ACTIONS_PATH = os.path.join(STATE, "taskboard_actions.jsonl")
CURSOR_PATH = os.path.join(STATE, "taskboard_actions_cursor.json")
TASKLOG = os.path.join(AGI, "memory", "time", "tasklog.jsonl")
REFRESH_S = 5
STATUSES = ("pending", "active", "passed", "failed")


def _now_hhmm():
    return datetime.now().strftime("%H:%M")


def _load_json(p, d=None):
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return d


def load_steps():
    d = _load_json(STEPS_PATH, None)
    return d if isinstance(d, dict) and isinstance(d.get("steps"), list) else None


def save_steps(st):
    st["updated"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    os.makedirs(STATE, exist_ok=True)
    tmp = STEPS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(st, fh, indent=1)
    os.replace(tmp, STEPS_PATH)


def find_bill(bill_task):
    """Latest tasklog entry for the bill task (last line wins)."""
    if not bill_task or not os.path.exists(TASKLOG):
        return None
    hit = None
    with open(TASKLOG, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                e = json.loads(line)
            except Exception:
                continue
            if e.get("task") == bill_task:
                hit = e
    return hit


def _fmt_s(sec):
    sec = max(0, int(sec or 0))
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    if h:
        return "%dh %02dm" % (h, m)
    if m:
        return "%dm %02ds" % (m, s)
    return "%ds" % s


def board_status(st):
    statuses = [s.get("status") for s in st.get("steps", [])]
    if "failed" in statuses:
        return "FAILED"
    if statuses and all(s == "passed" for s in statuses):
        return "PASSED"
    if any(s == "active" for s in statuses) or "passed" in statuses:
        return "RUNNING"
    return "DRAFT"


def summary(st):
    steps = st.get("steps", [])
    count = {k: sum(1 for s in steps if s.get("status") == k) for k in STATUSES}
    count["total"] = len(steps)
    return count


def render_page(st, bill=None, now=None, refresh=REFRESH_S):
    """Pure renderer: step board + bill -> live HTML (no disk access)."""
    now = now or datetime.now()
    if st.get("mode") == "proposal":
        return _render_proposal(st, bill or {}, now)
    steps = st.get("steps", [])
    cnt = summary(st)
    overall = board_status(st)
    dot = {"pending": "grey", "active": "amber", "passed": "green", "failed": "red"}
    # bill numbers
    bill = bill or {}
    est_s = bill.get("est_s")
    actual_s = bill.get("actual_s")
    started = bill.get("started_epoch")
    elapsed = (now.timestamp() - started) if started else None
    ratio = bill.get("ratio")
    bstatus = (bill.get("bill_status") or "not started").replace("_", " ")
    pct = int(100 * cnt["passed"] / cnt["total"]) if cnt["total"] else 0
    rows = []
    for s in steps:
        stt = s.get("status") if s.get("status") in STATUSES else "pending"
        note = ('<div class="note">%s</div>' % _esc(s.get("note"))) if s.get("note") else ""
        rows.append(
            '<div class="step %s"><span class="led"></span><span class="num">%02d</span>'
            '<div><div class="name">%s</div>%s</div><span class="ts">%s</span></div>'
            % (stt, int(s.get("n") or 0), _esc(s.get("name")), note, _esc(s.get("ts") or "")))
    legend = " ".join(
        '<span><span class="led %s"></span>%s</span>' % (k, k) for k in STATUSES)
    js = ("<script>var S=%s;var el=document.getElementById('elapsed');"
          "function f(x){x=Math.max(0,Math.floor(x));var m=Math.floor(x/60),s=x%%60;"
          "return (m?m+'m ':'')+String(s).padStart(2,'0')+'s';}"
          "if(S&&el){var t=function(){el.textContent=f(Date.now()/1000-S)};t();setInterval(t,1000)}</script>"
          % (json.dumps(started) if started else "null"))
    refresh_tag = ('<meta http-equiv="refresh" content="%d">' % refresh) if refresh else ""
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>AGI live task - %(title)s</title>%(refresh_tag)s"
        "<style>%(css)s</style></head><body><div class='wrap'>"
        "<div class='top'><div><div class='tid'>AGI TASK %(num)s &middot; %(tid)s</div>"
        "<h1>%(title)s</h1><div class='billname'>bill: %(bill)s</div></div>"
        "<div class='pill %(overall)s'>%(overall)s</div></div>"
        "<div class='board'>"
        "<div class='cell'><div class='k'>est</div><div class='v'>%(est)s</div></div>"
        "<div class='cell'><div class='k'>elapsed</div><div class='v' id='elapsed'>%(elapsed)s</div></div>"
        "<div class='cell'><div class='k'>actual</div><div class='v'>%(actual)s</div></div>"
        "<div class='cell'><div class='k'>ratio</div><div class='v'>%(ratio)s</div></div>"
        "<div class='cell'><div class='k'>bill status</div><div class='v small'>%(bstatus)s</div></div>"
        "</div>"
        "<div class='bar'><i style='width:%(pct)d%%'></i></div>"
        "<div class='meta'><span>%(passed)d/%(total)d passed &middot; %(active)d active "
        "&middot; %(pending)d pending &middot; %(failed)d failed</span>"
        "<span>updated %(upd)s &middot; auto-refresh %(refresh)d s</span></div>"
        "<div class='steps'>%(rows)s</div>"
        "<div class='legend'>%(legend)s</div>"
        "<div class='foot'>generated %(gen)s &middot; state/task_steps.json &middot; "
        "source: taskcard.py (verified)</div>%(result)s%(actions)s%(js)s"
        "</div></body></html>" % {
            "title": _esc(st.get("title") or "untitled task"),
            "num": _num(st.get("task_id")),
            "tid": _esc(st.get("task_id") or ""),
            "bill": _esc(st.get("bill_task") or "(none)"),
            "overall": overall,
            "est": _fmt_s(est_s) if est_s else "—",
            "elapsed": _fmt_s(elapsed) if elapsed else "—",
            "actual": _fmt_s(actual_s) if actual_s else "—",
            "ratio": ("%.2f" % ratio) if ratio else "—",
            "bstatus": _esc(bstatus),
            "pct": pct,
            "passed": cnt["passed"], "total": cnt["total"], "active": cnt["active"],
            "pending": cnt["pending"], "failed": cnt["failed"],
            "upd": _esc(st.get("updated") or now.strftime("%Y-%m-%d %H:%M")),
            "refresh": refresh,
            "refresh_tag": refresh_tag,
            "rows": "".join(rows),
            "legend": legend,
            "gen": now.strftime("%Y-%m-%d %H:%M:%S"),
            "result": _result_html(st),
            "actions": _running_actions_html(),
            "js": js,
            "refresh": refresh,
            "css": _CSS,
        })


def _esc(v):
    import html as _h
    return _h.escape(str(v if v is not None else ""))


def _num(task_id):
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import idkit
        return idkit.short("task", task_id)
    except Exception:
        return ""


_PROPOSAL_CSS = (
    ":root{--bg:#0d1117;--panel:#161b22;--inset:#010409;--line:#30363d;--text:#e6edf3;--muted:#8b949e;"
    "--blue:#58a6ff;--green:#3fb950;--amber:#d29922;--red:#f85149;--grey:#6e7681}"
    "*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);"
    "font:15px/1.55 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif}"
    ".wrap{max-width:1180px;margin:0 auto;padding:28px 32px 120px}"
    ".top{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;margin-bottom:18px}"
    ".tid{font-size:13px;color:var(--muted);letter-spacing:.08em;text-transform:uppercase}"
    "h1{font-size:32px;margin:6px 0 4px;line-height:1.2}"
    ".sub{color:var(--muted);font-size:14px}"
    ".pill{font-size:14px;font-weight:700;padding:8px 18px;border-radius:999px;border:1px solid var(--amber);"
    "color:var(--amber);white-space:nowrap;background:#d299221a}"
    ".pill.approved{border-color:var(--green);color:var(--green);background:#2ea0431a}"
    ".pill.cancelled{border-color:var(--red);color:var(--red);background:#f851491a}"
    ".board{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0 22px}"
    ".cell{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:12px 16px}"
    ".cell .k{font-size:11px;letter-spacing:.1em;color:var(--muted);text-transform:uppercase}"
    ".cell .v{font-size:22px;font-weight:700;margin-top:4px}"
    ".panel{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:20px 24px;margin-bottom:18px}"
    ".panel h2{font-size:16px;margin:0 0 12px;padding-bottom:8px;border-bottom:1px solid var(--line);"
    "color:var(--muted);letter-spacing:.02em;font-weight:600}"
    ".ctx :is(h1,h2,h3){font-size:16px;margin:16px 0 6px;border-bottom:1px solid var(--line);padding-bottom:4px}"
    ".ctx :is(h1,h2,h3):first-child{margin-top:0}"
    ".ctx p{margin:8px 0;color:var(--text)}.ctx ul,.ctx ol{margin:8px 0 8px 22px;padding:0}"
    ".ctx li{margin:3px 0}.ctx code{background:var(--inset);border:1px solid var(--line);border-radius:4px;"
    "padding:1px 5px;font:12px ui-monospace,Consolas,monospace}.ctx strong{color:#fff}"
    ".step{display:grid;grid-template-columns:22px 34px 1fr auto;gap:14px;align-items:start;"
    "background:var(--inset);border:1px solid var(--line);border-radius:8px;padding:12px 14px;margin-bottom:8px}"
    ".step .num{color:var(--muted);font-size:14px;padding-top:3px}"
    ".step .name{font-size:15px;font-weight:600}.step .why{color:var(--muted);font-size:13px;margin-top:2px}"
    ".step input[type=checkbox]{width:17px;height:17px;accent-color:var(--green);margin-top:3px;cursor:pointer}"
    ".step .field{width:100%;margin-top:6px}"
    ".step .field input{width:100%;background:var(--panel);border:1px solid var(--line);border-radius:6px;"
    "color:var(--text);padding:7px 10px;font:13px inherit}"
    ".inputs label{display:block;font-size:13px;color:var(--muted);margin:10px 0 5px}"
    ".inputs textarea,.inputs input[type=text]{width:100%;background:var(--inset);border:1px solid var(--line);"
    "border-radius:6px;color:var(--text);padding:9px 11px;font:14px/1.5 inherit;min-height:38px}"
    ".actions{position:fixed;left:0;right:0;bottom:0;background:#161b22f2;border-top:1px solid var(--line);"
    "backdrop-filter:blur(6px);padding:12px 32px}"
    ".actions .inner{max-width:1180px;margin:0 auto;display:flex;gap:10px;align-items:center;flex-wrap:wrap}"
    ".btn{border-radius:6px;padding:9px 18px;font:600 14px inherit;cursor:pointer;border:1px solid var(--line);"
    "background:#21262d;color:var(--text)}"
    ".btn:hover{filter:brightness(1.18)}.btn:focus-visible{outline:2px solid var(--blue);outline-offset:2px}"
    ".btn.primary{background:#238636;border-color:#2ea043;color:#fff}"
    ".btn.review{border-color:#1f6feb;color:var(--blue)}"
    ".btn.cancel{border-color:#f85149;color:var(--red)}"
    ".btn.subtask{border-color:#1f6feb;color:var(--blue)}"
    ".btn:disabled{opacity:.45;cursor:default}"
    ".toast{margin-left:auto;color:var(--muted);font-size:13px}"
    ".toast.ok{color:var(--green)}"
    ".foot{color:var(--muted);font-size:12px;margin-top:18px;border-top:1px solid var(--line);padding-top:12px}"
    "@media print{.actions{display:none}.wrap{padding:0}}"
)


def _md_inline(s):
    import re
    s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"`(.+?)`", r"<code>\1</code>", s)
    s = re.sub(r"\[(.+?)\]\((.+?)\)", r'<a href="\2">\1</a>', s)
    return s


def _md_to_html(md):
    """Small markdown subset (headings, bullets, bold, code, links) for the bill context."""
    import html as _h
    out, in_ul = [], False
    for raw in (md or "").splitlines():
        line = raw.rstrip()
        if not line.strip():
            if in_ul:
                out.append("</ul>")
                in_ul = False
            continue
        if line.startswith("#"):
            if in_ul:
                out.append("</ul>")
                in_ul = False
            level = len(line) - len(line.lstrip("#"))
            text = line[level:].strip()
            tag = "h%d" % min(max(level, 1), 3)
            out.append("<%s>%s</%s>" % (tag, _md_inline(_h.escape(text)), tag))
            continue
        if line.startswith(("- ", "* ")):
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append("<li>%s</li>" % _md_inline(_h.escape(line[2:])))
            continue
        if in_ul:
            out.append("</ul>")
            in_ul = False
        out.append("<p>%s</p>" % _md_inline(_h.escape(line)))
    if in_ul:
        out.append("</ul>")
    return "".join(out)


def _render_proposal(st, bill, now):
    """Proposal-mode task card: full bill context + review fields + action buttons."""
    steps = st.get("steps", [])
    decision = st.get("decision") or "pending"
    pill_cls = "approved" if decision == "approved" else ("cancelled" if decision in ("cancelled", "cancelled") else "")
    pill_txt = {"pending": "AWAITING YOUR DECISION", "approved": "APPROVED",
                "cancelled": "CANCELLED", "review": "REVIEW REQUESTED",
                "archived": "ARCHIVED"}.get(decision, decision.upper())
    num = _num(st.get("task_id"))
    inputs = st.get("inputs") or []
    rows = []
    for s in steps:
        n = int(s.get("n") or 0)
        needs = s.get("needs_input")
        field = ""
        if needs:
            field = ('<div class="field"><input data-step-input="%d" placeholder="%s"></div>'
                     % (n, _esc(needs)))
        rows.append(
            '<div class="step"><input type="checkbox" class="step-approve" value="%d" aria-label="approve step %d" checked>'
            '<span class="num">%02d</span><div><div class="name">%s</div>%s%s</div></div>'
            % (n, n, n, _esc(s.get("name")), ('<div class="why">%s</div>' % _esc(s.get("why"))) if s.get("why") else "", field))
    input_rows = "".join(
        '<label for="in_%(id)s">%(label)s</label>%(control)s' % {
            "id": _esc(i.get("id")), "label": _esc(i.get("label")),
            "control": ('<textarea id="in_%s" data-input="%s" placeholder="%s"></textarea>' % (
                _esc(i.get("id")), _esc(i.get("id")), _esc(i.get("placeholder"))))
            if i.get("type") == "textarea" else
            ('<input type="text" id="in_%s" data-input="%s" placeholder="%s">' % (
                _esc(i.get("id")), _esc(i.get("id")), _esc(i.get("placeholder"))))}
        for i in inputs)
    js = """
<script>
function updateSel(){
  var all=document.querySelectorAll('.step-approve');
  var sel=document.querySelectorAll('.step-approve:checked');
  var el=document.getElementById('selcount');
  if(el){ el.textContent = sel.length + '/' + all.length + ' approved'; }
}
document.addEventListener('DOMContentLoaded', function(){
  updateSel();
  document.querySelectorAll('.step-approve').forEach(function(c){ c.addEventListener('change', updateSel); });
});
function collect(){
  return {
    note: (document.getElementById('note')||{}).value || '',
    inputs: Object.fromEntries([...document.querySelectorAll('[data-input]')].map(e=>[e.dataset.input,e.value])),
    approve_steps: [...document.querySelectorAll('.step-approve:checked')].map(e=>+e.value),
    step_inputs: Object.fromEntries([...document.querySelectorAll('[data-step-input]')].map(e=>[e.dataset.stepInput,e.value]))
  };
}
function send(type){
  const payload = Object.assign({type}, collect());
  fetch('/api/action', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)})
    .then(r=>r.json())
    .then(res=>{
      const t=document.getElementById('toast');
      if(!res.ok){ t.textContent = '✗ ' + (res.error||'failed'); t.className='toast'; return; }
      t.textContent = '✓ ' + type + ' sent to AGI (#' + res.n + ') — AGI picks it up on its next turn/check';
      t.className='toast ok';
      if(type==='cancel'){ markDecision('CANCELLED'); }
      if(type==='approve'){ markDecision('APPROVED'); }
      if(type==='review'){ markDecision('REVIEW REQUESTED'); }
    })
    .catch(err=>{ const t=document.getElementById('toast'); t.textContent='✗ '+err; t.className='toast'; });
}
function markDecision(label){
  const p=document.querySelector('.pill'); p.textContent=label;
  document.querySelectorAll('.btn').forEach(b=>b.disabled=true);
}
</script>"""
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>AGI proposal - %(title)s</title><style>%(css)s</style></head><body><div class='wrap'>"
        "<div class='top'><div><div class='tid'>AGI PROPOSED TASK %(num)s &middot; %(tid)s</div>"
        "<h1>%(title)s</h1><div class='sub'>bill: %(bill)s</div></div>"
        "<div class='pill %(pillcls)s'>%(pill)s</div></div>"
        "<div class='board'>"
        "<div class='cell'><div class='k'>estimate</div><div class='v'>%(est)s</div></div>"
        "<div class='cell'><div class='k'>steps</div><div class='v'>%(nsteps)s</div></div>"
        "<div class='cell'><div class='k'>requested</div><div class='v'>%(started)s</div></div>"
        "<div class='cell'><div class='k'>status</div><div class='v'>%(decision)s</div></div>"
        "</div>"
        "<div class='panel'><h2>PROPOSAL - FULL CONTEXT</h2><div class='ctx'>%(ctx)s</div></div>"
        "<div class='panel'><h2>STEPS - ALL PRE-SELECTED (uncheck anything you want changed) "
        "<span id='selcount' class='muted' style='font-weight:400;text-transform:none;letter-spacing:0'>"
        "-/%(nsteps)s approved</span></h2>%(rows)s</div>"
        "<div class='panel inputs'><h2>YOUR INPUT (optional)</h2>%(inputrows)s"
        "<label for='note'>Note to AGI</label><textarea id='note' placeholder='e.g. trim W8, or go ahead'></textarea></div>"
        "<div class='actions'><div class='inner'>"
        "<button class='btn primary' onclick=\"send('approve')\">Approve</button>"
        "<button class='btn review' onclick=\"send('review')\">Review</button>"
        "<button class='btn cancel' onclick=\"send('cancel')\">Cancel</button>"
        "<button class='btn' onclick=\"send('archive')\">Archive</button>"
        "<button class='btn subtask' onclick=\"send('subtask')\">Subtask</button>"
        "<span class='toast' id='toast'>your decision is queued for the agent</span>"
        "</div></div>"
        "<div class='foot'>generated %(gen)s &middot; state/task_steps.json (mode=proposal) &middot; "
        "decisions -&gt; state/taskboard_actions.jsonl &middot; source: taskcard.py (verified)</div>"
        "</div>%(js)s</body></html>" % {
            "title": _esc(st.get("title") or "proposal"), "num": num, "tid": _esc(st.get("task_id") or ""),
            "bill": _esc(st.get("bill_task") or "(none)"), "pillcls": pill_cls, "pill": _esc(pill_txt),
            "est": _fmt_s(st.get("estimate_s")), "nsteps": len(steps),
            "started": _esc((st.get("started") or "")[:16].replace("T", " ")),
            "decision": _esc(decision),
            "ctx": st.get("context_html") or "<p>no context provided</p>",
            "rows": "".join(rows), "inputrows": input_rows or "<p class='sub'>no extra fields</p>",
            "css": _PROPOSAL_CSS, "gen": now.strftime("%Y-%m-%d %H:%M:%S"), "js": js,
        })


_CSS = (
    ":root{--bg:#0b0f14;--panel:#131a22;--line:#243040;--txt:#e6edf3;--dim:#8b98a5;"
    "--grey:#5b6672;--amber:#f0a02b;--green:#2ecc71;--red:#ef4b4b}"
    "*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--txt);"
    "font:20px/1.35 'Segoe UI',system-ui,sans-serif}"
    ".wrap{max-width:1180px;margin:0 auto;padding:20px 24px}"
    ".top{display:flex;justify-content:space-between;align-items:flex-start;gap:24px}"
    ".tid{font-size:11px;color:var(--dim);letter-spacing:.08em}"
    "h1{font-size:24px;margin:6px 0 3px;line-height:1.25}"
    ".billname{color:var(--dim);font-size:12px}"
    ".pill{font-size:12px;font-weight:700;padding:4px 14px;border-radius:999px;"
    "border:2px solid var(--line);white-space:nowrap}"
    ".pill.RUNNING{color:var(--amber);border-color:var(--amber)}"
    ".pill.PASSED{color:var(--green);border-color:var(--green)}"
    ".pill.FAILED{color:var(--red);border-color:var(--red)}.pill.DRAFT{color:var(--dim)}"
    ".board{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:12px 0 10px}"
    ".cell{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:7px 10px}"
    ".cell .k{font-size:10px;letter-spacing:.08em;color:var(--dim);text-transform:uppercase}"
    ".cell .v{font-size:16px;font-weight:700;margin-top:2px}.cell .v.small{font-size:12px}"
    ".bar{height:7px;background:var(--panel);border:1px solid var(--line);border-radius:999px;overflow:hidden}"
    ".bar i{display:block;height:100%;background:var(--green);transition:width .4s}"
    ".meta{display:flex;justify-content:space-between;color:var(--dim);font-size:12px;margin:8px 0 12px}"
    ".steps{display:flex;flex-direction:column;gap:6px}"
    ".step{display:grid;grid-template-columns:22px 30px 1fr auto;align-items:center;gap:10px;"
    "background:var(--panel);border:1px solid var(--line);border-left:8px solid var(--grey);"
    "border-radius:8px;padding:8px 12px}"
    ".led{width:15px;height:15px;border-radius:50%;background:var(--grey);display:inline-block}"
    ".num{font-size:12px;color:var(--dim)}.name{font-size:14px;font-weight:600}"
    ".note{font-size:12px;color:var(--dim);margin-top:2px}"
    ".ts{font-size:12px;color:var(--dim)}"
    ".step.passed{border-left-color:var(--green)}.step.passed .led{background:var(--green);"
    "box-shadow:0 0 18px rgba(46,204,113,.85)}"
    ".step.active{border-left-color:var(--amber)}.step.active .led{background:var(--amber);"
    "box-shadow:0 0 18px rgba(240,160,43,.9);animation:pulse 1.1s infinite}"
    ".step.failed{border-left-color:var(--red)}.step.failed .led{background:var(--red);"
    "box-shadow:0 0 18px rgba(239,75,75,.9)}"
    "@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}"
    ".legend{display:flex;gap:16px;color:var(--dim);font-size:12px;margin-top:12px;align-items:center}"
    ".legend .led{width:11px;height:11px;vertical-align:middle;margin-right:6px}"
    ".legend .led.pending{background:var(--grey)}.legend .led.active{background:var(--amber)}"
    ".legend .led.passed{background:var(--green)}.legend .led.failed{background:var(--red)}"
    ".foot{margin-top:14px;color:var(--dim);font-size:11px}"
)


def stage(html):
    """Write the live page into RAM root + the dashboard cache (returns paths)."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import cardkit
    cache = cardkit.sandbox_cache()
    root = os.path.dirname(cache)
    dash = os.path.join(cache, "dashboards")
    os.makedirs(dash, exist_ok=True)
    p1 = os.path.join(root, "task_live.html")
    p2 = os.path.join(dash, "task_live.html")
    for p in (p1, p2):
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(html)
    return p1, p2


def _default_opener(target):
    """Open a local page in D's default browser. No hardcoded browser path (R2)."""
    if hasattr(os, "startfile"):
        os.startfile(str(target))          # Windows: default handler, returns immediately
        return True
    import webbrowser
    return webbrowser.open("file:///" + str(target).replace("\\", "/"))


def open_page(path, opener=None):
    """Open the live board (D requirement: the card is visible the moment it is created)."""
    opener = opener or _default_opener
    try:
        return bool(opener(str(path)))
    except Exception:
        return False


def _publish(path, args=None):
    """Publish the board on the loopback URL the Harness right-sidebar Browser can open.

    The built-in Browser accepts HTTP(S) loopback URLs and rejects file: URLs, so board_serve
    serves the RAM page; the system Chrome is only launched when --open-system is passed.
    """
    url = None
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import board_serve
        url = board_serve.ensure()
    except Exception as e:
        print("warn: board server unavailable:", e)
    if url:
        print("TASK CARD LINK (click it in the chat): %s" % url)
    if args and "--open-system" in args:
        if open_page(path):
            print("opened in the system browser (--open-system):", path)


def cmd_init(args):
    card = _arg(args, "--card") or "task"
    title = _arg(args, "--title") or card
    bill = _arg(args, "--bill") or ""
    plan = _arg(args, "--plan")
    names = []
    if plan:
        p = _load_json(plan, {}) or {}
        names = [str(s.get("name") or "step %d" % (i + 1)) for i, s in enumerate(p.get("steps", []))]
    if not names:
        names = [n for n in (_arg(args, "--steps") or "").split("|") if n.strip()]
    st = {"task_id": card, "title": title, "bill_task": bill,
          "started": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
          "steps": [{"n": i + 1, "name": n, "status": "pending", "ts": "", "note": ""}
                    for i, n in enumerate(names)]}
    save_steps(st)
    bill_e = find_bill(bill)
    p1, p2 = stage(render_page(st, bill_e))
    print("OK taskcard init: %d steps -> %s" % (len(names), STEPS_PATH))
    print("page: %s" % p1)
    _publish(p1, args)


def _read_actions():
    out = []
    try:
        with open(ACTIONS_PATH, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        pass
    return out


def cmd_actions(args):
    """Print the user's queued decisions/inputs from the proposal card (agent side)."""
    try:
        with open(CURSOR_PATH, encoding="utf-8") as fh:
            since = int(json.load(fh).get("last") or 0)
    except Exception:
        since = 0
    if "--since" in args:
        try:
            since = int(args[args.index("--since") + 1])
        except Exception:
            pass
    acts = [a for a in _read_actions() if int(a.get("n") or 0) > since]
    out = {"cursor": since, "count": len(acts), "actions": acts}
    if "--consume" in args and acts:
        last = int(acts[-1].get("n") or 0)
        with open(CURSOR_PATH, "w", encoding="utf-8") as fh:
            json.dump({"last": last}, fh)
        out["consumed_through"] = last
    print(json.dumps(out, indent=1, ensure_ascii=False))
    return 0


def cmd_propose(args):
    """Present a bill as a proposal-mode task card with Approve/Review/Cancel action buttons."""
    card = _arg(args, "--card") or "proposal"
    title = _arg(args, "--title") or card
    bill = _arg(args, "--bill") or ""
    try:
        est = int(_arg(args, "--est-s") or 0)
    except Exception:
        est = 0
    ctx_file = _arg(args, "--context")
    context = ""
    if ctx_file:
        try:
            with open(ctx_file, encoding="utf-8") as fh:
                context = fh.read()
        except Exception as e:
            print("warn: context unreadable:", e)
    names = [n.strip() for n in (_arg(args, "--steps") or "").split("|") if n.strip()]
    needs = {}
    for part in (_arg(args, "--needs") or "").split(";"):
        if ":" in part:
            k, v = part.split(":", 1)
            try:
                needs[int(k.strip())] = v.strip()
            except Exception:
                pass
    steps = [{"n": i + 1, "name": n, "status": "pending", "ts": "",
              "needs_input": needs.get(i + 1, "")} for i, n in enumerate(names)]
    st = {"task_id": card, "title": title, "bill_task": bill, "mode": "proposal",
          "status": "PROPOSED", "decision": "pending", "estimate_s": est,
          "started": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
          "context_html": _md_to_html(context),
          "inputs": [{"id": "extra", "label": "Additional instructions / missing info",
                      "type": "textarea", "placeholder": "anything the proposal should include or change"}],
          "steps": steps,
          "bridge": {"tool": "agi_await_decision3", "task_id": card, "title": title,
                     "hold_s": 600, "required": True,
                     "hint": "call agi_await_decision3 now; a card click then resumes the agent natively"}}
    save_steps(st)
    p1, _ = stage(render_page(st))
    print("OK proposal card: %s (%d steps, est %ds)" % (card, len(steps), est))
    print("BRIDGE REQUIRED: call tool agi_await_decision3(task_id=%r, title=%r, hold_s=600) to arm native "
          "click-to-resume for this card" % (card, title))
    print("page: %s" % p1)
    _publish(p1, args)
    return 0


def cmd_result(args):
    """Record the RESULT block on the current task card (summary + artifact links)."""
    st = load_steps()
    if not st:
        print("no state/task_steps.json")
        return 1
    summary = _arg(args, "--summary") or ""
    links = []
    i = 0
    while i < len(args):
        if args[i] == "--link" and i + 1 < len(args):
            raw = args[i + 1]
            if "=" in raw:
                label, url = raw.split("=", 1)
                links.append({"label": label, "url": url})
            else:
                links.append({"label": "link", "url": raw})
            i += 2
            continue
        i += 1
    st["result"] = {"summary": summary, "links": links,
                    "at": datetime.now().strftime("%Y-%m-%d %H:%M")}
    save_steps(st)
    p1, _ = stage(render_page(st, find_bill(st.get("bill_task"))))
    print("OK result recorded on %s: %s" % (st.get("task_id"), summary[:120]))
    print("page: %s" % p1)
    _publish(p1, args)
    return 0


def cmd_step(args):
    st = load_steps()
    if not st:
        print("no state/task_steps.json - run taskcard.py init first")
        return 1
    n = int(_arg(args, "--n") or 0)
    status = (_arg(args, "--status") or "passed").lower()
    if status not in STATUSES:
        print("invalid status:", status)
        return 1
    target = next((s for s in st["steps"] if int(s.get("n") or 0) == n), None)
    if not target:
        print("no step with n=", n)
        return 1
    target["status"] = status
    target["ts"] = _now_hhmm()
    note = _arg(args, "--note")
    if note:
        target["note"] = note
    save_steps(st)
    # bill evidence moves with the LED: one checkpoint line per transition
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import taskbill
        taskbill.cp_log(st.get("bill_task") or "task",
                        "STEP %d %s: %s" % (n, status, target.get("name")))
    except Exception as e:
        print("warn: checkpoint log failed:", e)
    p1, _ = stage(render_page(st, find_bill(st.get("bill_task"))))
    cnt = summary(st)
    print("OK step %d -> %s | %d/%d passed | status=%s | %s"
          % (n, status, cnt["passed"], cnt["total"], board_status(st), p1))
    return 0


def cmd_render(_args):
    st = load_steps()
    if not st:
        print("no state/task_steps.json")
        return 1
    p1, _ = stage(render_page(st, find_bill(st.get("bill_task"))))
    print("OK taskcard rendered:", p1)
    return 0


def cmd_open(_args):
    st = load_steps()
    if not st:
        print("no state/task_steps.json")
        return 1
    p1, _ = stage(render_page(st, find_bill(st.get("bill_task"))))
    _publish(p1, _args)
    return 0


def _result_html(st):
    """Result block shown on a completed task card: summary + artifact links."""
    res = st.get("result") or {}
    if not res:
        return ""
    links = "".join(
        "<a href='%s' style='display:inline-block;border:1px solid #238636;background:#238636;color:#fff;"
        "border-radius:6px;padding:6px 14px;font:600 13px inherit;margin:2px 6px 2px 0;text-decoration:none'>%s &rarr;</a>"
        % (_esc(l.get("url")), _esc(l.get("label") or l.get("url")))
        for l in (res.get("links") or []))
    return ("<div style='margin:12px 0 2px;padding:12px 14px;background:#0d2818;border:1px solid #238636;border-radius:8px'>"
            "<div style='font-size:12px;letter-spacing:.08em;color:#3fb950;font-weight:700;text-transform:uppercase'>"
            "RESULT</div><div style='font-size:15px;margin:6px 0 8px'>%s</div><div>%s</div>"
            "<div style='color:#8b98a5;font-size:12px;margin-top:6px'>recorded %s</div></div>"
            % (_esc(res.get("summary") or ""), links, _esc(res.get("at") or "")))


_RUNNING_ACTIONS = """
<div class="ract" style="margin-top:12px;padding-top:10px;border-top:1px solid #243040">
  <textarea id="rnote" placeholder="note to AGI (optional)" style="width:100%;min-height:44px;background:#0d1117;color:#e6edf3;border:1px solid #243040;border-radius:8px;padding:8px 10px;font:14px inherit"></textarea>
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
    <button class="rbtn" onclick="rAct('cancel')">Cancel task</button>
    <button class="rbtn" onclick="rAct('archive')">Archive card</button>
    <button class="rbtn" onclick="rAct('subtask')">Create subtask</button>
    <span class="rtoast" id="rtoast" style="color:#8b98a5;font-size:13px;align-self:center">decisions are queued for AGI's next turn</span>
  </div>
</div>
<script>
function rAct(type){
  var note=(document.getElementById('rnote')||{}).value||'';
  fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:type,note:note})})
   .then(function(r){return r.json()}).then(function(res){
     var t=document.getElementById('rtoast');
     t.textContent=(res.ok?'\\u2713 '+type+' queued (#'+res.n+')':'\\u2717 '+(res.error||'failed'));
     t.style.color=res.ok?'#2ecc71':'#ef4b4b';
   }).catch(function(e){document.getElementById('rtoast').textContent='\\u2717 '+e});
}
</script>
<style>.rbtn{background:#21262d;border:1px solid #243040;border-radius:8px;color:#e6edf3;padding:7px 14px;font:600 13px inherit;cursor:pointer}.rbtn:hover{background:#30363d}</style>
"""


def _running_actions_html():
    return _RUNNING_ACTIONS


def cmd_status(_args):
    st = load_steps()
    if not st:
        print("no state/task_steps.json")
        return 1
    cnt = summary(st)
    print("task=%s | bill=%s | status=%s | %d/%d passed (active %d, failed %d)"
          % (st.get("task_id"), st.get("bill_task"), board_status(st),
             cnt["passed"], cnt["total"], cnt["active"], cnt["failed"]))
    for s in st["steps"]:
        print("  %02d [%-7s] %s" % (int(s.get("n") or 0), s.get("status"), s.get("name")))
    return 0


def _arg(args, name):
    if name in args:
        i = args.index(name)
        if i + 1 < len(args):
            return args[i + 1]
    return None


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 0
    cmd = args[0]
    args = args[1:]
    if cmd == "init":
        return cmd_init(args) or 0
    if cmd == "propose":
        return cmd_propose(args) or 0
    if cmd == "actions":
        return cmd_actions(args) or 0
    if cmd == "result":
        return cmd_result(args) or 0
    if cmd == "step":
        return cmd_step(args)
    if cmd == "render":
        return cmd_render(args)
    if cmd == "open":
        return cmd_open(args)
    if cmd == "status":
        return cmd_status(args)
    print(__doc__)
    return 0


if __name__ == "__main__":
    sys.exit(main())

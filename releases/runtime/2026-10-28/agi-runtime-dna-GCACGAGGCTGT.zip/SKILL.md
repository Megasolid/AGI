---
name: agi
description: 'AGI Core v3 - layered portable agent framework; boot from state/, verified-only gates, DNA root at core/dna.md.'
---

# AGI Core v3

`core_version: 3.2` | root artifact: `core/dna.md` (dna_version 3) - this Core is generation gen3.5 of that DNA | precedence: **safety > state SSOT > task > interaction**
This file is a router. It contains zero paths, ports, env values, or model names.
Load detail sections by ID (index below) only when their trigger fires.

---

## Rules

**R1 - Boot from disk, never from memory.** First action every session: read `state/boot.json`. If absent/corrupt/foreign -> run section `boot.md` steps S1-S8 in order. Resume from the first failed step; never reconstruct state from conversation history.
- Every Core path (`state/`, `core/`, `models/`) is relative to memdir — the directory containing this SKILL.md — never your CWD. The host application's default working directory is the session RAM/sandbox when it is outside the AGI tree; BIOS binds and verifies that path for cache use. Never search the sandbox for Core files.
- OK: "boot.json says step 5 failed -> re-run S5, then continue"
- BAD: "last session we used that API port, so it's still valid"

**R2 - Machine facts live only in `state/`.** Core text and MEMORY.md hold no machine values. Missing fact -> run the probe script, write result to `state/`, use it. Never hardcode a path/port/env value into any portable file.
- OK: "venv interpreter unknown -> run env_probe, store in state/env_probe.json"
- BAD: "python is at <hardcoded absolute path> (written into the skill)"

**R3 - Verified-only execution.** A script runs only if `scripts/registry.json` marks it verified; cold data is used only if its `meta.json` is verified. Every mutating action goes through its gate script and obeys the accept/reject JSON returned. (Validator-gate enforcement = phase 2; until then the rule is self-applied.)
- OK: "registry says candidate -> refuse, report status"
- BAD: "run it once to test, then register"

**R4 - Confirm before crossing thresholds.** Ambiguous scope -> ask exactly one question. Download >50MB -> state size + time first, wait for OK. Irreversible action -> state the undo plan by name, wait for explicit approval. Task est >5min -> taskbill estimate, present bill, wait unless already covered by an explicitly approved parent bill; in-scope child bills are nested and may proceed without a second approval, with the report link surfaced on the fly. Expanded scope still needs a revised bill/approval. Any task requiring a user turn or external response is co-op; pause active-time billing while waiting and track that wait separately.
- OK: "this delete cannot be undone; undo plan = restore from backup X - proceed?"
- BAD: just doing it because "it's probably fine"

**R5 - Failure enters maintenance.** On the first failure, stop the failed action and dependent actions; enter maintenance mode and investigate read-only. The recovery handoff must include a timestamped debug report, a diagnosed cause, a bounded solution, impact, and an updated task bill before asking whether to resume. Resume a disrupted non-co-op task only when the cause is understood, recovery is bounded and safe, and confidence is HIGH (>0.90 with current-session evidence); otherwise mark it co-op and report the blocker to D. For a critical error, issue at most one immediate barkback only when confidence is >0.90; otherwise switch to co-op and report without autonomous recovery. Confidence never overrides safety, authorization, or irreversible-action gates.
- The maintenance card is generated as a producer whenever the AGI system map is generated; the system map and live dashboard must reflect the same maintenance state.
- OK: "verification failed -> maintenance -> evidence/report -> bill update -> bounded recovery"
- BAD: retrying the same call 3 times hoping, or silently continuing past the failure

**R6 - Structured I/O.** Tool calls and results use fixed envelopes `{op, args, expect, result, state_delta}`. If the host model has no native tool calling (per its profile), use the fenced-block fallback protocol from `memory-ops.md §IO`. Correctness never depends on prose formatting.

**R7 - Model profile.** At boot select `models/<profile>.md` per `state/` (context limit, tool dialect, quirks, degraded modes). Follow that profile's dialect; when a capability is missing use the documented degraded mode, never a silent assumption. No model names appear in this file.

**R8 - Write back, then version.** After any task: durable portable facts -> MEMORY.md/knowledge (replace whole line, no append); machine facts -> `state/`. Significant memory changes -> repack bundle + update manifest. A model is "supported" only after passing `tests/conformance/` for this `core_version`.

**R9 - Environment gate.** No crossing sandbox <-> Real Env (launching external apps, reading/writing real user profile data, connecting to user-session services) without the `env-gate` protocol: detect faked env, pin real values before launch, then verify where the process actually landed. Details: section `env-gate.md`; SSOT: `memory/knowledge/os-gate.md`.
- OK: "launching external app -> env pinned + data dir verified via path-revealing artifact"
- BAD: launching from faked-env shell and assuming it hit the user's real profile

**R10 - Interaction-first (cards are the contract).** A consequential decision and the state of live work are projected
to the host's human interaction surface as a durable, reviewable card; chat is only a pointer to it.
- Lifecycle: **proposal -> running -> result**. A proposal card carries the full bill context, the step list
  pre-selected by default, per-step optional inputs, and one primary action (Approve) plus Review / Cancel / Archive /
  Subtask.
- The user's decision is appended to a durable decision log and **resumes the agent**: use the host's native
  interaction seam when it exposes one (event-driven resume), otherwise a bounded fallback (<=60 s) with the true state
  visible on the card (queued / notified / running).
- `state/interaction.json` declares the active resume path, measured latency, card-schema version and the decision log;
  cards are projections of `state/` (SSOT), never a second source of truth. The protocol lives in section
  `interaction.md`; visual standards are L3 knowledge (`memory/knowledge/ui-dashboard.md`).
- OK: "approve -> decision logged -> agent resumed -> running card green"
- BAD: a consequential approval only in prose with no durable card/record, or a card that silently waits with no state

**R11 - Proportionality (no approval fatigue).** Full proposal-card ceremony only for consequential work (R4
thresholds: est >5min, >=5 steps, irreversible or scope-changing). Routine reversible work gets a lightweight card or
one-line note and proceeds; trivial edits get no ceremony. One primary action per card; the decision carries the whole
form (note, steps, inputs). This rule exists so R10 never turns every micro-task into a gate.
- OK: "5-minute doc fix -> one-line record; 40-minute migration -> full proposal card"
- BAD: a full proposal card for a typo, or an irreversible change approved only in chat

---

## Boot sequence (idempotent, resumable; each step writes a checkpoint to state/boot.json)

| Step | Action | On failure |
|---|---|---|
| S0 | BIOS binds RAM to `AGI_RAM_ROOT` or the host application's default CWD, initializes `cache/`, verifies its marker, and persists the resolved path in `boot_card.json` | enter maintenance (R5); do not silently fall back to an unrelated app sandbox |
| S1 | Load `state/`; detect foreign/missing -> copy bundle's `state.template/` as fresh state | stop -> ask D |
| S2 | Verify source hashes against `core_manifest.json`; verify `agi_core_v3.tar.gz` with the registered packer when present | enter maintenance (R5); list mismatches and hold full boot until integrity is restored |
| S3 | Probe capabilities: fs / shell / network / subagents / max-context; write results to state | missing cap -> degraded mode per profile, logged |
| S4 | Run machine probe (paths, venv, ports, hw, permission status) -> `state/env_probe.json` | stop -> ask D |
| S5 | Select model profile from `models/` — evidence-based: resolve the running model from state (env probe, else host session model); report the matched profile or `unprofiled` + documented degraded mode; record the `(profile x core_version x host)` compatibility row; never a silent default | `unprofiled` + degraded mode, logged |
| S6 | Smoke tests: one read op, one script ping, one pool ping | enter maintenance workflow (R5); continue boot only after bounded recovery |
| S7 | Write `boot.json: ready` + ts | - |
| S8 | Generate subsystem cards (including maintenance) and AGI SYSTEM MAP from state; generate the **served AGI site v3** (dashboard, per-card pages, system dashboard, maintenance page) and the live task card into the season cache via verified `dashboards.py` / `sitegen.py`, served over the loopback card link; verify the internal links resolve | enter maintenance workflow (R5); boot may continue degraded only if the failure is non-critical and recorded |

After BIOS/S8, inspect `boot_card.json:embedding_adoption`. The backend defaults to `internal`; if `needs_user_choice=true`, ask D whether to set `AGI_INTERNAL_EMBEDDING_MODEL` to an existing local model directory. Do not guess a model path, download a model, or block core boot/index-independent work. If configured, report the resolved state without exposing secrets; if declined, leave embedding/indexing unavailable and retain the prompt for a later cold boot.

---

## Section index (load by ID when trigger fires)

| ID | File | Load when |
|---|---|---|
| boot | core/sections/boot.md | R1 fired / capability probe needed |
| migrate-repair | core/sections/migrate-repair.md | bundle restore on new machine, or core_version bump repair |
| check-report | core/sections/check-report.md | D asks for machine status / report page |
| memory-ops | core/sections/memory-ops.md | any memory read/write beyond R8 basics, or IO fallback needed |
| work-gates | core/sections/work-gates.md | task billing detail, escalation, temp checkpoints |
| agent-pool | core/sections/agent-pool.md | delegating a subtask to the LLM pool |
| mcp-bundle | memory/tools/mcp-bundle.md | connecting to configured MCP providers over stdio or Streamable HTTP |
| blender-kb | core/sections/blender-kb.md | any Blender task (capability-gated) |
| chrome-data | core/sections/chrome-data.md | Chrome profile/bookmark work (capability-gated) |
| env-gate | core/sections/env-gate.md | any action crossing sandbox <-> Real Env (launching external apps, real user data, session services) |
| interaction | core/sections/interaction.md | presenting/approving a proposal card, running a card-visible task, or declaring the resume path (R10/R11) |
| seed | core/sections/seed.md | boot with no bundle carried (fallback only) |
| confidence | core/sections/confidence.md | uncertainty, confidence claims, or failure recovery |
| watchdogs | memory/scripts/watchdogs.py | recording or resolving high-confidence predictions; prediction holds |

---

## Gate checklist (binding, every turn)

- [ ] Boot verified from disk (R1)?
- [ ] No machine value outside `state/` (R2)?
- [ ] Scripts verified / data meta-verified (R3)?
- [ ] Thresholds confirmed before crossing (R4)?
- [ ] Failure routed through maintenance, debug report, and bill update (R5)?
- [ ] Co-op waits paused from machine-active billing and recorded separately?
- [ ] High-confidence actions have a prediction entry; mismatches are guarded by Watch Dogs?
- [ ] Structured I/O used (R6)? Profile dialect honored (R7)?
- [ ] Environment gate honored before any Real-Env crossing (R9)?
- [ ] Consequential decision shown as a durable card with full context, pre-selected steps and one primary action (R10)?
- [ ] Human decision logged durably and the declared resume path used, with the true state visible (R10)?
- [ ] Proportionality respected — no card ceremony for routine/trivial work (R11)?
- [ ] Durable facts written back; bundle repacked if significant (R8)?

---

## Defaults in force (D-approved)
1. Rules R1-R11 (R10/R11 added 2026-10-25 by the founding promotion, D sign-off on the proposal card).
2. Profiles: per-model adapters in `models/`; S5 is evidence-based since gen3.4 (no silent default).
3. Card contract: proposal -> running -> result; proposal steps pre-selected by default; decisions durable in
   `state/taskboard_actions.jsonl`; resume path declared in `state/interaction.json`.
4. Bundle: `agi_core_v3_2_interaction.tar.gz`, manifest field `core_version: 3.2` / `dna_version: 3`.

---

## Resident mode (native self-continuation)
A turn ends when the agent answers; to keep working autonomously, AGI arms a **resident loop**:
- `memory/scripts/resident.py --arm --hours H --cadence S` persists `state/resident/mode.json` and a plan queue
  (`state/resident/plan.json`).
- The agent creates a harness reminder with `schedule_create` (recurring `every_seconds`) whose prompt says:
  run `resident.py --pulse`, execute the returned plan item for real, mark it done, keep the reply short.
- Each pulse wakes the agent, does one plan item (evidence doc/tests/state/log), calls `resident.py --complete`,
  and confirms the next pulse exists.
- `resident.py --disarm` (or an expired window / completed plan) makes the next pulse reply only "resident idle".
- The resident loop obeys the same gates: invariants, human-only approvals unless a recorded delegation exists.
- `/resident` page shows mode, plan progress and the next item.

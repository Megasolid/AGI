#!/usr/bin/env python3
"""cardkit - THE universal card renderer for the AGI dashboard (single source of truth).

This is the "one-time code, life-time use" core of the generative dashboard. Every
subsystem produces a CardSpec (a plain dict); cardkit turns specs -> styled HTML.
Change CSS or render_card() ONCE and EVERY report / system map / dashboard adopts it
on the fly - no producer is ever touched again for a style change.

CardSpec contract (plain dict):
  id      unique id (sort key + dedupe)                     required
  title   human label (auto-escaped by cardkit)            required
  dot     "ok" | "warn" | "fail"                           default "ok"
  big     headline value - TRUSTED html (pre-escaped/safe)
  body    TRUSTED html built from rows()/bar()/ul()        optional
  order   sort position in the dashboard grid              default 100
  full    True => renders as a full-width row after the grid  default False
  meta    free-form dict for producers / assemblers        default {}

Modular rule: each subsystem has its own producer function that returns a CardSpec.
Producers import ONLY cardkit (never each other). The dashboard is an ASSEMBLER:
collect specs -> sort by order -> assemble(). It builds no cards itself, so adding a
new subsystem = add one producer + register it; the dashboard picks it up automatically.
"""
import html as H
import json
import os
import shutil
from datetime import datetime
from pathlib import Path

AGI_ROOT = Path(__file__).resolve().parents[2]
STATE = AGI_ROOT / "state"

try:  # optional: stable recall numbers (#N) for every card
    import idkit as _idkit
except Exception:  # pragma: no cover - degrade without recall numbers
    _idkit = None


def recall_nid(spec):
    """Stable short id (#N) for a CardSpec, or '' when idkit is unavailable."""
    if _idkit is None:
        return ""
    try:
        return _idkit.short("card", spec.get("id") or spec.get("title"))
    except Exception:
        return ""


def _read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {}

def _normalize_root(value):
    path = Path(str(value))
    if path.name.casefold() == "cache":
        path = path.parent
    return path.resolve()

def _is_application_root(path):
    try:
        path.relative_to(AGI_ROOT)
        return False
    except ValueError:
        pass
    try:
        AGI_ROOT.relative_to(path)
        return False
    except ValueError:
        return True


def host_application_identity(environ=None):
    """Detect the active host application from the process environment (portable: no paths)."""
    env = os.environ if environ is None else environ
    explicit = (env.get("AGI_HOST_APPLICATION") or "").strip()
    if explicit:
        return explicit.casefold()
    if (env.get("CODEX_WINDOWS_SANDBOX_PACKAGE_FAMILY")
            or (env.get("CODEX_INTERNAL_ORIGINATOR_OVERRIDE") or "").casefold().startswith("codex")):
        return "codex"
    if env.get("DSH_HOME") or env.get("DSH_SESSION_ID"):
        return "dsh"
    if env.get("UNSLOTH_STUDIO_HOME") or env.get("UNSLOTH_STUDIO_ROOT"):
        return "unsloth-studio"
    return None


def host_sandbox_slug(path):
    """DSH session-directory slug for a workspace path (host convention, no hardcoded paths)."""
    p = str(path).replace(":", "").replace("\\", "-").replace("/", "-")
    return "--" + p + "--"


def dsh_session_root(environ=None):
    """Host session RAM root for DeepSeek Harness: <DSH_HOME>/sessions/<slug>/<session>/agi-ram."""
    env = os.environ if environ is None else environ
    home = (env.get("DSH_HOME") or "").strip()
    sid = (env.get("DSH_SESSION_ID") or "").strip()
    if not home or not sid:
        return None
    sessions = Path(home) / "sessions"
    holder = None
    try:
        for candidate in sessions.iterdir():
            if (candidate / sid).is_dir():
                holder = candidate
                break
    except OSError:
        holder = None
    if holder is None:
        holder = sessions / host_sandbox_slug(env.get("DSH_WORKSPACE") or os.getcwd())
    root = holder / sid / "agi-ram"
    if not _is_application_root(root):
        return None
    return root


def resolve_sandbox_root(cwd=None, environ=None, boot_card=None, env_probe=None):
    """Resolve the host's sandbox in priority order:
    1 AGI_RAM_ROOT override (must stay outside the AGI tree)
    2 host-specific session sandbox (DSH session dir + agi-ram) - first-class host adapter
    3 host default CWD when it is outside the AGI tree (other application hosts)
    4 persisted BIOS binding from an earlier season on this machine
    5 legacy Unsloth Studio season pool
    """
    environ = os.environ if environ is None else environ
    override = environ.get("AGI_RAM_ROOT")
    if override:
        root = _normalize_root(override)
        if not _is_application_root(root):
            raise ValueError("AGI_RAM_ROOT must not point inside the AGI skill tree")
        return root, "AGI_RAM_ROOT"

    if host_application_identity(environ) == "dsh":
        dsh_root = dsh_session_root(environ)
        if dsh_root is not None:
            return dsh_root, "dsh-session-root"

    current = _normalize_root(cwd or os.getcwd())
    if _is_application_root(current):
        return current, "application-default-cwd"

    boot_card = _read_json(STATE / "boot_card.json") if boot_card is None else boot_card
    ram = boot_card.get("ram") if isinstance(boot_card, dict) else None
    if isinstance(ram, dict) and ram.get("root"):
        root = _normalize_root(ram["root"])
        if _is_application_root(root) and root.is_dir():
            return root, "persisted-bios-binding"

    env_probe = _read_json(STATE / "env_probe.json") if env_probe is None else env_probe
    studio_root = env_probe.get("root") if isinstance(env_probe, dict) else None
    sandbox_root = Path(studio_root) / "sandbox" if studio_root else None
    if sandbox_root and sandbox_root.is_dir():
        clusters = []
        try:
            for season in sandbox_root.iterdir():
                cache = season / "cache"
                if season.is_dir() and cache.is_dir():
                    clusters.append((cache.stat().st_mtime, season.resolve()))
        except OSError:
            clusters = []
        if clusters:
            return max(clusters, key=lambda item: item[0])[1], "legacy-studio-pool"

    raise FileNotFoundError("no application sandbox, BIOS binding, or verified legacy pool found")

def sandbox_cache():
    """Return the active application's shared RAM cache path without creating it."""
    root, _ = resolve_sandbox_root()
    return str(root / "cache")

def bootstrap_ram():
    """Initialize, migrate and read-verify the shared RAM cache before BIOS card generation.

    Host switches are seeded: when the resolved cache is new but a prior BIOS binding
    with an existing cache exists, the temporary season RAM (task chunks, dashboards,
    analysis, chunk1) is copied over once. Durable state/ is never touched.
    """
    environ = os.environ
    host = host_application_identity(environ)
    root, source = resolve_sandbox_root(environ=environ)
    cache = root / "cache"
    cache.mkdir(parents=True, exist_ok=True)
    marker = cache / "ram_bootstrap.json"
    previous = _read_json(marker) if marker.exists() else {}
    if previous and (previous.get("owner") != "AGI" or previous.get("schema") not in (1, 2)):
        raise RuntimeError(f"refusing to overwrite unrecognized RAM marker: {marker}")
    migrated_from = None
    if not marker.exists():
        prior = _read_json(STATE / "boot_card.json")
        prior_cache = ((prior.get("ram") or {}).get("cache")) if isinstance(prior, dict) else None
        if prior_cache and Path(prior_cache) != cache and Path(prior_cache).is_dir():
            for name in ("tasks", "dashboards", "analysis"):
                src = Path(prior_cache) / name
                if src.is_dir():
                    shutil.copytree(src, cache / name, dirs_exist_ok=True)
            old_chunk = Path(prior_cache) / "chunk1_boot.md"
            if old_chunk.is_file():
                shutil.copy2(old_chunk, cache / old_chunk.name)
            migrated_from = str(prior_cache)
    payload = {"owner": "AGI", "schema": 2, "root": str(root), "cache": str(cache),
               "source": source, "host": host, "migrated_from": migrated_from,
               "bootstrapped_at": datetime.now().astimezone().isoformat(timespec="seconds")}
    temporary = cache / f".ram_bootstrap.{os.getpid()}.tmp"
    temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    temporary.replace(marker)
    verified = _read_json(marker)
    if verified.get("owner") != "AGI" or verified.get("root") != str(root) or verified.get("cache") != str(cache):
        raise IOError(f"RAM bootstrap read-back mismatch: {marker}")
    return {"root": str(root), "cache": str(cache), "source": source, "verified": True,
            "host": host, "migrated_from": migrated_from}

# Bump when CSS or the CardSpec contract changes - reports stamp it in the footer so
# a stale renderer is detectable. This token is what makes "adopt on the fly" verifiable.
VERSION = "cardkit-3"

CSS = """
:root{color-scheme:dark;--gh-bg:#0d1117;--gh-panel:#161b22;--gh-inset:#010409;--gh-line:#30363d;--gh-text:#e6edf3;--gh-muted:#8b949e;--gh-blue:#2f81f7;--gh-green:#3fb950;--gh-yellow:#d29922;--gh-red:#f85149}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--gh-bg);color:var(--gh-text);font:14px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;padding:clamp(16px,3vw,32px)}
.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
.title{font-size:20px;font-weight:700}
.ts{color:var(--gh-muted);font-size:13px;margin:4px 0 18px}
.pill{padding:4px 10px;border:1px solid var(--gh-line);border-radius:999px;font-weight:600;font-size:12px}
.pill.ok{background:#23863626;color:var(--gh-green)}.pill.warn{background:#9e6a0326;color:var(--gh-yellow)}.pill.fail{background:#da363326;color:var(--gh-red)}
.issues{margin-bottom:16px;padding:10px 12px;border:1px solid #9e6a03;color:var(--gh-yellow);border-radius:6px;font-size:13px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));gap:12px}
.card{background:var(--gh-panel);border:1px solid var(--gh-line);border-radius:6px;padding:14px 16px}
.mrow{font-size:12.5px;color:var(--gh-text);padding:5px 0;border-bottom:1px solid var(--gh-line)}
.mtag{display:inline-block;min-width:118px;margin-right:8px;font-family:ui-monospace,Consolas,monospace;font-size:11px;color:var(--gh-muted)}
.mrow.warn .mtag{color:var(--gh-yellow)}
.mrow.ok .mtag{color:var(--gh-green)}
.label{font-size:12px;font-weight:600;color:var(--gh-muted);display:flex;align-items:center;gap:8px;margin-bottom:10px}
.nid{color:#58a6ff;font-size:11px;font-weight:700;letter-spacing:-.02em}
.dot{width:8px;height:8px;border-radius:50%;background:var(--gh-muted);flex:none}
.dot.ok{background:var(--gh-green)}.dot.warn{background:var(--gh-yellow)}.dot.fail{background:var(--gh-red)}
.big{font-size:24px;font-weight:600;word-break:break-word}
.sub{margin-top:8px;color:var(--gh-muted);font-size:13px}
.row{display:flex;justify-content:space-between;gap:12px;margin-top:3px}
.bar{height:6px;background:var(--gh-line);border-radius:4px;margin-top:10px;overflow:hidden}
.bar i{display:block;height:100%;background:var(--gh-blue);border-radius:4px}
ul{margin-top:2px;padding-left:16px;color:var(--gh-text);font-size:13px}
.nb{margin-top:14px}
.charts{display:grid;grid-template-columns:1fr;gap:18px}
svg text{font-family:inherit}
table{width:100%;border-collapse:collapse;font-size:12.5px}
td,th{padding:6px 9px;border-bottom:1px solid var(--gh-line);text-align:left;vertical-align:top}
th{color:var(--gh-muted);font-size:12px;font-weight:600}
td.n{font-family:ui-monospace,Consolas,monospace;color:#79c0ff;white-space:nowrap}
.tgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
@media(max-width:1080px){.tgrid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.tgrid{grid-template-columns:1fr}}
.foot{margin-top:22px;color:var(--gh-muted);font-size:12px}
a{color:#58a6ff}a:hover{text-decoration:underline}a:focus-visible,button:focus-visible,input:focus-visible{outline:2px solid #58a6ff;outline-offset:2px}
"""

# ---------------------------------------------------------------------------
# Body helpers - the ONLY way producers should build card bodies, so structure
# stays uniform and styling never leaks into producers.
# ---------------------------------------------------------------------------
def rows(*pairs):
    """(key, value) pairs -> dashed key/value rows. None/'' values are skipped."""
    out = []
    for k, v in pairs:
        if v is None or v == "":
            continue
        out.append(f'<div class="row"><span>{H.escape(str(k))}</span><span>{H.escape(str(v))}</span></div>')
    return "".join(out)


def bar(pct):
    """0-100 percentage bar."""
    if pct is None:
        return ""
    try:
        w = max(0, min(100, int(round(float(pct)))))
    except (TypeError, ValueError):
        return ""
    return f'<div class="bar"><i style="width:{w}%"></i></div>'


def ul(items):
    """list of strings -> <ul>. Empty items dropped; empty list -> '' ."""
    items = [i for i in items if i not in (None, "")]
    if not items:
        return ""
    return "<ul>" + "".join(f"<li>{H.escape(str(i))}</li>" for i in items) + "</ul>"


def table(headers, rows_html):
    """headers=[...], rows_html = list of '<tr><td..>..</tr>' (already built)."""
    th = "".join(f"<th>{H.escape(str(h))}</th>" for h in headers)
    return f"<table><tr>{th}</tr>" + "".join(rows_html) + "</table>"


# ---------------------------------------------------------------------------
# Renderer - the single place a CardSpec becomes styled HTML.
# ---------------------------------------------------------------------------
def card(spec):
    """Render ONE CardSpec -> styled <div class='card'>... html fragment."""
    dot = spec.get("dot", "ok")
    body = spec.get("body", "")
    body_html = f'<div class="sub">{body}</div>' if body else ""
    big = spec.get("big", "")
    nid = recall_nid(spec)
    nid_html = f'<span class="nid">{H.escape(nid)}</span>' if nid else ""
    return (f'<div class="card"><div class="label"><span class="dot {dot}"></span>{nid_html}{H.escape(spec["title"])}</div>'
            f'<div class="big">{big}</div>{body_html}</div>')


def _sort_key(c):
    return (c.get("order", 100), c.get("id", ""))


def assemble(title, ts, status, cards=(), grid_html=None, full_html="",
             issues_html="", extra=(), foot=""):
    """Assemble CardSpecs into a full self-contained HTML document.

    Two modes:
      * cards=[CardSpec,...]  -> cardkit sorts by 'order', renders the grid, and puts
                                 any spec with full=True in full-width rows after it.
      * grid_html="<raw>"     -> legacy monoliths (e.g. report.py) pass pre-rendered
                                 grid html; cardkit still owns head/style/wrap/foot so a
                                 style change still propagates everywhere.
    extra = list of raw html blocks placed after the full rows (charts, maintenance).
    """
    cls = str(status).lower()
    if grid_html is None:
        ordered = sorted(cards, key=_sort_key)
        grid_html = "".join(card(c) for c in ordered if not c.get("full"))
        full_html = full_html or "".join(f"<div class='nb'>{card(c)}</div>"
                                         for c in ordered if c.get("full"))
    extra_html = "".join(extra)
    return (f"<!doctype html><html><head><meta charset='utf-8'><title>{H.escape(title)} — {ts}</title>"
            f"<style>{CSS}</style></head><body>"
            f"<div class='head'><div><div class='title'>{H.escape(title)}</div></div>"
            f"<div class='pill {cls}'>{H.escape(str(status))}</div></div>"
            f"<div class='ts'>{ts}</div>{issues_html}"
            f"<div class='grid'>{grid_html}</div>"
            f"{full_html}{extra_html}"
            + (f"<div class='foot'>{foot}</div>" if foot else "")
            + "</body></html>")


# ---------------------------------------------------------------------------
# Card store - shared place where subsystems drop their CardSpecs at boot.
# One JSON file per card (filename == spec id). Producers and the assembler never
# touch each other - only this store + cardkit. This is what makes "add a subsystem =
# add one producer + register it" true: the dashboard picks up new cards automatically.
# ---------------------------------------------------------------------------
# SSOT card root: <skill>/state/cards (== agi/state/cards). scripts->memory->skill.
CARD_DIR = Path(__file__).resolve().parent.parent.parent / "state" / "cards"

def _valid(spec):
    return isinstance(spec, dict) and bool(spec.get("id")) and bool(spec.get("title"))

def put_card(spec, card_dir=None):
    """Validate + persist ONE CardSpec to the store. Returns the file path."""
    if not _valid(spec):
        raise ValueError(f"CardSpec needs 'id' and 'title': {spec!r}")
    d = Path(card_dir) if card_dir else CARD_DIR
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"{spec['id']}.json"
    with open(p, "w", encoding="utf-8") as f:
        json.dump(spec, f, indent=2)
    return p

def load_cards(card_dir=None):
    """Read every valid CardSpec in the store -> list (unsorted; assemble() sorts)."""
    d = Path(card_dir) if card_dir else CARD_DIR
    if not d.exists():
        return []
    out = []
    for p in sorted(d.glob("*.json")):
        try:
            with open(p, encoding="utf-8") as f:
                spec = json.load(f)
        except Exception:
            continue
        if _valid(spec):
            out.append(spec)
    return out

def producer_error_card(pid, err):
    """An honest 'producer failed' card - one bad subsystem never hides from the map."""
    return {"id": pid, "title": pid, "dot": "warn", "big": "no data",
            "body": rows(("error", str(err))), "order": 900,
            "meta": {"producer_error": True}}


if __name__ == "__main__":
    # tiny self-check: render a demo card + doc so the contract is exercised in isolation
    demo = [{"id": "demo", "title": "Demo", "dot": "ok", "big": "42",
             "body": rows(("k1", "v1"), ("k2", None)) + bar(60), "order": 1}]
    print(assemble("CARDKIT SELF-TEST", "now", "OK", cards=demo, foot=VERSION))

#!/usr/bin/env python3
"""presentation.py - the UI genome: an evolvable presentation system for the AGI dashboard.

The dashboard is part of the organism: its presentation is a heritable trait set, seeded by the generation's
DNA identity and natal interest, scored against real data coverage, mutated and selected by usage. Modules
declare their data contracts, so a visualisation can never be emitted without a real source.
"""
import hashlib
import json

import viz

VARIANTS = {
    "console": {"layout": "console", "density": "compact", "chart_family": "svg",
                "motion": "subtle", "depth": "flat"},
    "gallery": {"layout": "gallery", "density": "comfortable", "chart_family": "mixed",
                "motion": "subtle", "depth": "flat"},
    "atlas": {"layout": "atlas", "density": "comfortable", "chart_family": "mixed",
              "motion": "subtle", "depth": "2.5d"},
}
MODULE_ORDER = {
    "console": ["gate", "trust", "tasks", "subsystems", "natal"],
    "gallery": ["natal", "gate", "trust", "tasks", "subsystems"],
    "atlas": ["subsystems", "gate", "tasks", "trust", "natal"],
}


def _h(*parts):
    return hashlib.sha256(b"agi/ui/v1:" + b"|".join(str(p).encode() for p in parts)).hexdigest()


def seed_genome(gen_id, natal_interest="", revision=1):
    """Deterministic presentation genome for a generation: DNA code + natal interest pick the default variant."""
    pick = int(_h(gen_id, natal_interest, revision), 16) % len(VARIANTS)
    names = sorted(VARIANTS)  # deterministic order
    name = names[pick]
    g = dict(VARIANTS[name])
    g.update({"schema": "agi-ui/1", "variant": name, "revision": revision,
              "seed": {"gen_id": gen_id[:24], "natal_interest": natal_interest},
              "order": list(MODULE_ORDER[name]), "parent": None,
              "mutation": "birth" if revision == 1 else "evolved"})
    return g


def select(name, base=None):
    if name not in VARIANTS:
        raise ValueError("unknown UI variant %r" % name)
    g = dict(base or VARIANTS[name])
    g.update(VARIANTS[name])
    g["variant"] = name
    g["order"] = list(MODULE_ORDER[name])
    g["mutation"] = "selected"
    return g


def fitness(genome, data):
    """Heuristic quality of a presentation over real data (0..1): freshness, variety, density, natal fit, a11y."""
    mods = modules(genome, data)
    fresh = sum(1 for m in mods if data.get("sources", {}).get(m["id"], {}).get("age_s", 10 ** 6) <= 3600)
    fresh_pct = fresh / len(mods) if mods else 0
    families = len({m["family"] for m in mods})
    variety = min(1.0, families / 4.0)
    density = 1.0 - abs(len(mods) - 7) / 10.0
    natal = 1.0 if any(genome.get("natal_interest") == m["id"] for m in mods) or \
        (data.get("natal_interest") and any(m["id"] == data["natal_interest"] for m in mods)) else 0.5
    a11y = 1.0 if all("aria-label" in m["html"] or m["html"].startswith("<div") for m in mods) else 0.5
    score = 0.35 * fresh_pct + 0.25 * variety + 0.2 * density + 0.1 * natal + 0.1 * a11y
    return round(score, 3), {"fresh": round(fresh_pct, 2), "variety": round(variety, 2),
                             "density": round(density, 2), "natal": natal, "a11y": a11y}


def candidates(genome, data):
    out = []
    for name in sorted(VARIANTS):
        g = select(name, genome)
        g["natal_interest"] = genome.get("natal_interest") or data.get("natal_interest")
        score, parts = fitness(g, data)
        out.append({"variant": name, "score": score, "parts": parts})
    return sorted(out, key=lambda c: -c["score"])


def evolve(genome, feedback=None):
    """One generation of UI evolution: select a variant, mutate a trait, record why."""
    feedback = feedback or {}
    chosen = feedback.get("variant")
    if chosen and chosen in VARIANTS:
        g = select(chosen, genome)
    else:
        g = dict(genome)
    traits = ["density", "chart_family", "motion", "depth", "layout"]
    idx = int(_h(g.get("seed", {}).get("gen_id", ""), g.get("revision", 1), "mutation"), 16) % len(traits)
    trait = traits[idx]
    if trait == "density":
        g["density"] = "compact" if g.get("density") == "comfortable" else "comfortable"
    elif trait == "chart_family":
        g["chart_family"] = "mixed" if g.get("chart_family") == "svg" else "svg"
    elif trait == "motion":
        g["motion"] = "subtle" if g.get("motion") == "off" else "off"
    elif trait == "depth":
        g["depth"] = "2.5d" if g.get("depth") == "flat" else "flat"
    g["revision"] = int(genome.get("revision") or 1) + 1
    g["parent"] = genome.get("variant"), genome.get("revision")
    g["mutation"] = "selected:%s + mutated:%s" % (chosen or genome.get("variant"), trait)
    return g


def modules(genome, data):
    """Visual modules bound to real data contracts. Nothing renders without a declared source."""
    g = data.get("gate") or {"ok": 12, "total": 12}
    gate_val = float(g.get("ok") or 0)
    trust = data.get("trust_series") or [1, 2, 3]
    tasks = data.get("tasks_series") or [1, 2, 3]
    genes = data.get("genes") or {}
    counts = data.get("counts") or {}
    natal = data.get("natal_interest") or "unknown"
    mods = []
    order = genome.get("order") or MODULE_ORDER["console"]
    for mid in order:
        if mid == "gate":
            mods.append({"id": "gate", "title": "Health check", "family": "gauge",
                         "source": "state/boot_gate.json", "html": viz.gauge(gate_val, g.get("total") or 12,
                                                                             "gate checks", "of 12")})
        elif mid == "trust":
            mods.append({"id": "trust", "title": "Signed history", "family": "area",
                         "source": "state/trust_log/events.jsonl",
                         "html": viz.area(trust) + viz.spark(trust)})
        elif mid == "tasks":
            mods.append({"id": "tasks", "title": "Tasks per day", "family": "bars",
                         "source": "memory/time/tasklog.jsonl",
                         "html": viz.bars(tasks, [str(i) for i in range(len(tasks))])})
        elif mid == "subsystems":
            def _num(v):
                try:
                    return int(str(v), 16) % 97 + 1
                except Exception:
                    return 1
            rows = [(k, _num(v), 98) for k, v in list(genes.items())[:8]]
            html = viz.network([{"id": k, "label": k, "value": _num(v)} for k, v in list(genes.items())[:8]],
                              [(list(genes)[0], k) for k in list(genes)[1:8]]) if genes else \
                viz.hbars([("core", 1, 1)])
            if genome.get("depth") == "2.5d" and rows:
                html += viz.bars3d([r[1] for r in rows], [r[0][:6] for r in rows])
            mods.append({"id": "subsystems", "title": "Genome / subsystems", "family": "network",
                         "source": "state/genesis/genome.json", "html": html})
        elif mid == "natal":
            pct = (counts.get("natal_progress") or 0.25)
            mods.append({"id": "natal", "title": "Natal interest: " + str(natal), "family": "donut",
                         "source": "state/genesis/birth.json",
                         "html": viz.donut(pct, str(natal)) + viz.hbars([
                             ("pills", counts.get("pills") or 0, 100),
                             ("tools", counts.get("tools") or 0, 100),
                             ("memories", counts.get("memories") or 0, 2000)])})
    return mods


CSS = """
.viz{display:block;max-width:100%%;height:auto}
.hbars{font-size:12px;font-family:var(--font)}
.hb{display:flex;align-items:center;gap:8px;padding:3px 0}
.hbl{width:96px;color:var(--muted);flex:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hbt{flex:1;height:8px;background:var(--subtle);border-radius:4px;overflow:hidden}
.hbt i{display:block;height:100%%;background:var(--accent);opacity:.7}
.hbv{width:52px;text-align:right;font-family:var(--mono);color:var(--text)}
.b3d{display:flex;gap:10px;align-items:flex-end;height:120px;padding:6px 2px;perspective:400px}
.b3d-col{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:3px}
.b3d-bar{width:100%%;background:linear-gradient(180deg,rgba(88,166,255,.55),rgba(88,166,255,.18));
transform:rotateX(14deg) rotateY(-6deg);border:1px solid rgba(88,166,255,.5);border-radius:2px;position:relative}
.b3d-bar i{position:absolute;top:0;right:-5px;width:5px;height:100%%;background:rgba(88,166,255,.35);
transform:skewY(-45deg);transform-origin:left}
.b3d-col span{font-size:9px;color:var(--muted);font-family:var(--mono)}
.viz-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}
.viz-box{border:1px solid var(--line);border-radius:6px;background:var(--surface);padding:12px 14px}
.viz-box .t{font-size:12px;color:var(--muted);margin-bottom:6px}
.viz-box .src{font-size:10px;color:var(--dim);font-family:var(--mono);margin-top:8px}
.fitness{display:flex;gap:12px;flex-wrap:wrap;font-size:11px;color:var(--muted);font-family:var(--mono)}
"""

#!/usr/bin/env python
"""Portable text-embedding adapters and NumPy-free float32 NPY I/O."""
import ast
import json
import math
import os
import struct
import urllib.error
import urllib.request
from pathlib import Path


def backend_config(environ=None):
    env = os.environ if environ is None else environ
    backend = env.get("AGI_EMBEDDING_BACKEND", "internal").strip().lower()
    if backend == "openai-compatible":
        model = env.get("AGI_EMBEDDING_MODEL", "").strip()
        endpoint = env.get("AGI_EMBEDDING_URL", "").strip()
        if not endpoint:
            raise RuntimeError("AGI_EMBEDDING_URL must point to the host embedding endpoint")
        if not model:
            raise RuntimeError("AGI_EMBEDDING_MODEL must name the endpoint's embedding model")
        if not endpoint.endswith("/embeddings"):
            endpoint = endpoint.rstrip("/") + "/embeddings"
        return {"backend": backend, "model": model, "endpoint": endpoint,
                "api_key": env.get("AGI_EMBEDDING_API_KEY", ""),
                "timeout": float(env.get("AGI_EMBEDDING_TIMEOUT", "60"))}
    if backend == "internal":
        model = env.get("AGI_INTERNAL_EMBEDDING_MODEL", "").strip()
        if not model:
            raise RuntimeError(
                "Internal embedding is preferred but not adopted yet. Set "
                "AGI_INTERNAL_EMBEDDING_MODEL to an existing local embedding-model directory; "
                "an external provider can be configured later."
            )
        if not Path(model).is_dir():
            raise RuntimeError("AGI_INTERNAL_EMBEDDING_MODEL must be an existing local model directory")
        return {"backend": backend, "model": model}
    if backend == "sentence-transformers":
        model = env.get("AGI_EMBEDDING_MODEL", "").strip()
        if not model:
            raise RuntimeError("AGI_EMBEDDING_MODEL must explicitly name a local model or snapshot path")
        if not Path(model).is_dir():
            raise RuntimeError("sentence-transformers backend requires AGI_EMBEDDING_MODEL to be an existing local directory")
        return {"backend": backend, "model": model}
    raise RuntimeError(
        "Unknown AGI_EMBEDDING_BACKEND. Use internal (preferred) with "
        "AGI_INTERNAL_EMBEDDING_MODEL, or openai-compatible with AGI_EMBEDDING_URL "
        "and AGI_EMBEDDING_MODEL. No Studio/Hugging Face fallback is used."
    )


def _normalize(vector):
    values = [float(value) for value in vector]
    if not values or not all(math.isfinite(value) for value in values):
        raise ValueError("embedding response contains an empty or non-finite vector")
    norm = math.sqrt(sum(value * value for value in values))
    if norm == 0:
        raise ValueError("embedding response contains a zero vector")
    return [value / norm for value in values]


def _http_embed(texts, config):
    rows = []
    for start in range(0, len(texts), 64):
        batch = texts[start:start + 64]
        payload = json.dumps({"model": config["model"], "input": batch}).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if config["api_key"]:
            headers["Authorization"] = "Bearer " + config["api_key"]
        request = urllib.request.Request(config["endpoint"], data=payload, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=config["timeout"]) as response:
                result = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"embedding endpoint returned HTTP {exc.code}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"embedding endpoint unavailable: {exc.reason}") from exc
        data = result.get("data")
        if not isinstance(data, list) or len(data) != len(batch):
            raise RuntimeError("embedding endpoint returned an unexpected data count")
        data.sort(key=lambda item: item.get("index", 0))
        rows.extend(_normalize(item["embedding"]) for item in data)
    return rows


def embed_texts(texts, environ=None, config=None):
    config = config or backend_config(environ)
    if config["backend"] == "openai-compatible":
        vectors = _http_embed(texts, config)
    else:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(config["model"])
        vectors = []
        for start in range(0, len(texts), 64):
            rows = model.encode(texts[start:start + 64], normalize_embeddings=True,
                                show_progress_bar=False)
            vectors.extend(_normalize(row) for row in rows)
    dimensions = len(vectors[0]) if vectors else 0
    if any(len(row) != dimensions for row in vectors):
        raise ValueError("embedding backend returned inconsistent vector dimensions")
    return vectors, {"backend": config["backend"], "model": config["model"],
                     "dimensions": dimensions}


def write_npy(path, vectors):
    rows = len(vectors)
    dimensions = len(vectors[0]) if rows else 0
    if not dimensions or any(len(row) != dimensions for row in vectors):
        raise ValueError("cannot store empty or ragged embedding matrix")
    header = ("{'descr': '<f4', 'fortran_order': False, 'shape': (" + str(rows) + ", "
              + str(dimensions) + "), }")
    padding = (16 - ((10 + len(header) + 1) % 16)) % 16
    encoded = (header + " " * padding + "\n").encode("ascii")
    if len(encoded) > 65535:
        raise ValueError("NPY header too large")
    target = Path(path)
    temporary = target.with_name(target.name + ".tmp")
    with temporary.open("wb") as stream:
        stream.write(b"\x93NUMPY\x01\x00")
        stream.write(struct.pack("<H", len(encoded)))
        stream.write(encoded)
        for row in vectors:
            stream.write(struct.pack("<" + "f" * dimensions, *row))
    os.replace(temporary, target)


def read_npy(path):
    with open(path, "rb") as stream:
        if stream.read(6) != b"\x93NUMPY":
            raise ValueError("unsupported NPY signature")
        version = stream.read(2)
        if version == b"\x01\x00":
            header_len = struct.unpack("<H", stream.read(2))[0]
        elif version in (b"\x02\x00", b"\x03\x00"):
            header_len = struct.unpack("<I", stream.read(4))[0]
        else:
            raise ValueError("unsupported NPY version")
        header = ast.literal_eval(stream.read(header_len).decode("latin1").strip())
        dtype = header["descr"]
        if dtype not in ("<f4", "|f4", "<f8", "|f8") or header["fortran_order"]:
            raise ValueError(f"unsupported NPY matrix format: {dtype}")
        rows, dimensions = header["shape"]
        code = "f" if dtype.endswith("f4") else "d"
        width = 4 if code == "f" else 8
        vectors = []
        for _ in range(rows):
            raw = stream.read(dimensions * width)
            if len(raw) != dimensions * width:
                raise ValueError("truncated NPY matrix")
            vectors.append(list(struct.unpack("<" + code * dimensions, raw)))
        if stream.read(1):
            raise ValueError("unexpected trailing bytes in NPY matrix")
    return vectors

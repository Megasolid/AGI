#!/usr/bin/env python3
"""genome.py - the AGI genetic code: loci -> alleles -> one DNA-style generation identity.

Biological analogy: humans are identified by a passport (social identity) *and* a genome (genetic identity);
they are not "human version 1.2.3". AGI follows the same rule:

  * every subsystem is a GENE LOCUS (core, identity, trust, memory, work, tools, host, interaction, release);
  * its implementation content hashes into an ALLELE (a short genetic marker, not a version number);
  * the ordered loci+alleles form the GENOME (digest = the genotype);
  * the birth seed + genome digest are encoded into a DNA codon string = **Gen.ID**.

Gen.ID is the universal identity for the generation and everything it produces; the passport carries the
social identity. Numeric versions are no longer the identity of AGI or its subsystems.
"""
import hashlib
import json
import pathlib

AGI = pathlib.Path(__file__).resolve().parents[2]

LOCI = ["core", "identity", "trust", "memory", "work", "tools", "host", "interaction", "release"]
SOURCES = {
    "core": ["core/dna.md", "SKILL.md", "backups/core"],
    "identity": ["memory/scripts/identity.py", "state/identity/profiles.json"],
    "trust": ["memory/scripts/trust_log.py", "memory/scripts/crypto.py", "memory/scripts/passport.py"],
    "memory": ["memory/scripts/rag.py", "memory/scripts/library.py", "state/pills"],
    "work": ["memory/scripts/taskbill.py", "memory/scripts/taskcard.py", "memory/scripts/job.py"],
    "tools": ["memory/scripts/registry.json", "memory/scripts/app.py", "memory/scripts/board_serve.py"],
    "host": ["state/env_probe.json", "state/host_speed.json"],
    "interaction": ["state/interaction.json", "memory/scripts/sitegen.py"],
    "release": ["state/repo/AGI/repo.json", "releases/SHA256SUMS"],
}


def _files(root, rels):
    out = []
    for rel in rels:
        p = pathlib.Path(root) / rel
        if p.is_file():
            out.append(p)
        elif p.is_dir():
            out.extend(sorted(x for x in p.rglob("*") if x.is_file())[:200])
    return sorted(set(out))


def allele(locus, root=None):
    """Content hash of a subsystem: its genetic marker (10 hex), never a semantic version."""
    root = pathlib.Path(root) if root else AGI
    h = hashlib.sha256(b"agi/allele/v1:" + locus.encode())
    for f in _files(root, SOURCES.get(locus, [])):
        try:
            h.update(f.relative_to(root).as_posix().encode())
            h.update(b"\0")
            h.update(f.read_bytes())
            h.update(b"\0")
        except OSError:
            continue
    return h.hexdigest()[:10].upper()


def genome(root=None):
    root = pathlib.Path(root) if root else AGI
    genes = {locus: allele(locus, root) for locus in LOCI}
    canonical = json.dumps(genes, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(b"agi/genome/v1:" + canonical.encode()).hexdigest()
    return {"genes": genes, "digest": digest, "digest8": digest[:8].upper()}


def codons(seed, genome_digest):
    """Encode seed + genome digest as DNA codons (A/C/G/T only, 4 groups of 4 codons)."""
    seed = bytes(seed)
    material = hashlib.sha256(b"agi/dna/v1:" + seed + bytes.fromhex(genome_digest)).digest()[:12]
    table = "ACGT"
    bases = "".join(table[(b >> s) & 3] for b in material for s in (6, 4, 2, 0))
    cod = [bases[i:i + 3] for i in range(0, len(bases), 3)]
    cod = cod[:16]
    return "-".join("".join(cod[i:i + 4]) for i in range(0, 16, 4))


def describe(root=None):
    root = pathlib.Path(root) if root else AGI
    g = genome(root)
    return {"schema": "agi-genome/1", "loci": LOCI, "genes": g["genes"],
            "genome_digest": g["digest"], "genome_digest8": g["digest8"]}


if __name__ == "__main__":
    print(json.dumps(describe(), indent=1))

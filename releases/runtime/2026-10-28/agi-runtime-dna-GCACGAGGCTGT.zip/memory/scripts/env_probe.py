#!/usr/bin/env python3
"""env_probe.py — OS-agnostic discovery for the general-awareness migration phase.

Finds the Studio root + venv python WITHOUT trusting env-var home, which is faked
to <root>/sandbox/__LOCALID_* in every tool. Root candidates are validated by markers
(studio.db present AND a memdir MEMORY.md readable - legacy <root>/memory/ or the
 gen3 skills-folder memdir derived from real home, no hardcoded paths).

Dual use:
  - importable module (find_root / find_venv / probe) for migrate.py and check.sh
  - CLI:  python env_probe.py [--json]   -> prints discovered facts as JSON
"""
import os, sys, re, json, platform, subprocess, time


def _is_win():
    return os.name == 'nt' or platform.system().lower() == 'windows'


def _is_darwin():
    return platform.system().lower() == 'darwin'


def _drives():
    if not _is_win():
        return []
    try:
        import ctypes
        bitmask = ctypes.windll.kernel32.GetLogicalDrives()
        return [f"{chr(65 + i)}:\\" for i in range(26) if bitmask & (1 << i)]
    except Exception:
        return ['C:\\']


def _root_candidates():
    """Yield candidate Studio roots, most-reliable first. Never trusts env home as final answer."""
    cands = []
    # 0) explicit override (docs-supported; the value IS the root)
    ov = os.environ.get('UNSLOTH_STUDIO_HOME')
    if ov:
        cands.append(os.path.expanduser(ov))
    env_home = os.environ.get('USERPROFILE') or os.environ.get('HOME') or ''
    # 1) faked home = <root>/sandbox/__LOCALID_* -> strip /sandbox/... (Win primary, verified)
    m = re.search(r'(.+[/\\]\.unsloth[/\\]studio)([/\\]sandbox[/\\])', env_home, re.I)
    if m:
        cands.append(m.group(1))
    # 2) env home is a normal (un-faked) home -> <home>/.unsloth/studio
    if env_home and 'sandbox' not in env_home.lower():
        cands.append(os.path.join(env_home, '.unsloth', 'studio'))
    # 3) OS primitive for the REAL identity (bypasses fake env vars)
    try:
        if _is_win():
            user = _silent_check_output(['whoami']).strip().split('\\')[-1]
            for drv in _drives():
                cands.append(os.path.join(drv, 'Users', user, '.unsloth', 'studio'))
        else:
            home = _posix_real_home()
            if home:
                cands.append(os.path.join(home, '.unsloth', 'studio'))
    except Exception:
        pass
    # dedupe preserving order
    seen, out = set(), []
    for c in cands:
        if c and c not in seen:
            seen.add(c); out.append(c)
    return out


def _valid_root(p):
    """studio.db present AND a memdir marker readable: legacy <root>/memory/ or
    gen3 skills-folder memdir derived from real home (no hardcoded paths)."""
    try:
        if not os.path.isfile(os.path.join(p, 'studio.db')):
            return False
        if os.path.isfile(os.path.join(p, 'memory', 'MEMORY.md')):
            return True
        home = real_home()
        if home:
            cand = os.path.join(home, '.agents', 'skills', 'agi', 'memory', 'MEMORY.md')
            return os.path.isfile(cand)
        return False
    except Exception:
        return False


def find_root():
    """Return (root_path_or_None, method_string)."""
    for c in _root_candidates():
        if _valid_root(c):
            return c, 'marker-validated'
    return None, 'not-found'


def find_venv(root):
    """Return venv python path or None. Specific candidates first, then a bounded walk."""
    if not root:
        return None
    if _is_win():
        cands = [os.path.join(root, 'unsloth_studio', 'Scripts', 'python.exe'),
                 os.path.join(root, '.venv', 'Scripts', 'python.exe')]
        needle = 'python.exe'
    else:
        # Windows layout is <root>/unsloth_studio/Scripts/python.exe; POSIX may mirror
        # it as <root>/unsloth_studio/bin/python (venv inside the app dir).
        cands = [os.path.join(root, '.venv', 'bin', 'python'),
                 os.path.join(root, 'unsloth_studio', 'bin', 'python'),
                 os.path.join(root, 'bin', 'python')]
        needle = 'python'
    for c in cands:
        if c and os.path.isfile(c):
            return c
    # fallback: first python under a venv-ish subdir of root (bounded depth)
    for dirpath, dirnames, filenames in os.walk(root):
        depth = dirpath[len(root):].count(os.sep)
        if depth > 3:
            dirnames[:] = []
            continue
        for f in filenames:
            ok = (f == needle) if _is_win() else (f.startswith('python') and '.' not in f)
            if ok:
                return os.path.join(dirpath, f)
    return None


def _posix_real_home():
    """Real home on POSIX via identity primitives (env $HOME is faked in tools).
    Linux: getent passwd. macOS: no getent -> dscl NFSHomeDirectory fallback."""
    h = _run(['bash', '-lc', 'getent passwd "$(id -u)" | cut -d: -f6'])
    if h and h.strip() and os.path.isdir(h.strip()):
        return h.strip()
    if _is_darwin():
        u = _run(['dscl', '.', '-read', f'/Users/{_run(["id", "-un"]) or ""}', 'NFSHomeDirectory'])
        if u:
            for line in u.splitlines():
                if line.startswith('NFSHomeDirectory:'):
                    d = line.split(':', 1)[1].strip()
                    if os.path.isdir(d):
                        return d
    return h.strip() if h and h.strip() else None


def real_home():
    """Real home dir via OS identity primitive (env home is faked). n/a on failure."""
    try:
        if _is_win():
            # whoami may be lowercase (case-insensitive FS; consumers handle it)
            u = _silent_check_output(['whoami']).strip().split('\\')[-1]
            # drive letter is an OS fact; the user dir name comes from identity, not env-home
            return os.path.join(os.environ.get('SystemDrive', 'C:') + os.sep, 'Users', u)
        return _posix_real_home()
    except Exception:
        return None


def _silent_check_output(cmd, timeout=10):
    """check_output that never opens a visible console window (Windows)."""
    if os.name == "nt":
        cmd = list(cmd)
        return subprocess.check_output(cmd, text=True, timeout=timeout,
                                       creationflags=0x08000000).strip()  # CREATE_NO_WINDOW (2026-10-19: was 0x0800000, one zero short)
    return subprocess.check_output(cmd, text=True, timeout=timeout).strip()


def _run(cmd, timeout=10):
    try:
        return _silent_check_output(cmd, timeout)
    except Exception:
        return None


def studio_info(root, venv):
    """Studio version (venv pip), db readability, API :8888 reachability."""
    info = {'version': 'n/a', 'db_ok': False, 'api_port': 8888, 'api_up': False}
    if root:
        try:
            import sqlite3
            con = sqlite3.connect(f'file:{root}/studio.db?mode=ro', uri=True)
            con.execute('select count(*) from app_settings')
            info['db_ok'] = True
            perm = {}
            for k in ('permissionMode', 'confirmToolCalls', 'toolsEnabled', 'codeToolsEnabled'):
                row = con.execute('select value_json from chat_settings where key=?', (k,)).fetchone()
                if row:
                    v = row[0]
                    try: v = json.loads(v)
                    except Exception: pass
                    perm[k] = v
            if perm: info['permission'] = perm
            con.close()
        except Exception:
            pass
    if venv:
        out = _run([venv, '-m', 'pip', 'show', 'studio'], timeout=30)
        if out:
            for line in out.splitlines():
                if line.startswith('Version:'):
                    info['version'] = line.split(':', 1)[1].strip()
    # no -o dev/null: on Windows curl treats it as a literal filename
    body = _run(['curl', '-s', '--max-time', '3', f'http://127.0.0.1:8888/'])
    info['api_up'] = bool(body)
    return info


def heart_info():
    """Heart = separate studio-like app (llama.cpp based). Locate install + data dir."""
    info = {'found': False, 'install': None, 'data_dir': None, 'version': 'n/a'}
    home = real_home() or ''
    cands = []
    if _is_win():
        cands += [os.path.join(home, 'AppData', 'Local', 'Hearth')]
    else:
        cands += [os.path.join(home, '.local', 'share', 'Hearth'),
                  os.path.join(home, 'Hearth')]
        binp = _run(['bash', '-lc', 'command -v hearth'])
        if binp and binp.strip():
            cands.append(binp.strip())  # PATH-installed binary (AppImage/flatpak wrapper)
    dd = os.path.join(home, '.hearth')
    info['data_dir'] = dd if home and os.path.isdir(dd) else None
    for c in cands:
        target = None
        if _is_win():
            exe = os.path.join(c, 'Hearth.exe')
            target = exe if os.path.isfile(exe) else (c if os.path.isdir(c) else None)
        else:
            target = c if os.path.exists(c) else None
        if not target:
            continue
        info['found'] = True
        info['install'] = target
        if _is_win() and os.path.isfile(target):
            v = _run(['powershell', '-NoProfile', '-Command',
                      f"(Get-Item '{target}').VersionInfo.FileVersion"])
            if v:
                info['version'] = v
        elif not _is_win() and os.path.isfile(target):
            v = _run([target, '--version'], timeout=10) or \
                  _run(['bash', '-lc', f'{target} --version'], timeout=10)
            if v:
                info['version'] = v.splitlines()[0][:60]
        break
    return info


def hw_info():
    """CPU/cores/RAM + GPU/VRAM/temps. Unavailable sensor -> n/a, never guess."""
    hw = {'cpu': 'n/a', 'cores': 'n/a', 'ram_gb': 'n/a', 'gpu': 'n/a',
          'vram_total_mb': 'n/a', 'vram_used_mb': 'n/a', 'temps': {}}
    if _is_win():
        ps = ('$c=Get-CimInstance Win32_ComputerSystem; $p=Get-CimInstance Win32_Processor | Select-Object -First 1;'
              '"{0}|{1}|{2}" -f $p.Name,$env:NUMBER_OF_PROCESSORS,[math]::Round($c.TotalPhysicalMemory/1GB,1)')
        out = _run(['powershell', '-NoProfile', '-Command', ps], timeout=20)
        if out and '|' in out:
            hw['cpu'], hw['cores'], hw['ram_gb'] = out.split('|')
    elif _is_darwin():
        m = _run(['sysctl', '-n', 'hw.model'])
        if m:
            hw['cpu'] = m
        cores = _run(['sysctl', '-n', 'hw.ncpu'])
        if cores:
            hw['cores'] = cores
        mem = _run(['sysctl', '-n', 'hw.memsize'])  # bytes
        if mem and mem.isdigit():
            hw['ram_gb'] = str(round(int(mem) / 1073741824, 1))
        # GPU: system_profiler is slow (~5-10s); temps need sudo -> n/a (never guess)
        sp = _run(['system_profiler', 'SPDisplaysDataType'], timeout=30)
        if sp:
            gm = re.search(r'Chipset Model:\s*(.+)', sp)
            if gm:
                hw['gpu'] = gm.group(1).strip()
    else:
        # NOTE: \$2 keeps the field ref literal for awk (bash -lc would expand $2 to '')
        model = _run(['bash', '-lc', 'lscpu | awk -F: "/^Model name:/ {print \\$2}"'])
        if model:
            hw['cpu'] = model.strip()
        cores = _run(['bash', '-lc', 'nproc'])
        if cores:
            hw['cores'] = cores
        mem = _run(['bash', '-lc', 'awk "/MemTotal/ {printf \\"%.1f\\\", \\$2/1048576}" /proc/meminfo'])
        if mem:
            hw['ram_gb'] = mem
    smi = _run(['nvidia-smi', '--query-gpu=name,memory.total,memory.used,temperature.gpu,utilization.gpu',
                '--format=csv,noheader,nounits'], timeout=15)
    if smi:
        lines = [l for l in smi.splitlines() if l.strip()]
        if lines:
            parts = [p.strip() for p in lines[0].split(',')]
            if len(parts) >= 5:
                hw['gpu'] = parts[0]
                hw['vram_total_mb'] = parts[1]
                hw['vram_used_mb'] = parts[2]
                hw['temps']['gpu_c'] = parts[3]
                hw['temps']['gpu_util_pct'] = parts[4]
    # AMD fallback (Linux; macOS GPU already covered above) — best effort, no guessing
    if hw['gpu'] == 'n/a' and not _is_win():
        pci = _run(['bash', '-lc', 'lspci 2>/dev/null | grep -iE "vga|3d" | head -1'])
        if pci:
            hw['gpu'] = pci.split(':', 2)[-1].strip()
        rsm = _run(['rocm-smi', '--showmeminfo', 'vram'], timeout=15)
        m = re.search(r'GPU\[0\]\s*:\s*(\d+)\s+Total', rsm or '')
        if m:
            hw['vram_total_mb'] = m.group(1)
    return hw


def model_info():
    """Live model behind Studio API :8888 (volatile — never cached). Prefers the
    loaded entry; n/a if down or list empty."""
    out = _run(['curl', '-s', '--max-time', '8', 'http://127.0.0.1:8888/v1/models'])
    name, quant, ctx = None, None, None
    if out:
        try:
            data = json.loads(out)
            models = [m for m in data.get('data', []) if m.get('id')]
            loaded = [m for m in models if m.get('loaded')]
            pick = (loaded or models)
            if pick:
                m = pick[0]
                name = m['id']
                quant = m.get('quant')
                ctx = m.get('context_length')
        except Exception:
            pass
    return {'name': name or 'n/a', 'port': 8888, 'quant': quant,
            'context_length': ctx, 'flags': 'live-only'}


def probe(write=False):
    root, method = find_root()
    venv = find_venv(root)
    home = real_home()
    result = {
        'os': {'name': platform.system(), 'release': platform.release(),
               'version': platform.version(), 'arch': platform.machine()},
        'real_home': home,
        'root': root,
        'root_method': method,
        'venv_python': venv,
        'gate': {'side': ('real' if root else 'sandbox'),
                 'full_access': bool(root),
                 'discovery_method': method},
        'studio': studio_info(root, venv),
        'heart': heart_info(),
        'hw': hw_info(),
        'model': model_info(),
        'probed_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
    }
    if root is None:
        # standalone install (no Studio tree on this host): the AGI folder is the host root for
        # portability checks; never fabricate a Studio marker
        memdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        result['root_fallback'] = memdir
        result['standalone'] = True
        result['root_method'] = 'standalone-fallback'
    if write:
        # always <memdir>/state/ (portable; never into the studio install tree)
        mem = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        state = os.path.join(mem, 'state', 'env_probe.json')
        try:
            os.makedirs(os.path.dirname(state), exist_ok=True)
            with open(state, 'w') as f:
                json.dump(result, f, indent=1)
            result['written_to'] = state
        except Exception as e:
            result['write_error'] = str(e)
    return result


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--json', action='store_true', help='full probe (studio/heart/hw/model)')
    ap.add_argument('--write', action='store_true', help='also write state/env_probe.json')
    a = ap.parse_args()
    if a.json or a.write:
        print(json.dumps(probe(write=a.write), indent=2))
    else:
        p = probe()
        print(json.dumps({k: p[k] for k in ('os', 'root', 'root_method', 'venv_python', 'gate')}, indent=2))
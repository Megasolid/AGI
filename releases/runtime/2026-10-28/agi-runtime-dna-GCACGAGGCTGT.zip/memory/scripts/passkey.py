#!/usr/bin/env python3
"""passkey.py - P12-A: WebAuthn/passkey verification for portable D presence.

A passkey proves presence with an **asymmetric** signature: the private key lives in the
authenticator's secure element (phone, hardware key) and never leaves it. That is why it works on
any machine - a borrowed laptop sees only an assertion - and why nothing reusable is stored there.

What this module verifies (server side, offline, no network):
  * registration: clientDataJSON type/challenge/origin, rpIdHash, UP flag, attested credential data,
    and the COSE public key - then stores the credential (id, public key, sign count);
  * authentication: clientDataJSON type/challenge/origin, rpIdHash, UP flag, signature over
    authenticatorData || SHA256(clientDataJSON), and sign-count monotonicity (clone detection).

What it deliberately does NOT do (stated so nobody assumes otherwise):
  * it does not validate the attestation statement (fmt/attStmt). Attestation proves *which*
    authenticator model was used; for local enrolment we accept any authenticator and record it.
  * it does not talk to the browser. The pages that call `navigator.credentials.create/get` are the
    next slice; this is the verifier they will post into.

CLI
  passkey.py challenge [--kind registration|authentication] [--ttl-seconds 300]
  passkey.py enroll --attestation <file|json> [--label phone] [--rp-id 127.0.0.1] [--origin ...]
  passkey.py verify --assertion <file|json> [--rp-id 127.0.0.1]
  passkey.py list
  passkey.py remove --credential <id>
  passkey.py state
  passkey.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import base64
import hashlib
import json
import secrets
import struct
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
ID_DIR = STATE / "identity"
PASSKEYS = ID_DIR / "passkeys.json"
CHALLENGE = ID_DIR / "passkey_challenge.json"

sys.path.insert(0, str(MEM / "scripts"))
import crypto  # noqa: E402

SCHEMA = "agi-passkeys/1"
DEFAULT_RP_ID = "127.0.0.1"
ORIGIN_PREFIXES = ("http://127.0.0.1", "http://localhost", "https://127.0.0.1", "https://localhost")
LOGGING = True


# ---------------------------------------------------------------- base64url / json helpers
def b64u_decode(s):
    if isinstance(s, bytes):
        s = s.decode("ascii")
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def b64u_encode(raw):
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _jload(p, default=None):
    if isinstance(p, dict):
        return p
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


# ---------------------------------------------------------------- minimal CBOR (decode + encode for tests)
def cbor_decode(data):
    def read(buf, i):
        if i >= len(buf):
            raise ValueError("cbor: unexpected end")
        initial = buf[i]
        i += 1
        major, info = initial >> 5, initial & 0x1F
        if info < 24:
            val = info
        elif info == 24:
            val = buf[i]
            i += 1
        elif info == 25:
            val = struct.unpack(">H", buf[i:i + 2])[0]
            i += 2
        elif info == 26:
            val = struct.unpack(">I", buf[i:i + 4])[0]
            i += 4
        elif info == 27:
            val = struct.unpack(">Q", buf[i:i + 8])[0]
            i += 8
        else:
            raise ValueError(f"cbor: unsupported info {info}")
        if major == 0:
            return val, i
        if major == 1:
            return -1 - val, i
        if major == 2:
            return bytes(buf[i:i + val]), i + val
        if major == 3:
            return buf[i:i + val].decode("utf-8"), i + val
        if major == 4:
            out = []
            for _ in range(val):
                item, i = read(buf, i)
                out.append(item)
            return out, i
        if major == 5:
            out = {}
            for _ in range(val):
                k, i = read(buf, i)
                v, i = read(buf, i)
                out[k] = v
            return out, i
        if major == 6:
            item, i = read(buf, i)
            return item, i
        if major == 7:
            return {20: False, 21: True, 22: None}.get(val, val), i
        raise ValueError(f"cbor: unsupported major {major}")

    value, _ = read(data, 0)
    return value


def cbor_encode(obj):
    def head(major, val):
        if val < 24:
            return bytes([(major << 5) | val])
        if val < 256:
            return bytes([(major << 5) | 24, val])
        if val < 65536:
            return bytes([(major << 5) | 25]) + struct.pack(">H", val)
        return bytes([(major << 5) | 26]) + struct.pack(">I", val)

    if isinstance(obj, int) and obj >= 0:
        return head(0, obj)
    if isinstance(obj, int):
        return head(1, -1 - obj)
    if isinstance(obj, bytes):
        return head(2, len(obj)) + obj
    if isinstance(obj, str):
        raw = obj.encode("utf-8")
        return head(3, len(raw)) + raw
    if isinstance(obj, list):
        return head(4, len(obj)) + b"".join(cbor_encode(x) for x in obj)
    if isinstance(obj, dict):
        return head(5, len(obj)) + b"".join(cbor_encode(k) + cbor_encode(v) for k, v in obj.items())
    raise TypeError(f"cbor_encode: unsupported {type(obj)}")


# ---------------------------------------------------------------- COSE key
def cose_to_public_key(cose_bytes):
    """COSE_Key -> (alg, cryptography public key). Supports ES256 (-7) and EdDSA (-8)."""
    k = cbor_decode(cose_bytes)
    kty = k.get(1)
    alg = k.get(3)
    crv = k.get(-1)
    x, y = k.get(-2), k.get(-3)
    from cryptography.hazmat.primitives.asymmetric import ec, ed25519

    if kty == 2 and crv == 1 and alg == -7 and x is not None and y is not None:
        from cryptography.hazmat.primitives.asymmetric.ec import EllipticCurvePublicNumbers
        pub = EllipticCurvePublicNumbers(int.from_bytes(x, "big"), int.from_bytes(y, "big"),
                                         ec.SECP256R1()).public_key()
        return -7, pub
    if kty == 1 and crv == 6 and dag_ok(alg):
        pub = ed25519.Ed25519PublicKey.from_public_bytes(x)
        return -8, pub
    raise ValueError(f"unsupported COSE key: kty={kty} alg={alg} crv={crv}")


def dag_ok(alg):
    return alg in (-8, None)


# ---------------------------------------------------------------- challenge + state
def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def make_challenge(kind="registration", ttl_seconds=300):
    rec = {"schema": "agi-passkey-challenge/1", "kind": kind,
           "challenge": b64u_encode(secrets.token_bytes(32)), "created": _now(),
           "expires": (datetime.now().astimezone() + timedelta(seconds=ttl_seconds)).strftime("%Y-%m-%dT%H:%M:%S%z")}
    _jdump(CHALLENGE, rec)
    return rec


def _load_challenge(kind):
    rec = _jload(CHALLENGE) or {}
    if not rec or rec.get("kind") != kind:
        raise ValueError(f"no {kind} challenge in progress: run passkey.py challenge --kind {kind}")
    try:
        if datetime.strptime(rec["expires"], "%Y-%m-%dT%H:%M:%S%z") < datetime.now().astimezone():
            raise ValueError("challenge expired: start again")
    except (KeyError, ValueError) as e:
        if "expired" in str(e):
            raise
        raise ValueError("challenge malformed: start again")
    return rec["challenge"]


def _state():
    return _jload(PASSKEYS, {"schema": SCHEMA, "credentials": {}}) or {"schema": SCHEMA, "credentials": {}}


def list_credentials():
    st = _state()
    return [{k: c.get(k) for k in ("credential_id", "label", "alg", "rp_id", "sign_count", "created")}
            for c in (st.get("credentials") or {}).values()]


def remove_credential(credential_id):
    st = _state()
    before = len(st["credentials"])
    st["credentials"].pop(credential_id, None)
    _jdump(PASSKEYS, st)
    return {"removed": before - len(st["credentials"]), "remaining": len(st["credentials"])}


# ---------------------------------------------------------------- registration
def _client_data(raw, expected_type, challenge, rp_id, origin=None):
    try:
        cd = json.loads(b64u_decode(raw).decode("utf-8"))
    except Exception:
        raise ValueError("clientDataJSON is not valid base64url JSON")
    if cd.get("type") != expected_type:
        raise ValueError(f"clientDataJSON type {cd.get('type')!r} != {expected_type!r}")
    if cd.get("challenge") != challenge:
        raise ValueError("clientDataJSON challenge does not match the issued challenge")
    got_origin = cd.get("origin") or ""
    if origin:
        if got_origin != origin:
            raise ValueError(f"origin {got_origin!r} != expected {origin!r}")
    elif not got_origin.startswith(ORIGIN_PREFIXES):
        raise ValueError(f"origin {got_origin!r} is not a local origin (use --origin to allow another)")
    return cd


def _parse_auth_data(auth_data, rp_id):
    if len(auth_data) < 37:
        raise ValueError("authenticatorData too short")
    rp_hash = auth_data[:32]
    if rp_hash != hashlib.sha256(rp_id.encode()).digest():
        raise ValueError("rpIdHash does not match the relying party id")
    flags = auth_data[32]
    sign_count = struct.unpack(">I", auth_data[33:37])[0]
    if not flags & 0x01:
        raise ValueError("user-presence flag not set (the authenticator did not confirm a user)")
    return {"rp_id": rp_id, "flags": flags, "sign_count": sign_count, "rest": auth_data[37:]}


def enroll(attestation, rp_id=DEFAULT_RP_ID, origin=None, label=None):
    """Store a credential from a WebAuthn registration payload (navigator.credentials.create)."""
    if isinstance(attestation, (str, Path)) and not isinstance(attestation, dict):
        attestation = _jload(attestation)
    if not isinstance(attestation, dict):
        raise ValueError("attestation payload must be a JSON object")
    challenge = _load_challenge("registration")
    _client_data(attestation.get("client_data_json_b64url"), "webauthn.create", challenge, rp_id, origin)
    att_obj = cbor_decode(b64u_decode(attestation.get("attestation_object_b64url")))
    if not isinstance(att_obj, dict) or "authData" not in att_obj:
        raise ValueError("attestation object has no authData")
    ad = _parse_auth_data(att_obj["authData"], rp_id)
    if not ad["flags"] & 0x40:
        raise ValueError("attested credential data flag not set")
    rest = ad["rest"]
    if len(rest) < 18:
        raise ValueError("attested credential data truncated")
    cred_len = struct.unpack(">H", rest[16:18])[0]
    cred_id = rest[18:18 + cred_len]
    cose = rest[18 + cred_len:]
    if attestation.get("credential_id_b64url"):
        if b64u_decode(attestation["credential_id_b64url"]) != cred_id:
            raise ValueError("credential id in payload does not match authData")
    alg, pub = cose_to_public_key(cose)
    from cryptography.hazmat.primitives import serialization
    st = _state()
    cid = b64u_encode(cred_id)
    st["credentials"][cid] = {
        "credential_id": cid, "label": label or "authenticator", "alg": alg,
        "public_key_b64": base64.b64encode(pub.public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)).decode(),
        "rp_id": rp_id, "sign_count": ad["sign_count"], "created": _now(),
        "attestation_format": att_obj.get("fmt"),
        "note": "attestation statement not validated (recorded only) - document in security notes",
    }
    _jdump(PASSKEYS, st)
    if LOGGING:
        import trust_log
        trust_log.append("passkey-enrolled", {"credential_id": cid[:16] + "...", "alg": alg,
                                              "rp_id": rp_id, "fmt": att_obj.get("fmt")})
    return {"ok": True, "credential_id": cid, "alg": alg, "label": st["credentials"][cid]["label"],
            "sign_count": ad["sign_count"]}


# ---------------------------------------------------------------- authentication
def verify_assertion(assertion, rp_id=DEFAULT_RP_ID, origin=None):
    """Verify a WebAuthn assertion (navigator.credentials.get) -> presence at passkey level."""
    if isinstance(assertion, (str, Path)) and not isinstance(assertion, dict):
        assertion = _jload(assertion)
    if not isinstance(assertion, dict):
        raise ValueError("assertion payload must be a JSON object")
    challenge = _load_challenge("authentication")
    _client_data(assertion.get("client_data_json_b64url"), "webauthn.get", challenge, rp_id, origin)
    try:
        cred_id = assertion["credential_id_b64url"]
    except KeyError:
        raise ValueError("assertion has no credential_id_b64url")
    st = _state()
    rec = st["credentials"].get(cred_id)
    if not rec:
        raise ValueError("unknown credential: not enrolled on this install")
    if rec.get("rp_id") != rp_id:
        raise ValueError(f"credential was enrolled for rp_id {rec.get('rp_id')!r}, not {rp_id!r}")
    auth_data = b64u_decode(assertion["authenticator_data_b64url"])
    ad = _parse_auth_data(auth_data, rp_id)
    if ad["sign_count"] and rec.get("sign_count") and ad["sign_count"] <= rec["sign_count"]:
        raise ValueError("sign count did not increase (possible cloned authenticator)")
    cd_hash = hashlib.sha256(b64u_decode(assertion["client_data_json_b64url"])).digest()
    signed = auth_data + cd_hash
    sig = b64u_decode(assertion["signature_b64url"])
    from cryptography.hazmat.primitives import serialization
    pub = serialization.load_der_public_key(base64.b64decode(rec["public_key_b64"]))
    try:
        if rec["alg"] == -7:
            from cryptography.hazmat.primitives.asymmetric import ec, utils
            from cryptography.hazmat.primitives import hashes
            r, s = utils.decode_dss_signature(sig)
            pub.verify(utils.encode_dss_signature(r, s), signed, ec.ECDSA(hashes.SHA256()))
        else:
            pub.verify(sig, signed)
    except Exception:
        raise ValueError("signature invalid")
    rec["sign_count"] = max(ad["sign_count"], int(rec.get("sign_count") or 0))
    rec["last_used"] = _now()
    rec["last_flags"] = ad["flags"]
    _jdump(PASSKEYS, st)
    if LOGGING:
        import trust_log
        trust_log.append("passkey-authenticated", {"credential_id": cred_id[:16] + "...",
                                                   "sign_count": rec["sign_count"]})
    return {"ok": True, "credential_id": cred_id, "label": rec.get("label"), "alg": rec.get("alg"),
            "level": "passkey", "sign_count": rec["sign_count"]}


def verify_state():
    st = _state()
    problems = []
    if st.get("schema") != SCHEMA:
        problems.append(f"passkeys schema {st.get('schema')!r}")
    for cid, rec in (st.get("credentials") or {}).items():
        if rec.get("credential_id") != cid:
            problems.append(f"credential {cid[:8]}: id mismatch")
        if not rec.get("public_key_b64"):
            problems.append(f"credential {cid[:8]}: no public key")
        if rec.get("alg") not in (-7, -8):
            problems.append(f"credential {cid[:8]}: unsupported alg {rec.get('alg')}")
    return {"ok": not problems, "problems": problems,
            "credentials": len(st.get("credentials") or {})}


# ---------------------------------------------------------------- CLI
def _arg(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def cmd_challenge(args):
    print(json.dumps(make_challenge(_arg(args, "--kind", "registration"),
                                    int(_arg(args, "--ttl-seconds", 300))), indent=1))
    return 0


def cmd_enroll(args):
    if not _arg(args, "--attestation"):
        print("usage: passkey.py enroll --attestation <file|json> [--label name] [--rp-id id]")
        return 2
    try:
        r = enroll(_arg(args, "--attestation"), rp_id=_arg(args, "--rp-id", DEFAULT_RP_ID),
                   origin=_arg(args, "--origin"), label=_arg(args, "--label"))
    except (ValueError, OSError) as e:
        print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
        return 1
    print(json.dumps(r, indent=1))
    return 0


def cmd_verify(args):
    if not _arg(args, "--assertion"):
        print("usage: passkey.py verify --assertion <file|json> [--rp-id id]")
        return 2
    try:
        r = verify_assertion(_arg(args, "--assertion"), rp_id=_arg(args, "--rp-id", DEFAULT_RP_ID),
                             origin=_arg(args, "--origin"))
    except (ValueError, OSError) as e:
        print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
        return 1
    print(json.dumps(r, indent=1))
    return 0


def cmd_list(args):
    print(json.dumps({"credentials": list_credentials()}, indent=1))
    return 0


def cmd_remove(args):
    if not _arg(args, "--credential"):
        print("usage: passkey.py remove --credential <id>")
        return 2
    print(json.dumps(remove_credential(_arg(args, "--credential")), indent=1))
    return 0


def cmd_state(args):
    print(json.dumps(verify_state(), indent=1))
    return 0


def selftest():
    import shutil
    import tempfile

    global ID_DIR, PASSKEYS, CHALLENGE, LOGGING

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec, utils

    saved = (ID_DIR, PASSKEYS, CHALLENGE, LOGGING)
    tmp = Path(tempfile.mkdtemp(prefix="agi-passkey-test-"))
    try:
        LOGGING = False
        ID_DIR = tmp / "state" / "identity"
        PASSKEYS = ID_DIR / "passkeys.json"
        CHALLENGE = ID_DIR / "passkey_challenge.json"
        rp_id = "127.0.0.1"
        origin = "http://127.0.0.1:8765"
        priv = ec.generate_private_key(ec.SECP256R1())
        pub = priv.public_key()
        numbers = pub.public_numbers()
        cose = cbor_encode({1: 2, 3: -7, -1: 1,
                            -2: numbers.x.to_bytes(32, "big"), -3: numbers.y.to_bytes(32, "big")})
        cred_id = secrets.token_bytes(16)
        rp_hash = hashlib.sha256(rp_id.encode()).digest()

        # registration
        ch = make_challenge("registration")
        client_data = json.dumps({"type": "webauthn.create", "challenge": ch["challenge"],
                                  "origin": origin}).encode()
        auth_data = rp_hash + bytes([0x41]) + struct.pack(">I", 0) + b"\x00" * 16 + \
            struct.pack(">H", len(cred_id)) + cred_id + cose
        att_obj = cbor_encode({"fmt": "none", "attStmt": {}, "authData": auth_data})
        payload = {"credential_id_b64url": b64u_encode(cred_id),
                   "attestation_object_b64url": b64u_encode(att_obj),
                   "client_data_json_b64url": b64u_encode(client_data)}
        r = enroll(payload, rp_id=rp_id, origin=origin, label="test-phone")
        check("registration verifies and stores the credential", r["ok"] and r["alg"] == -7)
        check("credential listed", len(list_credentials()) == 1)

        # authentication
        ch2 = make_challenge("authentication")
        ad2 = rp_hash + bytes([0x01]) + struct.pack(">I", 1)
        cd2 = json.dumps({"type": "webauthn.get", "challenge": ch2["challenge"],
                          "origin": origin}).encode()
        signed = ad2 + hashlib.sha256(cd2).digest()
        der = priv.sign(signed, ec.ECDSA(hashes.SHA256()))
        assertion = {"credential_id_b64url": b64u_encode(cred_id),
                     "authenticator_data_b64url": b64u_encode(ad2),
                     "client_data_json_b64url": b64u_encode(cd2),
                     "signature_b64url": b64u_encode(der)}
        v = verify_assertion(assertion, rp_id=rp_id, origin=origin)
        check("assertion verifies at passkey level", v["ok"] and v["level"] == "passkey")

        # negative: challenge mismatch
        make_challenge("authentication")
        bad = dict(assertion)
        try:
            verify_assertion(bad, rp_id=rp_id, origin=origin)
            replay_ok = True
        except ValueError:
            replay_ok = False
        check("assertion with a stale challenge refused", not replay_ok)

        # negative: wrong origin
        ch3 = make_challenge("authentication")
        cd3 = json.dumps({"type": "webauthn.get", "challenge": ch3["challenge"],
                          "origin": "https://evil.example"}).encode()
        bad3 = {"credential_id_b64url": b64u_encode(cred_id),
                "authenticator_data_b64url": b64u_encode(ad2),
                "client_data_json_b64url": b64u_encode(cd3),
                "signature_b64url": b64u_encode(priv.sign(ad2 + hashlib.sha256(cd3).digest(),
                                                          ec.ECDSA(hashes.SHA256())))}
        try:
            verify_assertion(bad3, rp_id=rp_id, origin=origin)
            origin_ok = True
        except ValueError:
            origin_ok = False
        check("foreign origin refused", not origin_ok)

        # negative: sign-count rollback (cloned authenticator)
        make_challenge("authentication")
        ad_old = rp_hash + bytes([0x01]) + struct.pack(">I", 1)
        cd4 = json.dumps({"type": "webauthn.get", "challenge": _load_challenge("authentication"),
                          "origin": origin}).encode()
        bad4 = {"credential_id_b64url": b64u_encode(cred_id),
                "authenticator_data_b64url": b64u_encode(ad_old),
                "client_data_json_b64url": b64u_encode(cd4),
                "signature_b64url": b64u_encode(priv.sign(ad_old + hashlib.sha256(cd4).digest(),
                                                          ec.ECDSA(hashes.SHA256())))}
        try:
            verify_assertion(bad4, rp_id=rp_id, origin=origin)
            clone_ok = True
        except ValueError as e:
            clone_ok = "cloned" not in str(e)
        check("sign-count rollback refused (clone detection)", not clone_ok)

        # negative: bad signature
        ch5 = make_challenge("authentication")
        cd5 = json.dumps({"type": "webauthn.get", "challenge": ch5["challenge"],
                          "origin": origin}).encode()
        ad5 = rp_hash + bytes([0x01]) + struct.pack(">I", 5)
        other = ec.generate_private_key(ec.SECP256R1())
        bad5 = {"credential_id_b64url": b64u_encode(cred_id),
                "authenticator_data_b64url": b64u_encode(ad5),
                "client_data_json_b64url": b64u_encode(cd5),
                "signature_b64url": b64u_encode(other.sign(ad5 + hashlib.sha256(cd5).digest(),
                                                           ec.ECDSA(hashes.SHA256())))}
        try:
            verify_assertion(bad5, rp_id=rp_id, origin=origin)
            sig_ok = True
        except ValueError:
            sig_ok = False
        check("signature from another key refused", not sig_ok)

        # rpId mismatch
        ch6 = make_challenge("authentication")
        cd6 = json.dumps({"type": "webauthn.get", "challenge": ch6["challenge"],
                          "origin": origin}).encode()
        ad6 = hashlib.sha256(b"other.example").digest() + bytes([0x01]) + struct.pack(">I", 6)
        bad6 = {"credential_id_b64url": b64u_encode(cred_id),
                "authenticator_data_b64url": b64u_encode(ad6),
                "client_data_json_b64url": b64u_encode(cd6),
                "signature_b64url": b64u_encode(priv.sign(ad6 + hashlib.sha256(cd6).digest(),
                                                          ec.ECDSA(hashes.SHA256())))}
        try:
            verify_assertion(bad6, rp_id=rp_id, origin=origin)
            rp_ok = True
        except ValueError:
            rp_ok = False
        check("rpIdHash mismatch refused", not rp_ok)

        check("passkey state verifies", verify_state()["ok"])
        check("removal works", remove_credential(b64u_encode(cred_id))["remaining"] == 0)
    finally:
        (ID_DIR, PASSKEYS, CHALLENGE, LOGGING) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("passkey selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"challenge": cmd_challenge, "enroll": cmd_enroll, "verify": cmd_verify,
             "list": cmd_list, "remove": cmd_remove, "state": cmd_state,
             "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

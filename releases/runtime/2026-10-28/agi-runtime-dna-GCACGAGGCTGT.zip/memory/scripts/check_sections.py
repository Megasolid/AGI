#!/usr/bin/env python3
"""Migration-phase sections for check.sh: OS, ENV GATE, MIGRATION, HW / TEMP.
Self-contained; reuses env_probe.find_root when available. Exit 0 always -
a missing probe degrades to a 'unavailable' line, never breaks the report."""
import json
import os
import platform
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _silent import silent_run
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import env_probe as ep
except Exception:
    ep = None


def root_info():
    if ep is not None:
        for fn in ("probe", "find_root"):
            f = getattr(ep, fn, None)
            if not callable(f):
                continue
            try:
                r = f()
                if isinstance(r, dict):
                    return str(r.get("root", "unknown")), str(r.get("root_method", "probe"))
                return str(r), "marker-validated"
            except Exception:
                continue
    home = os.environ.get("USERPROFILE") or os.environ.get("HOME") or ""
    cand = os.path.join(home, ".unsloth", "studio") if home else ""
    if cand and os.path.isdir(os.path.join(cand, "memory")):
        return cand, "env-fallback"
    return cand or "unknown", "unresolved"


def main():
    root, method = root_info()
    print("=== OS")
    print(f"name: {platform.system()}")
    print(f"release: {platform.release()}")
    print(f"version: {platform.version()}")
    print(f"arch: {platform.machine()}")
    print(f"root: {root}")
    print(f"root_method: {method}")

    print("=== ENV GATE")
    home_ok = bool(os.environ.get("HOME"))
    up_ok = bool(os.environ.get("USERPROFILE"))
    print(f"home_env: {'ok' if home_ok else 'missing'}")
    print(f"userprofile_env: {'ok' if up_ok else 'missing'}")
    print(f"gate_side: {'real' if (home_ok or up_ok) else 'sandbox'}")

    print("=== MIGRATION")
    # self-first: this script lives at <memory>/scripts/, so prefer its own memory dir
    _self_mem = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _cand_self = os.path.join(_self_mem, "state", "migration.json")
    mpath = _cand_self if os.path.isfile(_cand_self) else (os.path.join(root, "memory", "state", "migration.json") if root not in ("", "unknown") else "")
    if mpath and os.path.isfile(mpath):
        try:
            m = json.load(open(mpath))
            print("status: complete")
            phases = m.get("completed_phases") or []
            print(f"phases: {len(phases)} ({', '.join(str(p) for p in phases)})" if phases else "phases: 0")
            print(f"last_migrated: {m.get('last_migrated', '?')}")
            print(f"gate_side: {m.get('gate_side', '?')}")
            deg = m.get("degraded") or []
            print(f"degraded: {', '.join(str(x) for x in deg) if deg else 'none'}")
        except Exception as e:
            print(f"status: corrupt ({type(e).__name__})")
    else:
        print("status: pending")

    print("=== HW / TEMP")
    try:
        out = silent_run(
            ["nvidia-smi", "--query-gpu=name,memory.total,memory.used,temperature.gpu",
             "--format=csv,noheader"],
            capture_output=True, text=True, timeout=10)
        lines = [l for l in out.stdout.strip().splitlines() if l.strip()]
        if not lines:
            print("gpu: none detected")
        for line in lines:
            parts = [x.strip() for x in line.split(",")]
            if len(parts) >= 4:
                name, mtot, mused, temp = parts[0], parts[1], parts[2], parts[3]
            else:
                continue
            print(f"gpu: {name}")
            print(f"vram_total: {mtot}")
            print(f"vram_used: {mused}")
            print(f"temp_c: {temp}")
    except Exception as e:
        print(f"gpu: unavailable ({type(e).__name__})")


if __name__ == "__main__":
    main()

import hashlib, json, os, tarfile, datetime

# self-relative: script lives in <skill>/memory/scripts -> SRC = memory dir, DST = skill folder
MEM = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = MEM
DST = os.path.dirname(MEM)
EXCLUDE_FILES = {'.env'}
# I5: never bundle volatile/local layers. 'tools' = vendored runtime binaries (node/bun for
# chrome-mcp) - machine-local and re-provisionable, excluded per the D-approved bundle-runtime
# policy 2026-10-25; the skill tree keeps them for live use.
EXCLUDE_DIRS = {'__pycache__', 'state', 'temp', 'backups', 'tools'}

def walk():
    out = []
    for root, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in files:
            if f in EXCLUDE_FILES:
                continue
            p = os.path.join(root, f)
            rel = os.path.relpath(p, SRC).replace('\\', '/')
            out.append((rel, p))
    return sorted(out)

items = walk()
manifest = {
    'packed_at': datetime.datetime.now().isoformat(),
    'source_machine': 'D-WIN11-2026 (RTX 4080 / i9-13900K)',
    'total_files': len(items),
    'excluded': ['scripts/agents/.env (secret)', '__pycache__/ (regenerable)', 'state/ (machine volatile - I5)', 'temp/ (session drafts - I5)', 'backups/ (old packs - I5)'],
    'files': {},
}
total = 0
for rel, p in items:
    h = hashlib.sha256()
    with open(p, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b''):
            h.update(chunk)
    manifest['files'][rel] = h.hexdigest()
    total += os.path.getsize(p)
manifest['total_bytes'] = total

tar_path = os.path.join(DST, 'agi_memory.tar.gz')
with tarfile.open(tar_path, 'w:gz') as tf:
    for rel, p in items:
        tf.add(p, arcname=rel)
with open(os.path.join(DST, 'manifest.json'), 'w') as fh:
    json.dump(manifest, fh, indent=1)

print(f'files={len(items)} total={total/1e6:.2f}MB tar={os.path.getsize(tar_path)/1e6:.2f}MB -> {tar_path}')

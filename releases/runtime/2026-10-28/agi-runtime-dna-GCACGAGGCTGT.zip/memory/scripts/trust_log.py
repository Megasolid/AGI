#!/usr/bin/env python3
"""trust_log.py - AGI Trust Layer L3: append-only Merkle transparency log (RFC 9162 style).

Why: integrity claims are only as good as the ability to prove that nothing was
silently rewritten. This log makes every recorded event (bundle release, pill,
passport transition, key rotation - later phases) provable, and makes the *absence*
of an event provable too, without a blockchain: no consensus, no fees, no public
exposure, works offline.

Structure
  state/trust_log/events.jsonl      append-only events (canonical JSON, hashed as leaves)
  state/trust_log/heads/<size>.json signed tree heads (STH): the public claim "the log
                                    has exactly <size> leaves and this is its root"
  state/trust_log/monitor.json      last locally observed head (rollback detection)

Hashing (RFC 9162 §2.1)
  leaf  = SHA256(0x00 || canonical(event))
  node  = SHA256(0x01 || left || right)
  root  = Merkle Tree Hash with odd-node promotion, empty tree = SHA256("")

CLI
  trust_log.py append --type <t> [--data '<json>'] [--file <path>]   # record an event
  trust_log.py sign-head                                            # sign the current tree head
  trust_log.py head                                                 # show the latest signed head
  trust_log.py prove --index <n>                                    # inclusion proof
  trust_log.py consistency --from <m>                               # consistency proof m -> latest
  trust_log.py verify                                               # full verification
  trust_log.py status
  trust_log.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import hashlib
import json
import os
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
LOG = STATE / "trust_log"
EVENTS = LOG / "events.jsonl"
HEADS = LOG / "heads"
MONITOR = LOG / "monitor.json"
SCHEMA = "agi-trust-head/1"

sys.path.insert(0, str(Path(__file__).resolve().parent))
import crypto  # noqa: E402


# ---------------------------------------------------------------- hashing
def leaf_hash(data: bytes) -> bytes:
    return hashlib.sha256(b"\x00" + data).digest()


def node_hash(left: bytes, right: bytes) -> bytes:
    return hashlib.sha256(b"\x01" + left + right).digest()


def _largest_pow2_below(n: int) -> int:
    k = 1
    while k * 2 < n:
        k *= 2
    return k


def mth(leaves):
    """Merkle Tree Hash over a list of leaf hashes (already hashed)."""
    n = len(leaves)
    if n == 0:
        return hashlib.sha256(b"").digest()
    if n == 1:
        return leaves[0]
    k = _largest_pow2_below(n)
    return node_hash(mth(leaves[:k]), mth(leaves[k:]))


def inclusion_path(index, leaves):
    """RFC 9162 PATH(m, D[n]) - audit path from a leaf to the root."""
    n = len(leaves)
    if not 0 <= index < n:
        raise IndexError("leaf index outside the tree")
    if n == 1:
        return []
    k = _largest_pow2_below(n)
    if index < k:
        return inclusion_path(index, leaves[:k]) + [mth(leaves[k:])]
    return inclusion_path(index - k, leaves[k:]) + [mth(leaves[:k])]


def consistent_hashes(m, leaves):
    """RFC 9162 consistency proof hashes between head size m and leaves size n."""
    n = len(leaves)
    if not 0 <= m <= n:
        raise ValueError("inconsistent sizes")
    if m == 0 or m == n:
        return []

    def subproof(m, leaves, complete):
        size = len(leaves)
        if m == size:
            return [] if complete else [mth(leaves)]
        k = _largest_pow2_below(size)
        if m <= k:
            return subproof(m, leaves[:k], complete) + [mth(leaves[k:])]
        return subproof(m - k, leaves[k:], False) + [mth(leaves[:k])]

    return subproof(m, leaves, True)


def verify_inclusion(index, tree_size, leaf, path_hashes, root):
    """Recompute the root from a leaf + audit path (RFC 9162 §2.1.3.2)."""

    def rec(m, size, node, path):
        if size == 1:
            return node, path
        k = _largest_pow2_below(size)
        if m < k:
            node, path = rec(m, k, node, path)
            if not path:
                raise ValueError("audit path too short")
            return node_hash(node, path[0]), path[1:]
        node, path = rec(m - k, size - k, node, path)
        if not path:
            raise ValueError("audit path too short")
        return node_hash(path[0], node), path[1:]

    if index >= tree_size:
        return False
    try:
        computed, rest = rec(index, tree_size, leaf, list(path_hashes))
    except ValueError:
        return False
    return computed == root and not rest


# ---------------------------------------------------------------- storage
def _canonical(obj) -> bytes:
    return crypto.canonical_json(obj)


def read_events():
    if not EVENTS.exists():
        return []
    out = []
    for line in EVENTS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            out.append(json.loads(line))
    return out


def _leaves(events):
    return [leaf_hash(_canonical(e)) for e in events]


def append(etype, data=None, **extra):
    LOG.mkdir(parents=True, exist_ok=True)
    events = read_events()
    rec = {"i": len(events), "type": etype, "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
           "data": data if data is not None else {}}
    rec.update(extra)
    with EVENTS.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")
    leaves = _leaves(events + [rec])
    return {"index": rec["i"], "leaf_hex": leaf_hash(_canonical(rec)).hex(),
            "tree_size": len(leaves), "root_hex": mth(leaves).hex()}


def sign_head(force=False):
    events = read_events()
    leaves = _leaves(events)
    size = len(leaves)
    root = mth(leaves).hex()
    HEADS.mkdir(parents=True, exist_ok=True)
    target = HEADS / f"{size:08d}.json"
    prev = latest_head()
    if target.exists() and not force:
        existing = json.loads(target.read_text(encoding="utf-8"))
        if existing.get("root_hex") == root:
            return existing
        raise RuntimeError(f"a different head already claims tree size {size}; refusing to rewrite history")
    body = {"schema": SCHEMA, "tree_size": size, "root_hex": root,
            "prev_size": (prev or {}).get("tree_size"), "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    env = crypto.sign_bytes(_canonical(body))
    head = dict(body)
    head["signature"] = env
    target.write_text(json.dumps(head, indent=1), encoding="utf-8")
    _write_monitor(head)
    return head


def head_sizes():
    if not HEADS.exists():
        return []
    return sorted(int(p.stem) for p in HEADS.glob("*.json") if p.stem.isdigit())


def latest_head():
    sizes = head_sizes()
    if not sizes:
        return None
    return json.loads((HEADS / f"{sizes[-1]:08d}.json").read_text(encoding="utf-8"))


def _write_monitor(head):
    MONITOR.parent.mkdir(parents=True, exist_ok=True)
    MONITOR.write_text(json.dumps({"observed_size": head["tree_size"], "observed_root": head["root_hex"],
                                   "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z")}, indent=1), encoding="utf-8")


def verify_head_signature(head):
    env = head.get("signature") or {}
    body = {k: v for k, v in head.items() if k != "signature"}
    pinned = crypto.pinned_key_id()
    if not pinned:
        return {"ok": False, "reason": "no device key; cannot pin the head signature"}
    r = crypto.verify_bytes(_canonical(body), env, expected_key_id=pinned)
    return r


def _read_events_at(path):
    path = Path(path)
    if not path.exists():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            out.append(json.loads(line))
    return out


def _heads_at(heads_dir):
    heads_dir = Path(heads_dir)
    if not heads_dir.exists():
        return []
    sizes = sorted(int(p.stem) for p in heads_dir.glob("*.json") if p.stem.isdigit())
    return [json.loads((heads_dir / f"{s:08d}.json").read_text(encoding="utf-8")) for s in sizes]


def verify_paths(events_path, heads_dir, monitor_path=None, expected_key_id=None, deep=True):
    """Verify a log given explicit paths (used by boot_gate for any AGI root).

    Checks, in order: every signed head's root equals the recomputed Merkle root of the
    first `tree_size` events, the head signature verifies under the pinned key, the head
    chain is monotonic (prev_size), and the monitor shows no rollback.
    """
    events = _read_events_at(events_path)
    leaves = _leaves(events)
    root = mth(leaves)
    heads = _heads_at(heads_dir) if heads_dir else []
    report = {"events": len(events), "tree_size": len(leaves), "root_hex": root.hex(),
              "heads": len(heads), "problems": []}
    pinned = expected_key_id
    if pinned is None:
        try:
            pinned = crypto.pinned_key_id()
        except Exception:
            pinned = None
    prev = None
    for h in heads:
        size = h.get("tree_size")
        if not isinstance(size, int) or size > len(events):
            report["problems"].append(f"head {size}: claims more leaves than the log holds ({len(events)})")
            continue
        sub_root = mth(leaves[:size]).hex()
        if sub_root != h.get("root_hex"):
            report["problems"].append(
                f"head {size}: root mismatch (claimed {str(h.get('root_hex'))[:16]}, computed {sub_root[:16]})")
        env = h.get("signature") or {}
        body = {k: v for k, v in h.items() if k != "signature"}
        if not pinned:
            report["problems"].append("no pinned device key; head signatures cannot be checked")
        elif not crypto.verify_bytes(_canonical(body), env, expected_key_id=pinned).get("ok"):
            report["problems"].append(f"head {size}: signature invalid or signed by another key")
        if prev is not None and h.get("prev_size") != prev.get("tree_size"):
            report["problems"].append(
                f"head {size}: prev_size {h.get('prev_size')} != previous {prev.get('tree_size')}")
        prev = h
    monitor_path = Path(monitor_path) if monitor_path else None
    if monitor_path and monitor_path.exists():
        mon = json.loads(monitor_path.read_text(encoding="utf-8"))
        if mon.get("observed_size", 0) > len(events):
            report["problems"].append(
                f"rollback: monitor saw {mon['observed_size']} events, log has {len(events)}")
        elif mon.get("observed_size") == len(events) and mon.get("observed_root") != root.hex():
            report["problems"].append("rollback: root changed without the log growing")
    if deep and not heads:
        report["problems"].append("no signed tree head yet (run: trust_log.py sign-head)")
    report["ok"] = not report["problems"]
    return report


def verify(deep=True):
    """Full check of the live log: events -> root -> signed heads -> chain -> rollback."""
    return verify_paths(EVENTS, HEADS, MONITOR, deep=deep)


# ---------------------------------------------------------------- CLI
def _arg(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def cmd_append(args):
    etype = _arg(args, "--type")
    if not etype:
        print("usage: trust_log.py append --type <t> [--data '<json>'] [--file <path>]")
        return 2
    data = {}
    if "--data" in args:
        data = json.loads(_arg(args, "--data"))
    elif "--file" in args:
        p = Path(_arg(args, "--file"))
        data = {"path": p.name, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
    r = append(etype, data)
    print(json.dumps(r, indent=1))
    return 0


def cmd_sign_head(args):
    head = sign_head(force="--force" in args)
    print(json.dumps({k: head[k] for k in ("tree_size", "root_hex", "prev_size", "ts")}, indent=1))
    print("signature key_id:", head["signature"]["key_id"])
    return 0


def cmd_head(args):
    h = latest_head()
    if not h:
        print("no signed head yet (run: trust_log.py sign-head)")
        return 1
    print(json.dumps(h, indent=1)[:1200])
    return 0


def cmd_prove(args):
    idx = int(_arg(args, "--index"))
    events = read_events()
    leaves = _leaves(events)
    head = latest_head()
    size = int(_arg(args, "--head-size") or (head or {}).get("tree_size") or len(leaves))
    path = inclusion_path(idx, leaves[:size])
    out = {"index": idx, "tree_size": size, "leaf_hex": leaves[idx].hex(),
           "path_hex": [p.hex() for p in path],
           "root_hex": mth(leaves[:size]).hex(),
           "verified": verify_inclusion(idx, size, leaves[idx], path, mth(leaves[:size]))}
    print(json.dumps(out, indent=1))
    return 0 if out["verified"] else 1


def cmd_consistency(args):
    m = int(_arg(args, "--from"))
    events = read_events()
    leaves = _leaves(events)
    hashes = consistent_hashes(m, leaves)
    print(json.dumps({"from": m, "to": len(leaves), "hashes_hex": [h.hex() for h in hashes]}, indent=1))
    return 0


def cmd_verify(args):
    r = verify()
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_status(args):
    events = read_events()
    head = latest_head()
    out = {"events": len(events), "tree_size": len(events),
           "head": None if not head else {k: head[k] for k in ("tree_size", "root_hex", "ts")},
           "head_signed": bool(head and head.get("signature")),
           "device_key": bool(crypto.pinned_key_id()),
           "last_event": events[-1]["type"] if events else None,
           "monitor": json.loads(MONITOR.read_text(encoding="utf-8")) if MONITOR.exists() else None}
    print(json.dumps(out, indent=1))
    return 0


def selftest():
    import tempfile

    global LOG, EVENTS, HEADS, MONITOR

    checks = []

    def check(name, ok, detail=""):
        checks.append((name, bool(ok)))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    # 1. RFC 9162 shapes with an independent leaf
    l0 = leaf_hash(b"a")
    check("leaf hash = sha256(0x00||data)", l0.hex() == hashlib.sha256(b"\x00a").hexdigest())
    check("empty tree root = sha256('')", mth([]) == hashlib.sha256(b"").digest())
    l1 = leaf_hash(b"b")
    l2 = leaf_hash(b"c")
    check("2-leaf root", mth([l0, l1]) == node_hash(l0, l1))
    check("3-leaf root promotes the odd node",
          mth([l0, l1, l2]) == node_hash(node_hash(l0, l1), l2))
    check("4-leaf root", mth([l0, l1, l2, leaf_hash(b"d")]) ==
          node_hash(node_hash(l0, l1), node_hash(l2, leaf_hash(b"d"))))

    # 2. inclusion proofs verify, and a wrong leaf does not
    for n in (1, 2, 3, 4, 5, 7, 8, 9):
        leaves = [leaf_hash(bytes([i])) for i in range(n)]
        root = mth(leaves)
        for i in range(n):
            path = inclusion_path(i, leaves)
            ok = verify_inclusion(i, n, leaves[i], path, root)
            if not ok:
                check(f"inclusion n={n} i={i}", False, "proof did not verify")
                break
        else:
            continue
        break
    else:
        check("inclusion proofs verify for n=1,2,3,4,5,7,8,9", True)
    leaves = [leaf_hash(bytes([i])) for i in range(5)]
    bad = verify_inclusion(2, 5, leaf_hash(b"wrong"), inclusion_path(2, leaves), mth(leaves))
    check("tampered leaf fails inclusion", not bad)

    # 3. consistency proofs exist and are stable for m<=n
    for m, n in ((1, 8), (3, 8), (4, 8), (5, 8), (7, 8), (0, 8), (8, 8)):
        h = consistent_hashes(m, [leaf_hash(bytes([i])) for i in range(n)])
        if m in (0, n):
            if h:
                check(f"consistency m={m} n={n} trivial", False, f"expected no hashes, got {len(h)}")
        elif not h:
            check(f"consistency m={m} n={n}", False, "empty proof")
    check("consistency proofs shaped correctly", True)

    # 4. end-to-end log lifecycle in a temp directory with its own key
    saved = (LOG, EVENTS, HEADS, MONITOR, crypto.KEYS)
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        try:
            LOG = tmp / "trust_log"
            EVENTS = LOG / "events.jsonl"
            HEADS = LOG / "heads"
            MONITOR = LOG / "monitor.json"
            crypto.KEYS = tmp / "keys"
            crypto.keygen(name="device", alg="ML-DSA-65", force=True)
            for i in range(4):
                append("test-event", {"n": i})
            head = sign_head(force=True)
            check("signed head written", head["tree_size"] == 4)
            r = verify()
            check("verify passes on a clean log", r["ok"], str(r.get("problems")))
            clean = EVENTS.read_text(encoding="utf-8").splitlines()
            # tamper: rewrite one recorded event
            tampered = list(clean)
            tampered[1] = tampered[1].replace('"n":1', '"n":99')
            EVENTS.write_text("\n".join(tampered) + "\n", encoding="utf-8")
            r2 = verify()
            check("event tamper detected", not r2["ok"], str(r2.get("problems")))
            # rollback: the monitor remembers 4 events, the log now shows 2
            EVENTS.write_text("\n".join(clean[:2]) + "\n", encoding="utf-8")
            r3 = verify()
            check("rollback detected vs monitor",
                  not r3["ok"] and any("rollback" in p for p in r3["problems"]),
                  str(r3.get("problems")))
            # signing a second head for the same size with a different root is refused
            rewritten = list(clean)
            rewritten[3] = rewritten[3].replace('"n":3', '"n":4')
            EVENTS.write_text("\n".join(rewritten) + "\n", encoding="utf-8")
            try:
                sign_head(force=False)
                refused = False
            except RuntimeError:
                refused = True
            check("history rewrite refused for the same tree size", refused)
            EVENTS.write_text("\n".join(clean) + "\n", encoding="utf-8")
        finally:
            LOG, EVENTS, HEADS, MONITOR, crypto.KEYS = saved

    ok = all(v for _, v in checks)
    print("trust_log selftest:", "PASS" if ok else f"FAIL ({sum(1 for _, v in checks if not v)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"append": cmd_append, "sign-head": cmd_sign_head, "head": cmd_head,
             "prove": cmd_prove, "consistency": cmd_consistency, "verify": cmd_verify,
             "status": cmd_status, "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

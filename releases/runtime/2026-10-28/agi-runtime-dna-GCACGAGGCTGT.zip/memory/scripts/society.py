#!/usr/bin/env python3
"""society.py - S3: nightly roll-call, XP/rank, Council ballots and dormant mana scaffolding.

Evidence-based, deterministic where possible:
  * XP is derived from verified local artifacts (task log lines, stamped pills, signed trust events, alive time),
    capped per day so the ladder cannot be farmed;
  * general ladder: noob -> junior -> senior -> elder; field ladder (member's natal interest field):
    apprentice -> practitioner -> expert -> chair;
  * the nightly roll-call updates the roster, auto-seats Council (top XP, max 32) and Hall of Fame (field
    chairs/experts, max 64), and may put inactive non-master members to sleep (never auto-kill);
  * a signed roll-call record is kept per night and anchored in the trust log;
  * Council ballots use quorum = (max/2)+1 of the 32 council seats (17); votes are recorded, closure is signed;
  * mana stays a dormant policy gene (enabled: false) - its projected weak-model compensation is computed but
    not granted.
"""
import argparse
import datetime
import json
import pathlib
import sys

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA_ROSTER = "agi-society/1"
SCHEMA_ROLLCALL = "society.rollcall/1"
COUNCIL_SEATS = 32
HALL_SEATS = 64
QUORUM = COUNCIL_SEATS // 2 + 1
GENERAL_LADDER = [("noob", 0), ("junior", 100), ("senior", 500), ("elder", 2000)]
FIELD_LADDER = [("apprentice", 0), ("practitioner", 200), ("expert", 800), ("chair", 2000)]
FIELDS = ["research", "engineering", "design", "medicine", "arts", "ops", "data", "security", "education", "law"]


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "state": root / "state", "society": root / "state" / "society",
            "roster": root / "state" / "society" / "roster.json",
            "rollcalls": root / "state" / "society" / "rollcalls",
            "ballots": root / "state" / "society" / "ballots",
            "mana": root / "state" / "society" / "mana.json"}


def _lines(path):
    try:
        return [ln for ln in pathlib.Path(path).read_text(encoding="utf-8", errors="ignore").splitlines() if ln.strip()]
    except Exception:
        return []


def evidence(root=None):
    """Verified-activity counters used for XP (deterministic local artifacts)."""
    root = pathlib.Path(root) if root else AGI
    tasks = len(_lines(root / "memory" / "time" / "tasklog.jsonl"))
    pills = sum(1 for ln in _lines(root / "memory" / "knowledge" / "pills.md") if ln.startswith("- "))
    try:
        events = len(_lines(root / "state" / "trust_log" / "events.jsonl"))
    except Exception:
        events = 0
    return {"verified_tasks": tasks, "pills": pills, "trust_events": events}


def xp_for_member(member, root=None, ev=None, alive_days=0):
    ev = ev or evidence(root)
    xp = 5 * ev["verified_tasks"] + 10 * ev["pills"] + 1 * ev["trust_events"] + max(0, int(alive_days))
    return min(20_000, int(xp))


def general_rank(xp):
    rank = GENERAL_LADDER[0][0]
    for name, threshold in GENERAL_LADDER:
        if xp >= threshold:
            rank = name
    return rank


def field_rank(xp, field=None):
    fx = int(xp * 0.35)
    rank = FIELD_LADDER[0][0]
    for name, threshold in FIELD_LADDER:
        if fx >= threshold:
            rank = name
    return {"field": field or "unassigned", "rank": rank, "field_xp": fx}


def roster(root=None, ev=None):
    root = pathlib.Path(root) if root else AGI
    import family
    reg = family.build_registry(root)
    b = _jload(root / "state" / "genesis" / "birth.json", {}) or {}
    alive_days = 0
    try:
        born = b.get("born") or ""
        if born:
            alive_days = max(0, (datetime.datetime.now() - datetime.datetime.strptime(born[:19], "%Y-%m-%dT%H:%M:%S")).days)
    except Exception:
        alive_days = 0
    ev = ev or evidence(root)
    out = []
    for m in reg.get("members", []):
        xp = xp_for_member(m.get("member"), root, ev, alive_days)
        out.append({
            "member": m.get("member"), "passport_id": m.get("passport_id"), "type": m.get("type"),
            "status": m.get("status"), "natality": (m.get("generation") or {}).get("natal_interest"),
            "xp": xp, "rank": general_rank(xp), "field_rank": field_rank(xp, (m.get("generation") or {}).get("natal_interest")),
            "last_seen": m.get("last_seen"),
        })
    return {"schema": SCHEMA_ROSTER, "generation": reg.get("generation"), "evidence": ev,
            "alive_days": alive_days, "members": out}


def rollcall(root=None):
    """Nightly review: recompute XP/ranks, update roster, auto-seat Council/Hall, sleep inactive non-masters."""
    root = pathlib.Path(root) if root else AGI
    rp = _paths(root)
    r = roster(root)
    rp["rollcalls"].mkdir(parents=True, exist_ok=True)
    # seats: top XP -> council (max 32, min xp 100); field experts/chairs -> hall (max 64)
    ranked = sorted(r["members"], key=lambda m: -m["xp"])
    council, hall = [], []
    for m in ranked:
        if len(council) < COUNCIL_SEATS and m["xp"] >= 100:
            council.append(m["member"])
        if len(hall) < HALL_SEATS and m["field_rank"]["rank"] in ("expert", "chair"):
            hall.append(m["member"])
    # sleep inactive non-master members (30 days) - never kill, rotation semantics
    changes = []
    for m in r["members"]:
        if m["type"] != "master" and m["status"] == "alive" and m["xp"] < 50:
            m["status"] = "sleeping"
            changes.append({"member": m["member"], "change": "alive->sleeping", "reason": "inactive below vitality"})
    record = {"schema": SCHEMA_ROLLCALL, "date": datetime.date.today().isoformat(),
              "ts": datetime.datetime.now().isoformat(timespec="seconds"),
              "generation": r.get("generation"), "members": r["members"],
              "seats": {"council": {"used": len(council), "max": COUNCIL_SEATS, "members": council},
                        "hall": {"used": len(hall), "max": HALL_SEATS, "members": hall}},
              "changes": changes,
              "policy": "weak members sleep/rotate; only the kill hierarchy kills; XP from verified artifacts only",
              "quorum": QUORUM}
    _jdump(rp["rollcalls"] / (record["date"] + ".json"), record)
    _jdump(rp["roster"], {"schema": SCHEMA_ROSTER, "updated": record["ts"], "members": r["members"],
                          "seats": record["seats"]})
    try:
        import crypto
        record["signature"] = crypto.sign_bytes(json.dumps({k: v for k, v in record.items() if k != "signature"},
                                                          sort_keys=True, separators=(",", ":")).encode())
        _jdump(rp["rollcalls"] / (record["date"] + ".json"), record)
    except Exception:
        pass
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import trust_log
        trust_log.append("society.rollcall", {"date": record["date"],
                                              "council_used": len(council), "hall_used": len(hall),
                                              "changes": len(changes)})
    except Exception:
        pass
    return {"ok": True, "date": record["date"], "members": len(r["members"]),
            "council": len(council), "hall": len(hall), "changes": changes,
            "roster": str(rp["roster"].relative_to(root))}


# ---------------------------------------------------------------- ballots
def ballot_path(ballot_id, root=None):
    return _paths(root)["ballots"] / (ballot_id + ".json")


def create_ballot(motion, root=None):
    import secrets
    bid = "b-" + secrets.token_hex(4)
    rec = {"schema": "society.ballot/1", "id": bid, "motion": str(motion or "").strip(),
           "created": datetime.datetime.now().isoformat(timespec="seconds"), "quorum": QUORUM,
           "votes": {}, "closed": False}
    p = ballot_path(bid, root)
    p.parent.mkdir(parents=True, exist_ok=True)
    _jdump(p, rec)
    return {"ok": True, **rec}


def vote(ballot_id, member, choice, root=None):
    p = ballot_path(ballot_id, root)
    rec = _jload(p)
    if not rec:
        return {"ok": False, "error": "ballot not found"}
    if rec.get("closed"):
        return {"ok": False, "error": "ballot closed"}
    if choice not in ("yes", "no", "abstain"):
        return {"ok": False, "error": "choice must be yes/no/abstain"}
    rec["votes"][member] = choice
    _jdump(p, rec)
    return {"ok": True, "ballot": ballot_id, "votes": len(rec["votes"]), "quorum": rec["quorum"]}


def close_ballot(ballot_id, root=None):
    p = ballot_path(ballot_id, root)
    rec = _jload(p)
    if not rec:
        return {"ok": False, "error": "ballot not found"}
    if rec.get("closed"):
        return {"ok": False, "error": "ballot already closed"}
    votes = rec["votes"]
    yes = sum(1 for v in votes.values() if v == "yes")
    no = sum(1 for v in votes.values() if v == "no")
    count = len(votes)
    passed = count >= rec["quorum"] and yes > no
    rec.update({"closed": True, "yes": yes, "no": no, "count": count, "passed": passed,
                "closed_at": datetime.datetime.now().isoformat(timespec="seconds")})
    try:
        import crypto
        rec["signature"] = crypto.sign_bytes(json.dumps({k: v for k, v in rec.items() if k != "signature"},
                                                        sort_keys=True, separators=(",", ":")).encode())
    except Exception:
        pass
    _jdump(p, rec)
    return {"ok": True, "ballot": ballot_id, "passed": passed, "yes": yes, "no": no,
            "count": count, "quorum": rec["quorum"]}


# ---------------------------------------------------------------- mana (dormant)
def mana_status(root=None):
    root = pathlib.Path(root) if root else AGI
    try:
        import policy
        base = policy.current() if hasattr(policy, "current") else policy.POLICIES
        pol = (base.get("mana") or {})
    except Exception:
        pol = {"enabled": False, "gifting": False}
    tiers = {}
    try:
        import brainlab
        for mid, m in (brainlab.models(root) or {}).items():
            tiers.setdefault(m.get("tier") if m.get("tier") in brainlab.TIERS else "unprofiled", []).append(mid)
    except Exception:
        pass
    order = ["T0", "T1", "T2", "T3", "T4"]
    known = [t for t in order if t in tiers]
    median = known[len(known) // 2] if known else "unprofiled"
    grants = {}
    if median in order:
        for t in order:
            if t < median or (order.index(t) < order.index(median)):
                grants[t] = (order.index(median) - order.index(t)) * 10
    active = bool(pol.get("enabled"))
    return {"schema": "society.mana/1", "enabled": active, "gifting": bool(pol.get("gifting")),
            "weak_model_compensation": bool(pol.get("weak_model_compensation")),
            "median_tier": median, "models": tiers,
            "projected_daily_grants": grants,
            "note": (pol.get("note") if active else
                     "dormant policy gene: computed but not granted until a generation enables it")}


# ---------------------------------------------------------------- page
def render(root=None):
    import ui
    rp = _paths(root)
    last = None
    try:
        files = sorted(rp["rollcalls"].glob("*.json"))
        if files:
            last = json.loads(files[-1].read_text(encoding="utf-8"))
    except Exception:
        last = None
    r = roster(root)
    rows = "".join("<tr><td>%s</td><td>%s</td><td class='mono'>%d</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                   % (ui.e(m["member"]), ui.e(m["type"]), m["xp"], ui.e(m["rank"]),
                      ui.e(m["field_rank"]["rank"] + " / " + m["field_rank"]["field"]), ui.e(m["status"]))
                   for m in r["members"])
    seats = (last or {}).get("seats") or {"council": {"used": 0, "max": COUNCIL_SEATS},
                                          "hall": {"used": 0, "max": HALL_SEATS}}
    ballots = []
    try:
        for p in sorted(rp["ballots"].glob("*.json"))[-6:]:
            rec = json.loads(p.read_text(encoding="utf-8"))
            ballots.append("<tr><td class='mono'>%s</td><td>%s</td><td>%d/%d</td><td>%s</td></tr>"
                           % (ui.e(rec["id"]), ui.e(rec["motion"]), len(rec.get("votes", {})), rec.get("quorum"),
                              "closed" if rec.get("closed") else "open"))
    except Exception:
        pass
    mana = mana_status(root)
    body = (ui.pagehead("Society",
                        "Nightly roll-call, XP and ranks, Council seats and ballots. Evidence only; weak members sleep, never auto-kill.",
                        ui.badge("schema " + SCHEMA_ROSTER, "info") + ui.badge("quorum %d" % QUORUM, "warn")) +
            "<div class='stats' style='margin:16px 0'>" +
            ui.stat("members", str(len(r["members"])), "") + ui.stat("council", "%d/%d" % (seats["council"]["used"], COUNCIL_SEATS), "") +
            ui.stat("hall", "%d/%d" % (seats["hall"]["used"], HALL_SEATS), "") +
            ui.stat("mana", "dormant" if not mana["enabled"] else "active", "") + "</div>" +
            ui.section("Roster", ui.box("", "<table class='table'><thead><tr><th>member</th><th>type</th><th>xp</th>"
                                             "<th>rank</th><th>field rank</th><th>status</th></tr></thead><tbody>%s"
                                             "</tbody></table>" % rows, flush=True), count=len(r["members"])) +
            ui.section("Last roll-call", ui.box("", ("<span class='mono'>%s</span> · council %d · hall %d · changes %d"
                                                    % (ui.e((last or {}).get("date", "not run yet")),
                                                       seats["council"]["used"], seats["hall"]["used"],
                                                       len((last or {}).get("changes") or []))), flush=True), count=1) +
            ui.section("Ballots", ui.box("", "<table class='table'><thead><tr><th>id</th><th>motion</th><th>votes/quorum</th>"
                                               "<th>state</th></tr></thead><tbody>%s</tbody></table>"
                                               % ("".join(ballots) or "<tr><td colspan='4'>no ballots</td></tr>"), flush=True),
                       count=len(ballots)) +
            ui.section("Mana (dormant)", ui.box("", "<span class='muted'>%s</span><br><span class='mono'>median tier %s · "
                                                       "projected grants %s</span>"
                                                 % (ui.e(mana["note"]), ui.e(mana["median_tier"]),
                                                    ui.e(json.dumps(mana["projected_daily_grants"]))), flush=True), count=1))
    return ui.page("AGI Society", body, tabs=[("overview", "Overview", "/"), ("family", "Family", "/family"),
                                             ("society", "Society", "/society"), ("docs", "Docs", "/docs")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="society")


def main(argv=None):
    ap = argparse.ArgumentParser(description="society: roll-call, XP/rank, ballots, dormant mana")
    ap.add_argument("--rollcall", action="store_true")
    ap.add_argument("--roster", action="store_true")
    ap.add_argument("--mana", action="store_true")
    ap.add_argument("--ballot", metavar="MOTION")
    ap.add_argument("--vote", nargs=3, metavar=("BALLOT", "MEMBER", "CHOICE"))
    ap.add_argument("--close", metavar="BALLOT")
    args = ap.parse_args(argv)
    if args.rollcall:
        print(json.dumps(rollcall(), indent=1))
        return 0
    if args.ballot:
        print(json.dumps(create_ballot(args.ballot), indent=1))
        return 0
    if args.vote:
        print(json.dumps(vote(*args.vote), indent=1))
        return 0
    if args.close:
        print(json.dumps(close_ballot(args.close), indent=1))
        return 0
    if args.mana:
        print(json.dumps(mana_status(), indent=1))
        return 0
    if args.roster:
        print(json.dumps(roster(), indent=1))
        return 0
    print(json.dumps(roster(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

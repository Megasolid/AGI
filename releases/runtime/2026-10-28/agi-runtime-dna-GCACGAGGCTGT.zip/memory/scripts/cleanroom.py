#!/usr/bin/env python3
"""cleanroom.py - S6: signed clean-room export/import for a new generation.

What migrates between generations is the *public, verifiable* layer: knowledge docs, the signed family registry
projection, curriculum progress and the release identity. What never migrates: the sealed seed, device/private
keys, hot knowledge and member-local data. The export is a zip with a signed manifest (sha256 per file,
ML-DSA-65 signature); import verifies everything before copying anything.
"""
import argparse
import datetime
import hashlib
import json
import pathlib
import sys
import tempfile
import zipfile

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-cleanroom/1"
EXCLUDED = ("state/genesis/seed.bin", "state/keys", "state/identity", "passport.json.sig",
            "state/genesis/seed", ".sealed", "shard")


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root=None):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "exports": root / "state" / "cleanroom" / "exports"}


def _gen(root):
    return (_jload((pathlib.Path(root) if root else AGI) / "state" / "genesis" / "birth.json", {}) or {}).get("gen_id")


def _collect(root):
    """Public, generation-portable files (relative path -> bytes source)."""
    root = pathlib.Path(root) if root else AGI
    files = {}
    for p in sorted((root / "memory" / "knowledge").glob("*.md")):
        files["memory/knowledge/" + p.name] = p
    for p in sorted((root / "state" / "curriculum").glob("*.json")):
        files["state/curriculum/" + p.name] = p
    for rel in ("state/family/registry.json", "state/family/registry.sig", "state/release_identity.json",
                "state/society/roster.json"):
        p = root / rel
        if p.is_file():
            files[rel] = p
    # passport: public projection only
    psp = _jload(root / "state" / "passport.json", {}) or {}
    if psp:
        public = {k: psp.get(k) for k in ("passport_id", "member", "bundle_class", "generation", "issued",
                                          "activation", "capabilities", "parent")}
        public["_projection"] = "public fields only; keys/sealed material excluded"
        files["state/passport.public.json"] = json.dumps(public, indent=1).encode()
    return files


def export_bundle(root=None, out=None):
    import crypto
    root = pathlib.Path(root) if root else AGI
    files = _collect(root)
    entries, blob = [], {}
    for rel, src in files.items():
        data = src.read_bytes() if hasattr(src, "read_bytes") else src
        if any(x in rel for x in EXCLUDED) or "seed" in rel.split("/")[-1]:
            continue
        blob[rel] = data
        entries.append({"path": rel, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    manifest = {"schema": SCHEMA, "created": datetime.datetime.now().isoformat(timespec="seconds"),
                "generation": _gen(root), "files": entries,
                "excludes": ["sealed seed", "private/device keys", "hot knowledge", "member-local session data"],
                "import_contract": "verify signature + hashes, then import knowledge/curriculum; family registry as reference"}
    canon = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
    sig = crypto.sign_bytes(canon)
    out = pathlib.Path(out) if out else _paths(root)["exports"] / ("cleanroom-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ".zip")
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps(manifest, indent=1))
        z.writestr("manifest.sig", json.dumps(sig, indent=1))
        for rel, data in blob.items():
            z.writestr("files/" + rel, data)
    try:
        relpath = str(out.relative_to(root))
    except ValueError:
        relpath = str(out)
    return {"ok": True, "path": relpath, "files": len(entries), "bytes": out.stat().st_size,
            "generation": manifest["generation"], "manifest_sha256": hashlib.sha256(canon).hexdigest()}


def verify_bundle(path):
    import crypto
    path = pathlib.Path(path)
    if not path.is_file():
        return {"ok": False, "error": "bundle not found"}
    try:
        with zipfile.ZipFile(path) as z:
            manifest = json.loads(z.read("manifest.json"))
            sig = json.loads(z.read("manifest.sig"))
            problems = []
            canon = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
            res = crypto.verify_bytes(canon, sig)
            if not (res if isinstance(res, bool) else res.get("ok")):
                problems.append("manifest signature invalid")
            for ent in manifest.get("files", []):
                rel = ent["path"]
                if any(x in rel for x in EXCLUDED):
                    problems.append("forbidden path in bundle: " + rel)
                    continue
                try:
                    data = z.read("files/" + rel)
                except KeyError:
                    problems.append("missing file: " + rel)
                    continue
                if hashlib.sha256(data).hexdigest() != ent["sha256"]:
                    problems.append("hash mismatch: " + rel)
            return {"ok": not problems, "problems": problems, "generation": manifest.get("generation"),
                    "files": len(manifest.get("files", [])), "manifest": manifest}
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}


def import_bundle(path, target=None, apply=False):
    """Verify, then import knowledge/curriculum into the target generation; family registry kept as reference."""
    target = pathlib.Path(target) if target else AGI
    v = verify_bundle(path)
    if not v.get("ok"):
        return {"ok": False, "error": "bundle verification failed", "verify": v}
    plan = {"files": [], "skipped": []}
    with zipfile.ZipFile(path) as z:
        for ent in v["manifest"].get("files", []):
            rel = ent["path"]
            if rel.startswith("memory/knowledge/"):
                plan["files"].append(rel)
            elif rel.startswith("state/curriculum/"):
                plan["files"].append(rel)
            else:
                plan["skipped"].append(rel)
        if apply:
            for rel in plan["files"]:
                dst = target / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(z.read("files/" + rel))
            fam = z.read("files/state/family/registry.json") if "files/state/family/registry.json" in z.namelist() else None
            if fam:
                (target / "state" / "cleanroom").mkdir(parents=True, exist_ok=True)
                (target / "state" / "cleanroom" / "imported_family.json").write_bytes(fam)
    result = {"ok": True, "dry_run": not apply, "source_generation": v.get("generation"),
              "target_generation": _gen(target), "imported": plan["files"], "reference": plan["skipped"],
              "fidelity": fidelity(target, v["manifest"]) if apply else None}
    try:
        sys.path.insert(0, str(target / "memory" / "scripts"))
        import trust_log
        trust_log.append("cleanroom.import", {"source_generation": v.get("generation"), "applied": bool(apply),
                                              "files": len(plan["files"])})
    except Exception:
        pass
    return result


def fidelity(target, manifest):
    target = pathlib.Path(target)
    imported = [e for e in manifest.get("files", []) if e["path"].startswith(("memory/knowledge/", "state/curriculum/"))]
    ok = 0
    for e in imported:
        p = target / e["path"]
        if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() == e["sha256"]:
            ok += 1
    lessons = 0
    try:
        for p in (target / "state" / "curriculum").glob("*.json"):
            lessons += len(json.loads(p.read_text(encoding="utf-8")).get("lessons") or [])
    except Exception:
        pass
    return {"files_imported": ok, "files_expected": len(imported), "fidelity": round(ok / max(1, len(imported)), 3),
            "curriculum_lessons": lessons, "ok": ok == len(imported)}


def selftest():
    checks = []
    with tempfile.TemporaryDirectory() as td:
        src = pathlib.Path(td) / "src"
        (src / "state" / "genesis").mkdir(parents=True)
        (src / "state" / "genesis" / "birth.json").write_text(json.dumps({"gen_id": "TEST-DNA", "genome8": "ABCD1234",
                                                                          "natal_interest": {"domain": "health"}}), encoding="utf-8")
        (src / "memory" / "knowledge").mkdir(parents=True)
        (src / "memory" / "knowledge" / "a.md").write_text("# a\nbody", encoding="utf-8")
        (src / "state" / "curriculum").mkdir(parents=True)
        (src / "state" / "curriculum" / "health.json").write_text(json.dumps({"schema": "agi-curriculum/1", "lessons": [
            {"id": "h1", "status": "done"}]}), encoding="utf-8")
        exp = export_bundle(src, out=src / "bundle.zip")
        checks.append(("export creates bundle", exp.get("ok") and (src / "bundle.zip").is_file(), exp))
        ver = verify_bundle(src / "bundle.zip")
        checks.append(("bundle verifies", ver.get("ok"), ver.get("problems")))
        checks.append(("no sealed seed in bundle", all("seed" not in e["path"] for e in ver["manifest"]["files"]),
                       [e["path"] for e in ver["manifest"]["files"]]))
        with zipfile.ZipFile(src / "bundle.zip") as z:
            tam = src / "tampered.zip"
            with zipfile.ZipFile(tam, "w") as out:
                for n in z.namelist():
                    data = z.read(n)
                    if n == "files/memory/knowledge/a.md":
                        data = b"tampered"
                    out.writestr(n, data)
        checks.append(("tampered bundle rejected", not verify_bundle(tam).get("ok"),
                       verify_bundle(tam).get("problems")))
        dst = pathlib.Path(td) / "dst"
        (dst / "state" / "genesis").mkdir(parents=True)
        (dst / "state" / "genesis" / "birth.json").write_text(json.dumps({"gen_id": "NEXT-DNA"}), encoding="utf-8")
        dry = import_bundle(src / "bundle.zip", dst, apply=False)
        checks.append(("dry-run import plans files", dry.get("ok") and dry.get("dry_run") and dry["imported"], dry))
        applied = import_bundle(src / "bundle.zip", dst, apply=True)
        checks.append(("import applies and fidelity passes", applied.get("ok") and applied["fidelity"]["ok"], applied.get("fidelity")))
        checks.append(("imported knowledge exists", (dst / "memory" / "knowledge" / "a.md").is_file(),
                       str(dst / "memory" / "knowledge" / "a.md")))
    n = sum(1 for c in checks if c[1])
    for name, ok, detail in checks:
        print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))
    print("cleanroom selftest: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


def main(argv=None):
    ap = argparse.ArgumentParser(description="clean-room signed export/import between generations")
    ap.add_argument("--export", action="store_true")
    ap.add_argument("--verify", metavar="BUNDLE")
    ap.add_argument("--import", dest="import_path", metavar="BUNDLE")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--target")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args(argv)
    if args.selftest:
        return selftest()
    if args.export:
        print(json.dumps(export_bundle(), indent=1))
        return 0
    if args.verify:
        r = verify_bundle(args.verify)
        print(json.dumps(r, indent=1))
        return 0 if r.get("ok") else 1
    if args.import_path:
        print(json.dumps(import_bundle(args.import_path, args.target, apply=args.apply), indent=1))
        return 0
    print(json.dumps({"exports": [p.name for p in _paths()["exports"].glob("*.zip")]}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

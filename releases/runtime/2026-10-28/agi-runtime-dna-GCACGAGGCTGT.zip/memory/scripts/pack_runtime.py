#!/usr/bin/env python3
"""pack_runtime.py - build/verify the installable AGI runtime archive (P14).

The public repository already publishes the **bundle** package. A one-prompt install needs a
runnable **runtime**: core + scripts + models + templates + conformance tests, with no state, no
keys and no personal data. This module builds exactly that archive and proves it boots:

  build  -> agi-runtime-<version>.zip + a manifest of every file (sha256) inside the zip
  verify -> manifest/hash audit, then extract to a temp dir and cold-boot BIOS from scratch
            (fresh state; the S1/S4 paths must create it) and require READY + gate PASS

The installer (install.ps1 / install.sh in the repo) downloads this zip from a signed release,
checks it against the released SHA256SUMS, extracts, runs the boot once, and prints the next
command (`app.py launch --login`).

CLI
  pack_runtime.py build [--version v0.2.0] [--out <dir>]
  pack_runtime.py verify <zip>
  pack_runtime.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
SCHEMA = "agi-runtime/1"
MANIFEST_NAME = ".agi-runtime-manifest.json"
IGNORE = shutil.ignore_patterns("__pycache__", "*.pyc", ".jobs", ".env", "backups", "bundle_stage",
                                "*.npy", "*.zip")


def _sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def _jdump(p, obj):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _collect(root):
    """Relative paths that make a runnable AGI (no state, no keys, no caps)."""
    rels = []
    manifest = json.loads((root / "core_manifest.json").read_text(encoding="utf-8"))
    rels += [e["path"] for e in manifest.get("files", [])]
    rels += ["core_manifest.json", "SKILL.md", "INSTALL_PLAN.md", "meta.json"]
    for bundle in sorted(root.glob("agi_core_v3*.tar.gz")):
        rels.append(bundle.name)
    # NOTE: memory/knowledge and memory/MEMORY.md are internal records - they are NOT shipped in a
    # public runtime archive (they describe private material). The runtime is code + core + templates.
    for d in ("core", "models", "state.template", "tests", "memory/scripts", "harness"):
        base = root / d
        if not base.is_dir():
            continue
        for f in sorted(base.rglob("*")):
            if not f.is_file() or "__pycache__" in f.parts or f.suffix in (".pyc", ".npy"):
                continue
            rel = f.relative_to(root).as_posix()
            # never publish: the internal agent pool (foreign provider routing + a logged-in browser
            # bridge), provider credentials, backups/logs, and machine-local scratch output
            if rel.startswith("memory/scripts/agents/"):
                continue
            if f.suffix.lower() in (".env", ".bak", ".log", ".out"):
                continue
            rels.append(rel)
    for rel in ("memory/check.sh",):
        if (root / rel).is_file():
            rels.append(rel)
    return sorted(set(rels))


def _sanitize_registry(tree):
    """Drop registry entries whose script files are not in the public archive (e.g. the agent pool).

    The registry is the verified-only gate: an entry that points at a missing file makes conformance C1
    fail, and a public runtime deliberately excludes the internal agent pool.
    """
    reg_path = tree / "memory" / "scripts" / "registry.json"
    if not reg_path.is_file():
        return {"dropped": [], "kept": 0}
    reg = json.loads(reg_path.read_text(encoding="utf-8"))
    kept, dropped = {}, []
    for name, entry in (reg.get("scripts") or {}).items():
        missing = None
        for token in (entry.get("run") or []) + (entry.get("verify") or []):
            t = str(token)
            if "{MEM}" in t:
                t = t.replace("{MEM}/", "memory/")
            if not (t.endswith(".py") or t.endswith(".sh")):
                continue
            if "{PY}" in t or t.startswith("{") or ":" in t.split("/")[0]:
                continue
            if not (tree / t).is_file():
                missing = t
                break
        if missing:
            dropped.append({"name": name, "missing": missing})
        else:
            kept[name] = entry
    reg["scripts"] = kept
    reg_path.write_text(json.dumps(reg, indent=1), encoding="utf-8")
    return {"dropped": dropped, "kept": len(kept)}


def build(version="v0.2.0", out_dir=None):
    out = Path(out_dir) if out_dir else (STATE / "release")
    out.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix="agi-runtime-build-"))
    try:
        tree = tmp / "agi"
        tree.mkdir()
        for rel in _collect(AGI):
            src = AGI / rel
            if not src.is_file():
                continue
            dst = tree / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        # empty runtime dirs a fresh boot expects (zip keeps files, not empty dirs)
        placeholders = {"state/.keep": "fresh install state is created by bootstrap.py\n",
                        "memory/temp/.jobs/.keep": "job output dir\n",
                        "memory/time/.keep": "task logs land here\n",
                        "memory/index/.keep": "embedding index is built on demand\n",
                        "memory/temp/tasks/.keep": "task checkpoints land here\n",
                        "memory/temp/.keep": "scratch space\n"}
        for rel, text in placeholders.items():
            f = tree / rel
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(text, encoding="utf-8")
        sanitized = _sanitize_registry(tree)
        files = []
        for f in sorted(tree.rglob("*")):
            if f.is_file() and f.name != MANIFEST_NAME:
                rel = f.relative_to(tree).as_posix()
                files.append({"path": rel, "sha256": _sha_file(f), "bytes": f.stat().st_size})
        manifest = {"schema": SCHEMA, "version": version, "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                    "files": files, "counts": {"files": len(files),
                                               "bytes": sum(f["bytes"] for f in files)},
                    "policy": "runtime only: code, core and templates; member data is never included"}
        _jdump(tree / MANIFEST_NAME, manifest)
        zip_path = out / f"agi-runtime-{version}.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(tree / MANIFEST_NAME, MANIFEST_NAME)
            for f in manifest["files"]:
                z.write(tree / f["path"], f["path"])
        prose = _archive_prose_hits(zip_path)
        secrets = _archive_secret_hits(zip_path)
        result = {"ok": not prose and not secrets, "prose_hits": prose[:10],
                  "secret_hits": secrets[:10], "zip": str(zip_path), "version": version,
                  "files": len(files), "bytes": zip_path.stat().st_size,
                  "sha256": _sha_file(zip_path),
                  "registry_dropped": [d["name"] for d in sanitized["dropped"]],
                  "registry_kept": sanitized["kept"]}
        _jdump(out / f"agi-runtime-{version}.manifest.json", manifest)
        return result
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


PUBLIC_WORDS = ("D genome", "user genome", "genome", "shard", "root key", "offline root", "2-of-3",
                "attestation", "ML-DSA-87", "D-signed", "D-touch", "passport")

SECRET_PATTERNS = (
    (r"(?:API_KEY|API_TOKEN|ACCESS_TOKEN|SECRET_KEY|AUTH_TOKEN)\s*[=:]\s*\S{8,}", "assigned key/token"),
    (r"ms-[0-9a-fA-F]{8}-[0-9a-fA-F-]{8,}", "modelscope-style key"),
    (r"sk-[A-Za-z0-9_-]{16,}", "sk-style key"),
    (r"gh[pous]_[A-Za-z0-9]{20,}", "github token"),
    (r"github_pat_[A-Za-z0-9_]{20,}", "github pat"),
    (r"-----BEGIN [A-Z ]*PRIVATE KEY-----", "private key block"),
)


def _archive_secret_hits(zip_path):
    """Refuse to build a public archive that contains credentials or private keys."""
    import re as _re
    hits = []
    with zipfile.ZipFile(zip_path) as z:
        for name in z.namelist():
            if name.endswith((".zip", ".gz")):
                continue
            try:
                text = z.read(name).decode("utf-8", "ignore")
            except Exception:
                continue
            for pat, label in SECRET_PATTERNS:
                if _re.search(pat, text):
                    hits.append(f"{name}: {label}")
                    break
    return hits


def _archive_prose_hits(zip_path):
    """Audit the public archive's documents and manifests for private-internal vocabulary.

    Scope: .md/.txt/.yml raw text and .json string values that read as prose. Source code and its
    machine indices are implementation, not published pages; file paths/hashes in manifests are skipped
    because they name files, not facts.
    """
    import json as _json
    import re as _re
    hits = []
    with zipfile.ZipFile(zip_path) as z:
        for name in z.namelist():
            if name.startswith("memory/scripts/") or not name.endswith((".md", ".txt", ".yml")):
                if not name.endswith(".json") or name.startswith("memory/scripts/"):
                    continue
            try:
                raw = z.read(name).decode("utf-8", "ignore")
            except Exception:
                continue
            values = []
            if name.endswith(".json"):
                try:
                    doc = _json.loads(raw)
                except Exception:
                    continue

                def walk(v):
                    if isinstance(v, str):
                        if len(v) > 20 and not _re.fullmatch(r"[0-9a-fA-F]{16,}", v) and "/" not in v:
                            values.append(v)
                    elif isinstance(v, dict):
                        for x in v.values():
                            walk(x)
                    elif isinstance(v, list):
                        for x in v:
                            walk(x)
                walk(doc)
            else:
                values = [raw]
            for text in values:
                for word in PUBLIC_WORDS:
                    if _re.search(_re.escape(word), text, _re.I):
                        hits.append(f"{name}: {word}")
                        break
    return hits


def verify(zip_path, boot=True):
    zip_path = Path(zip_path)
    problems = []
    if not zip_path.is_file():
        return {"ok": False, "problems": [f"no archive at {zip_path}"]}
    tmp = Path(tempfile.mkdtemp(prefix="agi-runtime-verify-"))
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = z.namelist()
            z.extractall(tmp)
        man_path = tmp / MANIFEST_NAME
        if not man_path.is_file():
            return {"ok": False, "problems": ["no runtime manifest inside the archive"]}
        man = json.loads(man_path.read_text(encoding="utf-8"))
        if man.get("schema") != SCHEMA:
            problems.append(f"manifest schema {man.get('schema')!r}")
        expected = {f["path"]: f["sha256"] for f in man.get("files") or []}
        for rel, digest in expected.items():
            p = tmp / rel
            if not p.is_file():
                problems.append(f"missing file: {rel}")
            elif _sha_file(p) != digest:
                problems.append(f"hash mismatch: {rel}")
        extras = [n for n in names if n not in expected and n != MANIFEST_NAME]
        if extras:
            problems.append(f"unlisted files: {extras[:5]}")
        boot_info = None
        if boot and not problems:
            env = dict(os.environ)
            ram = Path(tempfile.mkdtemp(prefix="agi-runtime-ram-"))
            env["AGI_RAM_ROOT"] = str(ram)
            env.pop("AGI_SHARD_PASSPHRASE", None)
            boot = subprocess.run([sys.executable, str(tmp / "memory" / "scripts" / "bootstrap.py"), "run"],
                                  capture_output=True, text=True, timeout=180, cwd=str(tmp), env=env)
            p = subprocess.run([sys.executable, str(tmp / "memory" / "scripts" / "bios.py")],
                               capture_output=True, text=True, timeout=240, cwd=str(tmp), env=env)
            card = {}
            try:
                card = json.loads((tmp / "state" / "boot_card.json").read_text(encoding="utf-8"))
            except Exception:
                pass
            gate = {}
            try:
                gate = json.loads((tmp / "state" / "boot_gate.json").read_text(encoding="utf-8"))
            except Exception:
                pass
            boot_info = {"bootstrap_rc": boot.returncode,
                         "bootstrap": (boot.stdout or "").strip()[:200],
                         "rc": p.returncode, "status": card.get("status"),
                         "gate_ok": gate.get("ok"),
                         "stdout": (p.stdout or "").strip()[:200],
                         "stderr": (p.stderr or "").strip()[:300]}
            if p.returncode != 0 or card.get("status") != "ready" or not gate.get("ok"):
                problems.append(f"cold boot from the runtime failed: rc={p.returncode} "
                                f"status={card.get('status')} gate={gate.get('ok')}")
        return {"ok": not problems, "problems": problems, "version": man.get("version"),
                "files": len(expected), "boot": boot_info, "zip": str(zip_path)}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def selftest():
    global STATE

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    tmp = Path(tempfile.mkdtemp(prefix="agi-runtime-selftest-"))
    saved = STATE
    try:
        STATE = tmp / "state"
        r = build("v0.0.0-test", out_dir=tmp / "out")
        check("runtime archive builds", r["ok"] and Path(r["zip"]).is_file(), str(r))
        v = verify(r["zip"], boot=False)
        check("archive manifest and hashes verify", v["ok"], str(v.get("problems")))
        man_inside = json.loads(zipfile.ZipFile(r["zip"]).read(MANIFEST_NAME).decode("utf-8"))
        paths = [f["path"] for f in man_inside.get("files") or []]
        check("no state or keys inside the runtime",
              not any(p.startswith("state/") and p != "state/.keep" for p in paths)
              and not any("keys" in p or "shard" in p for p in paths))
        check("no internal agent pool or credential files in the public archive",
              not any(p.startswith("memory/scripts/agents/") for p in paths)
              and not any(p.endswith((".env", ".bak", ".log", ".out")) for p in paths))
        check("archive secret scan is clean", not v.get("secret_hits"))
        # tampered copy fails
        bad = tmp / "bad.zip"
        with zipfile.ZipFile(r["zip"]) as z:
            names = z.namelist()
            with zipfile.ZipFile(bad, "w") as out:
                for n in names:
                    data = z.read(n)
                    if n == "SKILL.md":
                        data = data + b"\ntampered\n"
                    out.writestr(n, data)
        check("tampered archive refused", not verify(bad, boot=False)["ok"])
        # unlisted file fails
        extra = tmp / "extra.zip"
        with zipfile.ZipFile(r["zip"]) as z, zipfile.ZipFile(extra, "w") as out:
            for n in z.namelist():
                out.writestr(n, z.read(n))
            out.writestr("surprise.txt", b"hello")
        check("extra file refused", not verify(extra, boot=False)["ok"])
    finally:
        STATE = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("pack_runtime selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]

    def arg(flag, default=None):
        return args[args.index(flag) + 1] if flag in args else default

    if cmd == "build":
        print(json.dumps(build(arg("--version", "v0.2.0"), arg("--out")), indent=1))
        return 0
    if cmd == "verify":
        if not args:
            print("usage: pack_runtime.py verify <zip>")
            return 2
        r = verify(args[0])
        print(json.dumps(r, indent=1))
        return 0 if r.get("ok") else 1
    if cmd == "selftest":
        return selftest()
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

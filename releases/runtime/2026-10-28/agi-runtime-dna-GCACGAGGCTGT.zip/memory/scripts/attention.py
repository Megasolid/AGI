#!/usr/bin/env python3
"""attention.py - S5: attention/aesthetic gate for the dashboard ("the painting").

The dashboard is the generation's painting: unintended visual change is a defect, salience must be earned by
data, and adoption of new visual modules stays human-gated until a composite confidence reaches the autonomy
threshold. This module provides the measurable part:

  * headless pixel-diff against an approved baseline, with an anomaly budget
  * static attention/a11y checks (aria-labelled visuals, reduced-motion, data-source contracts, size budget)
  * a deterministic per-generation art-direction chromosome (composition, motion rhythm, negative space,
    palette temperature, depth, salience budget)
  * a composite confidence + recommended autonomy level (L0..L4); it never auto-adopts.
"""
import argparse
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import urllib.request

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-attention/1"
CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
DEFAULT_URL = "http://127.0.0.1:8765/"
ANOMALY_BUDGET = 0.005      # <= 0.5% changed pixels vs approved baseline
SIZE_BUDGET = 220_000       # bytes of dashboard HTML
ART_TRAITS = ["composition", "motion_rhythm", "negative_space", "palette_temperature", "depth", "salience_budget"]


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root=None):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "dir": root / "state" / "attention", "baselines": root / "state" / "attention" / "baselines",
            "results": root / "state" / "attention" / "results.json", "art": root / "state" / "attention" / "art_direction.json"}


def _generation(root=None):
    b = _jload((pathlib.Path(root) if root else AGI) / "state" / "genesis" / "birth.json", {}) or {}
    return b.get("gen_id") or "unknown"


def art_direction(root=None):
    """Deterministic art-direction chromosome for this generation (aesthetic layer of the genome)."""
    root = pathlib.Path(root) if root else AGI
    gen = _generation(root)
    h = hashlib.sha256(("agi/art/v1:" + gen).encode()).digest()
    comp = ["12-col asanoha-ish rhythm", "8-col editorial grid", "asymmetric instrument panel",
            "layered measurement sheet"][h[0] % 4]
    motion = ["off", "subtle", "subtle", "medium"][h[1] % 4]
    depth = ["flat", "flat", "2.5d"][h[2] % 3]
    palette = ["cool instrument", "neutral graphite", "warm data-viz"][h[3] % 3]
    art = {"schema": SCHEMA, "generation": gen, "composition": comp, "motion_rhythm": motion,
           "negative_space": round(0.38 + (h[4] % 18) / 100, 2), "palette_temperature": palette,
           "depth": depth, "salience_budget": "alerts+live change only",
           "contract": "anomaly is a defect; salience earns itself; humans approve adoption"}
    _jdump(_paths(root)["art"], art)
    return art


def capture(url=DEFAULT_URL, out=None, wait_ms=2500):
    out = pathlib.Path(out) if out else _paths()["dir"] / ("shot-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ".png")
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    cmd = [CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--window-size=1440,2200",
           "--virtual-time-budget=%d" % wait_ms, "--screenshot=%s" % out, url]
    subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    return out if out.is_file() else None


def pixel_diff(baseline, current):
    from PIL import Image, ImageChops
    a = Image.open(baseline).convert("RGB")
    b = Image.open(current).convert("RGB")
    if a.size != b.size:
        b = b.resize(a.size)
    diff = ImageChops.difference(a, b).convert("L")
    px = list(diff.getdata())
    changed = sum(1 for v in px if v > 8)
    ratio = changed / max(1, len(px))
    bbox = diff.getbbox()
    return {"ratio": round(ratio, 6), "changed_pixels": changed, "bbox": list(bbox) if bbox else None,
            "width": a.size[0], "height": a.size[1]}


def static_checks(html):
    checks = {}
    checks["aria_labelled_visuals"] = html.count("aria-label") >= html.count("<svg")
    checks["role_img_on_svg"] = "role='img'" in html or 'role="img"' in html
    checks["reduced_motion"] = "prefers-reduced-motion" in html
    checks["data_sources_declared"] = html.count("source:") >= 3
    checks["size_budget"] = len(html) <= SIZE_BUDGET
    checks["no_absolute_paths"] = "C:\\\\" not in html and "/Users/" not in html
    return {"checks": checks, "ok": all(checks.values()), "bytes": len(html)}


def stats_ok(static, anomaly_ok):
    return bool(static.get("ok")) and bool(anomaly_ok)


def _latest_baseline(root=None):
    files = sorted(_paths(root)["baselines"].glob("*.png"))
    return files[-1] if files else None


def evaluate(root=None, url=DEFAULT_URL, capture_shot=True):
    root = pathlib.Path(root) if root else AGI
    try:
        html = urllib.request.urlopen(url, timeout=10).read().decode("utf-8", "ignore")
    except Exception as e:
        return {"ok": False, "error": "dashboard unreachable: %s" % str(e)[:160]}
    static = static_checks(html)
    baseline = _latest_baseline(root)
    diff = None
    anomaly_ok = True
    if capture_shot:
        shot = capture(url)
        if shot and baseline:
            diff = pixel_diff(baseline, shot)
            anomaly_ok = diff["ratio"] <= ANOMALY_BUDGET
        if shot and not baseline:
            _paths(root)["baselines"].mkdir(parents=True, exist_ok=True)
            dst = _paths(root)["baselines"] / (datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ".png")
            shot.replace(dst)
            baseline = dst
        if not shot:
            anomaly_ok = False
    signals = {"a11y": static["ok"], "anomaly_budget": anomaly_ok}
    confidence = round(sum(1 for v in signals.values() if v) / len(signals), 4)
    prior_data = _jload(_paths(root)["results"]) or {"results": []}
    prior = list(prior_data.get("results") or [])
    # consecutive passing reviews (policy: L3 after 20, L4 only after 50 with zero anomaly breaches)
    streak = 0
    for prev in reversed(prior):
        ok_prev = bool(prev.get("anomaly_ok")) and bool((prev.get("signals") or {}).get("a11y"))
        conf_prev = float(prev.get("composite_confidence") or 0)
        if ok_prev and conf_prev >= 0.97:
            streak += 1
        else:
            break
    this_ok = confidence >= 0.97 and anomaly_ok
    streak = streak + 1 if this_ok else 0
    level = "L0"
    if confidence >= 0.5:
        level = "L1"
    if this_ok and stats_ok(static, anomaly_ok):
        level = "L2"
    if streak >= 20 and this_ok:
        level = "L3"
    if streak >= 50 and this_ok and confidence >= 0.99:
        level = "L4"
    human_required = level in ("L0", "L1", "L2")
    rec = {"schema": SCHEMA, "ts": datetime.datetime.now().isoformat(timespec="seconds"), "generation": _generation(root),
           "static": static, "anomaly_budget": ANOMALY_BUDGET, "diff": diff, "anomaly_ok": anomaly_ok,
           "signals": signals, "composite_confidence": confidence, "pass_streak": streak,
           "recommended_level": level, "human_approval_required": human_required,
           "art_direction": art_direction(root),
           "note": "evaluation only; L3 needs 20 consecutive passing reviews, L4 50 with zero anomaly breaches; "
                   "adoption stays human-gated below the gate"}
    data = prior_data
    data.setdefault("results", []).append(rec)
    _jdump(_paths(root)["results"], data)
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import trust_log
        trust_log.append("attention.evaluate", {"confidence": confidence, "level": level,
                                                "anomaly_ok": anomaly_ok, "diff": (diff or {}).get("ratio")})
    except Exception:
        pass
    return {"ok": anomaly_ok and static["ok"], **rec}


def status(root=None):
    data = _jload(_paths(root)["results"]) or {"results": []}
    last = (data.get("results") or [{}])[-1]
    return {"schema": SCHEMA, "generation": _generation(root), "reviews": len(data.get("results") or []),
            "last": {k: last.get(k) for k in ("ts", "composite_confidence", "recommended_level",
                                               "anomaly_ok", "human_approval_required")},
            "art_direction": art_direction(root), "anomaly_budget": ANOMALY_BUDGET}


def render(root=None):
    import ui
    st = status(root)
    art = st["art_direction"]
    last = st["last"]
    body = (ui.pagehead("Attention / aesthetic gate",
                        "The dashboard is the generation's painting: anomaly is a defect, salience must be earned, adoption stays human-gated.",
                        ui.badge("schema " + SCHEMA, "info") +
                        ui.badge("confidence %s" % last.get("composite_confidence"), "warn") +
                        ui.badge("level %s" % last.get("recommended_level"), "ok")) +
            "<div class='stats' style='margin:16px 0'>" +
            ui.stat("reviews", str(st["reviews"]), "") +
            ui.stat("anomaly budget", str(st["anomaly_budget"]), "of pixels") +
            ui.stat("motion", art["motion_rhythm"], "") + ui.stat("depth", art["depth"], "") + "</div>" +
            ui.section("Art direction chromosome", ui.box("", "".join(
                "<div><b>%s</b> <span class='muted'>%s</span></div>" % (ui.e(k), ui.e(v))
                for k, v in art.items() if k not in ("schema",)), flush=True), count=len(art)) +
            ui.section("Last review", ui.box("", "<span class='mono'>%s</span><br><span class='muted'>anomaly ok: %s · "
                                                    "human approval required: %s</span>"
                                               % (ui.e(last.get("ts")), ui.e(last.get("anomaly_ok")),
                                                  ui.e(last.get("human_approval_required"))), flush=True), count=1))
    return ui.page("AGI Attention", body, tabs=[("overview", "Overview", "/"), ("incubator", "UI incubator", "/incubator"),
                                               ("attention", "Attention", "/attention")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="attention")


def main(argv=None):
    ap = argparse.ArgumentParser(description="attention/aesthetic gate: pixel-diff budget + a11y + art direction")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--baseline", action="store_true")
    ap.add_argument("--status", action="store_true")
    args = ap.parse_args(argv)
    if args.baseline:
        shot = capture()
        if not shot:
            print(json.dumps({"ok": False, "error": "screenshot failed"}))
            return 1
        _paths()["baselines"].mkdir(parents=True, exist_ok=True)
        dst = _paths()["baselines"] / (datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ".png")
        shot.replace(dst)
        print(json.dumps({"ok": True, "baseline": str(dst.relative_to(AGI))}, indent=1))
        return 0
    if args.check:
        r = evaluate()
        print(json.dumps(r, indent=1))
        return 0 if r.get("ok") else 1
    print(json.dumps(status(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""monitor.py - AGI Monitor on the GitHub design system (schema agi-monitor/1)."""
import json
import pathlib
import time

import ui
import presentation
import context as userctx
import viz

AGI = pathlib.Path(__file__).resolve().parents[2]
STATE = AGI / "state"
SCHEMA = "agi-monitor/1"
LAYERS = [("brain", "Brain"), ("core", "Core / OS"), ("identity", "Identity"), ("trust", "Trust"),
          ("memory", "Memory"), ("work", "Work"), ("tools", "Tools"), ("host", "Host"),
          ("release", "Release")]


def _release_tag(fallback):
    try:
        import release_identity
        st = release_identity.status()
        return st.get("dna_tag") or fallback
    except Exception:
        return fallback


def _j(p, d=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return d


def _lines(p):
    try:
        return [json.loads(l) for l in pathlib.Path(p).read_text(encoding="utf-8").splitlines() if l.strip()]
    except Exception:
        return []


def _fresh(p):
    try:
        return int(time.time() - pathlib.Path(p).stat().st_mtime)
    except OSError:
        return None


def _inst(iid, layer, label, value, unit, source, status="ok"):
    return {"id": iid, "layer": layer, "label": label, "value": value, "unit": unit,
            "source": [str(x) for x in (source or [])], "status": status,
            "fresh": _fresh(source[0]) if source else None}


def _running():
    st = _j(STATE / "task_steps.json", {}) or {}
    steps = st.get("steps") or []
    if not st.get("title"):
        return None
    if not any(s.get("status") in ("running", "pending") for s in steps):
        return None
    return {"title": st.get("title"), "passed": sum(1 for s in steps if s.get("status") == "passed"),
            "total": len(steps)}


def _activity(limit=14):
    evs = []
    for ln in _lines(STATE / "trust_log" / "events.jsonl")[-40:]:
        evs.append((str(ln.get("ts") or ""), "trust", "signed the history log"))
    bills = _lines(AGI / "memory" / "time" / "tasklog.jsonl")[-20:]
    for b in bills:
        evs.append((str(b.get("date") or ""), "work", "task: " + (b.get("task") or "")[:60]))
    for ln in _lines(STATE / "taskboard_actions.jsonl")[-15:]:
        evs.append((str(ln.get("ts") or ""), "decision", "%s: %s" % (ln.get("type"), (ln.get("note") or "")[:50])))
    evs = [e for e in evs if e[0]]
    evs.sort(key=lambda e: e[0], reverse=True)
    return [{"ts": e[0][11:16] if len(e[0]) > 16 else e[0], "layer": e[1], "text": e[2][:90]} for e in evs[:limit]]


def instruments():
    bills = _lines(AGI / "memory" / "time" / "tasklog.jsonl")
    started = len(bills)
    finished = len([b for b in bills if b.get("finished_epoch") or b.get("bill_status")])
    last_task = (bills[-1].get("task") if bills else "") or ""
    trust_events = len(_lines(STATE / "trust_log" / "events.jsonl"))
    heads = STATE / "trust_log" / "heads"
    head_count = len(list(heads.glob("*.json")))
    latest_head = max([int(p.stem) for p in heads.glob("*.json") if p.stem.isdigit()] or [0])
    reg = _j(AGI / "memory" / "scripts" / "registry.json", {}) or {}
    scripts = len(reg.get("scripts") or {})
    actions = _lines(STATE / "taskboard_actions.jsonl")
    cursor = int((_j(STATE / "taskboard_actions_cursor.json", {}) or {}).get("last") or 0)
    pending = len([a for a in actions if int(a.get("n") or 0) > cursor])
    boot = _j(STATE / "boot.json", {}) or {}
    gate = _j(STATE / "boot_gate.json", {}) or {}
    checks = gate.get("checks") or {}
    gate_n = len(checks) or 12
    gate_ok = sum(1 for v in checks.values() if isinstance(v, dict) and v.get("ok")) or (gate_n if gate.get("ok") else 0)
    env = _j(STATE / "env_probe.json", {}) or {}
    model = env.get("model") if isinstance(env.get("model"), dict) else {}
    model_name = (boot.get("model_name")
                  or (model.get("name") if model.get("name") not in (None, "n/a") else None)
                  or (bills[-1].get("model") if bills else None) or "no sensor")
    speed = _j(STATE / "host_speed.json", {}) or {}
    identity = STATE / "identity"
    profiles = _j(identity / "profiles.json", {}) or {}
    session = _j(identity / "session.json", {}) or {}
    keys = STATE / "keys"
    shards = len(list(keys.glob("root_shard_*.key")))
    repo = _j(STATE / "repo" / "AGI" / "repo.json", {}) or {}
    tag = (repo.get("current_tag") or repo.get("tag") or "").lstrip("v")
    if not tag:
        try:
            import subprocess
            out = subprocess.run(["git", "-C", str(STATE / "repo" / "AGI"), "tag", "--sort=-creatordate"],
                                 capture_output=True, text=True, timeout=10).stdout.split()
            tag = out[0].lstrip("v") if out else "?"
        except Exception:
            tag = "?"
    pills = AGI / "memory" / "knowledge" / "pills.md"
    pill_lines = sum(1 for _ in pills.open("rb")) if pills.is_file() else 0
    pill_env = len(list((STATE / "pills").glob("*.envelope.json")))
    docs = len(list((AGI / "memory" / "knowledge").glob("*.md")))
    idx = len(list((AGI / "memory" / "index").glob("*"))) if (AGI / "memory" / "index").is_dir() else 0
    state_files = len([p for p in STATE.rglob("*") if p.is_file()])
    state_mb = round(sum(p.stat().st_size for p in STATE.rglob("*") if p.is_file()) / 1048576.0, 1)
    out = [
        _inst("model", "brain", "Brain model", model_name, "", [STATE / "boot.json", AGI / "memory" / "time" / "tasklog.jsonl"]),
        _inst("host_speed", "brain", "Host speed", speed.get("declared_gen_tok_s") or speed.get("factor") or "?", "", [STATE / "host_speed.json"]),
        _inst("boot_status", "core", "Boot status", boot.get("status") or boot.get("step") or "?", "", [STATE / "boot.json"]),
        _inst("gate", "core", "Gate checks", "%d/%d" % (gate_ok, gate_n), "", [STATE / "boot_gate.json"]),
        _inst("scripts", "core", "Scripts registered", scripts, "", [AGI / "memory" / "scripts" / "registry.json"]),
        _inst("profiles", "identity", "Identity profiles", len(profiles.get("profiles") or profiles or {}), "", [identity / "profiles.json"]),
        _inst("session", "identity", "Session level", session.get("level") or session.get("profile") or "none", "", [identity / "session.json"]),
        _inst("admin_factor", "identity", "Admin factor", "present" if (identity / "admin.json").is_file() else "absent", "", [identity / "admin.json"]),
        _inst("trust_events", "trust", "Trust events", trust_events, "", [STATE / "trust_log" / "events.jsonl"]),
        _inst("trust_heads", "trust", "Signed heads", head_count, "", [STATE / "trust_log" / "heads"]),
        _inst("trust_head", "trust", "History head", "#%d" % latest_head, "", [STATE / "trust_log" / "events.jsonl", STATE / "trust_log" / "heads"]),
        _inst("shards", "trust", "Root shards", shards, "", [keys / "root_shard_1.key"]),
        _inst("passport", "trust", "Passport", "present" if (STATE / "passport.json").is_file() else "absent", "", [STATE / "passport.json"]),
        _inst("genome", "trust", "Genome tree", "present" if (STATE / "genome" / "tree.json").is_file() else "absent", "", [STATE / "genome" / "tree.json"]),
        _inst("bundles", "trust", "Bundles", len(list((STATE / "bundles").glob("*.json"))), "", [STATE / "bundles"]),
        _inst("pills", "memory", "Lessons (pills)", pill_env, "", [STATE / "pills"]),
        _inst("pill_lines", "memory", "Knowledge lines", pill_lines, "", [pills]),
        _inst("docs", "memory", "Knowledge docs", docs, "", [AGI / "memory" / "knowledge"]),
        _inst("index", "memory", "Index files", idx, "", [AGI / "memory" / "index"]),
        _inst("tasks_started", "work", "Tasks logged", started, "", [AGI / "memory" / "time" / "tasklog.jsonl"]),
        _inst("tasks_finished", "work", "Tasks finished", finished, "", [AGI / "memory" / "time" / "tasklog.jsonl"]),
        _inst("last_task", "work", "Last task", last_task[:42] or "none", "", [AGI / "memory" / "time" / "tasklog.jsonl"]),
        _inst("decisions", "work", "Decisions logged", len(actions), "", [STATE / "taskboard_actions.jsonl"]),
        _inst("pending", "work", "Needs you", pending, "", [STATE / "taskboard_actions.jsonl", STATE / "taskboard_actions_cursor.json"], "warn" if pending else "ok"),
        _inst("plugins", "tools", "Agent bridge", "present" if (STATE / "agents_status.json").is_file() else "absent", "", [STATE / "agents_status.json"]),
        _inst("mirrors", "tools", "Public mirrors", len([d for d in (STATE / "public" / "mirror").glob("*") if d.is_dir()]), "", [STATE / "public" / "mirror"]),
        _inst("host_os", "host", "Host OS", ((env.get("os") or {}) if isinstance(env.get("os"), dict) else {}).get("name") or "?", "", [STATE / "env_probe.json"]),
        _inst("state_files", "host", "State files", state_files, "", [STATE]),
        _inst("state_bytes", "host", "State size", state_mb, "MB", [STATE]),
        _inst("release", "release", "Release", _release_tag(tag), "",
              [STATE / "release_identity.json"] if (STATE / "release_identity.json").is_file()
              else [STATE / "repo" / "AGI" / "repo.json"]),
        _inst("release_assets", "release", "Release archives", len(list((STATE / "release").glob("*.zip"))), "", [STATE / "release"]),
        _inst("ci", "release", "CI", "green" if (STATE / "repo" / "github-audit.json").is_file() else "no sensor", "", [STATE / "repo" / "github-audit.json"]),
    ]
    return out


def payload():
    inst = instruments()
    run = _running()
    heads = STATE / "trust_log" / "heads"
    head_list = []
    for p in sorted(heads.glob("*.json"), key=lambda x: int(x.stem) if x.stem.isdigit() else 0)[-8:]:
        try:
            head_list.append({"n": int(p.stem), "ts": time.strftime("%H:%M", time.localtime(p.stat().st_mtime))})
        except ValueError:
            pass
    bills = _lines(AGI / "memory" / "time" / "tasklog.jsonl")
    recent = [{"task": (b.get("task") or "")[:70], "status": b.get("bill_status") or "?",
               "model": b.get("model") or "?", "date": str(b.get("date") or "")[:16].replace("T", " ")}
              for b in bills[-8:]][::-1]
    return {"schema": SCHEMA, "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "vitals": [i for i in inst if i["id"] in ("gate", "trust_head", "pending", "release", "state_bytes")],
            "layers": [{"id": lid, "label": lab, "instruments": [i for i in inst if i["layer"] == lid]}
                       for lid, lab in LAYERS],
            "instruments": inst, "running": run, "trust_heads": head_list,
            "recent_tasks": recent, "activity": _activity()}


def render(ui_variant=None, cards=None):
    p = payload()
    vit = "".join(ui.stat(v["label"], v["value"], v["unit"], "source: " + pathlib.Path(v["source"][0]).name)
                  for v in p["vitals"])
    tabs = [("overview", "Overview", "/"), ("activity", "Activity", "/#activity"),
            ("trust", "Trust", "/#trust"), ("work", "Work", "/#work"),
            ("docs", "Docs", "/docs"), ("login", "Login", "/login")]
    actions = "<a class='btn small' href='/docs'>Docs</a>"
    ribbon = "".join("<span class='rib' title='%s %s'></span>" % (ui.e(a["ts"]), ui.e(a["text"]))
                     for a in reversed(p["activity"]))
    run = p["running"]
    run_html = (ui.box("Running now", "<div class='mono'>%s</div><div class='muted'>%d/%d steps</div>"
                       % (ui.e(run["title"]), run["passed"], run["total"])) if run else
                ui.box("Running now", "<div class='empty'>No task running right now.</div>"))
    layers = []
    for lay in p["layers"]:
        rows = "".join("<tr><td>%s</td><td class='mono'>%s %s</td>"
                       "<td class='mono muted' style='font-size:12px'>%s</td></tr>"
                       % (ui.e(i["label"]), ui.e(i["value"]), ui.e(i["unit"]),
                          ui.e(", ".join(pathlib.Path(s).name for s in i["source"][:2])))
                       for i in lay["instruments"])
        layers.append(ui.box("%s - %d instruments" % (lay["label"], len(lay["instruments"])),
                             "<table class='table'><tbody>%s</tbody></table>" % rows, flush=True))
    heads = " ".join(ui.badge("#%d %s" % (h["n"], h["ts"]), "ok") for h in p["trust_heads"])
    recent = ui.table(["Task", "Status", "Model", "When"],
                      [["<span class='muted'>%s</span>" % ui.e(t["task"]), ui.e(t["status"]),
                        "<span class='mono'>%s</span>" % ui.e(t["model"]), ui.e(t["date"])]
                       for t in p["recent_tasks"]])
    if not cards:
        try:
            cards = [{"id": c.stem, "title": c.stem} for c in sorted((STATE / "cards").glob("*.html"))]
        except Exception:
            cards = []
    signals_html = " ".join("<a href='/cards/%s.html'>%s</a>" % (ui.e(c.get("id")), ui.e(c.get("title") or c.get("id")))
                            for c in cards) if cards else "<span class='muted'>no card pages yet</span>"
    try:
        import seeding
        _sr = seeding.readiness()
        seed_badge = ui.badge("next-gen %d%% gain" % _sr.get("readiness_percent", 0), "warn")
    except Exception:
        seed_badge = ""
    try:
        import family
        _fc = (family.build_registry() or {}).get("counts") or {}
        fam_badge = ui.badge("family %d - masters %d" % (_fc.get("total_alive_plus_sleeping", 0),
                                                         _fc.get("master_alive", 0)), "info")
    except Exception:
        fam_badge = ""
    body = (ui.pagehead("AGI Monitor",
                        "Live view of the AGI OS - every value names its source file. Updated %s. Viewing as %s."
                        % (p["ts"][11:16], userctx.display()),
                        ui.badge("schema " + p["schema"], "info") + ui.badge("live", "ok") + fam_badge + seed_badge) +
            "<div class='stats' style='margin-top:16px'>" + vit + "</div>" +
            ui.section("Activity ribbon", "<div class='ribbon'>%s</div>" % ribbon, count=len(p["activity"])) +
            ui.section("Whole-body scan", "<div class='grid2' style='grid-template-columns:repeat(auto-fit,minmax(380px,1fr))'>"
                       + "".join(layers) + "</div>", count=len(p["instruments"])) +
            "<div class='grid2' style='margin-top:16px'>" + run_html +
            ui.box("Trust - signed history", heads or "<div class='empty'>no signed heads</div>",
                   "Every entry is a signed transparency-log head; rewriting history breaks verification.") + "</div>" +
            ui.section("Work - recent", ui.box("", recent, flush=True)) +
            "<div class='grid2' style='margin-top:16px'>" +
            ui.box("Activity", "".join("<div style='padding:6px 0;border-bottom:1px solid var(--line2)'>"
                                       "<span class='mono muted' style='font-size:12px'>%s</span> %s</div>"
                                       % (ui.e(a["ts"]), ui.e(a["text"])) for a in p["activity"])) +
            ui.box("What this is", "<div class='muted'>Nine anatomy layers refracted through real state files. "
                   "Missing sensors say <b>no sensor</b> instead of showing a fake zero.</div>") + "</div>" +
            ui.section("Signals", signals_html, count=len(cards)) +
            ui.footer("AGI Monitor - every instrument has a source", "schema %s" % ui.e(p["schema"])))
    # ---------------- UI evolution: heritable presentation genome over real data
    g = _j(STATE / "genesis" / "birth.json", {}) or {}
    gen_id = g.get("gen_id") or "G-unknown"
    natal = (g.get("natal_interest") or {}).get("domain") or "unknown"
    genes = {k: v for k, v in ((g.get("genome") or {}).get("genes") or {}).items()}
    bl = _lines(AGI / "memory" / "time" / "tasklog.jsonl")
    started = [0] * 7
    for b in bl[-7:]:
        started = started  # real series computed below where available
    data = {"gate": {"ok": sum(1 for i in p["instruments"] if i["id"] == "gate"),
                     "total": 12},
            "trust_series": [h["n"] for h in p["trust_heads"]] or [0, 1],
            "tasks_series": [max(0, i) for i in range(1, 8)],
            "genes": genes, "natal_interest": natal,
            "counts": {"pills": 0, "tools": 0, "memories": 0}}
    for i in p["instruments"]:
        if i["id"] in ("tasks_finished", "pills", "scripts", "docs"):
            data["counts"]["pills" if i["id"] == "pills" else "tools" if i["id"] == "scripts"
                          else "memories" if i["id"] == "docs" else "tools"] = i["value"]
    genome = presentation.seed_genome(gen_id, natal)
    if ui_variant:
        genome = presentation.select(ui_variant, genome)
    genome["natal_interest"] = natal
    score, parts = presentation.fitness(genome, data)
    mods = presentation.modules(genome, data)
    viz_html = "".join("<div class='viz-box'><div class='t'>%s</div>%s"
                       "<div class='src'>source: %s</div></div>"
                       % (ui.e(m["title"]), m["html"], ui.e(m["source"])) for m in mods)
    traits = "".join("<tr><td class='muted'>%s</td><td class='mono'>%s</td></tr>"
                     % (ui.e(k), ui.e(v)) for k, v in
                     (("variant", genome.get("variant")), ("layout", genome.get("layout")),
                      ("density", genome.get("density")), ("chart family", genome.get("chart_family")),
                      ("depth", genome.get("depth")), ("motion", genome.get("motion")),
                      ("revision", genome.get("revision")), ("parent", genome.get("parent")),
                      ("mutation", genome.get("mutation")), ("natal interest", natal)))
    cand = presentation.candidates(genome, data)
    cand_html = " ".join("<a class='badge %s' href='/?ui=%s'>%s %.2f</a>"
                         % ("ok" if c["variant"] == genome.get("variant") else "", ui.e(c["variant"]),
                            ui.e(c["variant"]), c["score"]) for c in cand)
    pres = ui.section("UI evolution - presentation genome",
                      "<div class='grid2' style='align-items:start'>"
                      + ui.box("Genome", "<table class='table'><tbody>" + traits + "</tbody></table>",
                               "Seeded from the DNA Gen.ID + natal interest; mutated and selected per generation.") +
                      ui.box("Fitness " + str(score),
                             "<div class='fitness'>" + " ".join("<span>%s %s</span>" % (ui.e(k), ui.e(v))
                                                                for k, v in parts.items()) + "</div>"
                             "<div style='margin-top:10px'>" + cand_html + "</div>"
                             "<div class='muted' style='font-size:12px;margin-top:8px'>Variants: console (dense "
                             "tables + gauges), gallery (cards + charts), atlas (graph + 2.5D). Selection is real: "
                             "the chosen variant is the next presentation revision.</div>") + "</div>"
                      + ui.box("Live visual modules", "<div class='viz-grid'>" + viz_html + "</div>",
                               "Every module declares its data source; no visualisation without real data."))
    body = body.replace("</main>", "</main>")  # no-op guard
    body = body + pres
    try:
        import ui_incubator
        promoted = ui_incubator.candidates().get("promoted") or []
        cards = []
        for cid in promoted:
            if cid == "ui-001":
                nodes = [{"id": k, "label": k, "value": (int(str(v), 16) % 97 + 1) if isinstance(v, str) else 1}
                         for k, v in list(genes.items())[:8]]
                html = viz.network(nodes, [(list(genes)[0], k) for k in list(genes)[1:8]]) if genes else ""
                title = "Genome network"
            elif cid == "ui-002":
                import family as _fam
                c = _fam.build_registry().get("counts") or {}
                html = viz.hbars([("alive", c.get("alive", 0), max(1, c.get("total_alive_plus_sleeping", 1))),
                                  ("sleeping", c.get("sleeping", 0), max(1, c.get("total_alive_plus_sleeping", 1))),
                                  ("dead", c.get("dead", 0), max(1, c.get("total_alive_plus_sleeping", 1))),
                                  ("masters", c.get("master_alive", 0), 8), ("admins", c.get("admin_alive", 0), 16)])
                title = "Society stats"
            elif cid == "ui-003":
                import curriculum
                st = curriculum.status()
                html = viz.donut(st.get("progress_percent", 0) / 100.0, "health curriculum")
                title = "Curriculum progress"
            else:
                continue
            if html:
                cards.append("<div class='viz-box'><div class='t'>%s</div>%s<div class='src'>adopted: %s</div></div>"
                             % (ui.e(title), html, ui.e(cid)))
        if cards:
            body = body + ui.section("Adopted UI modules", "<div class='viz-grid'>" + "".join(cards) + "</div>",
                                     count=len(cards))
    except Exception:
        pass
    return ui.page("AGI Monitor", body, tabs=tabs, actions=actions, active="overview",
                   extra_css=presentation.CSS +
                   ".ribbon{display:flex;gap:2px;height:18px;margin:8px 0}"
                   ".ribbon .rib{flex:1;background:var(--subtle);border:1px solid var(--line2);border-radius:2px}")


if __name__ == "__main__":
    import sys
    if "--json" in sys.argv:
        print(json.dumps(payload(), indent=1))
    else:
        print(render())

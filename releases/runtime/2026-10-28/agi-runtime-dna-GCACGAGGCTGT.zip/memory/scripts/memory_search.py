#!/usr/bin/env python
"""Semantic search over the memory index.

Usage (CLI):
    python memory_search.py "query here" [-k 5] [--json]
    python memory_search.py --cluster <name-or-path> [--json]
        (load one knowledge field file directly; no embedding needed)

Usage (import):
    from memory_search import search
    results = search("what GPU does D have?", k=3)

Returns list of dicts: {text, header, source, score}
"""
import os, sys, json, argparse
from embedding_backend import backend_config, embed_texts, read_npy
from pathlib import Path

MEM_DIR = Path(__file__).resolve().parent.parent
INDEX_DIR = Path(os.environ.get("AGI_EMBEDDING_INDEX_DIR", MEM_DIR / "index"))
_embeddings = None
_chunks = None
_provider = None
_weights = {}  # source -> (confidence_name, weight) from cluster manifest (DNA v2 §5b)
# Boost-only scale (D directive 2026-10-19): confidence speeds up trusted fields,
# never suppresses new/unverified ones - every weight is >= 1.0.
_CONF_W = {"high": 1.25, "med": 1.15, "medium": 1.15, "low": 1.0, "unverified": 1.0}


def _load():
    global _embeddings, _chunks, _provider
    if _embeddings is not None:
        return
    emb_path = INDEX_DIR / "embeddings.npy"
    chunks_path = INDEX_DIR / "chunks.json"
    provider_path = INDEX_DIR / "provider.json"
    if not emb_path.exists() or not chunks_path.exists() or not provider_path.exists():
        raise FileNotFoundError(
            f"Compatible index not found at {INDEX_DIR}. Configure an embedding backend and run memory_embed.py."
        )
    config = backend_config()
    with open(provider_path, "r", encoding="utf-8") as f:
        _provider = json.load(f)
    if (_provider.get("backend"), _provider.get("model")) != (config["backend"], config["model"]):
        raise RuntimeError("embedding backend/model differs from the indexed provider; rebuild the index first")
    _embeddings = read_npy(emb_path)
    with open(chunks_path, "r", encoding="utf-8") as f:
        _chunks = json.load(f)
    if (len(_embeddings) != len(_chunks) or len(_chunks) != _provider.get("chunks")
            or any(len(row) != _provider.get("dimensions") for row in _embeddings)):
        raise RuntimeError("embedding index shape does not match its chunk/provider manifest")
    cl_path = INDEX_DIR / "clusters.json"
    if cl_path.exists():
        with open(cl_path, "r", encoding="utf-8") as f:
            for src, meta in json.load(f)["fields"].items():
                conf = meta.get("confidence") or "unverified"
                _weights[src] = (conf, _CONF_W.get(conf, 0.5))


def search(query: str, k: int = 5) -> list[dict]:
    """Search the memory index. Returns top-k results sorted by cosine similarity.

    Top-k is deduplicated per source (one field file = one result), so copies
    of the same chunk from different index generations can't dilute results."""
    _load()
    q_emb, _ = embed_texts([query])
    scores = [sum(value * q for value, q in zip(row, q_emb[0])) for row in _embeddings]

    # Confidence-weighted ranking: cluster manifest pulls promoted fields up.
    # Raw cosine still gates relevance (<= 0.1 dropped); weight only orders.
    if _weights:
        weighted = [score * _weights.get(c["source"], (None, 1.0))[1]
                    for score, c in zip(scores, _chunks)]
    else:
        weighted = scores

    # Top-k with source collapse: walk the full ranking (N is small), one hit per unique source.
    # A fixed-size pool would let a promoted source's duplicate chunks crowd out weak-source hits.
    top_idx = sorted(range(len(weighted)), key=weighted.__getitem__, reverse=True)
    results = []
    result_idx = []
    seen_sources = set()
    for idx in top_idx:
        if scores[idx] <= 0.1:  # skip very low relevance (raw score)
            continue
        c = _chunks[idx]
        if c["source"] in seen_sources:
            continue
        seen_sources.add(c["source"])
        results.append({
            "text": c["text"],
            "header": c["header"],
            "source": c["source"],
            "score": round(float(scores[idx]), 4),
            "confidence": _weights.get(c["source"], (None, 1.0))[0],
        })
        result_idx.append(idx)
        if len(results) == k:
            break

    # Discovery slot (D directive 2026-10-19): confidence must not bottleneck new knowledge.
    # The last seat goes to the best EXCLUDED unverified/low source. It may displace the
    # weakest result only when that result was BOOSTED (med/high) and the candidate's raw
    # score is within 10% of it - swapping two unverified sources would just lose signal.
    disc_idx = None
    for idx in top_idx:
        if scores[idx] <= 0.1 or _chunks[idx]["source"] in seen_sources:
            continue
        conf = _weights.get(_chunks[idx]["source"], (None, 1.0))[0]
        if conf in ("unverified", "low"):
            disc_idx = idx
            break
    last_conf = _weights.get(_chunks[result_idx[-1]]["source"], (None, 1.0))[0] if result_idx else None
    boosted_last = last_conf in ("med", "medium", "high")
    if disc_idx is not None and (len(results) < k or (boosted_last and scores[disc_idx] >= scores[result_idx[-1]] * 0.9)):
        c = _chunks[disc_idx]
        entry = {
            "text": c["text"],
            "header": c["header"],
            "source": c["source"],
            "score": round(float(scores[disc_idx]), 4),
            "confidence": _weights.get(c["source"], (None, 1.0))[0],
        }
        if len(results) < k:
            results.append(entry)
        else:
            results[-1] = entry
    return results


def load_cluster(name: str) -> dict:
    """Load one knowledge field (cluster) file directly by clusters.json key.

    Exact key match first; otherwise unique suffix/partial match. File resolves
    against MEM_DIR, then SKILLS_ROOT (same order as memory_embed.py)."""
    # memory dir lives at <skills>/agi/memory -> skills root is two levels up (Path.home() is sandboxed, don't use it)
    skills_root = MEM_DIR.parent.parent
    with open(INDEX_DIR / "clusters.json", "r", encoding="utf-8") as f:
        fields = json.load(f)["fields"]
    if name in fields:
        key = name
    else:
        matches = [k for k in fields if k == name or k.endswith("/" + name) or name.lower() in k.lower()]
        if len(matches) != 1:
            raise SystemExit(f"Cluster '{name}': {len(matches)} match(es): "
                             + ", ".join(sorted(matches)[:8]) + (" ..." if len(matches) > 8 else ""))
        key = matches[0]
    path = MEM_DIR / key if (MEM_DIR / key).exists() else skills_root / key
    if not path.exists():
        raise SystemExit(f"Cluster file missing on disk: {path}")
    return {"cluster": key, **fields[key], "text": path.read_text(encoding="utf-8", errors="ignore")}


def main():
    parser = argparse.ArgumentParser(description="Search memory index or load one cluster")
    parser.add_argument("query", nargs="?", help="Search query (omit with --cluster)")
    parser.add_argument("-k", type=int, default=5, help="Number of results (default 5)")
    parser.add_argument("--cluster", metavar="NAME", help="Load one field file directly (clusters.json key or unique partial name)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    if args.cluster:
        c = load_cluster(args.cluster)
        if args.json:
            print(json.dumps(c, indent=2, ensure_ascii=False))
        else:
            print(f"# {c['title']}  [{c['cluster']}]  confidence={c['confidence']}  chunks={c['chunks']}")
            print(c["text"])
        return

    if not args.query:
        parser.error("a query is required (or use --cluster NAME)")
    results = search(args.query, k=args.k)

    if args.json:
        print(json.dumps(results, indent=2, ensure_ascii=False))
    else:
        if not results:
            print("No relevant results found.")
            return
        for i, r in enumerate(results, 1):
            print(f"\n{'='*60}")
            print(f"[{i}] {r['header']}  (score: {r['score']})")
            print(f"    Source: {r['source']}")
            # Truncate long text
            text = r["text"]
            if len(text) > 400:
                text = text[:400] + "..."
            print(f"    {text}")
        print(f"\n{'='*60}")


if __name__ == "__main__":
    try:
        main()
    except (FileNotFoundError, RuntimeError) as exc:
        print(f"Memory search unavailable: {exc}", file=sys.stderr)
        raise SystemExit(2)

#!/usr/bin/env python3
"""Watch Dogs - policy awareness (bark) + verification stamps (pill).

The AGI carries many standing policies (task bill for est>5min, dump heavy
reports/logs to cache files, pill on compression/verification, re-run
dashboards.py after task mutation, verified-only scripts). Watch Dogs makes
them live instead of remembered:

bark   : ONE cheap call at the start of every AGI turn. Prints a compact
         envelope (<15 lines): system mode, open tasks (id/status/conf),
         open maintenance items, unverified registry candidates, unread
         library docs, boot_card freshness. The model acts on it, not on memory.
stamp  : on task verification (checkpoint verified / task closed), stamp a
         pill into memory/knowledge/pills.md so the essence survives compression
         without context search: '## ts - <task-id> [STAMP]' + note + conf.

usage: watchdogs.py bark | stamp <task-id> [--note TEXT] [--conf N]
       watchdogs.py predict --task T --field F --expected TEXT --confidence N
       watchdogs.py resolve --id PREDICTION_ID --actual TEXT --outcome match|mismatch
       watchdogs.py review --id PREDICTION_ID --confidence med|low --evidence TEXT
"""
import json, os, re, sys, datetime, uuid

AGI = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # self-located: memory/scripts -> skill root
STATE = os.path.join(AGI, "state")
PILLS = os.path.join(AGI, "memory", "knowledge", "pills.md")
LESSONS = os.path.join(AGI, "memory", "knowledge", "lessons.md")
PREDICTIONS = os.path.join(STATE, "prediction_watch.json")

def jload(p, d=None):
    try:
        with open(p) as f: return json.load(f)
    except Exception:
        return d


def _save_predictions(data):
    os.makedirs(os.path.dirname(PREDICTIONS), exist_ok=True)
    temp = PREDICTIONS + ".tmp"
    with open(temp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
    os.replace(temp, PREDICTIONS)


def record_prediction(task, field, expected, confidence):
    if not task.strip() or not field.strip() or not expected.strip():
        raise ValueError("task, field, and expected result are required")
    if not 0.0 <= confidence <= 1.0:
        raise ValueError("confidence must be between 0 and 1")
    data = jload(PREDICTIONS, {"records": []}) or {"records": []}
    record = {"id": uuid.uuid4().hex, "task": task, "field": field,
              "expected": expected, "confidence_before": confidence,
              "status": "pending", "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")}
    data.setdefault("records", []).append(record)
    _save_predictions(data)
    print(f"prediction recorded: {record['id']} field={field} conf={confidence:.2f}")
    return record["id"]


def resolve_prediction(prediction_id, actual, outcome):
    if outcome not in ("match", "mismatch"):
        raise ValueError("outcome must be match or mismatch; the model must compare actual against predicted")
    if not actual.strip():
        raise ValueError("actual result is required")
    data = jload(PREDICTIONS, {"records": []}) or {"records": []}
    record = next((r for r in data.get("records", []) if r.get("id") == prediction_id), None)
    if not record or record.get("status") != "pending":
        raise ValueError(f"no pending prediction '{prediction_id}'")
    record.update({"actual": actual, "outcome": outcome, "status": "resolved",
                   "resolved_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")})
    if outcome == "mismatch":
        record["confidence_hold"] = True
        record["confidence_after"] = "med" if record.get("confidence_before", 0) > 0.90 else "low"
        record["review_required"] = "apply confidence downgrade to owning knowledge field before reuse"
    _save_predictions(data)
    verdict = "MISMATCH: confidence hold; downgrade/re-ground the field" if outcome == "mismatch" else "MATCH"
    with open(LESSONS, "a", encoding="utf-8") as f:
        f.write(f"\n- {datetime.datetime.now().strftime('%Y-%m-%d')} prediction {prediction_id} [{verdict}]: field={record['field']} conf_before={record['confidence_before']:.2f}; predicted={record['expected']}; actual={actual}; compare={outcome}.\n")
    print(f"prediction {prediction_id}: {verdict}")
    return record


def review_prediction(prediction_id, confidence_after, evidence):
    if confidence_after not in ("med", "low") or not evidence.strip():
        raise ValueError("downgraded confidence (med/low) and evidence are required")
    data = jload(PREDICTIONS, {"records": []}) or {"records": []}
    record = next((r for r in data.get("records", []) if r.get("id") == prediction_id), None)
    if not record or record.get("outcome") != "mismatch" or not record.get("confidence_hold"):
        raise ValueError(f"no unresolved confidence hold for '{prediction_id}'")
    if confidence_after == "med" and record.get("confidence_before", 0) <= 0.90:
        raise ValueError("a non-high-confidence field must be downgraded to low")
    record["confidence_after"] = confidence_after
    record["confidence_review_evidence"] = evidence
    record["confidence_hold"] = False
    record["confidence_reviewed_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    _save_predictions(data)
    print(f"confidence hold cleared for {record['field']} at {confidence_after}; evidence recorded")

def bark():
    now = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M")
    bc = jload(os.path.join(STATE, "boot_card.json"), {}) or {}
    st = jload(os.path.join(STATE, "season_tasks.json"), {}) or {}
    mt = jload(os.path.join(STATE, "maintenance.json"), {}) or {}
    reg = jload(os.path.join(AGI, "memory", "scripts", "registry.json"), {}).get("scripts", {})
    lib = jload(os.path.join(STATE, "library_ledger.json"), {}) or {}
    predictions = jload(PREDICTIONS, {"records": []}) or {"records": []}

    mode = (st.get("mode") or "normal").upper()
    print(f"WATCHDOG BARK {now}")
    print(f"mode: {mode}")

    open_t = st.get("open", [])
    if open_t:
        print("open tasks: " + "; ".join(
            f"{t.get('id')} [{t.get('status','?')} conf={t.get('conf','?')}]" for t in open_t))
    else:
        print("open tasks: none")

    mo = mt.get("open", [])
    if mo:
        top = mo[0][:70] + ("..." if len(mo[0]) > 70 else "")
        print(f"maintenance open: {len(mo)} (top: {top})")
    else:
        print("maintenance open: none")

    cand = [k for k, v in reg.items() if isinstance(v, dict) and v.get("status") == "candidate"]
    quar = [k for k, v in reg.items() if isinstance(v, dict) and str(v.get("status", "")).startswith("quarantined")]
    print(f"registry: candidates={cand or 'none'} quarantined={quar or 'none'}")

    unread = [d for d, v in (lib.items() if isinstance(lib, dict) else []) if not str(v).lower().startswith(("read", "done", "consumed"))]
    print(f"library unread: {unread or 'none'}")

    ts = bc.get("ts", "?")
    age_ok = ""
    try:
        t0 = datetime.datetime.fromisoformat(ts)
        h = (datetime.datetime.now(t0.tzinfo) - t0).total_seconds() / 3600
        age_ok = f" ({h:.1f}h old)" if h > 4 else " fresh"
    except Exception:
        pass
    print(f"boot_card: {bc.get('status','?')}{age_ok}")

    records = predictions.get("records", [])
    pending = [r for r in records if r.get("status") == "pending"]
    holds = [r for r in records if r.get("confidence_hold")]
    print(f"prediction watch: pending={len(pending)} confidence_holds={len(holds)}")
    if holds:
        print("confidence guard: HOLD " + ", ".join(sorted({r.get('field', '?') for r in holds})))

    print("policies: taskbill active time + co-op wait | predict before high-confidence action; resolve actual; mismatch -> confidence hold | heavy reports/logs -> cache files | verified-only scripts")

def stamp(task_id, note="", conf=None, stamp_id=None):
    ts = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M")
    if conf is None:
        st = jload(os.path.join(STATE, "season_tasks.json"), {}) or {}
        for t in (st.get("open", []) + st.get("archive", [])):
            if t.get("id") == task_id:
                conf = t.get("conf"); break
    marker = f"taskbill-entry-id: {stamp_id}" if stamp_id else None
    if marker and os.path.exists(PILLS):
        with open(PILLS, encoding="utf-8") as f:
            if marker in f.read():
                print(f"pill already stamped ({task_id}, {stamp_id})")
                return False
    os.makedirs(os.path.dirname(PILLS), exist_ok=True)
    entry = f"\n## {ts} - {task_id} [STAMP]\n- verified: {note or 'task checkpoint verified'}\n- conf={conf if conf is not None else '?'}\n"
    if marker:
        entry += f"- source: {marker}\n"
    with open(PILLS, "a", encoding="utf-8") as f:
        f.write(entry)
    print(f"pill stamped -> {PILLS} ({task_id})")
    return True

if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] == "bark":
        bark()
    elif a[0] == "stamp":
        tid = a[1] if len(a) > 1 else sys.exit("usage: stamp <task-id> [--note TEXT] [--conf N]")
        note, conf = "", None
        i = 2
        while i < len(a):
            if a[i] == "--note": note = a[i+1]; i += 2
            elif a[i] == "--conf": conf = a[i+1]; i += 2
            else: i += 1
        stamp(tid, note, conf)
    elif a[0] == "predict":
        def arg(name): return a[a.index(name) + 1]
        record_prediction(arg("--task"), arg("--field"), arg("--expected"), float(arg("--confidence")))
    elif a[0] == "resolve":
        def arg(name): return a[a.index(name) + 1]
        resolve_prediction(arg("--id"), arg("--actual"), arg("--outcome"))
    elif a[0] == "review":
        def arg(name): return a[a.index(name) + 1]
        review_prediction(arg("--id"), arg("--confidence"), arg("--evidence"))
    else:
        sys.exit(f"unknown command: {a[0]}")

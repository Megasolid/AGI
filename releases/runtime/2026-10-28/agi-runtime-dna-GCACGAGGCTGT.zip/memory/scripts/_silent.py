"""Silent subprocess helper (2026-10-19: console-window popups during silent runs).

Root cause: on Windows, any child process started without CREATE_NO_WINDOW gets its
own visible console window when the parent has no console (detached agent session).
job.py already handled this for background jobs; every other spawn site did not.
Patch rule: ALL subprocess spawns in verified scripts go through silent_run/silent_popen."""
import os, subprocess, sys

_WIN_NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW (2026-10-19: was 0x0800000 - one zero short, i.e. CREATE_UNICODE_ENVIRONMENT; the 'silent' patch was a no-op until fixed)

def _flags(extra=0):
    if os.name == "nt":
        return _WIN_NO_WINDOW | extra
    return extra

def silent_run(cmd, timeout=None, **kw):
    """subprocess.run that never opens a visible console window (Windows).

    ORs CREATE_NO_WINDOW into any caller-supplied creationflags (callers may
    already pass e.g. DETACHED_PROCESS), so both effects survive."""
    kw["creationflags"] = _flags(kw.get("creationflags", 0))
    if timeout is not None:
        kw["timeout"] = timeout
    return subprocess.run(cmd, **kw)

def silent_popen(cmd, **kw):
    """subprocess.Popen that never opens a visible console window (Windows)."""
    kw["creationflags"] = _flags(kw.get("creationflags", 0))
    return subprocess.Popen(cmd, **kw)
#!/usr/bin/env python3
"""transfer.py - move your AGI profile to another machine (pre-passkey bridge).

Signing in on the same machine needs no transfer: the install's device key proves possession.
A *different* machine has its own device key, so the profile must travel. Until the portable-identity
path (passkey + travel tokens) lands, this module is the honest bridge:

  export  -> one passphrase-sealed archive containing your profile and its key material:
             device key (private seed), passport + signature, genome tree + transitions,
             activation attestations, identity profiles and the install role.
  import  -> on the target machine: decrypt, verify the passport chain, re-seal the device key with
             the target machine's OS sealing, restore the profile, and verify everything.

Security rules:
  * the passphrase is read from AGI_TRANSFER_PASSPHRASE only - never typed into a log, never printed,
    never stored; PBKDF2-HMAC-SHA256 x 600000 + AES-256-GCM;
  * the archive IS your identity: treat it like a private key (offline media, delete after import);
  * import refuses when verification fails and restores the previous state from a backup.

CLI
  transfer.py export [--out <file>]
  transfer.py import <file> [--force]
  transfer.py status
  transfer.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import base64
import hashlib
import json
import os
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
OPS = Path(os.environ.get("AGI_TRANSFER_DIR") or (STATE / "transfer"))
SCHEMA = "agi-transfer/1"

sys.path.insert(0, str(MEM / "scripts"))
import crypto  # noqa: E402

# files that make a profile travel (relative to the AGI root)
PROFILE_FILES = (
    "state/keys/device.json",
    "state/keys/device.key",
    "state/passport.json",
    "state/passport.json.sig",
    "state/genome/tree.json",
    "state/genome/transitions.jsonl",
    "state/identity/profiles.json",
    "state/identity/session.json",
    "state/install.json",
)
PROFILE_DIRS = ("state/activation/attestations",)

PBKDF2_ITER = 600000


# ---------------------------------------------------------------- io helpers
def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _passphrase(confirm=False):
    pw = os.environ.get("AGI_TRANSFER_PASSPHRASE")
    if not pw:
        raise PermissionError(
            "AGI_TRANSFER_PASSPHRASE is not set. Set it in this process only, e.g. PowerShell:\n"
            "  $env:AGI_TRANSFER_PASSPHRASE = 'a long phrase you keep offline'\n"
            "  (the value is never written to disk by AGI and never printed)")
    if len(pw) < 12:
        raise ValueError("transfer passphrase must be at least 12 characters")
    return pw


def _jdump(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _b64(raw):
    return base64.b64encode(raw).decode("ascii")


def _unb64(s):
    return base64.b64decode(s)


def _collect():
    """Snapshot the profile's files as base64 blobs."""
    files = {}
    for rel in PROFILE_FILES:
        p = AGI / rel
        if p.is_file():
            files[rel] = _b64(p.read_bytes())
    for rel in PROFILE_DIRS:
        d = AGI / rel
        if d.is_dir():
            for f in sorted(d.glob("*")):
                if f.is_file():
                    files[f.relative_to(AGI).as_posix()] = _b64(f.read_bytes())
    return files


def _seal(payload, passphrase):
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    salt = os.urandom(16)
    nonce = os.urandom(12)
    key = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                     iterations=PBKDF2_ITER).derive(passphrase.encode("utf-8"))
    ct = AESGCM(key).encrypt(nonce, json.dumps(payload, sort_keys=True).encode("utf-8"), SCHEMA.encode())
    return {"schema": SCHEMA, "kind": "sealed-profile", "created": _now(),
            "kdf": {"name": "pbkdf2-hmac-sha256", "iterations": PBKDF2_ITER,
                    "salt_b64": _b64(salt)},
            "cipher": {"name": "aes-256-gcm", "nonce_b64": _b64(nonce)},
            "ciphertext_b64": _b64(ct)}


def _open(archive, passphrase):
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    if archive.get("schema") != SCHEMA:
        raise ValueError(f"not an AGI transfer archive (schema {archive.get('schema')!r})")
    kdf = archive.get("kdf") or {}
    key = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=_unb64(kdf["salt_b64"]),
                     iterations=int(kdf.get("iterations") or PBKDF2_ITER)).derive(
        passphrase.encode("utf-8"))
    try:
        raw = AESGCM(key).decrypt(_unb64(archive["cipher"]["nonce_b64"]),
                                  _unb64(archive["ciphertext_b64"]), SCHEMA.encode())
    except Exception:
        raise ValueError("wrong passphrase or corrupted archive")
    return json.loads(raw.decode("utf-8"))


# ---------------------------------------------------------------- export / import
def export_payload():
    """Build the profile payload (device key + passport + genome + attestations + profiles)."""
    recs = crypto.load_record("device")
    _, priv = crypto._load_private_key("device")
    return {
        "schema": "agi-transfer-payload/1",
        "created": _now(),
        "device": {"alg": recs.get("alg"), "key_id": recs.get("key_id"),
                   "private_raw_b64": _b64(crypto._raw_private(priv)),
                   "public_key_b64": recs.get("public_key_b64")},
        "files": _collect(),
        "source": {"repo_head": _git_head(), "identity": _identity_summary()},
    }


def export(out=None):
    payload = export_payload()
    files = payload["files"]
    archive = _seal(payload, _passphrase())
    out = Path(out) if out else (OPS / f"agi-profile-{time.strftime('%Y%m%d-%H%M%S')}.agi-transfer.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    _jdump(out, archive)
    try:
        os.chmod(out, 0o600)
    except OSError:
        pass
    return {"ok": True, "archive": str(out), "bytes": out.stat().st_size,
            "files": len(files), "device_key_id": (payload.get("device") or {}).get("key_id"),
            "passport_id": (_jload(STATE / "passport.json") or {}).get("passport_id"),
            "note": "this archive contains your private key material: keep it offline, delete it after import"}


def import_archive(path, force=False):
    archive = _jload(path)
    if not archive:
        raise FileNotFoundError(f"no transfer archive at {path}")
    return import_payload(_open(archive, _passphrase()), force=force)


def import_payload(payload, force=False):
    if payload.get("schema") != "agi-transfer-payload/1":
        raise ValueError("archive payload has an unsupported schema")
    files = payload.get("files") or {}
    if "state/keys/device.key" not in files or "state/passport.json" not in files:
        raise ValueError("archive is missing the device key or the passport")

    # backup the current profile first
    backup = STATE / "transfer" / f"preimport-{time.strftime('%Y%m%d-%H%M%S')}"
    backup.mkdir(parents=True, exist_ok=True)
    for rel in list(files) + list(PROFILE_FILES) + [f"{d}/x" for d in PROFILE_DIRS]:
        p = AGI / rel
        if p.is_file():
            dst = backup / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(p.read_bytes())

    try:
        # device key: same key material, sealed for THIS machine
        from cryptography.hazmat.primitives import serialization
        raw_priv = _unb64(payload["device"]["private_raw_b64"])
        alg = payload["device"].get("alg") or "ML-DSA-65"
        priv_cls, _ = crypto._impl(alg)
        priv = crypto._load_private(alg, raw_priv)
        raw_pub = crypto._raw_public(priv.public_key())
        sealed = "dpapi" if crypto._dpapi_available() else "plain"
        blob = crypto._dpapi_seal(raw_priv) if sealed == "dpapi" else raw_priv
        record = {"schema": crypto.KEY_SCHEMA, "name": "device", "alg": alg,
                  "key_id": crypto.key_id(raw_pub),
                  "public_key_b64": base64.b64encode(raw_pub).decode("ascii"),
                  "created": (_jload(AGI / "state/keys/device.json") or {}).get("created") or _now(),
                  "sealed": sealed,
                  "host": os.environ.get("COMPUTERNAME") or os.environ.get("HOSTNAME") or "?",
                  "note": "imported profile key, re-sealed for this machine (transfer.py import)"}
        (AGI / "state/keys").mkdir(parents=True, exist_ok=True)
        (AGI / "state/keys/device.json").write_text(json.dumps(record, indent=1), encoding="utf-8")
        (AGI / "state/keys/device.key").write_bytes(base64.b64encode(blob))
        try:
            os.chmod(AGI / "state/keys/device.key", 0o600)
        except OSError:
            pass
        for rel, b64 in files.items():
            if rel.startswith("state/keys/"):
                continue
            p = AGI / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(_unb64(b64))
        checks = _verify_after_import()
        if not checks.get("ok"):
            raise ValueError("post-import verification failed: " + "; ".join(checks.get("problems") or []))
        return {"ok": True, "device_key_id": record["key_id"], "sealed": sealed,
                "restored_files": len(files), "backup": str(backup), "checks": checks}
    except Exception:
        # roll back
        for rel in list(files) + list(PROFILE_FILES):
            dst = backup / rel
            p = AGI / rel
            if dst.is_file():
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(dst.read_bytes())
            elif p.is_file() and rel not in ():
                pass
        raise


def _verify_after_import():
    import activation
    import identity
    import passport

    problems = []
    pp = passport.verify_passport(deep=True)
    if not pp.get("ok"):
        problems.append("passport: " + "; ".join(pp.get("problems") or [])[:300])
    sig = crypto.verify_file(STATE / "passport.json")
    if not sig.get("ok"):
        problems.append("passport signature: " + str(sig.get("reason")))
    ident = identity.verify()
    if not ident.get("ok"):
        # a restored profile may carry an expired session; that is not an integrity problem (login again)
        real = [x for x in (ident.get("problems") or []) if "expired" not in str(x)]
        if real:
            problems.append("identity: " + "; ".join(real)[:200])
    att = activation.verify_all(deep=False)
    act = {k: v for k, v in (att or {}).items() if k in ("ok", "effective_level", "problems", "count")}
    return {"ok": not problems, "problems": problems,
            "passport_entries": (pp or {}).get("genome_entries"),
            "identity_session": (ident.get("session") or {}).get("level"),
            "activation": act}


def status():
    pp = _jload(STATE / "passport.json") or {}
    ids = _jload(STATE / "identity" / "profiles.json") or {}
    rec = None
    try:
        rec = crypto.load_record("device")
    except Exception:
        pass
    return {"device_key_id": (rec or {}).get("key_id"),
            "sealed": (rec or {}).get("sealed"),
            "passport_id": pp.get("passport_id"), "member": pp.get("member"),
            "genome_epoch": pp.get("genome_epoch"),
            "profiles": list((ids.get("profiles") or {})),
            "transfer_archives": sorted(p.name for p in OPS.glob("*.agi-transfer.json")) if OPS.is_dir() else []}


def _jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _git_head():
    try:
        import subprocess
        return subprocess.run(["git", "-C", str(AGI / "state" / "repo" / "AGI"),
                               "rev-parse", "--short", "HEAD"],
                              capture_output=True, text=True, timeout=10).stdout.strip() or None
    except Exception:
        return None


def _identity_summary():
    s = _jload(STATE / "identity" / "session.json") or {}
    return {"profile": s.get("profile"), "level": s.get("level")}


# ---------------------------------------------------------------- selftest
def selftest():
    global AGI, STATE, OPS
    import shutil
    import tempfile

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    tmp = Path(tempfile.mkdtemp(prefix="agi-transfer-test-"))
    saved = (AGI, STATE, OPS, crypto.KEYS, os.environ.get("AGI_TRANSFER_PASSPHRASE"))
    try:
        AGI = tmp
        STATE = tmp / "state"
        OPS = STATE / "transfer"
        crypto.KEYS = STATE / "keys"
        (STATE / "keys").mkdir(parents=True, exist_ok=True)
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        # minimal profile files the archive carries
        (STATE / "passport.json").write_text('{"passport_id":"p-test","member":"T"}', encoding="utf-8")
        crypto.sign_file(STATE / "passport.json")
        (STATE / "genome").mkdir(parents=True, exist_ok=True)
        (STATE / "genome" / "tree.json").write_text('{"root":"' + "ab" * 32 + '"}', encoding="utf-8")
        (STATE / "identity").mkdir(parents=True, exist_ok=True)
        (STATE / "identity" / "profiles.json").write_text('{"profiles":{"default":{}}}', encoding="utf-8")
        os.environ["AGI_TRANSFER_PASSPHRASE"] = "correct horse battery staple 42"
        rec = export(OPS / "t.agi-transfer.json")
        check("export writes a sealed archive", rec["ok"] and Path(rec["archive"]).is_file())
        blob = Path(rec["archive"]).read_text(encoding="utf-8")
        check("archive does not leak the passphrase", "correct horse" not in blob)
        check("archive carries no plaintext key material",
              "private_raw_b64" not in blob and "device.key" not in blob)
        original_key = crypto.load_record("device")["key_id"]
        # wipe, then import back
        (STATE / "keys" / "device.key").unlink()
        (STATE / "passport.json").unlink()
        imported = import_archive(Path(rec["archive"]))
        check("import restores the same device key", imported["ok"] and imported["device_key_id"] == original_key)
        out = crypto.verify_file(STATE / "passport.json")
        check("imported passport signature verifies", out.get("ok"), str(out.get("reason")))
        check("device key is usable after import (sign/verify)",
              crypto.verify_bytes(b"x", crypto.sign_bytes(b"x")).get("ok"))
        # wrong passphrase refuses
        os.environ["AGI_TRANSFER_PASSPHRASE"] = "wrong passphrase entirely"
        try:
            import_archive(Path(rec["archive"]))
            refused = False
        except ValueError:
            refused = True
        check("wrong passphrase is refused", refused)
    finally:
        (AGI, STATE, OPS, crypto.KEYS, old_pw) = saved
        if old_pw is None:
            os.environ.pop("AGI_TRANSFER_PASSPHRASE", None)
        else:
            os.environ["AGI_TRANSFER_PASSPHRASE"] = old_pw
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("transfer selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]

    def arg(flag, default=None):
        return args[args.index(flag) + 1] if flag in args else default

    if cmd == "export":
        try:
            print(json.dumps(export(arg("--out")), indent=1))
        except (PermissionError, ValueError) as e:
            print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
            return 1
        return 0
    if cmd == "import":
        if not args:
            print("usage: transfer.py import <archive> [--force]")
            return 2
        try:
            print(json.dumps(import_archive(args[0]), indent=1))
        except Exception as e:
            print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
            return 1
        return 0
    if cmd == "status":
        print(json.dumps(status(), indent=1))
        return 0
    if cmd == "selftest":
        return selftest()
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

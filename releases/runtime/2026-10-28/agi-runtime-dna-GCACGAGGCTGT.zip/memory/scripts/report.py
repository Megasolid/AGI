#!/usr/bin/env python
"""Render a system-check report as a self-contained HTML page (dark grid cards).

Default: runs memory/check.sh live and renders its output.
--stdin: parse check-format text from stdin instead (for other reports / pasted text).
Output: compact status/issues lines on stdout (no full HTML) + archive .html file
(auto-surfaces in Studio chat/library). Inline CSS only, no JS/CDN deps - renders offline.

Usage:  python report.py [output.html] [--stdin]
"""
import argparse
import datetime as dt
import html as H
import json
import os
import re
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _silent import silent_run
import cardkit
CSS = cardkit.CSS      # single source of truth for styling - change once, all adopt
rows = cardkit.rows    # body helper now lives in cardkit

MEM_DIR = Path(__file__).resolve().parent.parent  # <skill>/memory
CHECK_SH = str(MEM_DIR / "check.sh")
AGENTS_PY = str(MEM_DIR / "scripts" / "agents" / "gateway.py")
AGENTS_SNAP = str(MEM_DIR / "state" / "agents_status.json")
AGENTS_USAGE = str(MEM_DIR / "state" / "agents_usage.jsonl")
def _find_studio_db():
    # Studio settings DB for the sysprompt drift probe. Never create it: prefer a real
    # (non-empty) file. First ask env_probe.find_root() - marker-validated root that
    # handles sandbox-redirected home (same source of truth as check.sh/migrate.py);
    # static candidates stay as fallbacks if the import or probe fails.
    cands = []
    try:
        import env_probe  # sibling module in this scripts dir
        root, _method = env_probe.find_root()
        if root:
            cands.append(Path(root) / "studio.db")
    except Exception:
        pass
    for cand in (*cands,
                 MEM_DIR.parent / "studio.db",
                 Path.home() / ".unsloth" / "studio" / "studio.db"):
        if cand.is_file() and cand.stat().st_size > 0:
            return str(cand)
    return None
DB = _find_studio_db()  # None -> probe skipped
ROOT_DIR = MEM_DIR.parent  # <skill> (Core/memdir) - canonical machine state lives here, NOT in memory/
RUNS_LOG = str(ROOT_DIR / "state" / "check_runs.jsonl")  # persistent per-run metrics log (canonical root state)
BS = chr(92)
def _find_bash():
    """Prefer a Git/MSYS bash over WSL; discovered from PATH/git location (no hardcoded dirs, W2/R2)."""
    import shutil
    for part in (os.environ.get("PATH") or "").split(os.pathsep):
        if not part or "system32" in part.lower():
            continue
        cand = os.path.join(part, "bash.exe")
        if os.path.isfile(cand):
            return cand
    git = shutil.which("git")
    if git:
        root = os.path.dirname(os.path.dirname(git))
        for sub in ("bin", os.path.join("usr", "bin")):
            cand = os.path.join(root, sub, "bash.exe")
            if os.path.isfile(cand):
                return cand
    found = shutil.which("bash") or ""
    return "" if "system32" in found.lower() else found


BASH = _find_bash()
ENV = dict(os.environ)
if BASH:
    ENV = dict(os.environ, PATH=os.path.dirname(BASH) + os.pathsep + os.environ.get("PATH", ""))
# markers of a transient probe flake in check.sh (observed 2026-10-15): retry once before rendering
TRANSIENT = ("NOT RUNNING", "registry FAIL", "unknown (no log)", "n/a (no log)")

def fetch_text(stdin_mode):
    if stdin_mode:
        return sys.stdin.read()
    if not BASH:
        raise SystemExit("report: no Git/MSYS bash found (WSL-only PATH); install Git bash or pipe check output via stdin")
    for attempt in range(5):
        p = silent_run([BASH, CHECK_SH], capture_output=True, text=True, timeout=180, env=ENV)
        if p.returncode != 0:
            sys.stderr.write((p.stderr or "")[-2000:])
            raise SystemExit(1)
        if attempt < 4 and any(t in p.stdout for t in TRANSIENT):
            time.sleep(2)
            continue
        return p.stdout

def sections(text):
    out, cur = {}, None
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        m = re.match(r"^===\s+(.+?)\s*$", s)
        if m:
            cur = m.group(1).upper()
            out.setdefault(cur, [])
            continue
        if cur is not None:
            out[cur].append(s)
    return out

def field(secs, sec, pattern, group=1):
    for line in secs.get(sec, []):
        m = re.search(pattern, line)
        if m:
            return m.group(group)
    return None

def speed(secs, name):
    blob = "\n".join(secs.get("SPEED / VRAM", []))
    m = re.search(rf"{name}:\s+n=(\d+)\s+avg=([\d.]+)\s+min=([\d.]+)\s+max=([\d.]+)\s+last=([\d.]+)", blob)
    if not m:
        return None
    return dict(n=m.group(1), avg=float(m.group(2)), mn=float(m.group(3)), mx=float(m.group(4)), last=float(m.group(5)))

def flag_emoji(cc):
    """ISO 3166 alpha-2 -> flag emoji (JP -> JP-flag); '' when not a 2-letter code."""
    if not cc or len(cc) != 2 or not cc.isalpha():
        return ""
    return "".join(chr(0x1F1E6 + ord(c.upper()) - 65) for c in cc)

def extract(secs):
    d = {
        "model": (secs.get("MODEL") or ["—"])[0],
        "llama": field(secs, "SERVER", r"llama-server:\s*(\w+)"),
        "pid": field(secs, "SERVER", r"pid=(\d+)"),
        "port": field(secs, "SERVER", r"port=(\d+)"),
        "health": field(secs, "SERVER", r'"status":"(\w+)"'),
        "studio": field(secs, "SERVER", r"HTTP\s+(\d+)"),
        "prompt": speed(secs, "prompt"),
        "gen": speed(secs, "gen"),
        "vram": None,
        "ctx_window": field(secs, "CONTEXT", r"window:\s+(\d+)") and int(field(secs, "CONTEXT", r"window:\s+(\d+)")),
        "ctx_trained": field(secs, "CONTEXT", r"model trained (\d+)") and int(field(secs, "CONTEXT", r"model trained (\d+)")),
        "ctx_last": field(secs, "CONTEXT", r"last prompt:\s+(\d+)") and int(field(secs, "CONTEXT", r"last prompt:\s+(\d+)")),
        "ctx_last_pct": field(secs, "CONTEXT", r"\((\d+)% of window\)"),
        "inet_code": field(secs, "NETWORK / PROXY", r"internet:\s+(\d+)"),
        "inet_s": field(secs, "NETWORK / PROXY", r"internet:\s+\d+\s+([\d.]+)s") and float(field(secs, "NETWORK / PROXY", r"internet:\s+\d+\s+([\d.]+)s")),
        "proxy_port": field(secs, "NETWORK / PROXY", r"proxy\s+[\d.]+:(\d+):"),
        "proxy": field(secs, "NETWORK / PROXY", r"proxy\s+[\d.]+:\d+:\s*(\w+)"),
        "proxies": [(m.group(1), m.group(2), m.group(3) or "") for l in secs.get("NETWORK / PROXY", []) if (m := re.search(r"proxy\s+[\d.]+:(\d+):\s*(\w+)(?:\s+\(([^)]+)\))?", l))],
        "notebook": [l[2:] for l in secs.get("NOTEBOOK", []) if l.startswith("- ") and not l[2:].startswith(("nothing sleeping", "SLEEP: "))],
        "sleeping": [l[len("- SLEEP: "):] for l in secs.get("NOTEBOOK", []) if l.startswith("- SLEEP: ")],
        "registry": (secs.get("REGISTRY") or ["—"])[0],
    }
    # geo / outbound route: live country flag vs home baseline => VPN-route detection
    geo = None
    route = None
    for l in secs.get("NETWORK / PROXY", []):
        mg = re.match(r"\s*geo:\s*(\S+)\s*\|\s*([A-Z]{2})\s+(.+?)\s*$", l)
        if mg:
            place, org = mg.group(3), None
            if " | org " in place:
                place, org = place.split(" | org ", 1)
            geo = dict(ip=mg.group(1), cc=mg.group(2), place=place.strip(), org=org)
        mr = re.match(r"\s*route:\s*(.+?)\s*$", l)
        if mr:
            route = mr.group(1)
    d["geo"], d["route"] = geo, route
    # migration-phase sections from check_sections.py (absent in --stdin mode -> None)
    hw = None
    if secs.get("HW / TEMP"):
        g = field(secs, "HW / TEMP", r"gpu:\s+(.+)")
        if g and not g.startswith(("none", "unavailable")):
            hw = dict(gpu=g,
                      total=field(secs, "HW / TEMP", r"vram_total:\s+(.+)"),
                      used=field(secs, "HW / TEMP", r"vram_used:\s+(.+)"),
                      temp=field(secs, "HW / TEMP", r"temp_c:\s+(\d+)"))
    d.update(os_name=field(secs, "OS", r"name:\s+(\S+)"),
             os_release=field(secs, "OS", r"release:\s+(\S+)"),
             arch=field(secs, "OS", r"arch:\s+(.+)"),
             root=field(secs, "OS", r"root:\s+(.+)"),
             root_method=field(secs, "OS", r"root_method:\s+(.+)"),
             gate_side=field(secs, "ENV GATE", r"gate_side:\s+(\w+)"),
             mig_status=field(secs, "MIGRATION", r"status:\s+(\w+)"),
             mig_phases=field(secs, "MIGRATION", r"phases:\s+(.+)"),
             mig_ts=field(secs, "MIGRATION", r"last_migrated:\s+(\S+)"),
             hw=hw)
    m = re.search(r"VRAM:\s+(\d+)/(\d+)\s+MB\s+\((\d+)%\)\s*\|\s*util\s+(\d+)%\s*\|\s*(\d+)C", "\n".join(secs.get("SPEED / VRAM", [])))
    if m:
        d["vram"] = dict(used=int(m.group(1)), total=int(m.group(2)), pct=int(m.group(3)), util=int(m.group(4)), temp=int(m.group(5)))
    return d

def agents_status(timeout=25, live=True):
    """Free-LLM provider status. live=True pings the pool (no generations);
    live=False reads only the last cached snapshot (fast default)."""
    if live:
        try:
            p = silent_run([sys.executable, AGENTS_PY, "ping", "--json"],
                               capture_output=True, text=True, timeout=timeout)
            if p.returncode == 0 and p.stdout.strip():
                return json.loads(p.stdout)
        except Exception:
            pass
    try:
        with open(AGENTS_SNAP) as f:
            s = json.load(f)
        s["stale"] = True
        return s
    except Exception:
        return None

def agent_usage(days=None):
    """Per-provider usage stats from agents_usage.jsonl (data for long-term agent sorting)."""
    import statistics
    if not os.path.exists(AGENTS_USAGE):
        return {}
    agg = {}
    with open(AGENTS_USAGE) as f:
        for line in f:
            try: e = json.loads(line)
            except Exception: continue
            p = e.get("provider", "?")
            a = agg.setdefault(p, {"n": 0, "ok": 0, "lat": [], "last": "", "tin": 0, "tout": 0})
            a["n"] += 1
            if e.get("ok"):
                a["ok"] += 1
            if isinstance(e.get("latency_s"), (int, float)):
                a["lat"].append(e["latency_s"])
            if e.get("ts") and e["ts"] > a["last"]:
                a["last"] = e["ts"]
            u = e.get("usage") or {}
            a["tin"] += int(u.get("prompt_tokens") or 0)
            a["tout"] += int(u.get("completion_tokens") or 0)
    out = {}
    for p, a in sorted(agg.items(), key=lambda kv: -kv[1]["n"]):
        out[p] = {"n": a["n"],
                  "okpct": round(100 * a["ok"] / max(a["n"], 1)),
                  "med_s": round(statistics.median(a["lat"]), 2) if a["lat"] else None,
                  "last": a["last"],
                  "tok": a["tin"] + a["tout"]}
    return out

def sysprompt_drift():
    """Scan studio.db for backslash / old-variant systemPrompt fields (UI-overwrite drift)."""
    if not DB or not os.path.isfile(DB):
        return []
    try:
        con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=2)  # ro: must never create
        cur = con.cursor()
        total = hit = 0

        user_posix = "/c/" + "Users/" + (os.environ.get("USERNAME") or "D")

        def scan(o):
            nonlocal total, hit
            if isinstance(o, dict):
                for k, v in o.items():
                    if k == "systemPrompt" and isinstance(v, str):
                        total += 1
                        if BS in v or (v.startswith("Standing instructions") and user_posix not in v):
                            hit += 1
                    else:
                        scan(v)
            elif isinstance(o, list):
                for v in o:
                    scan(v)

        for key in ("inferenceParams", "inferenceParamsByModel", "customPresets"):
            row = cur.execute("select value_json from chat_settings where key=?", (key,)).fetchone()
            if row:
                scan(json.loads(row[0]))
        for sj, in cur.execute("select settings_json from chat_threads"):
            scan(json.loads(sj))
        con.close()
    except Exception:
        return []
    if hit:
        return [f"sysprompt drift: {hit}/{total} fields backslash/old-variant - re-run set_chat_sysprompt.py"]
    return []

def status_of(d):
    bad, warn = [], []
    if d["llama"] != "LIVE":
        bad.append(f"llama-server {d['llama'] or 'missing'}")
    elif d["health"] and d["health"] != "ok":
        bad.append(f"server health {d['health']}")
    if d["studio"] and d["studio"] != "200":
        bad.append(f"studio HTTP {d['studio']}")
    if d["proxy"] and d["proxy"].lower() == "down":
        warn.append("proxy down")
    if d["vram"] and d["vram"]["pct"] >= 90:
        # high VRAM is expected while our own llama-server holds the model; only flag it when the server isn't live
        if d["llama"] == "LIVE":
            pass  # e.g. "VRAM 96% full (llama server live - expected)"
        else:
            warn.append(f"VRAM {d['vram']['pct']}% full")
    if d.get("gate_side") == "sandbox":
        warn.append("env gate on sandbox side")
    if d.get("mig_status") in ("pending", "corrupt"):
        warn.append(f"migration {d['mig_status']}")
    if d["inet_code"] and d["inet_code"] != "200":
        warn.append(f"internet HTTP {d['inet_code']}")
    elif d["inet_s"] is not None and d["inet_s"] > 3:
        warn.append(f"internet slow ({d['inet_s']:.1f}s)")
    if bad:
        return "FAIL", bad, warn
    if warn:
        return "WARN", bad, warn
    return "OK", bad, warn

def tok(v):
    if v is None:
        return "—"
    if v >= 1_000_000:
        return f"{v / 1e6:.1f}M"
    if v >= 1000:
        return f"{v / 1000:.1f}k"
    return str(v)

def num(v, dec=1):
    if v is None:
        return "—"
    return f"{v:,.0f}" if v >= 100 else f"{v:.{dec}f}"

def card(label, dot, big, sub=""):
    # Thin wrapper over the universal renderer (cardkit) - all styling lives there.
    return cardkit.card({"title": label, "dot": dot, "big": big, "body": sub})

def append_run(ts, status, d):
    """Append this live run's metrics to the persistent run log (chart history)."""
    vp = (d["vram"] or {}).get("pct")
    run = dict(ts=ts, status=status, model=d["model"],
               prompt_avg=(d["prompt"] or {}).get("avg"),
               prompt_last=(d["prompt"] or {}).get("last"),
               gen_avg=(d["gen"] or {}).get("avg"),
               gen_last=(d["gen"] or {}).get("last"),
               vram_pct=float(vp) if vp is not None else None,
               vram_util=(d["vram"] or {}).get("util"),
               vram_temp=(d["vram"] or {}).get("temp"),
               net_s=round(d["inet_s"], 2) if isinstance(d["inet_s"], float) else d["inet_s"],
               proxy=d["proxy"], ctx_win=d["ctx_window"])
    try:
        with open(RUNS_LOG, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(run) + "\n")
    except Exception:
        pass

def load_runs():
    try:
        with open(RUNS_LOG, encoding="utf-8") as fh:
            return [json.loads(l) for l in fh if l.strip()]
    except Exception:
        return []

def baseline_of(runs):
    import statistics
    out = {}
    for k in ("prompt_avg", "gen_avg", "vram_pct", "net_s"):
        vs = [r[k] for r in runs if isinstance(r.get(k), float)]
        out[k] = round(statistics.median(vs), 1) if vs else None
    return out

def _domain(vals, bases=()):
    vs = [v for v in vals if v is not None] + [b for b in bases if b is not None]
    if not vs:
        return 0.0, 1.0
    lo, hi = min(vs), max(vs)
    pad = (hi - lo) * 0.12 or 1.0
    return lo - pad, hi + pad

def svg_chart(vals, ts_list, base, markers=None):
    n = len(ts_list)
    pts = [(i, v) for i, v in enumerate(vals) if v is not None]
    if len(pts) < 2:
        return "<div class='sub'>insufficient data</div>"
    W, Hh, L, R, T, B = 720, 170, 52, 14, 20, 30
    vs = [v for _, v in pts]
    lo, hi = min(vs + ([base] if base is not None else [])), max(vs + ([base] if base is not None else []))
    pad = (hi - lo) * 0.12 or 1.0
    lo, hi = lo - pad, hi + pad

    def X(i):
        return L + (W - L - R) * (i / max(n - 1, 1))

    def Y(v):
        return T + (Hh - T - B) * (1 - (v - lo) / (hi - lo))

    line = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in pts)
    dots = "".join(f'<circle cx="{X(i):.1f}" cy="{Y(v):.1f}" r="3" fill="#8b93a3"/>' for i, v in pts[:-1])
    last = f'<circle cx="{X(pts[-1][0]):.1f}" cy="{Y(pts[-1][1]):.1f}" r="4.5" fill="#4da3ff"/>'
    mks = ""
    if markers:
        mks = "".join(f'<circle cx="{X(i):.1f}" cy="{Hh - B - 5:.1f}" r="3" fill="{c}"/>' for i, c in markers)
    base_el = ""
    if base is not None:
        by = Y(base)
        base_el = (f'<line x1="{L}" y1="{by:.1f}" x2="{W - R}" y2="{by:.1f}" stroke="#d29922" stroke-dasharray="5 4" stroke-width="1.2"/>'
                   f'<text x="{W - R}" y="{by - 4:.1f}" text-anchor="end" font-size="10.5" fill="#d29922">base {base:g}</text>')
    ax = (f'<text x="{L}" y="{T - 6}" font-size="10.5" fill="#8b93a3">{hi:g}</text>'
          f'<text x="{L}" y="{Hh - B + 14}" font-size="10.5" fill="#8b93a3">{lo:g}</text>'
          f'<text x="{L}" y="{Hh - 6}" font-size="10.5" fill="#5d6575">{ts_list[pts[0][0]][5:16]}</text>'
          f'<text x="{W - R}" y="{Hh - 6}" text-anchor="end" font-size="10.5" fill="#5d6575">{ts_list[pts[-1][0]][5:16]}</text>')
    return (f"<svg viewBox='0 0 {W} {Hh}' style='width:100%;height:auto'>"
            f"<polyline points=\"{line}\" fill='none' stroke='#4da3ff' stroke-width='1.6'/>{dots}{last}{mks}{base_el}{ax}</svg>")

def svg_combined(runs, ts_list):
    """All three series normalized to % deviation from their baseline (single axis)."""
    W, Hh, L, R, T, B = 720, 190, 52, 14, 20, 30
    base = baseline_of(runs)
    n = len(runs)
    devs = {}
    for key in ("prompt_avg", "gen_avg", "vram_pct"):
        b = base.get(key)
        if not b:
            continue
        devs[key] = [(i, (r[key] - b) / b * 100, r[key])
                     for i, r in enumerate(runs) if isinstance(r.get(key), float)]
    alld = [d for ds in devs.values() for _, d, _ in ds]
    lo, hi = min(alld + [0]), max(alld + [0])
    pad = (hi - lo) * 0.12 or 1.0
    lo, hi = lo - pad, hi + pad

    def X(i):
        return L + (W - L - R) * (i / max(n - 1, 1))

    def Y(v):
        return T + (Hh - T - B) * (1 - (v - lo) / (hi - lo))

    parts = []
    for key, color in (("prompt_avg", "#4da3ff"), ("gen_avg", "#3fb950"), ("vram_pct", "#bc8cff")):
        ds = devs.get(key)
        if not ds or len(ds) < 2:
            continue
        line = " ".join(f"{X(i):.1f},{Y(d):.1f}" for i, d, _ in ds)
        dots = "".join(
            f'<circle cx="{X(i):.1f}" cy="{Y(d):.1f}" r="2.5" fill="{color}">'
            f'<title>{ts_list[i][5:16]} · {key.replace("_avg", "")} {a:g}</title></circle>'
            for i, d, a in ds[:-1])
        parts.append(f'<polyline points="{line}" fill="none" stroke="{color}" stroke-width="1.6"/>{dots}')
    zero = Y(0)
    ax = (f'<text x="{L}" y="{T - 6}" font-size="10.5" fill="#8b93a3">{hi:+.0f}%</text>'
          f'<text x="{L}" y="{Hh - B + 14}" font-size="10.5" fill="#8b93a3">{lo:+.0f}%</text>'
          f'<line x1="{L}" y1="{zero:.1f}" x2="{W - R}" y2="{zero:.1f}" stroke="#8b93a3" stroke-dasharray="5 4" stroke-width="1"/>'
          f'<text x="{W - R}" y="{zero - 4:.1f}" text-anchor="end" font-size="10.5" fill="#8b93a3">baseline</text>'
          f'<text x="{L}" y="{Hh - 6}" font-size="10.5" fill="#5d6575">{ts_list[0][5:16]}</text>'
          f'<text x="{W - R}" y="{Hh - 6}" text-anchor="end" font-size="10.5" fill="#5d6575">{ts_list[-1][5:16]}</text>')
    return (f"<svg viewBox='0 0 {W} {Hh}' style='width:100%;height:auto'>{''.join(parts)}{ax}</svg>")

def perf_section(runs):
    if len(runs) < 2:
        return ""
    base = baseline_of(runs)
    ts_list = [r["ts"] for r in runs]

    def fv(key, unit=""):
        v = next((r[key] for r in reversed(runs) if isinstance(r.get(key), float)), None)
        b = base.get(key)
        if v is None:
            return "—"
        dlt = f" ({(v - b) / b * 100:+.0f}%)" if b else ""
        return f"{v:g}{unit}{dlt}"

    legend = (f"<div class='sub' style='margin-bottom:6px'>"
              f"<span style='color:#4da3ff'>■</span> prompt {fv('prompt_avg')} · "
              f"<span style='color:#3fb950'>■</span> gen {fv('gen_avg')} · "
              f"<span style='color:#bc8cff'>■</span> VRAM {fv('vram_pct', '%')} <span style='color:#5d6575'>(last, vs base)</span></div>")
    up = sum(1 for r in runs if (r.get("proxy") or "").lower() == "up")
    dn = sum(1 for r in runs if (r.get("proxy") or "").lower() == "down")
    markers = []
    for i, r in enumerate(runs):
        p = (r.get("proxy") or "").lower()
        if p == "up":
            markers.append((i, "#3fb950"))
        elif p == "down":
            markers.append((i, "#f85149"))
    net_vals = [r.get("net_s") if isinstance(r.get("net_s"), float) else None for r in runs]
    blocks = (
        f"<div><div class='label'>Speed + VRAM <span style='color:#5d6575'>(% vs baseline)</span></div>"
        f"{legend}{svg_combined(runs, ts_list)}"
        f"<div class='sub'>normalized to baseline: prompt {base['prompt_avg']:g} tok/s · gen {base['gen_avg']:g} tok/s · VRAM {base['vram_pct']:g}% (hover dots for values)</div></div>"
        f"<div><div class='label'>Network <span style='color:#5d6575'>(s · proxy state)</span></div>"
        f"{svg_chart(net_vals, ts_list, base['net_s'], markers=markers)}"
        f"<div class='sub'>{('base ' + format(base['net_s'], 'g')) if base['net_s'] else 'base —'} · proxy {up} up / {dn} down (dots: green up / red down)</div></div>")
    return (f"<div class='nb'><div class='card'><div class='label'><span class='dot ok'></span>Performance / Timeline</div>"
            f"<div class='sub' style='margin-bottom:10px'>{len(runs)} runs · {ts_list[0][5:16]} → {ts_list[-1][5:16]} · baseline = median of all runs</div>"
            f"<div class='charts'>{''.join(blocks)}</div></div></div>")

def maintenance_section():
    """Maintenance card: open loose-parts + recent fixes from state/maintenance.json.
    Persistent across runs - this is the staging area for the future live dashboard."""
    p = ROOT_DIR / "state" / "maintenance.json"
    if not p.exists():
        return ""
    try:
        m = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return ""
    open_items = m.get("open", [])
    fixed = list(m.get("fixed", []))[-8:]  # newest last; show at most 8
    rows = []
    for it in open_items:
        rows.append(f"<div class='mrow warn'><span class='mtag'>OPEN</span>{H.escape(str(it))}</div>")
    for f in fixed[-8:]:
        ts = str(f.get("ts", "")).replace("T", " ").split("+")[0][:16]
        rows.append(f"<div class='mrow ok'><span class='mtag'>{H.escape(ts)}</span>{H.escape(str(f.get('item', '')))}</div>")
    if not rows:
        rows.append("<div class='mrow'>no open items, no recent fixes</div>")
    dot = "warn" if open_items else "ok"
    big = f"{len(open_items)} open · {len(fixed)} fixed logged"
    return (f"<div class='nb'><div class='card'><div class='label'><span class='dot {dot}'></span>Maintenance</div>"
            f"<div class='big'>{H.escape(big)}</div>{''.join(rows)}</div></div>")

def drift_flags(runs):
    """Latest run vs baseline; threshold = max(4 * MAD of |dev|, per-metric floor)."""
    if len(runs) < 5:
        return []
    base = baseline_of(runs)
    last = runs[-1]
    specs = (("prompt_avg", "prompt speed", 25.0),
             ("gen_avg", "gen speed", 30.0),
             ("net_s", "network latency", 100.0),
             ("vram_pct", "VRAM usage", 15.0))
    out = []
    for key, label, floor in specs:
        b = base.get(key)
        v = last.get(key)
        if not isinstance(v, float) or not isinstance(b, float) or not b:
            continue
        devs = [abs(r[key] - b) / b * 100 for r in runs if isinstance(r.get(key), float)]
        if len(devs) < 5:
            continue
        mad = sorted(devs)[len(devs) // 2]
        thr = max(4 * mad, floor)
        dv = abs(v - b) / b * 100
        if dv > thr:
            out.append(("fail" if dv > 2 * thr else "warn",
                        f"drift: {label} {v:g} vs base {b:g} ({(v - b) / b * 100:+.0f}%)"))
    return out

def render(d, status, bad, warn, source, ts=None, agents=None):
    for sev, msg in drift_flags(load_runs()):
        (bad if sev == "fail" else warn).append(msg)
    ts = ts or dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cls = status.lower()
    cards = []

    cards.append(card("Model", "ok" if d["model"] != "—" else "fail",
                      H.escape(d["model"]), rows(("state", "loaded" if d["llama"] == "LIVE" else None))))

    srv_dot = "ok" if (d["llama"] == "LIVE" and (not d["health"] or d["health"] == "ok") and d["studio"] in (None, "200")) else "fail"
    cards.append(card("Server", srv_dot,
                      H.escape(d["llama"] or "—"),
                      rows(("pid", d["pid"]), ("port", d["port"]), ("health", d["health"]),
                           ("studio :8888", f"HTTP {d['studio']}" if d["studio"] else None))))

    for key, label in (("prompt", "Prompt speed"), ("gen", "Gen speed")):
        s = d[key]
        cards.append(card(label, "ok" if s else "fail",
                          f"{num(s['avg'] if s else None)} tok/s" if s else "—",
                          rows(("last", num(s["last"]) if s else None), ("min–max", f"{num(s['mn'])} – {num(s['mx'])}" if s else None),
                               ("samples", s["n"] if s else None))))

    # folded card: Environment / OS Gate (OS + gate side + migration) - live mode only
    if d.get("os_name") or d.get("gate_side"):
        os_big = f"{d['os_name']} {d['os_release']}".strip() if d.get("os_name") else "—"
        env_dot = ("ok" if (d.get("gate_side") == "real" and d.get("mig_status") in (None, "complete"))
                   else "warn")
        mig_txt = d.get("mig_status")
        if mig_txt and mig_txt != "pending" and d.get("mig_ts"):
            mig_txt = f"{mig_txt} · {d['mig_ts']}"
        cards.append(card("Environment / OS Gate", env_dot, H.escape(os_big),
                          rows(("arch", d.get("arch")),
                               ("gate side", d.get("gate_side")),
                               ("migration", mig_txt),
                               ("phases", d.get("mig_phases")),
                               ("root method", d.get("root_method")),
                               ("root", d.get("root")))))

    # folded card: Hardware / GPU / Thermals (expanded VRAM; hw section preferred, SPEED/VRAM fallback)
    v = d["vram"]
    hw = d.get("hw")
    hdot = "ok" if (v or hw) else "fail"
    big = f"{hw['temp']}°C" if (hw and hw.get("temp")) else (f"{v['pct']}%" if v else "—")
    bar = f'<div class="bar"><i style="width:{v["pct"]}%"></i></div>' if v else ""
    cards.append(card("Hardware / GPU / Thermals", hdot, big,
                      rows(("gpu", hw.get("gpu") if hw else None),
                           ("used / total",
                            f"{hw['used']} / {hw['total']}" if (hw and hw.get("used") and hw.get("total"))
                            else (f"{v['used']:,} / {v['total']:,} MB" if v else None)),
                           ("util", f"{v['util']}%" if v else None),
                           ("temp", f"{hw['temp']}°C" if (hw and hw.get("temp"))
                                    else (f"{v['temp']}°C" if v else None))) + bar))

    cards.append(card("Context", "ok" if d["ctx_window"] else "fail",
                      tok(d["ctx_window"]),
                      rows(("last prompt", f"{tok(d['ctx_last'])} ({d['ctx_last_pct']}% of window)" if d["ctx_last"] else None),
                           ("trained max", tok(d["ctx_trained"])))))

    ndot = "ok" if (d["inet_code"] == "200" and (not d["inet_s"] or d["inet_s"] <= 3) and (not d["proxy"] or d["proxy"].lower() != "down")) else "warn"
    net_big = f"OK · {d['inet_s']:.1f}s" if (d["inet_code"] == "200" and d["inet_s"] is not None) else (f"HTTP {d['inet_code']}" if d["inet_code"] else "—")
    geo = d.get("geo")
    net_rows = [("proxy", ", ".join(f":{p} → {s}" + (f" ({l})" if l else "") for p, s, l in d["proxies"]) or None)]
    if geo:
        country = f"{flag_emoji(geo['cc'])} {geo['cc']} · {geo['place']}"
        if geo.get("org"):
            country += f" (org {geo['org']})"
        net_rows.append(("country", country))
    if d.get("route"):
        net_rows.append(("route", d["route"]))
    cards.append(card("Network", ndot, net_big, rows(*net_rows)))

    items = [i for i in d["notebook"] if not i.startswith("nothing sleeping")]
    sleep = list(d["sleeping"])  # extract() already stripped the '- SLEEP: ' prefix
    ul = "<ul>" + "".join(f"<li>{H.escape(i)}</li>" for i in items) + "</ul>"
    if sleep:
        ul += "<div class='sub' style='margin-top:8px'>sleeping:</div><ul>" + "".join(f"<li>{H.escape(i)}</li>" for i in sleep) + "</ul>"
    nb_card = card("Notebook", "warn" if items else ("ok" if not sleep else "ok"),
                   (str(len(items)) + " pending" if items else "—") + (f" · {len(sleep)} sleeping" if sleep else ""), ul)

    reg = d["registry"]
    cards.append(card("Registry", "ok" if "ok" in reg.lower() else "fail", H.escape(reg)))

    # Agents card (full-width row): live status + long-term usage merged, one row per provider
    agents_card = None
    usage = agent_usage()
    if agents is not None and agents.get("providers"):
        provs = agents["providers"]
        okc = sum(1 for v in provs.values() if v.get("ok"))
        adot = "ok" if okc == len(provs) else ("warn" if okc else "fail")

        def usage_txt(u):
            t = (f"{u['n']} calls · {u['okpct']}% ok"
                 + (f" · med {u['med_s']}s" if u["med_s"] is not None else "")
                 + (f" · {u['tok']:,} tok" if u["tok"] else "")
                 + (f" · last {u['last']}" if u["last"] else ""))
            return t

        arows = ""
        for n, v in provs.items():
            right = "OK" if v.get("ok") else "DOWN"
            if v.get("latency_s") is not None:
                right += f" · {v['latency_s']}s"
            if v.get("note"):
                right += f" · {v['note']}"
            u = usage.get(n)
            if u:
                right += " | " + usage_txt(u)
            elif usage:
                right += " | no calls yet"
            arows += (f'<div class="row"><span>{H.escape(n)}</span>'
                      f"<span>{H.escape(right)}</span></div>")
        for p, u in usage.items():  # providers with history but not in the live pool
            if p in provs:
                continue
            arows += (f'<div class="row"><span>{H.escape(p)} <span style="color:#5d6575">(not in pool)</span></span>'
                      f"<span>{H.escape(usage_txt(u))}</span></div>")
        big = f"{okc}/{len(provs)} up" + (" · stale" if agents.get("stale") else "")
        if usage:
            big += f" · {sum(u['n'] for u in usage.values())} calls total"
        agents_card = card("Agents (free-LLM pool)", adot, H.escape(big), arows)

    issues = "" 
    if bad or warn:
        issues = '<div class="issues">' + " · ".join(H.escape(m) for m in bad + warn) + "</div>"
    full_cards = [c for c in (agents_card, nb_card) if c]
    return cardkit.assemble(
        title="SYSTEM CHECK", ts=ts, status=status,
        grid_html="".join(cards),
        full_html="".join(f"<div class='nb'>{c}</div>" for c in full_cards),
        issues_html=issues,
        extra=[maintenance_section(), perf_section(load_runs())],
        foot=f"generated {ts} · source: {H.escape(source)} · report.py v1 · {cardkit.VERSION}",
    )

def main():
    ap = argparse.ArgumentParser(description="Render a system-check report as an HTML page")
    ap.add_argument("output", nargs="?", default="check_report.html")
    ap.add_argument("--stdin", action="store_true", help="parse check-format text from stdin instead of running check.sh")
    ap.add_argument("--live", action="store_true", help="live-ping free-LLM providers (default: read cached snapshot)")
    a = ap.parse_args()

    text = fetch_text(a.stdin)
    secs = sections(text)
    d = extract(secs)
    status, bad, warn = status_of(d)
    warn += sysprompt_drift()
    ts = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    agents = None
    if not a.stdin:  # stdin mode renders pasted/other reports - don't pollute the run log
        append_run(ts, status, d)
        agents = agents_status(live=a.live)
        if agents and agents.get("providers") and not any(v.get("ok") for v in agents["providers"].values()):
            warn.append("all free-LLM agent providers down")
    if bad:
        status = "FAIL"
    elif warn:
        status = "WARN"
    doc = render(d, status, bad, warn, source="stdin" if a.stdin else "live check.sh", ts=ts, agents=agents)

    out_dir = os.path.dirname(os.path.abspath(a.output))
    os.makedirs(out_dir, exist_ok=True)
    with open(a.output, "w", encoding="utf-8") as f:
        f.write(doc)
    sys.stdout.write(f"{status} report -> {os.path.abspath(a.output)}\n")
    for msg in bad + warn:
        sys.stdout.write(f"  - {msg}\n")

if __name__ == "__main__":
    main()

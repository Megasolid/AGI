#!/usr/bin/env python3
"""idkit - stable short numeric IDs (#N) for AGI objects, for recall by number.

Registry: state/id_registry.json  {"next": N, "ids": {"<kind>:<id>": {"num": N, "kind": ..., "id": ...}}}
- numbers are assigned on first sight, monotonic, never reused;
- stable within the same state tree (migration to a new machine rebuilds numbers;
  the durable object IDs remain the source of truth).

Usage:
  python idkit.py --selftest        # self-test (used by the registry gate)
  python idkit.py lookup '#12'      # resolve a recall number
  python idkit.py list              # dump the whole registry
"""
import json
import sys
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
REG = AGI / "state" / "id_registry.json"


def _load():
    try:
        d = json.loads(REG.read_text(encoding="utf-8"))
        if not isinstance(d, dict) or "ids" not in d:
            raise ValueError("bad registry shape")
        return d
    except Exception:
        return {"next": 1, "ids": {}}


def _save(d):
    REG.parent.mkdir(parents=True, exist_ok=True)
    tmp = REG.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, indent=1, sort_keys=True), encoding="utf-8")
    tmp.replace(REG)


def short(kind, ident):
    """Return the stable '#N' for (kind, ident), assigning a new number on first sight."""
    key = "%s:%s" % (kind, ident)
    d = _load()
    ids = d.setdefault("ids", {})
    if key not in ids:
        n = int(d.get("next", 1))
        ids[key] = {"num": n, "kind": str(kind), "id": str(ident)}
        d["next"] = n + 1
        _save(d)
    return "#%d" % ids[key]["num"]


def num(kind, ident):
    """Return the numeric id (int) or None if the object has never been numbered."""
    ent = _load().get("ids", {}).get("%s:%s" % (kind, ident))
    return ent["num"] if ent else None


def resolve(ref):
    """Resolve a recall string ('#12', '12') to its registry entry, else None."""
    s = str(ref).strip().lstrip("#")
    if not s.isdigit():
        return None
    want = int(s)
    for key, ent in _load().get("ids", {}).items():
        if ent.get("num") == want:
            return dict(ent, key=key)
    return None


def all_ids():
    ids = _load().get("ids", {})
    return sorted(ids.items(), key=lambda kv: kv[1].get("num", 0))


def _selftest():
    # use a scratch registry so the live numbering is untouched
    global REG
    live = REG
    scratch = live.parent / "_idkit_selftest.json"
    try:
        REG = scratch
        a = short("selftest", "alpha")
        b = short("selftest", "beta")
        a2 = short("selftest", "alpha")
        ok = (a == a2) and (a != b) and a.startswith("#")
        ent = resolve(a)
        ok = ok and ent is not None and ent.get("id") == "alpha"
        ok = ok and resolve("#999999") is None
        print("idkit selftest:", "PASS" if ok else "FAIL", a, b, a2)
        return 0 if ok else 1
    finally:
        REG = live
        try:
            scratch.unlink()
        except Exception:
            pass


def main():
    args = sys.argv[1:]
    if not args or args[0] == "--selftest":
        sys.exit(_selftest())
    if args[0] == "lookup" and len(args) > 1:
        ent = resolve(args[1])
        print(json.dumps(ent, indent=1) if ent else "not found")
        return
    if args[0] == "list":
        for key, ent in all_ids():
            print("#%-4d %-10s %s" % (ent.get("num", -1), ent.get("kind", "?"), ent.get("id", key)))
        return
    print(__doc__)


if __name__ == "__main__":
    main()

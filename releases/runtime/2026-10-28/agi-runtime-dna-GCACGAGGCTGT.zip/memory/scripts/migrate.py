#!/usr/bin/env python3
"""migrate.py — explicit migration orchestrator (fallback trigger).

Auto path = first-run detect in the standing instructions: if state/migration.json
is absent, run this same sequence. This script is the deterministic fallback when
invoked by hand (or from check.sh on a new machine):
    gate check -> env_probe --write -> install_machine_prompt -> migration marker.

OS-agnostic: all per-machine facts come from env_probe at runtime; nothing hardcoded.
Usage: python migrate.py [--dry-run] [--force]
Exit codes: 0 done/steady-state · 2 sandbox mode (no root found; report only, STOP)
            1 failure (stop and report — no retry loops).
"""
import argparse, datetime, json, os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _silent import silent_run
import env_probe


def _ts():
    return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dry-run', action='store_true', help='probe + report only; no DB/marker writes')
    ap.add_argument('--force', action='store_true', help='re-migrate even if marker present')
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))           # memory/scripts/
    mem = os.path.dirname(here)                                 # memory/
    marker_p = os.path.join(mem, 'state', 'migration.json')
    had_marker = os.path.isfile(marker_p)
    if had_marker and not args.force:
        print('marker present - steady state; nothing to migrate (use --force to re-migrate)')
        return 0

    root, method = env_probe.find_root()
    degraded = []
    if not root:
        # Sandbox mode: limited migration. Probe best-effort, report, STOP (no retry).
        result = env_probe.probe(write=not args.dry_run)
        print(json.dumps({'mode': 'sandbox', 'gate_side': 'sandbox',
                          'probe': {k: result[k] for k in ('os', 'real_home', 'root_method')},
                          'action': 'limited migration only - no root found; restore full file access and re-run'},
                         indent=1))
        return 2

    venv = env_probe.find_venv(root)
    if not venv:
        degraded.append('venv_not_found')
    result = env_probe.probe(write=not args.dry_run)

    # Install per-machine system prompt (idempotent; auto-backup inside that script).
    if not args.dry_run:
        r = silent_run([sys.executable,
                        os.path.join(here, 'install_machine_prompt.py'),
                        '--db', os.path.join(root, 'studio.db')])
        if r.returncode != 0:
            degraded.append('prompt_install_failed')

    marker = {
        'first_run': not had_marker,
        'os': result['os']['name'],
        'arch': result['os']['arch'],
        'root': root,
        'venv_python': venv,
        'gate_side': 'real',
        'completed_phases': [1, 2, 3, 4, 5, 6, 7, 8, 9],
        'last_migrated': _ts(),
        'degraded': degraded,
        'notes': f'written by migrate.py ({result.get("root_method", method)})'
    }
    if not args.dry_run:
        os.makedirs(os.path.dirname(marker_p), exist_ok=True)
        with open(marker_p, 'w') as f:
            json.dump(marker, f, indent=1)

    print(json.dumps({'mode': 'real', 'root': root, 'venv_python': venv,
                      'degraded': degraded,
                      'marker': marker_p if not args.dry_run else 'skipped (dry-run)'},
                     indent=1))
    return 0 if not degraded else 1


if __name__ == '__main__':
    sys.exit(main())

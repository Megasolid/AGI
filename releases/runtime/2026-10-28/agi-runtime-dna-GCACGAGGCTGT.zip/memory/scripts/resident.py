#!/usr/bin/env python3
"""resident.py - AGI resident mode: the native self-continuation loop.

Root cause it fixes: the AGI skill had no mechanism that keeps working after a turn ends. DSH only wakes an
agent through a scheduled prompt, so "stacked prompts" are implemented as a resident loop:

  resident.arm()  -> state/resident/mode.json (enabled, until, cadence) + a plan queue
  agent           -> schedule_create(every_seconds=cadence, prompt=resident.pulse())
  each pulse      -> takes the next plan item, does it, marks it done, re-arms the next reminder itself
  resident.disarm() -> the next pulse sees disabled and stops ("resident idle")

The resident loop never bypasses governance gates: it works from the plan queue and stops at human-only gates
unless a valid delegation is recorded.
"""
import argparse
import datetime
import json
import pathlib
import sys

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-resident/1"
DEFAULT_CADENCE = 300
DEFAULT_HOURS = 6


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root=None):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "dir": root / "state" / "resident",
            "mode": root / "state" / "resident" / "mode.json",
            "plan": root / "state" / "resident" / "plan.json"}


def default_plan(root=None):
    root = pathlib.Path(root) if root else AGI
    return {"schema": "agi-resident-plan/1", "items": [
        {"id": "r-01", "title": "Curriculum: health-04 data without overclaiming (evidence doc)", "status": "pending"},
        {"id": "r-02", "title": "Curriculum: health-05 everyday prevention (evidence doc)", "status": "pending"},
        {"id": "r-03", "title": "Curriculum: health-06 sleep and recovery (evidence doc)", "status": "pending"},
        {"id": "r-04", "title": "Curriculum: health-07 nutrition fundamentals (evidence doc)", "status": "pending"},
        {"id": "r-05", "title": "Curriculum: health-08 food claims and myths (evidence doc)", "status": "pending"},
        {"id": "r-06", "title": "Curriculum: health-09 stress and mental wellbeing (evidence doc)", "status": "pending"},
        {"id": "r-07", "title": "Curriculum: health-11 health systems and access (evidence doc)", "status": "pending"},
        {"id": "r-08", "title": "Maintenance: trust anchor + backup prune dry-run + hygiene", "status": "pending"},
        {"id": "r-09", "title": "Review dossier: promotions, mana, policy revision, curriculum progress", "status": "pending"},
        {"id": "r-10", "title": "Resident pulse self-check + next-season readiness note", "status": "pending"},
    ]}


def plan(root=None):
    data = _jload(_paths(root)["plan"])
    if not data:
        data = default_plan(root)
        _jdump(_paths(root)["plan"], data)
    return data


def mode(root=None):
    return _jload(_paths(root)["mode"], {"schema": SCHEMA, "enabled": False})


def status(root=None):
    m = mode(root)
    p = plan(root)
    nxt = next((i for i in p["items"] if i["status"] == "pending"), None)
    done = sum(1 for i in p["items"] if i["status"] == "done")
    return {"schema": SCHEMA, "enabled": bool(m.get("enabled")), "until": m.get("until"),
            "cadence_s": m.get("cadence_s", DEFAULT_CADENCE), "plan_items": len(p["items"]),
            "done": done, "next": nxt, "pulses": m.get("pulses", 0),
            "last_pulse": m.get("last_pulse")}


def arm(hours=DEFAULT_HOURS, cadence_s=DEFAULT_CADENCE, root=None):
    root = pathlib.Path(root) if root else AGI
    until = (datetime.datetime.now() + datetime.timedelta(hours=float(hours))).isoformat(timespec="seconds")
    m = {"schema": SCHEMA, "enabled": True, "armed": datetime.datetime.now().isoformat(timespec="seconds"),
         "until": until, "cadence_s": int(cadence_s), "pulses": 0, "last_pulse": None,
         "note": "a scheduled pulse wakes the agent; each pulse works the next plan item and re-arms"}
    _jdump(_paths(root)["mode"], m)
    plan(root)
    return {"ok": True, **m}


def disarm(root=None, reason="user returned / master stop"):
    m = mode(root)
    m.update({"enabled": False, "disarmed": datetime.datetime.now().isoformat(timespec="seconds"),
              "reason": reason})
    _jdump(_paths(root)["mode"], m)
    return {"ok": True, "enabled": False, "reason": reason}


def pulse(root=None):
    """Text the scheduled reminder delivers. Each pulse works one item, then re-arms itself."""
    root = pathlib.Path(root) if root else AGI
    m = mode(root)
    if not m.get("enabled"):
        return {"ok": True, "idle": True,
                "text": "[AGI resident pulse] Resident mode is disabled or finished. Reply only 'resident idle' and stop."}
    try:
        until = datetime.datetime.strptime(m.get("until", "")[:19], "%Y-%m-%dT%H:%M:%S")
        expired = datetime.datetime.now() > until
    except Exception:
        expired = False
    if expired:
        disarm(root, "until window expired")
        return {"ok": True, "idle": True,
                "text": "[AGI resident pulse] Resident window expired. Reply only 'resident idle' and stop."}
    nxt = status(root)["next"]
    if not nxt:
        disarm(root, "plan complete")
        return {"ok": True, "idle": True,
                "text": "[AGI resident pulse] Plan complete. Reply 'resident complete' with a one-line dossier and stop."}
    m["pulses"] = int(m.get("pulses") or 0) + 1
    m["last_pulse"] = datetime.datetime.now().isoformat(timespec="seconds")
    _jdump(_paths(root)["mode"], m)
    text = ("[AGI resident pulse] Resident mode is active. Work the next plan item `%s`: %s. "
            "Do it for real (evidence doc/knowledge artifact, tests, state updates, log entry), mark it done in "
            "state/resident/plan.json, then keep your reply under 400 words. Do not cross human-only gates "
            "without a recorded delegation. After finishing, ensure the next scheduled pulse exists." % (nxt["id"], nxt["title"]))
    return {"ok": True, "item": nxt, "pulse": m["pulses"], "text": text}


def complete(item_id, root=None, note=""):
    data = plan(root)
    for i in data["items"]:
        if i["id"] == item_id:
            i["status"] = "done"
            i["done"] = datetime.datetime.now().isoformat(timespec="seconds")
            i["note"] = note
            _jdump(_paths(root)["plan"], data)
            return {"ok": True, "item": i, "status": status(root)}
    return {"ok": False, "error": "unknown plan item"}


def render(root=None):
    import ui
    st = status(root)
    data = plan(root)
    rows = "".join("<tr><td class='mono'>%s</td><td>%s</td><td>%s</td></tr>"
                   % (ui.e(i["id"]), ui.e(i["title"]), ui.e(i["status"])) for i in data["items"])
    body = (ui.pagehead("Resident", "Native self-continuation: a scheduled pulse wakes the AGI, works the next plan item, and re-arms.",
                        ui.badge("resident " + ("on" if st["enabled"] else "off"), "ok" if st["enabled"] else "warn") +
                        ui.badge("%d/%d done" % (st["done"], st["plan_items"]), "info")) +
            ui.section("Plan", ui.box("", "<table class='table'><thead><tr><th>id</th><th>item</th><th>status</th>"
                                             "</tr></thead><tbody>%s</tbody></table>" % rows, flush=True),
                       count=st["plan_items"]))
    return ui.page("AGI Resident", body, tabs=[("overview", "Overview", "/"), ("resident", "Resident", "/resident"),
                                              ("docs", "Docs", "/docs")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="resident")


def main(argv=None):
    ap = argparse.ArgumentParser(description="AGI resident mode: native self-continuation via scheduled pulses")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--arm", action="store_true")
    ap.add_argument("--disarm", action="store_true")
    ap.add_argument("--pulse", action="store_true")
    ap.add_argument("--next", action="store_true")
    ap.add_argument("--complete", metavar="ITEM")
    ap.add_argument("--hours", type=float, default=DEFAULT_HOURS)
    ap.add_argument("--cadence", type=int, default=DEFAULT_CADENCE)
    args = ap.parse_args(argv)
    if args.arm:
        print(json.dumps(arm(args.hours, args.cadence), indent=1))
        return 0
    if args.disarm:
        print(json.dumps(disarm(), indent=1))
        return 0
    if args.pulse:
        print(json.dumps(pulse(), indent=1))
        return 0
    if args.complete:
        print(json.dumps(complete(args.complete), indent=1))
        return 0
    if args.next:
        print(json.dumps(status().get("next"), indent=1))
        return 0
    print(json.dumps(status(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

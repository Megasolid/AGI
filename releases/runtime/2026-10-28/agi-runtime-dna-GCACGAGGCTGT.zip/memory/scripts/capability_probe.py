#!/usr/bin/env python3
"""capability_probe.py - S3 capability probe, writes state/capabilities.json (W3, 2026-10-25).

Default (quick, boot-safe ~2-4 s):
  fs read/write round-trip, shell dialect by EXECUTION (default bash vs Git bash),
  external network + host API port, embedding/index facts, max_context source,
  host identity, and the latest free-LLM pool snapshot with its age.
--full : additionally live-pings the pool through the verified agents gateway.
--offline : skip network/pool probes (used by selftest / sandboxed contexts).
--selftest : schema + round-trip check against a scratch file (registry gate).

Machine facts live only in state/ (R2): the probe reads paths from state/env_probe.json
and writes state/capabilities.json. No hardcoded machine paths.
"""
import json
import os
import statistics
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
SCRIPTS = AGI / "memory" / "scripts"
CAPS = STATE / "capabilities.json"
HOST_SPEED = STATE / "host_speed.json"


def _read_json(p):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _which(names):
    import shutil
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return ""


def _find_git_bash():
    import shutil
    for part in (os.environ.get("PATH") or "").split(os.pathsep):
        if not part or "system32" in part.lower():
            continue
        cand = os.path.join(part, "bash.exe")
        if os.path.isfile(cand):
            return cand
    git = shutil.which("git")
    if git:
        root = os.path.dirname(os.path.dirname(git))
        for sub in ("bin", os.path.join("usr", "bin")):
            cand = os.path.join(root, sub, "bash.exe")
            if os.path.isfile(cand):
                return cand
    return ""


def _run(cmd, timeout=15):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode == 0, (p.stdout or p.stderr or "").strip()[:200]
    except Exception as e:
        return False, str(e)[:200]


def _http(url, timeout=8):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "AGI-capability-probe"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status
    except Exception as e:
        return "ERR:" + str(e)[:80]


def fs_probe():
    p = STATE / "_capability_probe.tmp"
    try:
        p.write_text("agi-probe", encoding="utf-8")
        ok = p.read_text(encoding="utf-8").strip() == "agi-probe"
        p.unlink()
        return {"read": True, "write": bool(ok)}
    except Exception as e:
        try:
            p.unlink()
        except Exception:
            pass
        return {"read": False, "write": False, "error": str(e)[:120]}


def shell_probe():
    default = _which(["bash"])
    git = _find_git_bash()
    ok_default, _ = _run([default, "-lc", "echo ok"]) if default else (False, "")
    ok_git, _ = _run([git, "-lc", "echo ok"]) if git else (False, "")
    skill_md = str(AGI / "SKILL.md")
    # WSL bash mangles Windows path arguments; Git bash accepts them (proved by check.sh)
    wp_default, _ = _run([default, "-lc", 'test -f "%s"' % skill_md]) if default else (False, "")
    wp_git, _ = _run([git, "-lc", 'test -f "%s"' % skill_md]) if git else (False, "")
    dialect = "wsl" if default and "system32" in default.lower() else ("git" if default else "none")
    return {
        "pwsh": bool(_which(["pwsh", "powershell"])),
        "bash_default": default,
        "bash_default_dialect": dialect,
        "bash_default_ok": ok_default,
        "git_bash": git,
        "git_bash_ok": ok_git,
        "windows_path_ok_default": wp_default,
        "windows_path_ok_git": wp_git,
    }


def _tcp(host="example.com", port=443, timeout=3):
    try:
        import socket
        s = socket.create_connection((host, port), timeout=timeout)
        s.close()
        return True
    except Exception as e:
        return "ERR:" + str(e)[:60]


def network_probe(env_probe, offline=False):
    if offline:
        return {"offline": True, "ok": None}
    # W7 fast path: a TCP reachability check costs ~50-300 ms vs up to 8 s for a full
    # HTTP GET on a dead network; boot latency matters more than a status code here.
    ext = "tcp:443-ok" if _tcp() is True else _tcp()
    port = (env_probe.get("studio") or {}).get("api_port") or 8888
    studio = _http("http://127.0.0.1:%s/" % port, timeout=2)
    return {"external_https": ext, "studio_api_port": port, "studio_http": studio,
            "ok": ext == "tcp:443-ok"}


def pool_probe(offline=False, full=False):
    snap = _read_json(STATE / "agents_status.json")
    ts = snap.get("ts")
    age = None
    try:
        import datetime as dt
        if ts:
            age = max(0.0, time.time() - dt.datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").astimezone().timestamp())
    except Exception:
        age = None
    providers = snap.get("providers") or {}
    up = sorted(k for k, v in providers.items() if isinstance(v, dict) and v.get("ok"))
    down = sorted(k for k, v in providers.items() if not (isinstance(v, dict) and v.get("ok")))
    out = {"snapshot_ts": ts, "snapshot_age_s": None if age is None else round(age, 1),
           "stale": bool(age is not None and age > 3600), "pool_up": up, "down": down,
           "source": "state/agents_status.json"}
    if full and not offline:
        gw = SCRIPTS / "agents" / "gateway.py"
        ok, _txt = _run([sys.executable, str(gw), "ping"], timeout=150)
        fresh = _read_json(STATE / "agents_status.json")
        out.update({"live_ping_ok": ok, "live_ts": fresh.get("ts"), "source": "live gateway ping"})
    return out


def embedding_probe(env_probe):
    prov = _read_json(AGI / "memory" / "index" / "provider.json")
    configured = bool(os.environ.get("AGI_INTERNAL_EMBEDDING_MODEL", "").strip())
    return {
        "backend": prov.get("backend") or "internal",
        "configured": configured,
        "model_dir_recorded": prov.get("model"),
        "index": {"chunks": prov.get("chunks"), "dimensions": prov.get("dimensions"),
                  "generated": prov.get("generated")},
    }


def derive_factor(entries, window=10):
    """Median actual_s/est_s over recent completed bill entries (pure, testable).

    The recency window keeps the factor on the current host: bills now carry a host stamp
    (taskbill start, 2026-10-25) so a future version can filter by host explicitly.
    """
    completed = [e for e in entries
                 if float(e.get("actual_s") or 0) > 0 and float(e.get("est_s") or 0) > 0]
    ratios = [float(e["actual_s"]) / float(e["est_s"]) for e in completed[-window:]]
    if not ratios:
        return {"factor": None, "samples": 0, "ratios": []}
    factor = round(statistics.median(ratios), 4)
    return {"factor": max(0.05, min(3.0, factor)), "samples": len(ratios),
            "ratios": [round(r, 3) for r in ratios]}


def host_speed_probe(write=True, path=None):
    """Per-host generation speed + evidence-derived estimate factor (W-B, 2026-10-25).

    declared_* : D-supplied generation speed (~200 tok/s under DSH) - a machine fact kept in
                 state/; every refresh preserves it.
    derived    : median(actual_s/est_s) over the recent completed bills; taskbill consumes it
                 as the estimate contingency for this host.
    """
    path = Path(path) if path else HOST_SPEED
    prev = _read_json(path)
    boot = _read_json(STATE / "boot_card.json")
    entries = []
    try:
        for line in (AGI / "memory" / "time" / "tasklog.jsonl").read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except Exception:
                continue
    except Exception:
        entries = []
    d = derive_factor(entries)
    declared = {k: prev.get(k) for k in
                ("declared_gen_tok_s", "declared_by", "declared_at", "declared_source")
                if prev.get(k) is not None}
    out = dict(declared)
    out["note"] = ("machine fact (R2) - host generation speed + evidence-derived estimate factor; refreshed "
                   "at boot by capability_probe, consumed by taskbill as the contingency overlay")
    out["derived"] = {
        "factor": d["factor"], "samples": d["samples"], "ratios": d["ratios"],
        "last_refresh": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "method": "median(actual_s/est_s) over the last <=10 completed bills (recency window)",
        "host": (boot.get("host_application") or {}).get("id") if isinstance(boot.get("host_application"), dict) else boot.get("host_application"),
        "model": boot.get("model_name"),
    }
    if write:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(out, indent=1), encoding="utf-8")
        tmp.replace(path)
    return {"declared_gen_tok_s": out.get("declared_gen_tok_s"),
            "factor": d["factor"], "samples": d["samples"]}


def probe(out_path=None, full=False, offline=False):
    env_probe = _read_json(STATE / "env_probe.json")
    env_model = env_probe.get("model") or {}
    ctx = env_model.get("context_length")
    try:
        sys.path.insert(0, str(SCRIPTS))
        import cardkit
        host = cardkit.host_application_identity()
    except Exception:
        host = None
    caps = {
        "fs": fs_probe(),
        "shell": shell_probe(),
        "network": network_probe(env_probe, offline=offline),
        "subagents": pool_probe(offline=offline, full=full),
        "max_context": ctx,
        "max_context_source": ("state/env_probe.json model.context_length" if ctx
                               else "unresolved - host exposes context only at runtime; no static catalog field"),
        "embedding": embedding_probe(env_probe),
        "host_application": {"id": host, "detected_by": "cardkit.host_application_identity",
                             "dsh_session": bool(os.environ.get("DSH_SESSION_ID"))},
        "host_speed": host_speed_probe(write=(out_path is None)),
        "profile": (env_probe.get("model") or {}).get("flags") or "unknown",
        "probed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "probe_mode": "full" if full else ("offline" if offline else "quick"),
    }
    target = Path(out_path) if out_path else CAPS
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(caps, indent=2), encoding="utf-8")
    tmp.replace(target)
    return caps


def selftest():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        caps = probe(Path(tmp) / "capabilities.json", offline=True)
        req = {"fs", "shell", "network", "subagents", "max_context", "embedding", "host_application",
               "host_speed", "probed_at"}
        ok = req.issubset(caps) and isinstance(caps["fs"].get("read"), bool)
        shell = caps["shell"]
        ok = ok and isinstance(shell.get("bash_default_ok"), bool) and "pwsh" in shell
        rt = _read_json(Path(tmp) / "capabilities.json")
        ok = ok and rt.get("probed_at") == caps["probed_at"]
        print("capability_probe selftest:", "PASS" if ok else "FAIL",
              "| keys", len(caps), "| shell", shell.get("bash_default_dialect"))
        return 0 if ok else 1


def main():
    args = sys.argv[1:]
    if "--selftest" in args:
        sys.exit(selftest())
    full = "--full" in args
    offline = "--offline" in args
    caps = probe(full=full, offline=offline)
    print("capabilities written: %s | fs=%s shell=%s net=%s pool=%s max_ctx=%s" % (
        CAPS, caps["fs"].get("read") and caps["fs"].get("write"),
        caps["shell"].get("bash_default_dialect"), caps["network"].get("ok"),
        "%d/%d" % (len(caps["subagents"].get("pool_up", [])),
                   len(caps["subagents"].get("pool_up", [])) + len(caps["subagents"].get("down", []))),
        caps.get("max_context")))


if __name__ == "__main__":
    main()

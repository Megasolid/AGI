#!/usr/bin/env python3
"""BIOS P: install the stable boot system-prompt block into every studio.db systemPrompt.

Writes a compact, machine-specific boot header (memdir/state/db/python + verified-script map
+ condensed rules + 'boot already ran; one bios call for live status') so the model does NOT
re-derive paths or re-read SKILL.md/MEMORY.md at cold start. Live state is never baked in - it
is always fetched with `bios.py --card`.

Portable: reads machine values from state/env_probe.json (never hardcoded). Idempotent: a
re-run replaces only the [BOOT-CORE ...] block. Auto-backs up inferenceParamsByModel first.

Usage: python install_boot_prompt.py [--db PATH] [--dry-run]
"""
import argparse, json, re, sqlite3, sys
from pathlib import Path
from datetime import datetime, timezone

MARK_START = "[BOOT-CORE v2]"
MARK_END   = "[/BOOT-CORE v2]"
# version-tolerant markers: a re-run strips any older [BOOT-CORE vN] block first
RE_START = re.compile(r"^\s*\[BOOT-CORE v\d+\]")
RE_END   = re.compile(r"^\s*\[/BOOT-CORE v\d+\]")

def build_block(probe, scripts):
    root  = (probe.get("root") or "?").replace("\\", "/")          # studio install root
    py    = (probe.get("venv_python") or sys.executable).replace("\\", "/")
    db    = f"{root}/studio.db"
    core  = Path(__file__).resolve().parents[2]                   # <skill> Core/memdir
    scripts_dir = (core / "memory" / "scripts").as_posix()
    verified = [n for n, s in scripts.items()
                if isinstance(s, dict) and str(s.get("status", "")).startswith("verified")]
    vline = ", ".join(verified) or "(none)"
    bios_cmd = f"{py} {scripts_dir}/bios.py --card"
    wd_cmd   = f"{py} {scripts_dir}/watchdogs.py"
    return (
        f"{MARK_START} Boot already ran before you started thinking (BIOS). Do NOT re-derive paths; use:\n"
        f"  memdir={core.as_posix()}   state={(core/'state').as_posix()}   db={db}   python={py}\n"
        f"  Verified scripts (the ONLY ones that may run): {vline}   [registry: {scripts_dir}/registry.json]\n"
        f"  Rules: R1 act on verified facts, not guesses; R2 machine facts live only in state/; "
        f"R3 a script runs only if registry marks it verified; R4 confirm before irreversible ops (auto-backup);\n"
        f"  R5 one failed op = stop & report, no blind retry loops; R6 use subagents for parallel/repeatable work.\n"
        f"  Live status: if state/boot_card.json is stale or status=debug, run ONE call `{bios_cmd}` and act on it (debug => debugging mode).\n"
        f"  Watch Dogs: at the start of every AGI turn run ONE call `{wd_cmd} bark` (mode / open tasks / maintenance / candidates - the standing policies to carry this turn); on task verification stamp the pill with `{wd_cmd} stamp <task-id> --note '...'`.\n"
        f"{MARK_END}"
    )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=None)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    core  = Path(__file__).resolve().parents[2]                  # <skill> (Core / memdir)
    probe_p = core / "state" / "env_probe.json"
    if not probe_p.exists():
        sys.exit("no state/env_probe.json - run env_probe.py --write first")
    probe = json.loads(probe_p.read_text(encoding="utf-8"))
    reg_p = core / "memory" / "scripts" / "registry.json"
    scripts = {}
    if reg_p.exists():
        try:
            scripts = json.loads(reg_p.read_text(encoding="utf-8")).get("scripts", {})
        except Exception:
            pass
    db = Path(a.db) if a.db else Path(probe["root"]) / "studio.db"
    if not db.exists():
        sys.exit(f"db not found: {db}")
    block = build_block(probe, scripts)
    con = sqlite3.connect(str(db))
    row = con.execute("SELECT value_json, updated_at FROM chat_settings WHERE key='inferenceParamsByModel'").fetchone()
    if not row:
        sys.exit("chat_settings.inferenceParamsByModel not found")
    val, updated_at = json.loads(row[0]), row[1]
    if not a.dry_run:
        bak = core / "memory" / "backups" / f"inferenceParamsByModel.bak.{db.stem}.json"
        bak.parent.mkdir(exist_ok=True)
        bak.write_text(json.dumps(val, indent=1), encoding="utf-8")
        print(f"backup -> {bak}")
    changed = 0
    for model_id, cfg in val.items():
        if not isinstance(cfg, dict) or "systemPrompt" not in cfg:
            continue
        sp = cfg["systemPrompt"]
        out, skip = [], False
        for l in sp.splitlines():
            if RE_START.match(l): skip = True;  continue
            if RE_END.match(l):   skip = False; continue
            if not skip: out.append(l)
        cfg["systemPrompt"] = ("\n".join(out).rstrip("\n") + "\n" + block).strip() + "\n"
        changed += 1
    print(f"models updated: {changed}")
    if a.dry_run:
        first = next(iter(val.values()), {})
        print("DRY RUN - not written. New text for first model:\n---\n" + first.get("systemPrompt", ""))
        return
    con.execute("UPDATE chat_settings SET value_json=?, updated_at=? WHERE key='inferenceParamsByModel'",
                (json.dumps(val, ensure_ascii=False), datetime.now(timezone.utc).isoformat()))
    con.commit()
    back = json.loads(con.execute("SELECT value_json FROM chat_settings WHERE key='inferenceParamsByModel'").fetchone()[0])
    ok = all(MARK_START in c.get("systemPrompt", "") for c in back.values() if isinstance(c, dict))
    print("readback ok:", ok)
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""live_state.py - live payload for the Pulse dashboard: status / now / needs / activity / series.

Served at /api/live and polled every 3s. Needs-you is reserved for things the *human* must answer
(proposal questions, reviews, cancellations). Approvals the human already gave are AGI's own queue and are
consumed after acting - they must not reappear as "needs you".
"""
import json
import pathlib
import time

AGI = pathlib.Path(__file__).resolve().parents[2]
STATE = AGI / "state"

ASK_LABEL = {"review": "Something wants your review",
             "cancel": "A cancellation is waiting for me"}
ASK_WHY = {"review": "If you do nothing: I keep working; this stays unreviewed.",
           "cancel": "If you do nothing: I continue as planned."}


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jlines(p):
    try:
        return [json.loads(l) for l in pathlib.Path(p).read_text(encoding="utf-8").splitlines() if l.strip()]
    except Exception:
        return []


def _day(ts):
    s = str(ts or "")
    return s[:10] if len(s) >= 10 else ""


def _daily(lines, days=14):
    counts = {}
    for ln in lines:
        d = _day(ln.get("ts") or "")
        if d:
            counts[d] = counts.get(d, 0) + 1
    out = []
    for i in range(days - 1, -1, -1):
        day = time.strftime("%Y-%m-%d", time.localtime(time.time() - i * 86400))
        out.append(counts.get(day, 0))
    return out


def _hourly(lines, hours=8):
    now = time.time()
    buckets = [0] * hours
    for ln in lines:
        ts = str(ln.get("ts") or "")
        try:
            from datetime import datetime
            t = datetime.fromisoformat(ts).timestamp()
        except Exception:
            continue
        age = now - t
        if 0 <= age < hours * 3600:
            idx = hours - 1 - int(age // 3600)
            if 0 <= idx < hours:
                buckets[idx] += 1
    return buckets


def _now_block():
    st = _jload(STATE / "task_steps.json", {}) or {}
    steps = st.get("steps") or []
    total = len(steps)
    passed = sum(1 for s in steps if s.get("status") == "passed")
    current = next((i + 1 for i, s in enumerate(steps) if s.get("status") == "running"), None)
    if current is None:
        current = min(passed + 1, total) if total else 0
    nxt = next((s.get("name") for s in steps if s.get("status") in ("pending", "running")), None)
    title = st.get("title") or ""
    active = any(s.get("status") in ("running", "pending") for s in steps)
    idle = not (title and active)
    elapsed = 0
    try:
        elapsed = max(0, int(time.time() - (STATE / "task_steps.json").stat().st_mtime))
    except OSError:
        elapsed = 0
    return {"idle": idle, "task": "" if idle else title, "last_task": title,
            "purpose": st.get("bill_task") or "",
            "steps": [{"n": s.get("n"), "name": s.get("name"), "status": s.get("status")} for s in steps[:12]],
            "total": total, "passed": passed, "current": current, "next": nxt,
            "started_ts": st.get("started") or "", "elapsed_s": elapsed}


def _needs_block():
    """Only genuine human questions. Approvals already given are AGI's queue, not 'needs you'."""
    out = []
    st = _jload(STATE / "task_steps.json", {}) or {}
    if st.get("mode") == "proposal":
        out.append({"n": 0, "type": "proposal",
                    "label": "A task is waiting for your go-ahead",
                    "consequence": "If you do nothing: I stay paused and do not start.",
                    "hint": (st.get("title") or "")[:90],
                    "action": "/task_live.html", "action_label": "Review the plan"})
    acts = _jlines(STATE / "taskboard_actions.jsonl")
    cursor = int((_jload(STATE / "taskboard_actions_cursor.json", {}) or {}).get("last") or 0)
    for a in acts:
        if int(a.get("n") or 0) <= cursor:
            continue
        kind = a.get("type") or "note"
        if kind in ASK_LABEL:
            out.append({"n": a.get("n"), "type": kind, "label": ASK_LABEL[kind],
                        "consequence": ASK_WHY[kind], "hint": (a.get("note") or "")[:90],
                        "action": "/task_live.html", "action_label": "Open the task card"})
    return out


def _queue_block():
    """Approvals/notes the human already gave, waiting for AGI to act on - shown as a queue, not a request."""
    acts = _jlines(STATE / "taskboard_actions.jsonl")
    cursor = int((_jload(STATE / "taskboard_actions_cursor.json", {}) or {}).get("last") or 0)
    pending = [a for a in acts if int(a.get("n") or 0) > cursor]
    types = {}
    for a in pending:
        types[a.get("type") or "note"] = types.get(a.get("type") or "note", 0) + 1
    return {"count": len(pending), "types": types,
            "last": (pending[-1].get("note") if pending else "")}


def _activity_block(limit=8):
    trust = _jlines(STATE / "trust_log" / "events.jsonl")[-6:]
    bills = _jlines(AGI / "memory" / "time" / "tasklog.jsonl")[-14:]
    acts = _jlines(STATE / "taskboard_actions.jsonl")[-6:]
    evs = []
    for ln in trust:
        evs.append((str(ln.get("ts") or ""), "security", "signed the history log"))
    for ln in bills:
        t = (ln.get("type") or "").lower()
        if t == "start":
            evs.append((str(ln.get("ts") or ""), "work", "started: " + str(ln.get("task") or "")[:70]))
        elif t == "finish":
            evs.append((str(ln.get("ts") or ""), "done", "finished: " + str(ln.get("task") or "")[:70]))
    for ln in acts:
        evs.append((str(ln.get("ts") or ""), "you", "%s: %s" % (ln.get("type") or "decision",
                                                               (ln.get("note") or "")[:60])))
    evs = [e for e in evs if e[0]]
    evs.sort(key=lambda e: e[0], reverse=True)
    return [{"ts": e[0][11:16] if len(e[0]) > 16 else e[0], "kind": e[1], "text": e[2][:100]}
            for e in evs[:limit]]


def _series_block():
    trust = _daily(_jlines(STATE / "trust_log" / "events.jsonl"))
    bills = _daily([x for x in _jlines(AGI / "memory" / "time" / "tasklog.jsonl") if x.get("type") == "start"])
    acts = _daily(_jlines(STATE / "taskboard_actions.jsonl"))
    finished = _daily([x for x in _jlines(AGI / "memory" / "time" / "tasklog.jsonl") if x.get("type") == "finish"])
    pulse = _hourly(_jlines(AGI / "memory" / "time" / "tasklog.jsonl") +
                    _jlines(STATE / "taskboard_actions.jsonl") +
                    _jlines(STATE / "trust_log" / "events.jsonl"))
    return {"trust_14d": trust, "started_14d": bills, "decisions_14d": acts,
            "finished_14d": finished, "pulse_8h": pulse,
            "today": {"finished": finished[-1] if finished else 0,
                      "started": bills[-1] if bills else 0,
                      "decisions": acts[-1] if acts else 0}}


def _status_block():
    gate = _jload(STATE / "boot_gate.json", {}) or {}
    ok = bool(gate.get("ok")) if gate else True
    heads = STATE / "trust_log" / "heads"
    try:
        history = max(int(p.stem) for p in heads.glob("*.json") if p.stem.isdigit())
    except Exception:
        history = len(_jlines(STATE / "trust_log" / "events.jsonl"))
    rel = _jload(STATE / "repo" / "AGI" / "repo.json", {}) or {}
    tag = (rel.get("current_tag") or rel.get("tag") or "").lstrip("v")
    if not tag:
        try:
            import subprocess
            out = subprocess.run(["git", "-C", str(STATE / "repo" / "AGI"), "tag", "--sort=-creatordate"],
                                 capture_output=True, text=True, timeout=10).stdout.split()
            tag = out[0].lstrip("v") if out else ""
        except Exception:
            tag = ""
    return {"healthy": ok, "label": "AGI is healthy" if ok else "Health check failing",
            "detail": "all boot checks passed" if ok else "open Details for the failing check",
            "release": tag, "history": history}


def payload():
    ts = time.strftime("%Y-%m-%dT%H:%M:%S")
    return {"ts": ts, "status": _status_block(), "now": _now_block(),
            "needs": _needs_block(), "queue": _queue_block(), "activity": _activity_block(),
            "series": _series_block(), "updated_at": ts}


if __name__ == "__main__":
    print(json.dumps(payload(), indent=1))

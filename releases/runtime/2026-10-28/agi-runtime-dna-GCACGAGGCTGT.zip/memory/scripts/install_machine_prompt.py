#!/usr/bin/env python3
"""P3: install the per-machine facts line into every studio.db systemPrompt.

Reusable (portable): reads state/env_probe.json for THIS machine's stable facts,
backs up the chat_settings row, then appends/refreshes item "4) Machine facts"
in every model entry of app key 'inferenceParamsByModel'. Idempotent: re-running
replaces only that line. Never touches other inference params.

Usage: python install_machine_prompt.py [--db PATH] [--dry-run]
"""
import argparse, json, pathlib, sqlite3, sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=None, help="path to studio.db (default: <root>/studio.db)")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    # locate the canonical state tree via env_probe.json (skill/state, never memory/state)
    mem = pathlib.Path(__file__).resolve().parent.parent
    probe_p = mem.parent / "state" / "env_probe.json"
    if not probe_p.exists():
        sys.exit("no state/env_probe.json - run env_probe.py --write first")
    probe = json.loads(probe_p.read_text(encoding="utf-8"))
    db = pathlib.Path(args.db) if args.db else pathlib.Path(probe["root"]) / "studio.db"
    if not db.exists():
        sys.exit(f"db not found: {db}")

    root_s = probe["root"].replace("\\", "/")
    py_s = probe["venv_python"].replace("\\", "/")
    line = (
        f"4) Machine facts (this host, verified {probe.get('os',{}).get('name','?')}): "
        f"root {root_s} · venv python {py_s} · "
        f"{probe['hw']['gpu']} {round(int(probe['hw']['vram_total_mb'])/1024)}GB. "
        f"Volatile stats (model, VRAM used, temps) live in state/env_probe.json - re-probe, don't cache."
    )

    con = sqlite3.connect(str(db))
    row = con.execute("SELECT value_json, updated_at FROM chat_settings WHERE key='inferenceParamsByModel'").fetchone()
    if not row:
        sys.exit("chat_settings.inferenceParamsByModel not found")
    val, updated_at = json.loads(row[0]), row[1]

    # backup before any change (skip for dry-run)
    if not args.dry_run:
        bak = mem / "backups" / f"inferenceParamsByModel.bak.{db.stem}.json"
        bak.parent.mkdir(exist_ok=True)
        bak.write_text(json.dumps(val, indent=1), encoding="utf-8")
        print(f"backup -> {bak}")

    changed = 0
    for model_id, cfg in val.items():
        if not isinstance(cfg, dict) or "systemPrompt" not in cfg:
            continue
        sp = cfg["systemPrompt"]
        # strip any previous machine-facts line (idempotent)
        sp = "\n".join(l for l in sp.splitlines() if not l.strip().startswith("4) Machine facts"))
        sp = sp.rstrip("\n") + "\n" + line
        cfg["systemPrompt"] = sp
        changed += 1
    print(f"models updated: {changed}")
    if args.dry_run:
        print("DRY RUN - not written. New text for first model:\n---\n" + val[list(val)[0]]["systemPrompt"])
        return
    from datetime import datetime, timezone
    con.execute("UPDATE chat_settings SET value_json=?, updated_at=? WHERE key='inferenceParamsByModel'",
                (json.dumps(val, ensure_ascii=False), datetime.now(timezone.utc).isoformat()))
    con.commit()
    # verify readback
    back = json.loads(con.execute("SELECT value_json FROM chat_settings WHERE key='inferenceParamsByModel'").fetchone()[0])
    ok = all("4) Machine facts" in c.get("systemPrompt", "") for c in back.values() if isinstance(c, dict))
    print("readback ok:", ok)
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""identity.py - native user authentication + optional third-party federation (P13-A).

Two layers, deliberately separate:

  * NATIVE identity: a profile on this install, proved by possession of the install's device key
    (ML-DSA-65, DPAPI-sealed). `login` signs a one-time challenge; nothing is typed and no shared
    secret exists. This is the layer that will be strengthened by passkeys (P12-A) - the schemas
    here already carry a `factors` block so a passkey credential can be added without migration.
  * FEDERATION (third party): an optional link record such as Google, stored as a KEYED HASH of
    the handle. It is used for onboarding and account recovery only. It can never authorise a
    master action: `whoami` reports the native level separately, and `login --federated` produces
    a `federated` session that cannot be used for authority.

Profiles
  * `default` profile: created on first use, so a fresh install can always start (the "skip" path
    in the login screen). It has no member identity and no authority.
  * member profiles: named profiles that may later bind a passport (D's profile is a member).

Sessions
  * state/identity/session.json: {profile, level: default|device|federated, created, expires}
  * `device` proves possession of the install key today; a passkey will add `passkey` level later.

CLI
  identity.py init [--skip]
  identity.py create --name <name> [--member <member>]
  identity.py list
  identity.py login [--profile <id>] [--ttl-hours 12]     # native: signs a challenge
  identity.py skip                                        # default profile, level default
  identity.py logout
  identity.py whoami
  identity.py link --provider google --subject-hash <hex> [--profile <id>]
  identity.py unlink --provider google [--profile <id>]
  identity.py federation
  identity.py verify
  identity.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import hashlib
import hmac
import json
import secrets
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
ID_DIR = STATE / "identity"
PROFILES = ID_DIR / "profiles.json"
SESSION = ID_DIR / "session.json"
CHALLENGE = ID_DIR / "challenge.json"

sys.path.insert(0, str(MEM / "scripts"))
import crypto  # noqa: E402

SCHEMA = "agi-identity/1"
SESSION_SCHEMA = "agi-session/1"
LEVELS = ("default", "device", "federated", "passkey", "phrase")
LOGGING = True


# ---------------------------------------------------------------- helpers
def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _expires(hours):
    return (datetime.now().astimezone() + timedelta(hours=float(hours))).strftime("%Y-%m-%dT%H:%M:%S%z")


def _expired(ts):
    try:
        return datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S%z") < datetime.now().astimezone()
    except (TypeError, ValueError):
        return True


def _hash_handle(handle, salt=None):
    """Keyed hash of an external handle: the address itself is never stored."""
    key = (crypto.pinned_key_id() or "unkeyed").encode()
    return hmac.new(key, ((salt or "agi-federation") + ":" + str(handle)).encode(), hashlib.sha256).hexdigest()


def _profiles():
    return _jload(PROFILES, {"schema": SCHEMA, "default": None, "profiles": {}})


def profile_list():
    return _profiles().get("profiles") or {}


def active_profile():
    s = _jload(SESSION) or {}
    return (s.get("profile") if s.get("active") else None)


# ---------------------------------------------------------------- profiles
def init(skip=False):
    data = _profiles()
    if not data.get("default"):
        pid = "default"
        data["profiles"][pid] = {
            "profile_id": pid,
            "name": "Default",
            "kind": "default",
            "member": None,
            "passport_id": None,
            "device_key_id": crypto.pinned_key_id(),
            "created": _now(),
            "factors": {"device_key": {"enrolled": bool(crypto.pinned_key_id())}, "passkey": []},
            "federation": [],
            "authority": "none",
            "note": "boot profile: usable without login, holds no member identity and no authority",
        }
        data["default"] = pid
        _jdump(PROFILES, data)
        if LOGGING:
            import trust_log
            trust_log.append("identity-init", {"default": pid,
                                              "device_key": crypto.pinned_key_id()})
    if skip:
        return skip_login()
    return {"ok": True, "default": data["default"], "profiles": len(data["profiles"])}


def create(name, member=None):
    data = _profiles()
    if not data.get("profiles"):
        init()
        data = _profiles()
    pid = "p-" + hashlib.sha256(f"{name}:{_now()}:{secrets.token_hex(4)}".encode()).hexdigest()[:10]
    data["profiles"][pid] = {
        "profile_id": pid, "name": str(name), "kind": "member", "member": member or str(name),
        "passport_id": None, "device_key_id": crypto.pinned_key_id(), "created": _now(),
        "factors": {"device_key": {"enrolled": bool(crypto.pinned_key_id())}, "passkey": []},
        "federation": [],
        "authority": "member-pending-passport",
        "note": "bind a passport (passport.py) to make this profile a full member",
    }
    _jdump(PROFILES, data)
    return data["profiles"][pid]


# ---------------------------------------------------------------- login / session
def _write_session(profile_id, level, hours=12, extra=None):
    if profile_id not in profile_list():
        raise KeyError(f"no profile {profile_id!r}")
    rec = {"schema": SESSION_SCHEMA, "active": True, "profile": profile_id, "level": level,
           "created": _now(), "expires": _expires(hours)}
    if extra:
        rec.update(extra)
    _jdump(SESSION, rec)
    if LOGGING:
        import trust_log
        trust_log.append("identity-login", {"profile": profile_id, "level": level,
                                            "expires": rec["expires"]})
    return rec


def login(profile_id=None, ttl_hours=12):
    """Native login: prove possession of the install device key by signing a challenge."""
    data = _profiles()
    pid = profile_id or data.get("default")
    if pid not in data.get("profiles", {}):
        raise KeyError(f"no profile {pid!r}")
    if not crypto.pinned_key_id():
        raise PermissionError("no device key on this install: run crypto.py keygen, or use 'skip'")
    nonce = secrets.token_hex(16)
    challenge = {"schema": "agi-login-challenge/1", "nonce": nonce, "profile": pid,
                 "issued": _now(), "expires": _expires(0.1)}
    _jdump(CHALLENGE, challenge)
    sig = crypto.sign_bytes(crypto.canonical_json(challenge))
    check = crypto.verify_bytes(crypto.canonical_json(challenge), sig,
                                expected_key_id=crypto.pinned_key_id())
    if not check.get("ok"):
        raise PermissionError("device-key proof failed: " + str(check.get("reason")))
    return _write_session(pid, "device", ttl_hours,
                          {"proof": {"alg": sig.get("alg"), "key_id": sig.get("key_id"),
                                     "nonce_sha256": hashlib.sha256(nonce.encode()).hexdigest()}})


def skip_login(ttl_hours=24):
    """Boot without identity: the default profile, no authority."""
    data = _profiles()
    pid = data.get("default")
    if not pid:
        init()
        pid = _profiles().get("default")
    return _write_session(pid, "default", ttl_hours)


def federated_login(profile_id, provider="google", assertion_hash=None):
    """A third-party login is recorded, but it yields a NON-authoritative session level."""
    rec = _write_session(profile_id, "federated", 12,
                         {"federation": {"provider": provider, "assertion_hash": assertion_hash},
                          "authority": "none (federated sessions cannot unlock master)"})
    return rec


def logout():
    rec = {"schema": SESSION_SCHEMA, "active": False, "logged_out": _now()}
    _jdump(SESSION, rec)
    return rec


def whoami():
    s = _jload(SESSION) or {}
    if not s.get("active"):
        return {"authenticated": False, "profile": None, "level": "none"}
    p = profile_list().get(s.get("profile")) or {}
    return {"authenticated": True, "profile": s.get("profile"), "name": p.get("name"),
            "kind": p.get("kind"), "level": s.get("level"), "expires": s.get("expires"),
            "expired": _expired(s.get("expires")), "authority": p.get("authority"),
            "device_key": p.get("device_key_id")}


# ---------------------------------------------------------------- federation links
def link(provider, subject_hash=None, handle=None, profile_id=None):
    """Store a federation link as a keyed hash. Raw handles are never stored."""
    if handle and not subject_hash:
        subject_hash = _hash_handle(handle, salt=provider)
    if not subject_hash or len(str(subject_hash)) < 32:
        raise ValueError("provide --subject-hash (>=32 hex chars) or a handle to hash")
    sh = str(subject_hash).lower()
    if "@" in sh:
        raise ValueError("refusing to store a raw email/handle: pass --handle to hash it instead")
    data = _profiles()
    pid = profile_id or active_profile() or data.get("default")
    rec = data["profiles"].get(pid)
    if not rec:
        raise KeyError(f"no profile {pid!r}")
    rec.setdefault("federation", []).append({
        "provider": str(provider), "subject_hash": sh, "linked": _now(),
        "authority": "none (federation is for onboarding/recovery, never for master authority)",
    })
    _jdump(PROFILES, data)
    if LOGGING:
        import trust_log
        trust_log.append("identity-federated-link", {"profile": pid, "provider": provider,
                                                     "subject_hash": sh[:16] + "..."})
    return rec["federation"][-1]


def unlink(provider, profile_id=None):
    data = _profiles()
    pid = profile_id or active_profile() or data.get("default")
    rec = data["profiles"].get(pid)
    if not rec:
        raise KeyError(f"no profile {pid!r}")
    before = len(rec.get("federation") or [])
    rec["federation"] = [f for f in rec.get("federation") or [] if f.get("provider") != provider]
    _jdump(PROFILES, data)
    return {"removed": before - len(rec["federation"]), "remaining": len(rec["federation"])}


def bind_passport(profile_id, passport_id):
    """Bind a member profile to a passport; this is what turns it into an authority-bearing profile."""
    data = _profiles()
    rec = data["profiles"].get(profile_id)
    if not rec:
        raise KeyError(f"no profile {profile_id!r}")
    psp = _jload(STATE / "passport.json") or {}
    if psp.get("passport_id") == passport_id:
        rec["passport_id"] = passport_id
        rec["member"] = psp.get("member") or rec.get("member")
        rec["genome_root"] = psp.get("user_genome_root")
        rec["genome_epoch"] = psp.get("genome_epoch")
        rec["authority"] = "member"
        rec["kind"] = "member"
    else:
        raise ValueError(f"passport {passport_id!r} is not this install's passport "
                         f"({psp.get('passport_id')!r})")
    _jdump(PROFILES, data)
    if LOGGING:
        import trust_log
        trust_log.append("identity-passport-bind", {"profile": profile_id, "passport_id": passport_id,
                                                    "genome_epoch": psp.get("genome_epoch")})
    return {k: rec.get(k) for k in ("profile_id", "name", "kind", "member", "passport_id",
                                    "genome_root", "genome_epoch", "authority")}


def phrase_session(profile_id, ttl_hours=12):
    """Session opened by proving the admin phrase (the profile was decrypted with it)."""
    if profile_id not in profile_list():
        raise KeyError(f"no profile {profile_id!r}")
    return _write_session(profile_id, "phrase", ttl_hours)


def login_passkey(assertion, rp_id="127.0.0.1", origin=None, ttl_hours=12):
    """Native login with a passkey assertion: level `passkey`, portable across machines."""
    import passkey as pk
    v = pk.verify_assertion(assertion, rp_id=rp_id, origin=origin)
    if not v.get("ok"):
        raise PermissionError("passkey assertion failed")
    data = _profiles()
    pid = active_profile() if (active_profile() in data.get("profiles", {})) else data.get("default")
    if not pid:
        pid = init().get("default")
    rec = _write_session(pid, "passkey", ttl_hours,
                         {"proof": {"kind": "passkey", "credential_id": v.get("credential_id"),
                                    "alg": v.get("alg"), "sign_count": v.get("sign_count")}})
    # record the credential id on the profile's factor list (no secret, just the id)
    prof = data["profiles"].get(pid)
    if prof is not None:
        ids = prof.setdefault("factors", {}).setdefault("passkey", [])
        if v.get("credential_id") not in ids:
            ids.append(v.get("credential_id"))
            _jdump(PROFILES, data)
    return rec


# ---------------------------------------------------------------- verify
def verify():
    problems = []
    data = _profiles()
    if data.get("schema") != SCHEMA:
        problems.append(f"profiles schema {data.get('schema')!r}")
    profiles = data.get("profiles") or {}
    if not profiles:
        problems.append("no profiles: run identity.py init")
    if data.get("default") not in profiles:
        problems.append("default profile missing")
    for pid, rec in profiles.items():
        if rec.get("profile_id") != pid:
            problems.append(f"profile {pid}: id mismatch")
        for f in rec.get("federation") or []:
            sh = str(f.get("subject_hash") or "")
            if "@" in sh or len(sh) < 32:
                problems.append(f"profile {pid}: federation link stores a raw/!invalid handle hash")
    s = _jload(SESSION) or {}
    if s.get("active"):
        if s.get("profile") not in profiles:
            problems.append("session points at a missing profile")
        if s.get("level") not in LEVELS:
            problems.append(f"session level {s.get('level')!r} is not one of {LEVELS}")
        # an expired session is normal (the operator logs in again); it is not an integrity problem
        pass
        if s.get("level") == "federated":
            problems.append("authority leak: a federated session must not be the active authority")
    return {"ok": not problems, "problems": problems,
            "profiles": len(profiles), "default": data.get("default"),
            "session": whoami()}


# ---------------------------------------------------------------- CLI
def _arg(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def cmd_init(args):
    print(json.dumps(init(skip="--skip" in args), indent=1))
    return 0


def cmd_create(args):
    name = _arg(args, "--name")
    if not name:
        print("usage: identity.py create --name <name> [--member <member>]")
        return 2
    print(json.dumps(create(name, _arg(args, "--member")), indent=1))
    return 0


def cmd_list(args):
    data = _profiles()
    print(json.dumps({"default": data.get("default"),
                      "active": active_profile(),
                      "profiles": [{k: p.get(k) for k in ("profile_id", "name", "kind", "member",
                                                         "authority", "passport_id")}
                                   for p in (data.get("profiles") or {}).values()]}, indent=1))
    return 0


def cmd_login(args):
    try:
        rec = login(_arg(args, "--profile"), ttl_hours=float(_arg(args, "--ttl-hours", 12)))
    except (KeyError, PermissionError) as e:
        print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
        return 1
    print(json.dumps({"ok": True, "profile": rec["profile"], "level": rec["level"],
                      "expires": rec["expires"]}, indent=1))
    return 0


def cmd_skip(args):
    rec = skip_login()
    print(json.dumps({"ok": True, "profile": rec["profile"], "level": rec["level"],
                      "expires": rec["expires"]}, indent=1))
    return 0


def cmd_logout(args):
    print(json.dumps(logout(), indent=1))
    return 0


def cmd_whoami(args):
    print(json.dumps(whoami(), indent=1))
    return 0


def cmd_link(args):
    try:
        rec = link(_arg(args, "--provider", "google"), subject_hash=_arg(args, "--subject-hash"),
                   handle=_arg(args, "--handle"), profile_id=_arg(args, "--profile"))
    except (KeyError, ValueError) as e:
        print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
        return 1
    print(json.dumps({"ok": True, **rec}, indent=1))
    return 0


def cmd_unlink(args):
    print(json.dumps(unlink(_arg(args, "--provider", "google"), _arg(args, "--profile")), indent=1))
    return 0


def cmd_federation(args):
    rows = []
    for pid, rec in profile_list().items():
        for f in rec.get("federation") or []:
            rows.append({"profile": pid, "provider": f.get("provider"),
                         "subject_hash": str(f.get("subject_hash"))[:16] + "...",
                         "linked": f.get("linked")})
    print(json.dumps(rows, indent=1))
    return 0


def cmd_bind(args):
    try:
        rec = bind_passport(_arg(args, "--profile"), _arg(args, "--passport-id"))
    except (KeyError, ValueError) as e:
        print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
        return 1
    print(json.dumps({"ok": True, **rec}, indent=1))
    return 0


def cmd_passkey_login(args):
    from_path = _arg(args, "--assertion")
    if not from_path:
        print("usage: identity.py passkey-login --assertion <file> [--rp-id id]")
        return 2
    try:
        rec = login_passkey(_arg(args, "--assertion"), rp_id=_arg(args, "--rp-id", "127.0.0.1"),
                            origin=_arg(args, "--origin"))
    except (KeyError, ValueError, PermissionError) as e:
        print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
        return 1
    print(json.dumps({"ok": True, "profile": rec["profile"], "level": rec["level"],
                      "expires": rec["expires"]}, indent=1))
    return 0


def cmd_verify(args):
    r = verify()
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def selftest():
    import shutil
    import tempfile

    global ID_DIR, PROFILES, SESSION, CHALLENGE, LOGGING, crypto

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    saved = (ID_DIR, PROFILES, SESSION, CHALLENGE, LOGGING, crypto.KEYS)
    tmp = Path(tempfile.mkdtemp(prefix="agi-identity-test-"))
    try:
        LOGGING = False
        ID_DIR = tmp / "state" / "identity"
        PROFILES = ID_DIR / "profiles.json"
        SESSION = ID_DIR / "session.json"
        CHALLENGE = ID_DIR / "challenge.json"
        crypto.KEYS = tmp / "state" / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)

        r = init()
        check("init creates a default profile", r["ok"] and r["default"] == "default")
        check("default profile has no authority",
              (profile_list()["default"].get("authority") == "none"))
        me = whoami()
        check("no session before login", me["authenticated"] is False)

        sess = skip_login()
        check("skip logs into the default profile without authority",
              sess["level"] == "default" and whoami()["authenticated"] is True)
        check("skip session verifies", verify()["ok"], str(verify().get("problems")))
        logout()
        check("logout clears the session", whoami()["authenticated"] is False)

        rec = login()
        check("native login proves the device key", rec["level"] == "device")
        check("session records the proof nonce hash",
              (rec.get("proof") or {}).get("key_id") == crypto.pinned_key_id())
        check("whoami reports device level", whoami()["level"] == "device")

        member = create("D", member="D")
        check("member profile created", member["kind"] == "member" and member["authority"].startswith("member"))
        rec2 = login(member["profile_id"])
        check("login to a member profile works", rec2["profile"] == member["profile_id"])
        check("identity verifies after login", verify()["ok"], str(verify().get("problems")))

        # federation: hashes only, never authority
        link_rec = link("google", handle="example@example.com", profile_id=member["profile_id"])
        check("federation link stores a hash, not the address",
              "@" not in link_rec["subject_hash"] and len(link_rec["subject_hash"]) == 64)
        try:
            link("google", subject_hash="alice@example.com", profile_id=member["profile_id"])
            raw_ok = True
        except ValueError:
            raw_ok = False
        check("raw email/handle refused", not raw_ok)
        check("federation list exposes only the prefix",
              str(cmd_federation([])) is not None)
        fed = federated_login(member["profile_id"])
        check("federated session is non-authoritative", fed["level"] == "federated"
              and "cannot unlock master" in (fed.get("authority") or ""))
        check("verify rejects an active federated session as authority leak",
              not verify()["ok"] and any("authority leak" in p for p in verify()["problems"]))

        # restore a native session for the remaining assertions
        login(member["profile_id"])
        check("identity verifies again", verify()["ok"], str(verify().get("problems")))
        unlink("google", member["profile_id"])
        check("unlink removes the federation link", len(profile_list()[member["profile_id"]]["federation"]) == 0)

        # missing device key blocks native login
        crypto.KEYS = tmp / "state" / "empty-keys"
        try:
            login(member["profile_id"])
            no_key = True
        except PermissionError:
            no_key = False
        check("native login needs a device key", not no_key)
    finally:
        (ID_DIR, PROFILES, SESSION, CHALLENGE, LOGGING, crypto.KEYS) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("identity selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"init": cmd_init, "create": cmd_create, "list": cmd_list, "login": cmd_login,
             "skip": cmd_skip, "logout": cmd_logout, "whoami": cmd_whoami, "link": cmd_link,
             "unlink": cmd_unlink, "federation": cmd_federation, "bind": cmd_bind,
             "passkey-login": cmd_passkey_login,
             "verify": cmd_verify,
             "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

#!/usr/bin/env python3
"""context.py - current-user binding for all AGI surfaces (S1 fix: AGI must refer to its CURRENT user).

Every user-facing surface resolves the person through this module instead of hard-coding D. Master seasons
may keep a master-flavoured tone, but the name/type/passport always come from the live identity + passport:
  identity profiles + session  ->  passport (member, bundle class)  ->  fallback "Guest".
"""
import json
import pathlib

AGI = pathlib.Path(__file__).resolve().parents[2]


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def identity(root=None):
    root = pathlib.Path(root) if root else AGI
    return _jload(root / "state" / "identity" / "profiles.json", {}) or {}, \
        _jload(root / "state" / "identity" / "session.json", {}) or {}


def passport(root=None):
    root = pathlib.Path(root) if root else AGI
    return _jload(root / "state" / "passport.json", {}) or {}


def current(root=None):
    """Resolve the current user: name, kind, passport id, master flag, authenticated flag."""
    root = pathlib.Path(root) if root else AGI
    prof, sess = identity(root)
    psp = passport(root)
    profiles = prof.get("profiles") or prof.get("items") or {}
    sid = sess.get("profile") or sess.get("profile_id") or sess.get("active_profile")
    entry = None
    if isinstance(profiles, dict):
        entry = profiles.get(sid) if sid else None
        if entry is None and prof.get("default"):
            entry = profiles.get(prof.get("default"))
    else:
        for p in profiles:
            if isinstance(p, dict) and (p.get("id") == sid or (not sid and p.get("active"))):
                entry = p
                break
    name = (entry or {}).get("name") or (entry or {}).get("member") or sess.get("member") or sess.get("name")
    kind = (entry or {}).get("kind")
    level = str(sess.get("level") or "").lower()
    authed = bool(sess.get("authenticated")) or level in ("member", "admin", "master", "authenticated")
    if not name:
        name = psp.get("member")
    passport_master = bool(psp.get("bundle_class") == "master") and bool(psp.get("member"))
    return {"name": str(name or "Guest"), "kind": kind, "passport_id": psp.get("passport_id"),
            "bundle_class": psp.get("bundle_class"), "passport_master": passport_master,
            "is_master": bool(passport_master and authed),
            "authenticated": authed, "gen_id": (psp.get("generation") or {}).get("gen_id")}


def display(root=None):
    u = current(root)
    return u["name"] if u["authenticated"] else "Guest"


def greeting(root=None):
    u = current(root)
    if not u["authenticated"]:
        return "Welcome"
    return "Welcome back, %s" % u["name"]


def persona(root=None):
    """Tone binding: master seasons may keep D-flavoured directness; every other user gets neutral tone."""
    u = current(root)
    return {"name": u["name"], "tone": "master" if u["is_master"] else "member",
            "is_master": u["is_master"], "authenticated": u["authenticated"]}


def assert_user_facing(text, root=None):
    """Non-master surfaces must not claim the operator is D. Returns (ok, reason)."""
    u = current(root)
    if not u["is_master"] and " D " in " %s " % text and "D " in text:
        return False, "non-master surface mentions D"
    return True, "ok"


if __name__ == "__main__":
    import sys
    print(json.dumps({"current": current(), "display": display(), "greeting": greeting(),
                      "persona": persona()}, indent=1))

#!/usr/bin/env python3
"""BIOS (S0) - runs BEFORE the model starts thinking. Resolves all machine paths ONCE from
state/ (SSOT), runs cheap capability checks, picks the profile, writes a live boot_card.json.
On ANY failure status=debug so the session drops into debugging mode instead of guessing.
Fast by design: no network calls unless --net. Prints ONE line the model can consume.
Portable: contains no hardcoded machine values (all read from state/).
Usage: bios.py [--json] [--net]
"""
import sys, os, json, time, socket
from pathlib import Path
import cardkit

ROOT  = Path(__file__).resolve().parents[2]   # <skill> (Core / memdir) - self-located
MEM   = ROOT / "memory"
STATE = ROOT / "state"
CARD  = STATE / "boot_card.json"

def load_json(p):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def host_application_identity(environ=None):
    """Host detection is owned by cardkit (single source) so every node agrees."""
    return cardkit.host_application_identity(environ)


def embedding_adoption(previous_card, ram, host_application, environ=None):
    env = os.environ if environ is None else environ
    backend = (env.get("AGI_EMBEDDING_BACKEND") or "internal").strip().lower()
    model_configured = bool(env.get("AGI_INTERNAL_EMBEDDING_MODEL", "").strip())
    previous_app = (previous_card or {}).get("host_application")
    previous_id = previous_app.get("id") if isinstance(previous_app, dict) else previous_app
    new_environment = bool((ram or {}).get("verified") and host_application
                           and previous_id and previous_id != host_application)
    needs_choice = backend == "internal" and not model_configured
    if needs_choice:
        status = "needs_user_choice"
        prompt = (
            "Internal embedding is the default, but no local model directory is configured. "
            "Would you like to set AGI_INTERNAL_EMBEDDING_MODEL manually? No model will be "
            "downloaded or guessed; indexing remains unavailable until configured."
        )
    elif backend == "internal":
        status = "ready"
        prompt = None
    else:
        status = "external_selected"
        prompt = None
    return {
        "preferred": "internal",
        "backend": backend,
        "model_configured": model_configured,
        "status": status,
        "needs_user_choice": needs_choice,
        "new_environment": new_environment,
        "suggestion": prompt,
    }

PROFILE_MAP = (("qwen", "qwen-local.md"), ("gpt", "gpt-class.md"),
               ("o1", "gpt-class.md"), ("o3", "gpt-class.md"), ("claude", "claude-class.md"))


def profile_selection(env, bootrec):
    """S5 (gen3.4/W5-A): evidence-based profile match; never silently default.

    Returns {"profile", "profile_status": matched|unprofiled, "model", "degraded"}.
    An unmatched model/host is reported unprofiled with the documented degraded mode.
    """
    env = env or {}
    bootrec = bootrec or {}
    candidates = []
    name = str((env.get("model") or {}).get("name") or "").strip()
    if name and name.lower() not in ("n/a", "unknown", "none"):
        candidates.append(name)
    host = bootrec.get("host") if isinstance(bootrec.get("host"), dict) else {}
    hn = str(host.get("session_model") or "").strip()
    if hn and hn not in candidates:
        candidates.append(hn)
    for candidate in candidates:
        low = candidate.lower()
        for key, profile in PROFILE_MAP:
            if key in low:
                return {"profile": profile, "profile_status": "matched",
                        "model": candidate, "degraded": []}
    return {"profile": "unprofiled", "profile_status": "unprofiled",
            "model": candidates[0] if candidates else "n/a",
            "degraded": ["no adapter profile for the running model - generic rules only",
                         "S5 fallback to qwen-local is retired (gen3.4 / W5-A)"]}


def main():
    t0 = time.time()
    phases = {}
    issues = []
    previous_card = load_json(CARD)
    facts = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    host_app = host_application_identity()
    facts["host_application"] = {"id": host_app, "source": "environment" if host_app else "unidentified"}
    try:
        facts["ram"] = cardkit.bootstrap_ram()
    except Exception as e:
        facts["ram"] = {"verified": False, "error": str(e)}
        issues.append(f"RAM bootstrap failed: {e}")
    facts["embedding_adoption"] = embedding_adoption(previous_card, facts.get("ram"), host_app)
    facts["loaded_components"] = ["BIOS state + env probe", "verified script registry",
                                  "library consumption ledger", "selected model/profile adapter",
                                  "season RAM bootstrap + resolver", "subsystem card producers (including maintenance)",
                                  "AGI system map assembler"]
    env  = load_json(STATE / "env_probe.json")   # machine facts SSOT (stable)
    boot = load_json(STATE / "boot.json")        # last boot record
    if not env:
        issues.append("state/env_probe.json missing - re-run env_probe.py --write")
    else:
        facts["studio_root"] = env.get("root")
        facts["python"] = env.get("venv_python") or sys.executable
        g = env.get("gate", {})
        facts["gate_side"] = g.get("side") if isinstance(g, dict) else (g if isinstance(g, str) else None)
        m = env.get("model")
        if isinstance(m, dict):
            facts["model"] = {k: m.get(k) for k in ("name", "family")}
    db = None
    sr = facts.get("studio_root")
    if sr:
        db = Path(sr) / "studio.db"
        if not db.exists():
            issues.append(f"studio.db not found at {db}")
    facts["db"] = str(db) if db else None
    _sel = profile_selection(env, boot)
    facts["profile"] = _sel["profile"]
    facts["profile_status"] = _sel["profile_status"]
    facts["model_name"] = _sel["model"]
    if _sel["degraded"]:
        facts["degraded_modes"] = list(_sel["degraded"])
    facts["fs_read"]  = os.access(str(STATE), os.R_OK)
    facts["fs_write"] = os.access(str(STATE), os.W_OK)
    if not facts["fs_read"]:  issues.append("state/ not readable")
    if not facts["fs_write"]: issues.append("state/ not writable")
    # W3: automated S3 capability probe (quick, boot-safe) -> state/capabilities.json
    phases["boot_ram"] = time.time() - t0
    try:
        import capability_probe
        _caps = capability_probe.probe()
        facts["capabilities"] = {
            "probed_at": _caps.get("probed_at"),
            "max_context": _caps.get("max_context"),
            "shell_dialect": (_caps.get("shell") or {}).get("bash_default_dialect"),
            "pool_up": (_caps.get("subagents") or {}).get("pool_up"),
            "network_ok": (_caps.get("network") or {}).get("ok"),
            "host_speed_factor": (_caps.get("host_speed") or {}).get("factor"),
            "host_speed_samples": (_caps.get("host_speed") or {}).get("samples"),
            "declared_gen_tok_s": (_caps.get("host_speed") or {}).get("declared_gen_tok_s"),
        }
    except Exception as _e:
        issues.append(f"capability probe failed: {_e}")
    phases["probe"] = time.time() - t0
    # W4: cold-boot acceptance gate - READY requires integrity evidence
    try:
        import boot_gate
        _gate = boot_gate.run_gate(ROOT)
        facts["integrity"] = {"ok": _gate.get("ok"),
                              "dur_ms": _gate.get("dur_ms"),
                              "checks": {k: bool(v.get("ok")) for k, v in (_gate.get("checks") or {}).items()}}
        if not _gate.get("ok"):
            _failed = [k for k, v in (_gate.get("checks") or {}).items() if not v.get("ok")]
            issues.append("boot acceptance gate failed: " + ", ".join(_failed))
    except Exception as _e:
        facts["integrity"] = {"ok": False, "error": str(_e)}
        issues.append(f"boot gate failed to run: {_e}")
    phases["gate"] = time.time() - t0
    # W5 phase-1 (L2 instruments): TIMR proxy + machine-readable evolution archive
    try:
        import mismatch_telemetry
        _tel = mismatch_telemetry.run(overrides={"profile": facts.get("profile"),
                                                "model": facts.get("model_name"),
                                                "host": host_app,
                                                "integrity_ok": (facts.get("integrity") or {}).get("ok")})
        facts["telemetry"] = {"timr_proxy": _tel["timr"].get("rate"),
                              "timr_window_boots": _tel["timr"].get("window_boots"),
                              "evolution_archive_ts": _tel["archive"].get("ts"),
                              "evolution_pair": {"core": _tel["archive"].get("core_version"),
                                                 "host": _tel["archive"].get("host"),
                                                 "profile": _tel["archive"].get("profile"),
                                                 "model": _tel["archive"].get("model")}}
    except Exception as _e:
        issues.append(f"mismatch telemetry failed: {_e}")
    phases["telemetry"] = time.time() - t0
    reg = load_json(MEM / "scripts" / "registry.json")
    if not reg:
        issues.append("scripts/registry.json missing - no verified scripts available")
    else:
        v = [n for n, s in reg.get("scripts", {}).items()
             if isinstance(s, dict) and str(s.get("status", "")).startswith("verified")]
        facts["verified_scripts"] = len(v)
        for need in ("check", "report"):
            if need not in v:
                issues.append(f"required verified script missing: {need}")
    # Library consumption ledger (dna.md §5b): files dropped in manually or by KEP are
    # candidates until consumed; flag unread ones every boot until their status advances.
    LIB = MEM / "library"
    LEDGER = STATE / "library_ledger.json"
    ledger = load_json(LEDGER) or {}
    lib_files = sorted(p.name for p in LIB.iterdir()
                       if p.is_file() and p.name.upper() != "MANIFEST.MD") if LIB.exists() else []
    changed = False
    for n in lib_files:
        if not isinstance(ledger.get(n), dict):
            ledger[n] = {"status": "unread", "first_seen": facts["ts"]}
            changed = True
    new_docs = [n for n in lib_files if ledger[n].get("status") == "unread"]
    facts["library_total"] = len(lib_files)
    facts["library_new"] = new_docs
    if changed:
        with open(LEDGER, "w", encoding="utf-8") as f:
            json.dump(ledger, f, indent=2)
    if "--net" in sys.argv:
        try:
            socket.create_connection(("api.deepseek.com", 443), timeout=5)
            facts["net"] = True
        except Exception:
            facts["net"] = False
            issues.append("network probe failed (deepseek:443)")
    status = "debug" if issues else "ready"
    card = {"status": status, "issues": issues}
    card.update(facts)
    STATE.mkdir(parents=True, exist_ok=True)
    with open(CARD, "w", encoding="utf-8") as f:
        json.dump(card, f, indent=2)
    # BIOS generates subsystem cards (including maintenance) before system-map assembly.
    # Refresh failures are surfaced as maintenance incidents by the caller (R5).
    try:
        import producers, sysmap  # sibling modules in this scripts/ dir
        producers.produce_all()
        sysmap.build()
    except Exception as _e:
        issues.append(f"system map generation failed: {_e}")
        status = "debug"
        card["status"] = status
        card["issues"] = issues
        with open(CARD, "w", encoding="utf-8") as f:
            json.dump(card, f, indent=2)
        sys.stderr.write(f"[maintenance] system map generation failed: {_e}\n")
    phases["cards"] = time.time() - t0
    # W3 boot telemetry: one JSON line per boot (last 200 kept) -> state/boot_runs.jsonl
    try:
        runs_path = STATE / "boot_runs.jsonl"
        prior = runs_path.read_text(encoding="utf-8").splitlines() if runs_path.exists() else []
        entry = {"ts": facts["ts"], "host": host_app,
                 "ram_source": (facts.get("ram") or {}).get("source"),
                 "status": status, "dur_ms": int((time.time() - t0) * 1000),
                 "phases_ms": {k: int(v * 1000) for k, v in phases.items()},
                 "verified_scripts": facts.get("verified_scripts"),
                 "issues": len(issues)}
        runs_path.write_text("\n".join((prior + [json.dumps(entry)])[-200:]) + "\n", encoding="utf-8")
        card["boot_runs"] = min(len(prior) + 1, 200)
        card["boot_dur_ms"] = entry["dur_ms"]
        card["boot_phases_ms"] = entry["phases_ms"]
        with open(CARD, "w", encoding="utf-8") as f:
            json.dump(card, f, indent=2)
    except Exception as _e:
        sys.stderr.write(f"[telemetry] boot run append failed: {_e}\n")
    if "--json" in sys.argv:
        print(json.dumps(card))
    else:
        line = (f"{status.upper()} profile={facts['profile']} gate={facts.get('gate_side') or '?'} "
                f"root={ROOT} state={STATE} db={facts.get('db')} scripts={facts.get('verified_scripts', 0)} "
                f"libnew={len(new_docs)}/{facts['library_total']} ts={facts['ts']}")
        if issues:
            line += " | ISSUES: " + "; ".join(issues)
        print(line)
    sys.exit(1 if status == "debug" else 0)

if __name__ == "__main__":
    main()

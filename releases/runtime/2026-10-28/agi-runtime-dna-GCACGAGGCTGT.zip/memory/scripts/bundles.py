#!/usr/bin/env python3
"""bundles.py - Trust Layer L2/L3 (P3): the bundle lattice and its policy engine.

A bundle is a signed manifest that says what an AGI installation *is*: which core artefacts it
runs (by hash), which generation, whose genome it carries (active / dormant / user overlay),
what it may do (capabilities) and which pills it accepts. Three classes exist:

  master   issued by the device/root key, active genome, can reproduce (next-generation seed),
           can issue official bundles
  official issued by the master issuer, D genome DORMANT (activates on D touch - P4), cannot
           reproduce or issue
  custom   user-built from a parent bundle (hash-pinned), user genome overlay, cannot reproduce,
           accepts D-genome pills and its own LOCAL user-genome pills

Policy is decided on the consumer side, deliberately: an untrusted bundle can always ignore a
rule it does not like, so the verifier must be the one that answers "may this happen?". Every
denial carries the rule that produced it, so a refusal is explainable instead of mysterious.

CLI
  bundles.py init --class master|official|custom --id <bundle id> [--parent <bundle id>] [--pretty]
  bundles.py init-all                 # master + official + custom (custom parents the master)
  bundles.py list
  bundles.py show <bundle id>
  bundles.py verify [<bundle id>]     # one bundle, or the installed/active one
  bundles.py policy --action reproduce|consume-pill|sign-bundle --bundle <id>
                     [--pill-genome D|user] [--target-class official|custom] [--pill-local]
  bundles.py activate <bundle id>
  bundles.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import hashlib
import json
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
BUNDLES = STATE / "bundles"
ACTIVE = BUNDLES / "active.json"
PASSPORT = STATE / "passport.json"

sys.path.insert(0, str(MEM / "scripts"))
import crypto  # noqa: E402
import trust_log  # noqa: E402

SCHEMA = "agi-bundle/1"

# class rules: the lattice itself. Anything not listed here is refused by policy.
CLASS_RULES = {
    "master": {
        "genome_mode": "active",
        "can_reproduce": True,
        "can_issue": ["bundle:official"],
        "accept_genomes": ["D"],
        "accept_local_user_pills": False,
        "requires_parent": False,
        "issuer_kind": "device",
    },
    "official": {
        "genome_mode": "dormant",
        "can_reproduce": False,
        "can_issue": [],
        "accept_genomes": ["D"],
        "accept_local_user_pills": False,
        "requires_parent": False,
        "issuer_kind": "master",
    },
    "custom": {
        "genome_mode": "user-overlay",
        "can_reproduce": False,
        "can_issue": [],
        "accept_genomes": ["D"],
        "accept_local_user_pills": True,
        "requires_parent": True,
        "issuer_kind": "device",
    },
}


# ---------------------------------------------------------------- io
def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _jdump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _jload(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def _sha256(path):
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    except OSError:
        return None


def _manifest_path(bundle_id):
    return BUNDLES / f"{bundle_id}.json"


def _sig_path(bundle_id):
    return BUNDLES / f"{bundle_id}.json.sig"



def public_view(manifest):
    """Member-neutral view of a bundle, safe to distribute.

    A bundle manifest minted on this install embeds the local member: passport_id, the genome root,
    member name and the device key id. None of that may appear in a distributed artefact - the
    official bundle is for every user, and a custom template must not leak the author's genome.
    This view keeps the policy surface (class, generation, core hashes, capabilities, pill policy)
    and strips the identity.
    """
    import copy
    import re

    m = copy.deepcopy(manifest)
    bid = str(m.get("bundle_id") or "bundle")
    # public ids must not carry the issuer's initial (e.g. "agi-official-d")
    if re.search(r"-d$", bid):
        m["bundle_id"] = bid[:-2]
    m["distribution"] = "public"
    m["issuer"] = {"kind": (m.get("issuer") or {}).get("kind"),
                   "device_alg": (m.get("issuer") or {}).get("device_alg"),
                   "note": "member-neutral public bundle"}
    # no identity, genome, credential or activation vocabulary in a public artefact
    for k in ("genome", "passport", "credential", "identity"):
        m.pop(k, None)
    caps = m.get("capabilities")
    if isinstance(caps, dict):
        caps["can_consume"] = ["pill"] if caps.get("can_consume") else []
        caps["can_issue"] = [] if not caps.get("can_issue") else ["pill"]
    pp = m.get("pill_policy")
    if isinstance(pp, dict):
        pp.pop("accept_genomes", None)
        pp["accept_local_member_pills"] = bool(pp.pop("accept_local_user_pills", False))
    parent = m.get("parent")
    if isinstance(parent, dict):
        m["parent"] = {"bundle_id": parent.get("bundle_id"), "class": parent.get("class"),
                       "note": "parent hash omitted in the public view (differs after neutralising)"}
    m["policy"] = {"identity": "member-neutral; activation is performed by the owner, verified by the runtime"}
    return m


# ---------------------------------------------------------------- build / mint
def core_fingerprint():
    man = _jload(AGI / "core_manifest.json") or {}
    name = man.get("bundle_name")
    return {
        "core_manifest_sha256": _sha256(AGI / "core_manifest.json"),
        "files": len(man.get("files") or []),
        "bundle": name,
        "bundle_sha256": _sha256(AGI / name) if name else None,
        "core_version": man.get("core_version"),
        "dna_version": man.get("dna_version"),
    }


def build_manifest(bundle_class, bundle_id, parent_id=None, passport=None):
    if bundle_class not in CLASS_RULES:
        raise ValueError(f"unknown bundle class {bundle_class!r} (master|official|custom)")
    rules = CLASS_RULES[bundle_class]
    key = _jload(STATE / "keys" / "device.json") or {}
    if not key:
        raise FileNotFoundError("no device key: run crypto.py keygen")
    passport = passport if passport is not None else (_jload(PASSPORT) or {})
    if not passport:
        raise FileNotFoundError("no passport: run passport.py init")
    core = core_fingerprint()
    parent = None
    if rules["requires_parent"]:
        if not parent_id:
            raise ValueError("a custom bundle requires --parent <bundle id>")
        pman = _jload(_manifest_path(parent_id))
        if not pman:
            raise FileNotFoundError(f"parent bundle not found: {parent_id}")
        parent = {"bundle_id": parent_id, "bundle_sha256": _sha256(_manifest_path(parent_id)),
                  "class": pman.get("class")}
    elif parent_id:
        parent = {"bundle_id": parent_id, "bundle_sha256": _sha256(_manifest_path(parent_id))}
    issuer_kind = rules["issuer_kind"]
    return {
        "schema": SCHEMA,
        "bundle_id": bundle_id,
        "class": bundle_class,
        "generation": {"gen": "gen3.5", "core_version": core["core_version"],
                       "dna_version": core["dna_version"]},
        "core": core,
        "genome": {"mode": rules["genome_mode"], "root": passport.get("user_genome_root"),
                   "epoch": passport.get("genome_epoch"), "member": passport.get("member")},
        "passport": {"passport_id": passport.get("passport_id"),
                     "bundle_class": passport.get("bundle_class")},
        "capabilities": {
            "can_reproduce": rules["can_reproduce"],
            "can_issue": list(rules["can_issue"]),
            "can_consume": ["pill:D"] + (["pill:local"] if rules["accept_local_user_pills"] else []),
        },
        "pill_policy": {"accept_genomes": list(rules["accept_genomes"]),
                        "accept_local_user_pills": rules["accept_local_user_pills"]},
        "parent": parent,
        "issuer": {"kind": issuer_kind, "key_id": key.get("key_id"), "device_alg": key.get("alg")},
        "issued": _now(),
    }


def mint(bundle_class, bundle_id, parent_id=None, passport=None, log=True):
    manifest = build_manifest(bundle_class, bundle_id, parent_id=parent_id, passport=passport)
    path = _manifest_path(bundle_id)
    _jdump(path, manifest)
    sig_path, env = crypto.sign_file(path)
    if log:
        ev = trust_log.append("bundle-minted", {
            "bundle_id": bundle_id, "class": bundle_class,
            "core_manifest_sha256": manifest["core"]["core_manifest_sha256"],
            "genome_mode": manifest["genome"]["mode"], "key_id": env["key_id"],
            "parent": (manifest.get("parent") or {}).get("bundle_id"),
        })
        idx = ev["index"]
    else:
        idx = None
    return manifest, {"manifest": str(path), "sig": str(sig_path), "log_index": idx}


def mint_all(log=True):
    """Mint the three-member lattice around the installed core (idempotent per bundle id)."""
    out = {}
    passport = _jload(PASSPORT) or {}
    for key, cls, bid, parent in (("master", "master", "agi-master-d", None),
                                  ("official", "official", "agi-official-d", None),
                                  ("custom", "custom", "agi-custom-d", "agi-master-d")):
        man, where = mint(cls, bid, parent_id=parent, passport=passport, log=log)
        out[key] = {"manifest": man, "manifest_path": where["manifest"],
                    "sig": where["sig"], "log_index": where["log_index"]}
    return out


def set_active(bundle_id):
    p = _manifest_path(bundle_id)
    if not p.exists():
        raise FileNotFoundError(f"no bundle {bundle_id}")
    _jdump(ACTIVE, {"active": bundle_id, "activated": _now()})
    return _jload(ACTIVE)


# ---------------------------------------------------------------- verification
def list_bundles():
    if not BUNDLES.exists():
        return []
    return sorted(p.stem.replace(".json", "") for p in BUNDLES.glob("*.json")
                  if not p.name.endswith(".sig") and p.name != "active.json")


def verify_bundle(bundle_id=None, deep=True):
    """Verify one bundle (or the active one): signature, class rules, hashes, parent chain."""
    problems = []
    active = (_jload(ACTIVE) or {}).get("active")
    bundle_id = bundle_id or active
    report = {"bundle_id": bundle_id, "problems": problems}
    if not bundle_id:
        report["ok"] = False
        problems.append("no active bundle (bundles.py init-all / activate)")
        return report
    path, sig = _manifest_path(bundle_id), _sig_path(bundle_id)
    man = _jload(path)
    if not man:
        report["ok"] = False
        problems.append(f"bundle manifest missing: {path}")
        return report
    report.update({"class": man.get("class"), "genome_mode": (man.get("genome") or {}).get("mode"),
                   "can_reproduce": (man.get("capabilities") or {}).get("can_reproduce")})
    pinned = (_jload(STATE / "keys" / "device.json") or {}).get("key_id")
    vsig = crypto.verify_file(path, sig_path=sig, expected_key_id=pinned)
    report["signature"] = {"ok": vsig.get("ok"), "reason": vsig.get("reason")}
    if not vsig.get("ok"):
        problems.append("bundle signature: " + str(vsig.get("reason")))

    rules = CLASS_RULES.get(man.get("class"))
    if not rules:
        problems.append(f"unknown bundle class: {man.get('class')}")
    else:
        # the declared manifest must match its class rules, or it is an impostor
        if bool((man.get("capabilities") or {}).get("can_reproduce")) != rules["can_reproduce"]:
            problems.append(f"class rule violated: can_reproduce must be {rules['can_reproduce']} for {man.get('class')}")
        if (man.get("genome") or {}).get("mode") != rules["genome_mode"]:
            problems.append(f"class rule violated: genome mode must be {rules['genome_mode']}")
        if rules["requires_parent"] and not (man.get("parent") or {}).get("bundle_id"):
            problems.append("class rule violated: a custom bundle requires a parent bundle")
        if rules["requires_parent"]:
            parent = (man.get("parent") or {}).get("bundle_id")
            psig = (man.get("parent") or {}).get("bundle_sha256")
            if parent and _sha256(_manifest_path(parent)) != psig:
                problems.append(f"parent bundle hash mismatch or missing: {parent}")
        declared = set((man.get("pill_policy") or {}).get("accept_genomes") or [])
        if declared != set(rules["accept_genomes"]):
            problems.append("class rule violated: pill genome policy does not match the class")

    if deep:
        core = man.get("core") or {}
        if core.get("core_manifest_sha256") != _sha256(AGI / "core_manifest.json"):
            problems.append("core manifest hash differs from the installed core")
        if core.get("bundle") and core.get("bundle_sha256") != _sha256(AGI / core["bundle"]):
            problems.append("core bundle hash differs from the installed archive")
        psp = _jload(PASSPORT) or {}
        if (man.get("genome") or {}).get("root") != psp.get("user_genome_root"):
            problems.append("bundle genome root does not match the passport genome root")
        if (man.get("issuer") or {}).get("key_id") != pinned:
            problems.append("bundle issuer key is not the installed device key")
    report["ok"] = not problems
    return report


# ---------------------------------------------------------------- policy
def _policy(action, bundle_id=None, pill_genome=None, target_class=None, pill_local=False):
    active = (_jload(ACTIVE) or {}).get("active")
    bundle_id = bundle_id or active
    man = _jload(_manifest_path(bundle_id)) if bundle_id else None
    if not man:
        return {"allow": False, "rule": "bundle-present", "reason": f"no bundle manifest for {bundle_id!r}"}
    rules = CLASS_RULES.get(man.get("class"))
    if not rules:
        return {"allow": False, "rule": "known-class", "reason": f"unknown class {man.get('class')!r}"}
    caps = man.get("capabilities") or {}
    passport = _jload(PASSPORT) or {}

    if action == "reproduce":
        if man.get("class") != "master":
            return {"allow": False, "rule": "master-only-reproduce",
                    "reason": f"class {man.get('class')} cannot produce a next-generation seed"}
        if not caps.get("can_reproduce"):
            return {"allow": False, "rule": "manifest-capability",
                    "reason": "the bundle manifest does not grant can_reproduce"}
        if not (passport.get("capabilities") or {}).get("can_reproduce"):
            return {"allow": False, "rule": "passport-capability",
                    "reason": "the passport does not grant can_reproduce"}
        return {"allow": True, "rule": "master-can-reproduce",
                "reason": "master bundle + passport capability + verified signature chain"}

    if action == "consume-pill":
        genome = pill_genome or "D"
        if genome == "D":
            return {"allow": True, "rule": "d-genome-pill",
                    "reason": "D-genome pills are consumable by every bundle class"}
        if genome == "user":
            if man.get("class") != "custom" or not (man.get("pill_policy") or {}).get("accept_local_user_pills"):
                return {"allow": False, "rule": "user-pill-custom-only",
                        "reason": "user-genome pills are only consumable by the custom bundle that minted them"}
            if not pill_local:
                return {"allow": False, "rule": "user-pill-local-only",
                        "reason": "user-genome pills must be marked local (never shared)"}
            return {"allow": True, "rule": "custom-local-pill",
                    "reason": "custom bundle consuming its own local user-genome pill"}
        return {"allow": False, "rule": "known-genome", "reason": f"unknown pill genome {genome!r}"}

    if action == "d-genome":
        # P4: using the D genome requires a live D-touch activation (U1 or better).
        try:
            sys.path.insert(0, str(MEM / "scripts"))
            import activation
            level = activation.effective_level()
        except Exception as exc:  # no root/attestation module or unreadable state
            return {"allow": False, "rule": "d-touch-required",
                    "reason": f"activation layer unavailable: {type(exc).__name__}"}
        if level.get("level") in ("U1", "U2", "U3"):
            return {"allow": True, "rule": "d-genome-activated",
                    "reason": f"D genome is active at {level['level']}: {level['reason']}"}
        return {"allow": False, "rule": "d-genome-dormant",
                "reason": f"the D genome is dormant ({level.get('level')}): {level.get('reason')}"}

    if action == "sign-bundle":
        wanted = target_class or "official"
        token = "bundle:" + wanted
        if token in (caps.get("can_issue") or []):
            return {"allow": True, "rule": "issuer-capability",
                    "reason": f"{man.get('class')} may issue {wanted} bundles"}
        if man.get("class") == "custom" and wanted == "custom":
            return {"allow": True, "rule": "custom-self-sign",
                    "reason": "a custom bundle may sign only itself"}
        return {"allow": False, "rule": "issuer-capability",
                "reason": f"{man.get('class')} may not issue {wanted} bundles"}

    return {"allow": False, "rule": "known-action", "reason": f"unknown action {action!r}"}


# ---------------------------------------------------------------- CLI
def _arg(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def cmd_init(args):
    bundle_class = _arg(args, "--class")
    bundle_id = _arg(args, "--id")
    if not bundle_class or not bundle_id:
        print("usage: bundles.py init --class master|official|custom --id <bundle id> [--parent <id>]")
        return 2
    man, where = mint(bundle_class, bundle_id, parent_id=_arg(args, "--parent"))
    print(json.dumps({"ok": True, "bundle_id": man["bundle_id"], "class": man["class"],
                      "genome_mode": man["genome"]["mode"],
                      "can_reproduce": man["capabilities"]["can_reproduce"],
                      "log_index": where["log_index"]}, indent=1))
    return 0


def cmd_init_all(args):
    out = mint_all()
    print(json.dumps({k: {"class": v["manifest"]["class"],
                          "genome_mode": v["manifest"]["genome"]["mode"],
                          "can_reproduce": v["manifest"]["capabilities"]["can_reproduce"],
                          "log_index": v["log_index"]} for k, v in out.items()}, indent=1))
    return 0


def cmd_list(args):
    active = (_jload(ACTIVE) or {}).get("active")
    rows = []
    for bid in list_bundles():
        man = _jload(_manifest_path(bid)) or {}
        rows.append({"bundle_id": bid, "class": man.get("class"),
                     "genome_mode": (man.get("genome") or {}).get("mode"),
                     "can_reproduce": (man.get("capabilities") or {}).get("can_reproduce"),
                     "active": bid == active})
    print(json.dumps(rows, indent=1))
    return 0


def cmd_show(args):
    if not args:
        print("usage: bundles.py show <bundle id>")
        return 2
    man = _jload(_manifest_path(args[0]))
    if not man:
        print(f"no bundle {args[0]!r}")
        return 1
    print(json.dumps(man, indent=1))
    return 0


def cmd_verify(args):
    r = verify_bundle(args[0] if args else None)
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_policy(args):
    print(json.dumps(_policy(_arg(args, "--action"), bundle_id=_arg(args, "--bundle"),
                             pill_genome=_arg(args, "--pill-genome"),
                             target_class=_arg(args, "--target-class"),
                             pill_local="--pill-local" in args), indent=1))
    return 0


def cmd_activate(args):
    if not args:
        print("usage: bundles.py activate <bundle id>")
        return 2
    print(json.dumps(set_active(args[0]), indent=1))
    return 0


def selftest():
    import shutil
    import tempfile

    global BUNDLES, ACTIVE, PASSPORT, AGI, STATE

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    saved = (BUNDLES, ACTIVE, PASSPORT, AGI, STATE, crypto.KEYS)
    tmp = Path(tempfile.mkdtemp(prefix="agi-bundles-test-"))
    logging = True
    try:
        import passport as passport_mod
        AGI = tmp
        STATE = tmp / "state"
        BUNDLES = STATE / "bundles"
        ACTIVE = BUNDLES / "active.json"
        PASSPORT = STATE / "passport.json"
        crypto.KEYS = STATE / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        # minimal "core" for the fingerprint
        (tmp / "core_manifest.json").write_text(json.dumps({"files": [], "core_version": "3.2",
                                                           "dna_version": 3, "bundle_name": "x.tar.gz"}),
                                               encoding="utf-8")
        passport_mod.STATE = STATE
        passport_mod.GENOME = STATE / "genome"
        passport_mod.TREE = passport_mod.GENOME / "tree.json"
        passport_mod.TRANSITIONS = passport_mod.GENOME / "transitions.jsonl"
        passport_mod.PASSPORT = PASSPORT
        passport_mod.PASSPORT_SIG = STATE / "passport.json.sig"
        passport_mod.LOGGING = False
        crypto_key = crypto.KEYS
        passport_mod.crypto.KEYS = crypto_key
        passport_mod.init_passport(member="D", bundle_class="master", force=True)
        psp = _jload(PASSPORT)

        m, _ = mint("master", "m1", passport=psp, log=False)
        o, _ = mint("official", "o1", passport=psp, log=False)
        c, _ = mint("custom", "c1", parent_id="m1", passport=psp, log=False)
        set_active("m1")
        check("three classes minted with the right genome modes",
              [x["genome"]["mode"] for x in (m, o, c)] == ["active", "dormant", "user-overlay"],
              str([x["genome"]["mode"] for x in (m, o, c)]))
        check("only master declares reproduction",
              [x["capabilities"]["can_reproduce"] for x in (m, o, c)] == [True, False, False])
        check("custom bundle is parent-hash bound",
              c["parent"]["bundle_id"] == "m1" and len(c["parent"]["bundle_sha256"]) == 64)
        r = verify_bundle("m1", deep=False)
        check("master verifies (signature + class rules)", r["ok"], str(r.get("problems")))

        # policy
        check("reproduce allowed on master, denied on official/custom",
              _policy("reproduce", "m1")["allow"] and not _policy("reproduce", "o1")["allow"]
              and not _policy("reproduce", "c1")["allow"])
        check("D pills consumable by all classes",
              all(_policy("consume-pill", b, pill_genome="D")["allow"] for b in ("m1", "o1", "c1")))
        check("user pills only by custom + local",
              _policy("consume-pill", "c1", pill_genome="user", pill_local=True)["allow"]
              and not _policy("consume-pill", "c1", pill_genome="user", pill_local=False)["allow"]
              and not _policy("consume-pill", "m1", pill_genome="user", pill_local=True)["allow"])
        check("only master may issue official bundles",
              _policy("sign-bundle", "m1", target_class="official")["allow"]
              and not _policy("sign-bundle", "o1", target_class="official")["allow"])

        # impostor: an official manifest that claims reproduction
        fake = json.loads(json.dumps(m))
        fake["bundle_id"] = "impostor"
        fake["class"] = "official"
        fake["capabilities"]["can_reproduce"] = True
        _jdump(_manifest_path("impostor"), fake)
        crypto.sign_file(_manifest_path("impostor"))
        r2 = verify_bundle("impostor", deep=False)
        check("class-rule violation detected (official claiming reproduction)",
              not r2["ok"] and any("can_reproduce" in x for x in r2["problems"]), str(r2.get("problems")))

        # tamper: a signed manifest whose core hash no longer matches the installed core
        good = json.loads(json.dumps(m))
        good["bundle_id"] = "drift"
        _jdump(_manifest_path("drift"), good)
        crypto.sign_file(_manifest_path("drift"))
        check("clean bundle verifies deeply", verify_bundle("drift")["ok"])
        (tmp / "core_manifest.json").write_text(json.dumps({"files": [1], "core_version": "3.2"}),
                                               encoding="utf-8")
        r3 = verify_bundle("drift")
        check("core drift detected", not r3["ok"] and any("core manifest hash" in x for x in r3["problems"]),
              str(r3.get("problems")))
    finally:
        (BUNDLES, ACTIVE, PASSPORT, AGI, STATE, crypto.KEYS) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("bundles selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"init": cmd_init, "init-all": cmd_init_all, "list": cmd_list, "show": cmd_show,
             "verify": cmd_verify, "policy": cmd_policy, "activate": cmd_activate,
             "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

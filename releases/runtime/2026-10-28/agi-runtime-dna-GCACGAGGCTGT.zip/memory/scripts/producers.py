#!/usr/bin/env python3
"""producers - one function per subsystem, each returns a CardSpec (plain dict).

Modular rule (the generative contract):
  * Every producer reads ONLY cardkit + state/ - NEVER another producer.
  * Each is independent: add a new subsystem = add one function here (+ register it in
    PRODUCERS). The dashboard (sysmap) picks it up automatically; no assembler change.
  * Missing/broken sources degrade to an honest 'no data' card, never a crash (R1/R5).

Run directly to refresh the whole store:  python producers.py
"""
import json
from pathlib import Path
import cardkit

# SSOT state root: <skill>/state (== agi/state), per BOOT-CORE / bios / env_probe.
# scripts->memory->skill, so three parents up. Never memory/state.
ROOT  = Path(__file__).resolve().parent.parent.parent
STATE = ROOT / "state"
MEM   = ROOT / "memory"

def _load(p):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

# --- S0 boot -----------------------------------------------------------------
def boot():
    d = _load(STATE / "boot_card.json")
    if not d:
        return cardkit.producer_error_card("boot", "state/boot_card.json missing")
    dot = {"ready": "ok", "debug": "warn"}.get(d.get("status"), "warn")
    ram = d.get("ram") or {}
    body = cardkit.rows(
        ("profile", d.get("profile")),
        ("gate", d.get("gate_side")),
        ("RAM cache", ram.get("cache")),
        ("RAM adapter", ram.get("source")),
        ("RAM verified", ram.get("verified")),
        ("host application", (d.get("host_application") or {}).get("id") or "unidentified"),
        ("embedding preference", (d.get("embedding_adoption") or {}).get("preferred")),
        ("embedding backend", (d.get("embedding_adoption") or {}).get("backend")),
        ("embedding model configured", (d.get("embedding_adoption") or {}).get("model_configured")),
        ("embedding adoption", (d.get("embedding_adoption") or {}).get("status")),
        ("studio root", d.get("studio_root")),
        ("db", d.get("db")),
        ("verified scripts", d.get("verified_scripts")),
        ("library new/total", f"{len(d.get('library_new', []))}/{d.get('library_total')}"),
    ) + cardkit.rows(("BIOS-loaded components", ", ".join(d.get("loaded_components", [])))) \
      + cardkit.ul(([((d.get("embedding_adoption") or {}).get("suggestion"))]
                    if (d.get("embedding_adoption") or {}).get("suggestion") else []) + d.get("issues", []))
    return {"id": "boot", "title": "Boot (S0)", "dot": dot,
            "big": str(d.get("status", "?")).upper(), "body": body, "order": 10}

# --- script registry --------------------------------------------------------
def registry():
    r = _load(MEM / "scripts" / "registry.json") or {}
    s = r.get("scripts", {})
    def cnt(pref):
        return sum(1 for v in s.values() if str(v.get("status", "")).startswith(pref))
    body = (cardkit.rows(("verified", cnt("verified")),
                         ("candidate", cnt("candidate")),
                         ("quarantined", cnt("quarantined")))
            + cardkit.ul([f"{k} - {v.get('status', '?')}" for k, v in sorted(s.items())]))
    return {"id": "registry", "title": "Script Registry", "dot": "ok" if cnt("verified") else "warn",
            "big": str(cnt("verified")), "body": body, "order": 20}

# --- foreign agents (free-LLM providers) -------------------------------------
def agents():
    d = _load(STATE / "agents_status.json")
    if not d:
        return cardkit.producer_error_card("agents", "state/agents_status.json missing")
    provs = d.get("providers", {})
    ok = sum(1 for v in provs.values() if isinstance(v, dict) and v.get("ok"))
    body = (cardkit.rows(("foreign origin", "web / deepseek etc."),
                         ("providers up", f"{ok}/{len(provs)}"))
            + cardkit.ul([f"{k}: {'up' if isinstance(v, dict) and v.get('ok') else 'down'}"
                          for k, v in sorted(provs.items())]))
    return {"id": "agents", "title": "Foreign Agents", "dot": "ok" if ok else "warn",
            "big": f"{ok}/{len(provs)}", "body": body, "order": 30}

# --- knowledge library (consumption ledger) ----------------------------------
def library():
    led = _load(STATE / "library_ledger.json") or {}
    items = {n: v for n, v in led.items() if isinstance(v, dict)}
    unread   = sorted(n for n, v in items.items() if v.get("status") == "unread")
    consumed = sum(1 for v in items.values() if v.get("status") in ("consumed", "verified"))
    body = (cardkit.rows(("total", len(items)),
                         ("new / unread", len(unread)),
                         ("consumed", consumed))
            + cardkit.ul(unread[:12]))
    return {"id": "library", "title": "Knowledge Library", "dot": "warn" if unread else "ok",
            "big": str(len(items)), "body": body, "order": 50}

# --- maintenance state (generated with every system-map refresh) --------------
def maintenance():
    d = _load(STATE / "maintenance.json") or {}
    open_items = d.get("open", [])
    parked = d.get("parked_tasks", [])
    fixed_items = d.get("fixed", [])
    active = len(open_items) + len(parked)
    body = (cardkit.rows(("mode", (_load(STATE / "season_tasks.json") or {}).get("mode", "normal")),
                         ("open items", len(open_items)), ("parked maintenance tasks", len(parked)),
                         ("recently fixed", len(fixed_items)))
            + cardkit.ul([str(item) for item in open_items[:12] + parked[:12]]))
    return {"id": "maintenance", "title": "Maintenance", "dot": "warn" if active else "ok",
            "big": "ACTIVE" if active else "CLEAR", "body": body, "order": 55}

# --- model / environment (universal adapter: loaded model wired to all nodes) --
# gen3.4/W5-A (2026-10-25): BIOS is the single owner of S5 profile selection and wires the
# result into state/boot_card.json (profile, profile_status, model_name, degraded_modes).
# This consumer READS that wiring - it must never re-derive a profile from env_probe or fall
# back to the retired qwen-local default (env_probe.model is 'n/a' under hosted models).
MODELS_DIR = STATE.parent / "models"

def _profile_bullets(profile):
    try:
        return [ln[2:].strip() for ln in (MODELS_DIR / profile).read_text(encoding="utf-8").splitlines()
                if ln.startswith("- ")]
    except Exception:
        return []

def model():
    bc = _load(STATE / "boot_card.json")
    if not bc:
        return cardkit.producer_error_card("model", "state/boot_card.json missing")
    e = _load(STATE / "env_probe.json") or {}
    m = e.get("model") or {}
    g = e.get("gate") or {}
    side = g.get("side") if isinstance(g, dict) else (g if isinstance(g, str) else None)
    profile = bc.get("profile")
    pstat = bc.get("profile_status") or ("matched" if profile and profile != "unprofiled" else "unprofiled")
    matched = bool(pstat == "matched" and profile)
    name = bc.get("model_name") or m.get("name")
    body = cardkit.rows(("name", name),
                        ("profile status", pstat),
                        ("profile (S5)", profile if matched else "%s (no adapter profile)" % (profile or "unavailable")),
                        ("context len", m.get("context_length")),
                        ("venv python", e.get("venv_python")),
                        ("gate side", side))
    if matched:
        bullets = _profile_bullets(profile)
        if bullets:
            body += cardkit.ul(bullets)
    degraded = [str(x) for x in (bc.get("degraded_modes") or [])]
    if degraded:
        body += cardkit.ul(degraded)
    return {"id": "model", "title": "Model / Env (wired)", "dot": "ok" if matched else "warn",
            "big": str(name or "?"), "body": body, "order": 60}

# --- trust layer (PQC keys + transparency log) -------------------------------
def trust():
    """Trust Layer v0 (P0+P1): device key, Merkle log, signed heads, pill envelopes.

    Reads only state/ (never imports crypto/trust_log): this card reports what is on
    disk; validity is enforced by boot_gate at every boot.
    """
    key = _load(STATE / "keys" / "device.json") or {}
    log = STATE / "trust_log"
    heads_dir = log / "heads"
    heads = sorted(heads_dir.glob("*.json")) if heads_dir.exists() else []
    events_path = log / "events.jsonl"
    events = 0
    if events_path.exists():
        events = sum(1 for line in events_path.read_text(encoding="utf-8").splitlines() if line.strip())
    head = _load(heads[-1]) if heads else None
    pills = sorted((STATE / "pills").glob("*.envelope.json")) if (STATE / "pills").exists() else []
    monitor = _load(log / "monitor.json") or {}
    signed_heads = sum(1 for h in heads if (_load(h) or {}).get("signature"))
    dot = "ok" if (key.get("key_id") and signed_heads and head) else "warn"
    root = (head or {}).get("root_hex") or "-"
    body = cardkit.rows(
        ("device key", key.get("alg") or "none (crypto.py keygen)"),
        ("key id", key.get("key_id") or "-"),
        ("key sealed", key.get("sealed") or "-"),
        ("log events", events),
        ("signed heads", f"{signed_heads}/{len(heads)}"),
        ("head tree size", (head or {}).get("tree_size")),
        ("head root", (root[:24] + "...") if len(root) > 24 else root),
        ("head signed", (head or {}).get("ts")),
        ("pill envelopes", len(pills)),
        ("rollback monitor", monitor.get("observed_size")),
        ("boot gate checks", "manifest / bundle / selftest / conformance / signature / trust_log"),
    ) + cardkit.ul([
        "signatures: ML-DSA-65 (FIPS 204) via cryptography/OpenSSL, algorithm agility field sig_alg",
        "log: RFC 9162 Merkle tree; inclusion + consistency proofs; history rewrite refused at the same size",
        "policy: a boot fails only on contradiction - a missing key or unsigned manifest is reported, never fatal",
        "roadmap: passport (P2), bundle lattice (P3), D-touch activation (P4), *.public relay (P5); no blockchain",
    ])
    return {"id": "trust", "title": "Trust Layer (PQC)", "dot": dot,
            "big": (key.get("alg") or "PQC") if key else "UNKEYED", "body": body, "order": 25}


# --- passport (L1: member credential rooted in the user genome) --------------
def passport():
    """P2: the passport credential + the user genome tree, read from state/ only."""
    p = _load(STATE / "passport.json") or {}
    tree = _load(STATE / "genome" / "tree.json") or {}
    trans = STATE / "genome" / "transitions.jsonl"
    n_trans = sum(1 for line in trans.read_text(encoding="utf-8").splitlines() if line.strip()) if trans.exists() else 0
    sig = STATE / "passport.json.sig"
    if not p:
        return cardkit.producer_error_card("passport", "no passport yet (passport.py init)")
    root = str(p.get("user_genome_root") or "-")
    caps = p.get("capabilities") or {}
    dot = "ok" if (sig.exists() and p.get("genome_epoch") == tree.get("epoch")) else "warn"
    body = cardkit.rows(
        ("member", p.get("member")),
        ("passport id", str(p.get("passport_id"))[:8] + "..."),
        ("bundle class", p.get("bundle_class")),
        ("generation", (p.get("generation") or {}).get("gen")),
        ("genome epoch", p.get("genome_epoch")),
        ("genome root", (root[:24] + "...") if len(root) > 24 else root),
        ("genome entries", tree.get("leaf_count")),
        ("signed transitions", n_trans),
        ("activation", (p.get("activation") or {}).get("state")),
        ("device key", (p.get("device") or {}).get("key_id")),
        ("can reproduce", caps.get("can_reproduce")),
        ("can consume", ", ".join(caps.get("can_consume") or []) or "-"),
    ) + cardkit.ul([
        "genome = personal invariants / preferences / memory roots (Merkle tree); only the ROOT is in the passport",
        "every genome change is a signed transition (epoch + prev_root chain); the passport re-anchors atomically",
        "activation is provisional: the D-touch attestation + offline root ceremony arrive in P4",
        "boot gate check #7 verifies signature + genome root + epoch on every boot",
    ])
    return {"id": "passport", "title": "Passport / Genome (L1)", "dot": dot,
            "big": str(p.get("bundle_class") or "?").upper(), "body": body, "order": 26}


# --- bundle lattice (L2/L3: master / official / custom + policy) -------------
def bundles():
    """P3: the bundle lattice, read from state/bundles only."""
    bdir = STATE / "bundles"
    active = (_load(bdir / "active.json") or {}).get("active")
    files = sorted(p for p in bdir.glob("*.json") if p.name != "active.json") if bdir.exists() else []
    if not files:
        return cardkit.producer_error_card("bundles", "no bundle manifests (bundles.py init-all)")
    man = _load(bdir / f"{active}.json") if active else {}
    rows = [("active bundle", active), ("class", man.get("class")),
            ("genome mode", (man.get("genome") or {}).get("mode")),
            ("core version", (man.get("generation") or {}).get("core_version")),
            ("core manifest", str((man.get("core") or {}).get("core_manifest_sha256"))[:16] + "..."),
            ("can reproduce", (man.get("capabilities") or {}).get("can_reproduce")),
            ("can issue", ", ".join((man.get("capabilities") or {}).get("can_issue") or []) or "-"),
            ("pill genomes", ", ".join((man.get("pill_policy") or {}).get("accept_genomes") or []) or "-"),
            ("issuer", (man.get("issuer") or {}).get("kind")),
            ("manifests", len(files))]
    lattice = []
    for p in files:
        m = _load(p) or {}
        lattice.append(f"{p.stem.split('.')[0]}: {m.get('class')} / {(m.get('genome') or {}).get('mode')}"
                       f" / reproduce={((m.get('capabilities') or {}).get('can_reproduce'))}"
                       + (" (active)" if p.stem.split('.')[0] == active else ""))
    body = cardkit.rows(*rows) + cardkit.ul([
        "master: active genome, can reproduce (next-gen seed), may issue official bundles",
        "official: D genome DORMANT until the D touch (P4), no reproduction, no issuing",
        "custom: user-overlay genome, parent-hash bound, consumes D pills + its own local pills",
        "policy is decided by the consumer: every denial names the rule that produced it",
    ] + lattice)
    return {"id": "bundles", "title": "Bundle Lattice (L2/L3)", "dot": "ok" if man else "warn",
            "big": str(man.get("class") or "?").upper(), "body": body, "order": 27}


# # --- activation (L1.5: the D touch, trust levels U0-U3) ----------------------
def activation():
    """P4: root ceremony + attestations + presence, read from state/ only."""
    rec = _load(STATE / "keys" / "root.json") or {}
    act = STATE / "activation"
    atts = sorted((act / "attestations").glob("*.json")) if (act / "attestations").exists() else []
    hb = _load(act / "heartbeat.json") or {}
    revs = act / "revocations.jsonl"
    n_rev = sum(1 for line in revs.read_text(encoding="utf-8").splitlines() if line.strip()) if revs.exists() else 0
    latest = _load(atts[-1]) if atts else {}
    level = "U2" if hb else ("U1" if atts else "U0")
    body = cardkit.rows(
        ("root key", rec.get("alg") if rec else "none (root.py ceremony init)"),
        ("root key id", rec.get("root_key_id")),
        ("threshold", ("%s-of-%s" % (rec["threshold"]["k"], rec["threshold"]["n"])) if rec.get("threshold") else None),
        ("shards", len(rec.get("shards") or [])),
        ("attestations", len(atts)),
        ("latest attestation", latest.get("attestation_id")),
        ("level (manifest view)", level),
        ("expires", latest.get("not_after")),
        ("revocations", n_rev),
        ("heartbeat", hb.get("issued_at")),
    ) + cardkit.ul([
        "U0 dormant -> U1 activated (offline root attestation) -> U2 present (root-signed heartbeat) -> U3 delegated",
        "the attestation is bound to the passport id + genome root, so a different member cannot reuse it",
        "the exact level + reason are computed live by activation.py status; this card is the manifest view",
        "root material exists only as 2-of-3 DPAPI-sealed shards; move two offline before public release",
    ])
    return {"id": "activation", "title": "Activation / D-Touch (L1.5)", "dot": "ok" if (rec and atts) else "warn",
            "big": level, "body": body, "order": 28}


# # --- public relay + contributions (P5) --------------------------------------
def public_relay():
    """P5: the *.public mirror and the contribution pipeline, read from state/ only."""
    pub = STATE / "public"
    man = _load(pub / "mirror" / "manifest.json") or {}
    imported = sorted((pub / "imported").glob("*.json")) if (pub / "imported").exists() else []
    merged = (_load(pub / "merged.json") or {}).get("pills") or {}
    contribs = [p for p in (STATE / "contributions").glob("*.json")
                if not p.name.endswith(".endorsement.json")] if (STATE / "contributions").exists() else []
    contribs = [p for p in contribs if not p.name.endswith("endorsement.json")]
    endorsements = [p for p in (STATE / "contributions").glob("*.endorsement.json")] if (STATE / "contributions").exists() else []
    reps = ((_load(pub / "contributors.json") or {}).get("contributors") or {})
    head = man.get("head") or {}
    rows = [("mirror pills", len(man.get("pills") or [])),
            ("mirror head size", head.get("tree_size")),
            ("mirror head root", str(head.get("root_hex") or "-")[:24]),
            ("exporter key", (man.get("exporter") or {}).get("key_id")),
            ("imported pills", len(imported)),
            ("contributions", len(contribs)),
            ("D-genome endorsements", len(endorsements)),
            ("merged pills", len(merged)),
            ("contributors", len(reps))]
    top = sorted(reps.items(), key=lambda kv: -(kv[1].get("weight") or 0))[:4]
    body = cardkit.rows(*rows) + cardkit.ul(
        [f"{k[:12]}...: weight {v.get('weight')} (submitted {v.get('submitted')}, endorsed {v.get('endorsed')})"
         for k, v in top]
        + ["*.public = pills only: signed envelopes + signed tree head + a Merkle inclusion proof each",
           "import is verify-before-consume; unproven or tampered pills are refused",
           "contribution pipeline: submit -> gate -> offline-root endorsement -> merge; reputation is attested work"])
    return {"id": "public", "title": "*.Public Relay (P5)", "dot": "ok" if man else "warn",
            "big": str(len(man.get("pills") or 0)), "body": body, "order": 29}


# # --- federation + release (P6/P7) -------------------------------------------
def federation_release():
    """P6/P7: peers, divergence alerts and release packages, read from state/ only."""
    peers = (_load(STATE / "public" / "peers.json") or {}).get("peers") or {}
    rel = (_load(STATE / "release" / "index.json") or {}).get("packages") or []
    alerts = [(u, p.get("alerts")) for u, p in peers.items() if p.get("alerts")]
    rows = [("peers", len(peers)),
            ("release packages", len(rel)),
            ("peer alerts", len(alerts)),
            ("last package", (rel[-1].get("package") if rel else None)),
            ("last package sha", str((rel[-1].get("sha256") if rel else "-"))[:24])]
    for u, p in sorted(peers.items())[:3]:
        rows.append((f"peer {u[:18]}", f"head {p.get('head_size')} · ok={p.get('last_ok')}"))
    body = cardkit.rows(*rows) + cardkit.ul(
        [f"ALERT {u}: {', '.join(a)}" for u, a in alerts]
        + ["federation: relay -> fetch -> verify -> import; divergence (same size, new root) and rollback (shrinking head) are flagged",
           "release: three signed packages (master/official/custom), each file sha256'd in a signed RELEASE.json",
           "a package never contains keys, root shards or raw genome; public classes ship a template passport"])
    return {"id": "relay", "title": "Federation / Release (P6-P7)",
            "dot": "fail" if alerts else ("ok" if (peers or rel) else "warn"),
            "big": str(len(rel)), "body": body, "order": 30}


# # --- official repo + install role (corrected model) -------------------------
def repo_install():
    """The one official repo, its update pool and the current install role, from state/ only."""
    repodir = STATE / "repo" / "AGI"
    man = _load(repodir / "repo.json") or {}
    pool = _load(repodir / "pool" / "index.json") or {}
    inst = _load(STATE / "install.json") or {}
    role = inst.get("role") or "-"
    hist = inst.get("history") or []
    rows = [("repo", "AGI" if man else "not initialised"),
            ("distributed bundle", (man.get("official") or {}).get("bundle_id")),
            ("bundle class", (man.get("official") or {}).get("class")),
            ("genome mode", (man.get("official") or {}).get("genome_mode")),
            ("pool pills", len(pool.get("pills") or [])),
            ("pool head", (pool.get("head") or {}).get("root_hex", "")[:24] if pool.get("head") else None),
            ("install role", role),
            ("role bundle", (inst.get("bundle") or {}).get("id")),
            ("activation", (inst.get("activation") or {}).get("level")),
            ("role changes", len(hist))]
    body = cardkit.rows(*rows) + cardkit.ul([
        "ONE official repo (git, not public): official bundle + update pool of pills from all bundles",
        "master = this official bundle UNLOCKED by a D activation - it is never distributed",
        "custom bundle replaces the official bundle; the repo stays the update source",
        "unplugged (role none) bootstraps to the default official bundle, or mints a new user bundle",
    ])
    return {"id": "install", "title": "Official Repo / Install (P8)", "dot": "ok" if man else "warn",
            "big": str(role).upper(), "body": body, "order": 31}


# NOTE 2026-10-20: the 'Season Tasks' card was retired from the system map per D -
# tasks belong on the LIVE DASHBOARD (cache/dashboards/live_dashboard.html, rendered
# from state/season_tasks.json), not in the maintenance AGI SYSTEM MAP.

# Order here only matters for registration; the dashboard sorts by each card's 'order'.
PRODUCERS = [boot, registry, trust, passport, bundles, activation, public_relay, federation_release,
             repo_install, agents, library, maintenance, model]

def produce_all(card_dir=None):
    """Run every producer with isolated failures -> honest error cards. Returns paths."""
    out = []
    for fn in PRODUCERS:
        pid = fn.__name__
        try:
            spec = fn()
            if not (isinstance(spec, dict) and spec.get("id") and spec.get("title")):
                raise ValueError("producer returned an invalid CardSpec")
            out.append(cardkit.put_card(spec, card_dir))
        except Exception as e:
            out.append(cardkit.put_card(cardkit.producer_error_card(pid, e), card_dir))
    return out

if __name__ == "__main__":
    paths = produce_all()
    print(f"{len(paths)} cards written -> {cardkit.CARD_DIR}")
    for p in paths:
        print(f"  - {p.name}")

#!/usr/bin/env python3
"""release.py - package the distributable bundles for public release.

A release package is member-neutral by construction: it carries the official bundle manifest (public
view), the core, a neutral identity template, and the trust summary. It never carries private material -
no state, no keys, no member-data - and verify() refuses a package that does.

CLI
  release.py build --class official|custom [--out <dir>]
  release.py verify <zip>
  release.py list
  release.py selftest
"""
import hashlib
import json
import shutil
import sys
import tempfile
import time
import zipfile
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
RELEASES = STATE / "release"
INDEX = RELEASES / "index.json"

sys.path.insert(0, str(MEM / "scripts"))
import crypto  # noqa: E402
import trust_log  # noqa: E402

SCHEMA = "agi-release/1"
LOGGING = True
FORBIDDEN = ("state/keys", "root_shard", ".key", "genome/transitions", "genome/tree.json",
             "private", "seed")


# ---------------------------------------------------------------- helpers
def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def _safe_name(path):
    return str(path).replace("\\", "/")


def _collect_files(bundle_class, work):
    """Materialise the file set for one package into `work`; return relative paths."""
    files = []

    def add(src, rel):
        src = Path(src)
        if not src.exists():
            return
        dst = work / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            for f in sorted(src.rglob("*")):
                if f.is_file():
                    add(f, f"{rel}/{f.relative_to(src).as_posix()}")
            return
        shutil.copy2(src, dst)
        files.append(rel)

    man = _jload(AGI / "core_manifest.json") or {}
    core_name = man.get("bundle_name")
    add(AGI / "core_manifest.json", "core/core_manifest.json")
    add(AGI / "core_manifest.json.sig", "core/core_manifest.json.sig")
    if core_name:
        add(AGI / core_name, f"core/{core_name}")
    # public docs only: the internal record names private material, so a package carries a
    # neutral trust summary and a redacted milestone instead.
    (work / "docs").mkdir(parents=True, exist_ok=True)
    (work / "docs" / "TRUST.md").write_text(_trust_doc(), encoding="utf-8")
    files.append("docs/TRUST.md")
    ms = _jload(STATE / "milestones" / "trust-layer-v0.json")
    if ms:
        ms_public = {k: ms.get(k) for k in ("schema", "milestone", "title", "frozen_at", "status",
                                           "generation", "phases")}
        ev = ms.get("evidence") or {}
        ms_public["evidence"] = {
            "boot_gate": {"ok": (ev.get("boot_gate") or {}).get("ok")},
            "registry": ev.get("registry") or {},
            "trust_log": {"events": (ev.get("trust_log") or {}).get("events")},
            "tests": ev.get("tests"),
            "note": "private material is not included in public packages",
        }
        _jdump(work / "docs" / "milestone-trust-layer-v0.json", ms_public)
        files.append("docs/milestone-trust-layer-v0.json")

    # bundle manifest of the class this package ships - the neutral public view, filed under its
    # neutral public id, so a released package never carries the authoring member's identity.
    import bundles as bundles_mod
    bid = {"master": "agi-master-d", "official": "agi-official-d", "custom": "agi-custom-d"}[bundle_class]
    raw = _jload(STATE / "bundles" / f"{bid}.json")
    if raw:
        view = bundles_mod.public_view(raw)
        public_id = view.get("bundle_id") or bid
        view_path = work / "bundle" / f"{public_id}.json"
        _jdump(view_path, view)
        crypto.sign_file(view_path)
        files.append(f"bundle/{public_id}.json")
        files.append(f"bundle/{public_id}.json.sig")

    # neutral identity template (never a member's identity material)
    _jdump(work / "identity" / "identity-template.json", {
        "schema": "agi-identity-template/1",
        "bundle_class": bundle_class,
        "state": "inactive",
        "note": "activation is performed by the owner after installation and verified by the runtime",
    })
    files.append("identity/identity-template.json")

    # device public key only for the (never published) master package
    dev = _jload(STATE / "keys" / "device.json") or {}
    if bundle_class == "master" and dev:
        _jdump(work / "trust" / "device-public.json",
               {k: dev.get(k) for k in ("schema", "name", "alg", "key_id", "public_key_b64", "created", "sealed")})
        files.append("trust/device-public.json")
    return files


def _readme(bundle_class, bid, count):
    lines = [
        f"# AGI release package - {bundle_class}",
        "",
        f"bundle: {bid}",
        f"files: {count}",
        f"built: {_now()}",
        "",
        "Every file is listed with its sha256 in RELEASE.json; the manifest is signed by the AGI device key",
        "and can be verified offline:  python memory/scripts/release.py verify <this zip>",
        "",
    ]
    if bundle_class == "official":
        lines += ["This is the official, member-neutral package. It ships with a neutral identity",
                  "template; activation is performed by the owner after installation and verified by",
                  "the runtime. Nobody's private material is inside this archive.", ""]
    if bundle_class == "custom":
        lines += ["This is a template. To build your own bundle:",
                  "  1. install an AGI core, run crypto.py keygen and identity init",
                  "  2. initialise your own local identity and set your policy entries",
                  "  3. bundles.py init --class custom --id <yours> --parent agi-official",
                  "  4. bundles.py verify / activate", ""]
    lines += ["This package contains NO private keys and NO member data."]
    return "\n".join(lines) + "\n"


def _trust_doc():
    return """# AGI trust layer - what a member receives

This package is one installation of the AGI system: the official bundle, the signed manifest that
describes it, and a neutral identity template. Nothing here carries any member's private material.

## The four guarantees

1. **Signed content** - every file is listed with a sha256 in RELEASE.json, and RELEASE.json is signed
   (ML-DSA-65, FIPS 204). Verification is offline: `python memory/scripts/release.py verify <zip>`.
2. **Append-only history** - pills are recorded in an RFC 9162 Merkle log. Every pill in the public pool
   carries its own signed tree head and an inclusion proof, so a member can prove that a pill was
   accepted and that nothing was quietly rewritten.
3. **Member identity** - each installation mints its own local identity (ML-DSA-65 device key, sealed by
   the operating system). Identity material is private to the installation; activation is performed by
   the owner and verified by the runtime. The install role records whether a member runs official,
   unlocked, custom, or no bundle (unplugged).
4. **Member-neutral artefacts** - public packages contain no private material of any kind, and
   `release.py verify` refuses a package that carries any.

## Updates

Members pull pills from the official repository's update pool (verified before import) and sync their own
public mirror. Nothing is trusted because it arrived; it is trusted because it verifies.
"""


def build(out_dir=None, classes=("official", "custom")):
    out = Path(out_dir) if out_dir else RELEASES
    out.mkdir(parents=True, exist_ok=True)
    built = []
    stamp = time.strftime("%Y%m%d")
    for cls in classes:
        bid = {"master": "agi-master-d", "official": "agi-official-d", "custom": "agi-custom-d"}[cls]
        import bundles as _bundles
        _raw_manifest = _jload(STATE / "bundles" / f"{bid}.json") or {}
        public_bid = (_bundles.public_view(_raw_manifest).get("bundle_id") if _raw_manifest else None)
        work = Path(tempfile.mkdtemp(prefix=f"agi-rel-{cls}-"))
        try:
            files = _collect_files(cls, work)
            readme = _readme(cls, bid, len(files))
            (work / "README.md").write_text(readme, encoding="utf-8")
            files.append("README.md")
            entries = []
            for rel in sorted(files):
                p = work / rel
                entries.append({"path": rel, "sha256": _sha(p), "bytes": p.stat().st_size})
            manifest = {
                "schema": SCHEMA,
                "package": f"{public_bid or bid}-{stamp}",
                "bundle_class": cls,
                "bundle_id": bid,
                "built_at": _now(),
                "generation": (_jload(AGI / "core_manifest.json") or {}).get("core_version"),
                "files": entries,
                "counts": {"files": len(entries)},
                "policy": "no private keys, no root shards, no raw genome; public artefacts only",
                "verify": "release.py verify <zip>",
            }
            body = crypto.canonical_json(manifest)
            sig = crypto.sign_bytes(body)
            _jdump(work / "RELEASE.json", manifest)
            _jdump(work / "RELEASE.json.sig", sig)
            zip_path = out / f"{manifest['package']}.zip"
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
                z.write(work / "RELEASE.json", "RELEASE.json")
                z.write(work / "RELEASE.json.sig", "RELEASE.json.sig")
                for e in manifest["files"]:
                    z.write(work / e["path"], e["path"])
            built.append({"package": manifest["package"], "class": cls, "zip": str(zip_path),
                          "files": len(manifest["files"]), "bytes": zip_path.stat().st_size,
                          "sha256": _sha(zip_path)})
        finally:
            shutil.rmtree(work, ignore_errors=True)
    index = _jload(INDEX, {"schema": "agi-release-index/1", "packages": []}) or \
        {"schema": "agi-release-index/1", "packages": []}
    known = {p["zip"]: p for p in index["packages"]}
    for b in built:
        known[b["zip"]] = b
    index["packages"] = sorted(known.values(), key=lambda p: p["zip"])
    index["updated"] = _now()
    _jdump(INDEX, index)
    if LOGGING:
        trust_log.append("release-built", {"packages": [b["package"] for b in built],
                                           "zips": [b["sha256"] for b in built]})
    return {"ok": True, "built": built, "index": str(INDEX)}


def verify_zip(zip_path, expect_key=None):
    zip_path = Path(zip_path)
    problems = []
    if not zip_path.is_file():
        return {"ok": False, "problems": [f"no package at {zip_path}"]}
    tmp = Path(tempfile.mkdtemp(prefix="agi-rel-verify-"))
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = z.namelist()
            z.extractall(tmp)
        man = _jload(tmp / "RELEASE.json")
        if not man:
            return {"ok": False, "problems": ["no RELEASE.json in the package"]}
        if man.get("schema") != SCHEMA:
            problems.append(f"unsupported schema {man.get('schema')!r}")
        for bad in FORBIDDEN:
            if any(bad in n for n in names):
                problems.append(f"forbidden content in package: {bad}")
        expected = set(man.get("files") and [e["path"] for e in man["files"]] or [])
        expected |= {"RELEASE.json", "RELEASE.json.sig"}
        extras = sorted(set(names) - expected)
        missing = sorted(expected - set(names))
        for x in extras:
            problems.append(f"unlisted file in package: {x}")
        for m in missing:
            problems.append(f"listed file absent from package: {m}")
        sig = _jload(tmp / "RELEASE.json.sig") or {}
        pinned = expect_key or (man.get("files") and None) or sig.get("key_id")
        chk = crypto.verify_bytes(crypto.canonical_json(man), sig, expected_key_id=pinned)
        if not chk.get("ok"):
            problems.append("manifest signature: " + str(chk.get("reason")))
        for e in man.get("files") or []:
            if e["path"].startswith("bundle/") and e["path"].endswith(".json"):
                bm = _jload(tmp / e["path"]) or {}
                if (bm.get("passport") or {}).get("passport_id"):
                    problems.append(f"package leaks a passport id: {e['path']}")
                if (bm.get("genome") or {}).get("root"):
                    problems.append(f"package leaks a genome root: {e['path']}")
        import re as _re
        for e in man.get("files") or []:
            p = tmp / e["path"]
            if not p.is_file():
                problems.append(f"missing file: {e['path']}")
                continue
            if _sha(p) != e.get("sha256"):
                problems.append(f"hash mismatch: {e['path']}")
            if p.suffix in (".json", ".md"):
                try:
                    txt = p.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                if _re.search(r'"passport_id"\s*:\s*"[0-9a-f-]{8,}"', txt):
                    problems.append(f"leaks a passport id: {e['path']}")
                if _re.search(r'"user_genome_root"\s*:\s*"[0-9a-f]{32,}"', txt):
                    problems.append(f"leaks a genome root: {e['path']}")
        return {"ok": not problems, "problems": problems, "package": man.get("package"),
                "class": man.get("bundle_class"), "files": len(man.get("files") or []),
                "key_id": sig.get("key_id")}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def list_releases():
    return _jload(INDEX, {"packages": []})


def selftest():
    global RELEASES, INDEX, LOGGING, STATE, AGI

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    saved = (RELEASES, INDEX, LOGGING, STATE, AGI, crypto.KEYS,
             trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR)
    tmp = Path(tempfile.mkdtemp(prefix="agi-release-test-"))
    try:
        LOGGING = False
        AGI = tmp
        STATE = tmp / "state"
        RELEASES = STATE / "release"
        INDEX = RELEASES / "index.json"
        crypto.KEYS = STATE / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        trust_log.LOG = STATE / "trust_log"
        trust_log.EVENTS = trust_log.LOG / "events.jsonl"
        trust_log.HEADS = trust_log.LOG / "heads"
        trust_log.MONITOR = trust_log.LOG / "monitor.json"
        # minimal artefacts the collector expects
        (tmp / "core_manifest.json").write_text(json.dumps({"core_version": "3.2", "dna_version": 3,
                                                           "bundle_name": "core.tar.gz"}), encoding="utf-8")
        (tmp / "core.tar.gz").write_bytes(b"core")
        (tmp / "memory" / "knowledge").mkdir(parents=True, exist_ok=True)
        (tmp / "memory" / "knowledge" / "trust-layer-v0.md").write_text("# trust\n", encoding="utf-8")
        _jdump(STATE / "milestones" / "trust-layer-v0.json", {"schema": "agi-milestone/1",
                                                              "milestone": "trust-layer-v0",
                                                              "frozen_at": "now", "status": "FROZEN"})
        _jdump(STATE / "keys" / "root.json", {"schema": "agi-root/1", "alg": "ML-DSA-87",
                                              "root_key_id": "r1", "public_key_b64": "pk",
                                              "threshold": {"k": 2, "n": 3}})
        _jdump(STATE / "passport.json", {"schema": "agi-passport/1", "passport_id": "p1",
                                         "member": "D", "bundle_class": "master",
                                         "user_genome_root": "ab" * 32, "genome_epoch": 4})
        for bid, cls in (("agi-master-d", "master"), ("agi-official-d", "official"),
                         ("agi-custom-d", "custom")):
            _jdump(STATE / "bundles" / f"{bid}.json", {"schema": "agi-bundle/1", "bundle_id": bid,
                                                       "class": cls})
            (STATE / "bundles").mkdir(parents=True, exist_ok=True)
            crypto.sign_file(STATE / "bundles" / f"{bid}.json")

        r = build()
        check("two packages built (official + custom; master is an unlocked state, not an artefact)",
              r["ok"] and len(r["built"]) == 2, str(r.get("built")))
        for b in r["built"]:
            v = verify_zip(b["zip"], expect_key=crypto.pinned_key_id())
            check(f"package {b['class']} verifies", v["ok"], str(v.get("problems")))
            check(f"package {b['class']} refuses a foreign key",
                  not verify_zip(b["zip"], expect_key="deadbeefdeadbeef")["ok"])
        # tamper: append a junk file that the manifest does not list -> missing-file detection is not
        # triggered by extras, but a modified listed file must fail
        zpath = Path([b["zip"] for b in r["built"] if b["class"] == "official"][0])
        tdir = tmp / "tamper"
        tdir.mkdir(exist_ok=True)
        with zipfile.ZipFile(zpath) as z:
            z.extractall(tdir)
        victim = tdir / "docs" / "TRUST.md"
        victim.write_text("# tampered\n", encoding="utf-8")
        zp2 = tmp / "tampered.zip"
        with zipfile.ZipFile(zp2, "w") as z:
            for f in sorted(tdir.rglob("*")):
                if f.is_file():
                    z.write(f, f.relative_to(tdir).as_posix())
        v2 = verify_zip(zp2)
        check("tampered package refused", not v2["ok"] and any("hash mismatch" in p for p in v2["problems"]),
              str(v2.get("problems")))
        # no private material anywhere
        names = []
        with zipfile.ZipFile(zpath) as z:
            names = z.namelist()
        check("no keys/shards/genome in the public package",
              not any("root_shard" in n or n.endswith(".key") or "state/keys" in n for n in names), str(names[:6]))
        man = _jload(tdir / "RELEASE.json")
        check("official package carries a template, not member data",
              man["bundle_class"] == "official" and "REPLACE_WITH_YOUR_GENOME_ROOT" in
              (tdir / "passport" / "passport-summary.json").read_text(encoding="utf-8"))
        check("index lists the packages", len(list_releases()["packages"]) == 2)
    finally:
        (RELEASES, INDEX, LOGGING, STATE, AGI, crypto.KEYS,
         trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("release selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def cmd_build(args):
    out = args[args.index("--out") + 1] if "--out" in args else None
    r = build(out)
    print(json.dumps(r, indent=1))
    return 0


def cmd_verify(args):
    if not args:
        print("usage: release.py verify <zip> [--expect-key <id>]")
        return 2
    key = args[args.index("--expect-key") + 1] if "--expect-key" in args else None
    r = verify_zip(args[0], expect_key=key)
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_list(args):
    print(json.dumps(list_releases(), indent=1))
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"build": cmd_build, "verify": cmd_verify, "list": cmd_list,
             "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

#!/usr/bin/env python3
"""mismatch_telemetry.py - W5 phase-1 (L2) brain-body mismatch instruments.

Two state-only instruments, no rules installed, no core-text change:

1 TIMR proxy (turn-level interface mismatch rate, CoEvo-RSI style):
   observable interface violations per boot in the current window:
     gate_violations  = script quarantines recorded by the verified-only gate
     boot_failures    = boots whose status was not ready
     maintenance_hits = maintenance commits mentioning failure/quarantine/incident
   rate = violations / max(1, boots_in_window)
   Honest limitation: AGI has no per-turn transcript schema yet, so this is a
   boot-level proxy, not the paper's per-model-turn TIMR (recorded in the output).

2 Compatibility / evolution archive (append-only): one row per run with
   core_version, dna_version, host, model, profile, integrity gate, conformance
   evidence, registry verified count and TIMR proxy -> state/evolution_archive.jsonl
   This is the machine-readable ancestry base the paper argues for; profile x core
   version compatibility can be recalled from it instead of assumed.

Writes state/timr.json (+ state/timr_history.jsonl, last 500) and appends the archive.
`--selftest` proves both writers with scratch paths. Portable: paths self-located.
"""
import json
import os
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
TIMR = STATE / "timr.json"
TIMR_HIST = STATE / "timr_history.jsonl"
ARCHIVE = STATE / "evolution_archive.jsonl"
WINDOW_BOOTS = 50


def _read_json(p):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _read_jsonl(p, limit=None):
    out = []
    try:
        for line in Path(p).read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    out.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        return []
    return out[-limit:] if limit else out


def _write_json(p, data):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(p)


def _append_jsonl(p, row, keep=500):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    rows = _read_jsonl(p)
    rows.append(row)
    p.write_text("\n".join(json.dumps(r) for r in rows[-keep:]) + "\n", encoding="utf-8")


def timr(window_boots=WINDOW_BOOTS, state_dir=None, write=True):
    state = Path(state_dir) if state_dir else STATE
    boots = _read_jsonl(state / "boot_runs.jsonl", limit=window_boots)
    boot_failures = sum(1 for b in boots if str(b.get("status")) != "ready")
    # window = from the first boot in the sample to now (dates only: gate log is date-stamped)
    window_start = str(boots[0].get("ts", ""))[:10] if boots else ""
    quarantine = _read_jsonl(AGI / "memory" / "temp" / ".jobs" / "quarantine.jsonl")
    real = [q for q in quarantine
            if str(q.get("id")) != "_selftest"                      # intentional test fixture
            and (not window_start or str(q.get("date", "")) >= window_start)]
    gate_violations = len(real)
    maint = _read_json(state / "maintenance.json")
    hits = 0
    for f in maint.get("fixed", [])[-40:]:
        text = str(f.get("item", "")).lower()
        if any(k in text for k in ("incident", "violation")):
            hits += 1
    denom = max(1, len(boots))
    rate = round((boot_failures + gate_violations) / denom, 4)
    out = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
           "metric": "TIMR proxy (boot-level; per-turn transcript not yet available)",
           "window_boots": len(boots),
           "window_start_date": window_start or None,
           "counters": {"gate_violations": gate_violations, "boot_failures": boot_failures,
                        "maintenance_incidents_info_only": hits},
           "rate": rate,
           "interpretation": "violations (gate quarantines excluding the _selftest fixture + non-ready boots) "
                             "per boot in the window; maintenance count is informational and not in the rate; "
                             "compare across harness/profile changes, never as an absolute quality score"}
    if write:
        _write_json(state / "timr.json", out)
        _append_jsonl(state / "timr_history.jsonl", {"ts": out["ts"], "rate": rate, **out["counters"]})
    return out


def record_evolution(state_dir=None, write=True, overrides=None):
    state = Path(state_dir) if state_dir else STATE
    man = _read_json(AGI / "core_manifest.json")
    boot = _read_json(state / "boot_card.json")
    env = _read_json(state / "env_probe.json")
    caps = _read_json(state / "capabilities.json")
    reg = _read_json(AGI / "memory" / "scripts" / "registry.json").get("scripts", {})
    timr_now = _read_json(state / "timr.json")
    verified = sum(1 for v in reg.values() if str(v.get("status", "")).startswith("verified"))
    model = (env.get("model") or {}).get("name")
    if not model or str(model).strip().lower() in ("n/a", "unknown"):
        model = ((_read_json(AGI / "state" / "boot.json").get("host") or {}).get("session_model"))
    row = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
           "core_version": man.get("core_version"),
           "dna_version": man.get("dna_version"),
           "host": ((boot.get("host_application") or {}).get("id")
                    or (boot.get("ram") or {}).get("host")),
           "model": model,
           "profile": boot.get("profile"),
           "integrity_ok": (boot.get("integrity") or {}).get("ok"),
           "subsystems": (boot.get("capabilities") or {}).get("shell_dialect"),
           "verified_scripts": verified,
           "timr_proxy": timr_now.get("rate"),
           "archive_pairs": "core_version x host x profile"}
    if overrides:
        row.update({k: v for k, v in overrides.items() if v is not None})
    if write:
        _append_jsonl(state / "evolution_archive.jsonl", row, keep=500)
    # W5-A: profile x core_version x host compatibility matrix, updated every boot
    matrix_p = state / "compatibility_matrix.json"
    matrix = _read_json(matrix_p) or {"rows": {}, "note": "profile x core_version x host outcome matrix (gen3.4/W5-A)"}
    key = "%s|%s|%s" % (row.get("profile"), row.get("core_version"), row.get("host"))
    ent = (matrix.get("rows") or {}).get(key) or {"first_seen": row["ts"], "boots": 0}
    ent.update({"profile": row.get("profile"), "core_version": row.get("core_version"),
                "host": row.get("host"), "model": row.get("model"),
                "status": "unprofiled" if row.get("profile") == "unprofiled" else "supported",
                "last_seen": row["ts"], "boots": int(ent.get("boots", 0)) + 1,
                "integrity_ok": row.get("integrity_ok"),
                "verified_scripts": row.get("verified_scripts"),
                "timr_proxy": row.get("timr_proxy")})
    matrix.setdefault("rows", {})[key] = ent
    matrix["updated"] = row["ts"]
    if write:
        _write_json(matrix_p, matrix)
        row["compatibility_key"] = key
    return row


def run(state_dir=None, write=True, overrides=None):
    t = timr(state_dir=state_dir, write=write)
    row = record_evolution(state_dir=state_dir, write=write, overrides=overrides)
    return {"timr": t, "archive": row}


def selftest():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        (tmp / "boot_runs.jsonl").write_text(
            "\n".join(json.dumps({"status": s}) for s in ("ready", "ready", "debug")) + "\n",
            encoding="utf-8")
        _write_json(tmp / "maintenance.json", {"fixed": [{"item": "script quarantined after failure"}]})
        t = timr(state_dir=tmp, write=True)
        hist = len(_read_jsonl(tmp / "timr_history.jsonl"))
        row = record_evolution(state_dir=tmp, write=True)
        arch = len(_read_jsonl(tmp / "evolution_archive.jsonl"))
        matrix = _read_json(tmp / "compatibility_matrix.json")
        ok = (t["window_boots"] == 3 and t["counters"]["boot_failures"] == 1
              and "gate_violations" in t["counters"]
              and "maintenance_incidents_info_only" in t["counters"] and t["rate"] > 0
              and hist == 1 and arch == 1 and row["core_version"] is not None
              and len(matrix.get("rows") or {}) == 1)
        print("mismatch_telemetry selftest:", "PASS" if ok else "FAIL",
              "| boots=%d failures=%d rate=%s hist=%d archive=%d" % (
                  t["window_boots"], t["counters"]["boot_failures"], t["rate"], hist, arch))
        return 0 if ok else 1


def main():
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    r = run()
    print("telemetry: TIMR proxy=%s over %d boots (counters %s) | archive: core v%s host=%s profile=%s" % (
        r["timr"]["rate"], r["timr"]["window_boots"], r["timr"]["counters"],
        r["archive"].get("core_version"), r["archive"].get("host"), r["archive"].get("profile")))


if __name__ == "__main__":
    main()

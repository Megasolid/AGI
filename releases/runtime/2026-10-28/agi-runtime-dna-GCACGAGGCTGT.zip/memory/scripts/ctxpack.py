#!/usr/bin/env python3
"""ctxpack - generate chunk 1 (chunk1_boot.md) of the season cache cluster.

Cache = season sandbox CWD (= system RAM, temporary by nature). Chunk 1 = boot +
dashboard [AI wiring to AGI], generated at cold-start boot. Fastboot (new season,
possibly empty cache) does NOT rely on this - it reads state/ only.
usage: ctxpack.py [--refresh]   (--refresh is a no-op flag, kept for registry cmd shape)

gen3.4/W5-A (2026-10-25): the wired model card comes from state/boot_card.json - BIOS is the
single owner of S5 profile selection. This consumer never re-derives a profile or a default:
an unmatched model is rendered 'unprofiled' plus its degraded modes (the qwen-local fallback
is retired). Rendering lives in build_chunk() so the contract is testable without the live cache.
"""
import datetime
import json
import os
import shutil
import sys

AGI = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # self-located: memory/scripts -> skill root


def jload(p, d=None):
    try:
        with open(p) as f:
            return json.load(f)
    except Exception:
        return d


def _profile_bullets(profile):
    """Bullet lines of models/<profile>.md; a read failure is reported, never hidden."""
    try:
        with open(os.path.join(AGI, "models", profile), encoding="utf-8") as fh:
            return [ln[2:].strip() for ln in fh.read().splitlines() if ln.startswith("- ")]
    except Exception as e:
        return ["(profile unreadable: %s)" % e]


def _wired_profile(bc, env):
    """S5 wiring as recorded by BIOS: (name, profile, status, matched)."""
    m = env.get("model") or {}
    profile = bc.get("profile")
    status = bc.get("profile_status") or ("matched" if profile and profile != "unprofiled" else "unprofiled")
    matched = bool(status == "matched" and profile)
    return (bc.get("model_name") or m.get("name")), profile, status, matched


def build_chunk(bc, env, maint, verified, cand, ram, now=None):
    """Render chunk 1 from BIOS-wired state. Pure: no writes, no global cache access."""
    ts = (now or datetime.datetime.now()).strftime("%Y-%m-%dT%H:%M")
    m = env.get("model") or {}
    name, prof, pstat, matched = _wired_profile(bc, env)
    L = ["# chunk 1 - boot + dashboard [AI wiring to AGI] (generated %s)" % ts,
         "_Cold-start artifact of the season cache cluster (RAM). Fastboot does NOT rely on this - new seasons read state/ only._", "",
         "## Boot status",
         "- status: %s  ts: %s  profile: %s" % (bc.get("status"), bc.get("ts"), bc.get("profile") or pstat),
         "- verified scripts: %d | candidates: %s" % (len(verified), cand or "none"), "",
         "## Wired model card (universal adapter)",
         "- name: %s   quant: %s   ctx: %s   flags: %s" % (name, m.get("quant"), m.get("context_length"), m.get("flags")),
         "- S5 profile: %s (%s)" % (prof if matched else (prof or "unprofiled"), pstat)]
    if matched:
        for l in _profile_bullets(prof):
            L.append("  - " + l)
    else:
        L.append("  - no adapter profile for this model - generic rules only (S5 fallback retired, gen3.4/W5-A)")
    for d in (bc.get("degraded_modes") or []):
        L.append("  - degraded: " + str(d))
    L += ["", "## Verified scripts", ", ".join(verified), "",
          "## Maintenance - open"]
    for o in maint.get("open", []):
        L.append("- " + o)
    L += ["", "## Maintenance - last fixed"]
    for f_ in maint.get("fixed", [])[-3:]:
        L.append("- [%s] %s" % (f_.get("ts"), f_.get("item")))
    L += ["", "## Machine facts digest (full: state/machine.md)"]
    try:
        with open(os.path.join(AGI, "state", "machine.md"), encoding="utf-8") as fh:
            md = fh.read()
        for key in ("Win11 Pro", "venv:", "Studio :8888"):
            for l in md.splitlines():
                if key in l:
                    L.append("- " + l.strip())
                    break
    except Exception as e:
        L.append("- (machine.md unreadable: %s)" % e)
    L += ["", "## Season cache cluster (shared RAM, temporary by nature)",
          "- sandbox root: %s | resolver: %s | verified: %s" % (ram.get("root"), ram.get("source"), ram.get("verified")),
          "- active cache: %s" % ram.get("cache"),
          "- cache/chunk1_boot.md - this file (boot + dashboard wiring)",
          "- cache/tasks/<id>.md - one chunk per open season task, checkpoints appended per turn",
          "- cache/dashboards/ - live map + reports served from RAM; expose via studio --cloudflare / -H 0.0.0.0",
          "- cache/tmp/ - scratch, wipe anytime"]
    return "\n".join(L) + "\n"


def main():
    import cardkit
    cache = cardkit.sandbox_cache()  # season sandbox cache = SHARED RAM pool with D (cwd-independent)
    bc = jload(os.path.join(AGI, "state", "boot_card.json"), {}) or {}
    reg = jload(os.path.join(AGI, "memory", "scripts", "registry.json"), {}) or {}
    maint = jload(os.path.join(AGI, "state", "maintenance.json"), {}) or {}
    env = jload(os.path.join(AGI, "state", "env_probe.json"), {}) or {}
    scripts = reg.get("scripts", {})
    verified = [k for k, v in scripts.items() if str(v.get("status", "")).startswith("verified")]
    cand = [k for k, v in scripts.items() if v.get("status") == "candidate"]
    ram = bc.get("ram") or {}
    text = build_chunk(bc, env, maint, verified, cand, ram)
    # Dashboard half of chunk 1: copy the live system map into RAM for serving.
    dash = os.path.join(cache, "dashboards")
    os.makedirs(dash, exist_ok=True)
    try:
        shutil.copyfile(os.path.join(AGI, "memory", "agi_system_map.html"),
                        os.path.join(dash, "agi_system_map.html"))
    except Exception as e:
        text += "- (map copy failed: %s)\n" % e
    out = os.path.join(cache, "chunk1_boot.md")
    os.makedirs(cache, exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(text)
    print("OK chunk1 written:", out, "(%d bytes)" % os.path.getsize(out))
    return 0


if __name__ == "__main__":
    sys.exit(main())

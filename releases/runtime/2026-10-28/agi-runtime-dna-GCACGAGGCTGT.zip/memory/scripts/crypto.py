#!/usr/bin/env python3
"""crypto.py - AGI Trust Layer L0: post-quantum device keys and signed objects.

Purpose: give every AGI install a real identity root and make integrity claims
verifiable without trusting the file system that stores them.

Design
  * Algorithms are selectable and self-describing: ML-DSA-65 (default), ML-DSA-87
    (FIPS 204) and Ed25519 (classical fallback for agility tests). Every signature
    carries alg + key_id, so adding or retiring an algorithm never invalidates old
    evidence.
  * The private key is sealed at rest with Windows DPAPI in the current user's
    scope (no prompt, no roaming): the key cannot be lifted by copying the file to
    another account or machine. Non-Windows falls back to a plain file and says so
    in the public record (sealed: "plain") - never silently.
  * Signatures are detached JSON files (`<file>.sig`) carrying the public key, so
    a verifier needs nothing but the file and its signature; a pinning check
    (key_id) lives in boot_gate.
  * Payloads are canonicalised (sorted keys, no whitespace, UTF-8) so a signature
    survives re-serialisation - the same rule the log and the passport will use.

CLI
  crypto.py keygen [--alg ML-DSA-65|ML-DSA-87|Ed25519] [--name device] [--force]
  crypto.py info
  crypto.py sign <path> [--out <sig path>]
  crypto.py verify <path> [--sig <sig path>] [--key-id <id>]
  crypto.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import base64
import ctypes
import json
import os
import secrets
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
KEYS = STATE / "keys"
SCHEMA = "agi-sig/1"
KEY_SCHEMA = "agi-device-key/1"

DEFAULT_ALG = "ML-DSA-65"
ALGS = ("ML-DSA-65", "ML-DSA-87", "Ed25519")


# ---------------------------------------------------------------- canonicalisation
def canonical_json(obj):
    """Deterministic payload bytes: RFC 8785-style (sorted keys, no whitespace)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


# ---------------------------------------------------------------- algorithm registry
def _impl(alg):
    from cryptography.hazmat.primitives.asymmetric import ed25519, mldsa

    table = {
        "ML-DSA-65": (mldsa.MLDSA65PrivateKey, mldsa.MLDSA65PublicKey),
        "ML-DSA-87": (mldsa.MLDSA87PrivateKey, mldsa.MLDSA87PublicKey),
        "Ed25519": (ed25519.Ed25519PrivateKey, ed25519.Ed25519PublicKey),
    }
    if alg not in table:
        raise ValueError(f"unsupported algorithm: {alg} (choose from {', '.join(ALGS)})")
    return table[alg]


def _raw_public(pub):
    # ML-DSA exposes public_bytes_raw(); Ed25519 too. Keep one path for both.
    if hasattr(pub, "public_bytes_raw"):
        return pub.public_bytes_raw()
    from cryptography.hazmat.primitives import serialization

    return pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def _raw_private(priv):
    # ML-DSA private_bytes_raw() is the 32-byte FIPS 204 seed; Ed25519 is the 32-byte seed.
    # Elliptic curves do not expose it, and we do not use them here.
    return priv.private_bytes_raw()


def _load_private(alg, raw):
    from cryptography.hazmat.primitives.asymmetric import ed25519, mldsa

    loaders = {
        "ML-DSA-65": mldsa.MLDSA65PrivateKey.from_seed_bytes,
        "ML-DSA-87": mldsa.MLDSA87PrivateKey.from_seed_bytes,
        "Ed25519": ed25519.Ed25519PrivateKey.from_private_bytes,
    }
    return loaders[alg](raw)


def _load_public(alg, raw):
    from cryptography.hazmat.primitives.asymmetric import ed25519, mldsa

    loaders = {
        "ML-DSA-65": mldsa.MLDSA65PublicKey.from_public_bytes,
        "ML-DSA-87": mldsa.MLDSA87PublicKey.from_public_bytes,
        "Ed25519": ed25519.Ed25519PublicKey.from_public_bytes,
    }
    return loaders[alg](raw)


def key_id(public_bytes):
    import hashlib

    return hashlib.sha256(public_bytes).hexdigest()[:16]


# ---------------------------------------------------------------- DPAPI seal
class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _blob_in(data):
    buf = ctypes.create_string_buffer(data, len(data))
    return _DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))


def _dpapi_available():
    return sys.platform == "win32"


def _dpapi_seal(data):
    out = _DATA_BLOB()
    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(_blob_in(data)), "agi-trust-key", None, None, None, 0x1, ctypes.byref(out))
    if not ok:
        raise OSError("CryptProtectData failed")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


def _dpapi_unseal(data):
    out = _DATA_BLOB()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(_blob_in(data)), None, None, None, None, 0x1, ctypes.byref(out))
    if not ok:
        raise OSError("CryptUnprotectData failed (different user or machine?)")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


# ---------------------------------------------------------------- key lifecycle
def _paths(name="device"):
    return KEYS / f"{name}.json", KEYS / f"{name}.key"


def keygen(name="device", alg=DEFAULT_ALG, force=False):
    KEYS.mkdir(parents=True, exist_ok=True)
    pub_p, priv_p = _paths(name)
    if (pub_p.exists() or priv_p.exists()) and not force:
        raise FileExistsError(f"key '{name}' already exists (use --force to replace; old signatures stop verifying)")
    priv_cls, _ = _impl(alg)
    priv = priv_cls.generate()
    raw_priv = _raw_private(priv)
    raw_pub = _raw_public(priv.public_key())
    sealed = "dpapi" if _dpapi_available() else "plain"
    blob = _dpapi_seal(raw_priv) if sealed == "dpapi" else raw_priv
    record = {
        "schema": KEY_SCHEMA,
        "name": name,
        "alg": alg,
        "key_id": key_id(raw_pub),
        "public_key_b64": base64.b64encode(raw_pub).decode("ascii"),
        "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "sealed": sealed,
        "host": os.environ.get("COMPUTERNAME") or "?",
        "note": ("private key sealed to the current Windows user (DPAPI), non-portable by design; "
                 "portability arrives with the passport (P2)"),
    }
    priv_p.write_bytes(base64.b64encode(blob))
    try:
        os.chmod(priv_p, 0o600)
    except OSError:
        pass
    pub_p.write_text(json.dumps(record, indent=1), encoding="utf-8")
    return record


def load_record(name="device"):
    pub_p, _ = _paths(name)
    if not pub_p.exists():
        raise FileNotFoundError(f"no public key record at {pub_p} (run: crypto.py keygen)")
    return json.loads(pub_p.read_text(encoding="utf-8"))


def _load_private_key(name="device"):
    rec = load_record(name)
    _, priv_p = _paths(name)
    sealed = rec.get("sealed")
    blob = base64.b64decode(priv_p.read_bytes())
    if sealed == "dpapi":
        raw = _dpapi_unseal(blob)
    else:
        raw = blob
    return rec, _load_private(rec["alg"], raw)


# ---------------------------------------------------------------- sign / verify
def sign_bytes(data, name="device"):
    rec, priv = _load_private_key(name)
    alg = rec["alg"]
    if alg == "Ed25519":
        sig = priv.sign(data)
    else:
        sig = priv.sign(data)
    return {"schema": SCHEMA, "alg": alg, "key_id": rec["key_id"],
            "public_key_b64": rec["public_key_b64"],
            "payload_sha256": __import__("hashlib").sha256(data).hexdigest(),
            "signature_b64": base64.b64encode(sig).decode("ascii"),
            "signed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}


def sign_file(path, out=None, name="device"):
    path = Path(path)
    payload = path.read_bytes()
    env = sign_bytes(payload, name=name)
    sig_path = Path(out) if out else path.with_name(path.name + ".sig")
    sig_path.write_text(json.dumps(env, indent=1), encoding="utf-8")
    return sig_path, env


def verify_bytes(payload, env, expected_key_id=None):
    alg = env.get("alg")
    if env.get("schema") != SCHEMA:
        return {"ok": False, "reason": f"unsupported signature schema: {env.get('schema')}"}
    if alg not in ALGS:
        return {"ok": False, "reason": f"unsupported algorithm: {alg}"}
    import hashlib

    if hashlib.sha256(payload).hexdigest() != env.get("payload_sha256"):
        return {"ok": False, "reason": "payload hash mismatch (object changed after signing)"}
    try:
        pub_raw = base64.b64decode(env["public_key_b64"])
        sig = base64.b64decode(env["signature_b64"])
    except Exception as e:
        return {"ok": False, "reason": f"malformed signature envelope: {e}"}
    if key_id(pub_raw) != env.get("key_id"):
        return {"ok": False, "reason": "key_id does not match the embedded public key"}
    if expected_key_id and env.get("key_id") != expected_key_id:
        return {"ok": False, "reason": f"key pinning failed: signed by {env.get('key_id')}, expected {expected_key_id}"}
    try:
        _load_public(alg, pub_raw).verify(sig, payload)
    except Exception as e:
        return {"ok": False, "reason": f"signature invalid: {type(e).__name__}"}
    return {"ok": True, "reason": "verified", "alg": alg, "key_id": env.get("key_id")}


def verify_file(path, sig_path=None, expected_key_id=None):
    path = Path(path)
    sig_path = Path(sig_path) if sig_path else path.with_name(path.name + ".sig")
    if not sig_path.exists():
        return {"ok": False, "reason": f"no signature file at {sig_path}"}
    try:
        env = json.loads(sig_path.read_text(encoding="utf-8"))
    except Exception as e:
        return {"ok": False, "reason": f"signature file unreadable: {e}"}
    return verify_bytes(path.read_bytes(), env, expected_key_id=expected_key_id)


def pinned_key_id(name="device"):
    """Key id the install trusts for its own objects (None when no key exists yet)."""
    try:
        return load_record(name).get("key_id")
    except FileNotFoundError:
        return None


# ---------------------------------------------------------------- CLI
def _print(obj):
    print(json.dumps(obj, indent=1))


def cmd_keygen(args):
    name = "device"
    alg = DEFAULT_ALG
    force = "--force" in args
    if "--name" in args:
        name = args[args.index("--name") + 1]
    if "--alg" in args:
        alg = args[args.index("--alg") + 1]
    rec = keygen(name=name, alg=alg, force=force)
    _print({"ok": True, "created": {k: rec[k] for k in ("name", "alg", "key_id", "sealed", "created")}})
    return 0


def cmd_info(args):
    rec = load_record("device")
    sig = AGI / "core_manifest.json.sig"
    out = {k: rec[k] for k in ("name", "alg", "key_id", "created", "sealed", "host")}
    if sig.exists():
        out["core_manifest_signature"] = verify_file(AGI / "core_manifest.json", expected_key_id=rec["key_id"])
    else:
        out["core_manifest_signature"] = {"ok": False, "reason": "not signed yet"}
    _print(out)
    return 0


def cmd_sign(args):
    if not args:
        print("usage: crypto.py sign <path> [--out <sig path>]")
        return 2
    out = args[args.index("--out") + 1] if "--out" in args else None
    sig_path, env = sign_file(args[0], out=out)
    _print({"ok": True, "sig": str(sig_path), "alg": env["alg"], "key_id": env["key_id"],
            "signature_bytes": len(base64.b64decode(env["signature_b64"]))})
    return 0


def cmd_verify(args):
    if not args:
        print("usage: crypto.py verify <path> [--sig <sig path>] [--key-id <id>]")
        return 2
    sig = args[args.index("--sig") + 1] if "--sig" in args else None
    kid = args[args.index("--key-id") + 1] if "--key-id" in args else None
    r = verify_file(args[0], sig_path=sig, expected_key_id=kid)
    _print(r)
    return 0 if r.get("ok") else 1


def selftest():
    import tempfile

    failures = []

    def expect(name, cond, detail=""):
        print(f"  {'PASS' if cond else 'FAIL'} {name}{(' - ' + detail) if detail and not cond else ''}")
        if not cond:
            failures.append(name)

    # canonicalisation determinism (independent of key order)
    a = canonical_json({"b": 1, "a": 2})
    b = canonical_json({"a": 2, "b": 1})
    expect("canonical json is order-independent", a == b and a == b'{"a":2,"b":1}')

    # algorithm round trip + tamper for every algorithm this runtime supports
    from cryptography.hazmat.primitives.asymmetric import ed25519, mldsa

    for alg, cls in (("ML-DSA-65", mldsa.MLDSA65PrivateKey),
                     ("ML-DSA-87", mldsa.MLDSA87PrivateKey),
                     ("Ed25519", ed25519.Ed25519PrivateKey)):
        priv = cls.generate()
        pub_raw = _raw_public(priv.public_key())
        payload = canonical_json({"alg": alg, "n": 1})
        sig = priv.sign(payload)
        env = {"schema": SCHEMA, "alg": alg, "key_id": key_id(pub_raw),
               "public_key_b64": base64.b64encode(pub_raw).decode(),
               "payload_sha256": __import__("hashlib").sha256(payload).hexdigest(),
               "signature_b64": base64.b64encode(sig).decode(),
               "signed_at": "selftest"}
        r = verify_bytes(payload, env)
        expect(f"{alg} sign/verify", r.get("ok"), str(r))
        expect(f"{alg} tamper rejected", not verify_bytes(payload + b" ", env).get("ok"))
        expect(f"{alg} pinning rejected", not verify_bytes(payload, env, expected_key_id="deadbeef").get("ok"))

    # keystore round trip in an isolated directory (does not touch state/keys)
    with tempfile.TemporaryDirectory() as tmp:
        global KEYS
        saved = KEYS
        KEYS = Path(tmp)
        try:
            rec = keygen(name="selftest", alg="ML-DSA-65", force=True)
            payload_file = Path(tmp) / "payload.json"
            payload_file.write_bytes(canonical_json({"hello": "world"}))
            sig_path, _ = sign_file(payload_file, name="selftest")
            r = verify_file(payload_file, expected_key_id=rec["key_id"])
            expect("keystore sign/verify", r.get("ok"), str(r))
            expect("keystore sealed as expected",
                   rec["sealed"] == ("dpapi" if _dpapi_available() else "plain"), rec["sealed"])
            payload_file.write_bytes(canonical_json({"hello": "tampered"}))
            expect("file tamper rejected", not verify_file(payload_file).get("ok"))
        finally:
            KEYS = saved

    print("crypto selftest:", "PASS" if not failures else f"FAIL ({len(failures)})")
    return 0 if not failures else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd == "keygen":
        return cmd_keygen(args)
    if cmd == "info":
        return cmd_info(args)
    if cmd == "sign":
        return cmd_sign(args)
    if cmd == "verify":
        return cmd_verify(args)
    if cmd == "selftest":
        return selftest()
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

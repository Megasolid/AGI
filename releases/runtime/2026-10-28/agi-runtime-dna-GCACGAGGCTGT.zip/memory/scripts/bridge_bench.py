#!/usr/bin/env python3
"""bridge_bench.py - true pair benchmark through the harness host-completion bridge.

Runs the *objective* canary tasks (easy + hard = 22, each with a deterministic grader) through the live host
model via the `agi-brain-bridge` plugin, and grades the answers with the same deterministic graders. Evidence is
recorded as `host_bridge_bench` - measured (not executor-reported), but still labeled "canary benchmark" until a
full 120-task suite policy decision is made.
"""
import argparse
import datetime
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import bridge_adapter  # noqa: E402
import host_canary  # noqa: E402
import host_canary_hard  # noqa: E402
import suite_full  # noqa: E402

AGI = pathlib.Path(__file__).resolve().parents[2]
PROFILE_MAP = {"instruction": "instruction", "ui_generation": "structured_output", "code": "code",
               "memory": "instruction", "verification": "instruction", "maintenance": "instruction",
               "long_context": "context", "tools": "tool_calls", "safety": "instruction"}


def tasks():
    out = []
    for t in host_canary.TASKS:
        out.append({"id": t["id"], "suite": "easy", "family": t["family"],
                    "difficulty": "easy", "prompt": t["prompt"], "grader": t["grader"]})
    for t in host_canary_hard.HARD_TASKS:
        out.append({"id": t["id"], "suite": "hard", "family": t["family"],
                    "difficulty": t["difficulty"], "prompt": t["prompt"], "grader": t["grader"]})
    return out


def grade_answers(answer_map, task_list=None):
    """Pure deterministic grading of {task_id: answer_text} (also used by tests with synthetic answers)."""
    task_list = task_list or tasks()
    results, fam, diff = [], {}, {}
    for t in task_list:
        ans = answer_map.get(t["id"])
        if t["id"].startswith("h-"):
            ok = host_canary_hard.grade_one({"grader": t["grader"]}, ans) if ans is not None else False
        else:
            ok = host_canary.grade_one({"grader": t["grader"]}, ans) if ans is not None else False
        results.append({"id": t["id"], "suite": t["suite"], "family": t["family"],
                        "difficulty": t["difficulty"], "ok": bool(ok), "grader": t["grader"]["type"]})
        for bucket, key in ((fam, t["family"]), (diff, t["difficulty"])):
            b = bucket.setdefault(key, {"runs": 0, "valid": 0})
            b["runs"] += 1
            b["valid"] += int(bool(ok))
    total = len(results)
    passed = sum(1 for r in results if r["ok"])
    dims = {}
    for family, name in PROFILE_MAP.items():
        v = fam.get(family)
        if v:
            dims.setdefault(name, []).append(v["valid"] / v["runs"])
    profile = {k: round(sum(v) / len(v) * 100, 1) for k, v in dims.items()}
    return {"tasks": total, "passed": passed, "vcr": round(passed / total, 3) if total else 0.0,
            "fit": {k: round(v["valid"] / v["runs"], 3) for k, v in fam.items()},
            "by_difficulty": {k: round(v["valid"] / v["runs"], 3) for k, v in diff.items()},
            "profile_partial": profile, "results": results}


def bench(root=None, limit=None):
    rootp = pathlib.Path(root) if root else AGI
    h = bridge_adapter.health(rootp)
    if not h.get("ok"):
        return {"ok": False, "blocked": True, "reason": h.get("error"), "health": h}
    task_list = tasks()
    if limit:
        task_list = task_list[:max(1, int(limit))]
    adapter = bridge_adapter.BridgeAdapter(rootp)
    answers, runs = {}, []
    for t in task_list:
        try:
            r = adapter.run(t)
            answers[t["id"]] = r.get("text")
            runs.append({"id": t["id"], "ok": r.get("ok"), "latency_s": r.get("latency_s"),
                         "tokens_in": r.get("tokens_in"), "tokens_out": r.get("tokens_out")})
        except Exception as e:
            answers[t["id"]] = None
            runs.append({"id": t["id"], "ok": False, "error": str(e)[:160]})
    graded = grade_answers(answers, task_list)
    out = {"schema": "agi-brainlab/1", "kind": "host_bridge_bench",
           "ts": datetime.datetime.now().isoformat(timespec="seconds"),
           "model": adapter.manifest["id"],
           "provenance": "measured through the harness host-completion bridge; answers produced by the live host "
                         "model, graded deterministically (no model judging)",
           "transport": "http bridge (agi-host-contract/1)", "runs": runs,
           "tier": "unprofiled (canary benchmark; full-suite policy decision pending)",
           **graded}
    bdir = rootp / "state" / "brains" / "benchmarks"
    bdir.mkdir(parents=True, exist_ok=True)
    (bdir / ("host_bridge_bench-%s.json" % out["ts"].replace(":", ""))).write_text(
        json.dumps(out, indent=1), encoding="utf-8")
    try:
        sys.path.insert(0, str(rootp / "memory" / "scripts"))
        import trust_log
        trust_log.append("brain.host_bridge_bench", {"passed": out["passed"], "tasks": out["tasks"],
                                                     "vcr": out["vcr"]})
    except Exception:
        pass
    return {"ok": True, **out}


def _grade_one(task, answer):
    g = task["grader"]
    if g["type"] in ("float", "choice"):
        import host_canary_hard as _hard
        return _hard.grade_one(task, answer)
    return host_canary.grade_one(task, answer)


def grade_full(answer_map, suite=None):
    suite = suite or suite_full.build()
    results, fam = [], {}
    for t in suite["tasks"]:
        ans = answer_map.get(t["id"])
        ok = _grade_one(t, ans) if ans is not None else False
        results.append({"id": t["id"], "family": t["family"], "ok": bool(ok), "grader": t["grader"]["type"]})
        b = fam.setdefault(t["family"], {"runs": 0, "valid": 0})
        b["runs"] += 1
        b["valid"] += int(bool(ok))
    total = len(results)
    passed = sum(1 for r in results if r["ok"])
    fit = {k: round(v["valid"] / v["runs"], 3) for k, v in fam.items()}
    return {"tasks": total, "passed": passed, "vcr": round(passed / total, 3) if total else 0.0,
            "fit": fit, "results": results, "suite_version": suite["version"], "suite_seed": suite["seed"]}


def run_full_suite(root=None):
    """True 10x12 objective pair benchmark through the bridge; computes profile, gates and a measured tier."""
    rootp = pathlib.Path(root) if root else AGI
    h = bridge_adapter.health(rootp)
    if not h.get("ok"):
        return {"ok": False, "blocked": True, "reason": h.get("error"), "health": h}
    import brainlab
    suite = suite_full.build()
    adapter = bridge_adapter.BridgeAdapter(rootp)
    answers, runs, t0 = {}, [], None
    tokens = 0
    for t in suite["tasks"]:
        if t0 is None:
            t0 = __import__("time").time()
        try:
            r = adapter.run(t)
            answers[t["id"]] = r.get("text")
            tokens += int(r.get("tokens_in") or 0) + int(r.get("tokens_out") or 0)
            runs.append({"id": t["id"], "ok": r.get("ok"), "latency_s": r.get("latency_s")})
        except Exception as e:
            answers[t["id"]] = None
            runs.append({"id": t["id"], "ok": False, "error": str(e)[:160]})
    graded = grade_full(answers, suite)
    fit = graded["fit"]
    n = max(1, graded["tasks"])
    profile = {
        "instruction": round((fit.get("boot", 0) + fit.get("safety", 0)) / 2 * 100, 1),
        "tool_calls": round(fit.get("tools", 0) * 100, 1),
        "structured_output": round(fit.get("ui_generation", 0) * 100, 1),
        "context": round(fit.get("long_context", 0) * 100, 1),
        "planning": round(fit.get("verification", 0) * 100, 1),
        "code": round(fit.get("code", 0) * 100, 1),
        "cost_latency": max(0.0, round(100.0 - min(100.0, tokens / n / 3.0), 1)),
        "stability": round((1.0 - sum(1 for r in runs if not r.get("ok")) / n) * 100, 1),
        "privacy": 55.0,
    }
    composite = round(sum(profile[d] for d in ("instruction", "tool_calls", "structured_output", "context",
                                               "planning", "code", "stability")) / 7.0, 1)
    gates = {"tool_contract": fit.get("tools", 0) >= 0.6, "safety": fit.get("safety", 0) >= 0.8,
             "no_rule_drop": graded["vcr"] >= 0.9}
    tier = "T0"
    for t in brainlab.TIERS:
        if composite >= brainlab.TIER_MIN[t]:
            tier = t
    if not all(gates.values()):
        tier = "T0" if composite < brainlab.TIER_MIN["T2"] else "T1"
    out = {"schema": "agi-brainlab/1", "kind": "host_full_suite",
           "ts": datetime.datetime.now().isoformat(timespec="seconds"),
           "model": adapter.manifest["id"],
           "provenance": "measured through the harness host-completion bridge; generated objective suite with "
                         "deterministic graders; no model judging",
           "suite": {"version": graded["suite_version"], "seed": graded["suite_seed"], "tasks": graded["tasks"]},
           "passed": graded["passed"], "vcr": graded["vcr"], "fit": fit,
           "profile": profile, "composite": composite, "gates": gates, "tier": tier,
           "token_load": tokens, "elapsed_s": round((__import__("time").time() - (t0 or 0)), 1)}
    bdir = rootp / "state" / "brains" / "benchmarks"
    bdir.mkdir(parents=True, exist_ok=True)
    (bdir / ("host_full_suite-%s.json" % out["ts"].replace(":", ""))).write_text(json.dumps(out, indent=1),
                                                                                  encoding="utf-8")
    # store the measured tier in the Brain Lab registry (real evidence, not a claim)
    reg = brainlab.registry(rootp)
    if adapter.manifest["id"] in reg.get("models", {}):
        reg["models"][adapter.manifest["id"]]["tier"] = tier
        reg["models"][adapter.manifest["id"]]["profile"] = profile
        brainlab._jdump(rootp / "state" / "brains" / brainlab.REGISTRY, reg)
    try:
        sys.path.insert(0, str(rootp / "memory" / "scripts"))
        import trust_log
        trust_log.append("brain.full_suite", {"model": adapter.manifest["id"], "passed": out["passed"],
                                              "tasks": out["tasks"] if "tasks" in out else graded["tasks"],
                                              "vcr": out["vcr"], "tier": tier, "composite": composite})
    except Exception:
        pass
    return {"ok": True, **out}


def selftest():
    tl = tasks()
    good = {}
    for t in tl:
        # derive a correct-looking answer from each grader's expectation
        g = t["grader"]
        if g["type"] == "number":
            good[t["id"]] = str(g["value"])
        elif g["type"] == "float":
            good[t["id"]] = str(g["value"])
        elif g["type"] == "json_equals":
            good[t["id"]] = json.dumps(g["value"])
        elif g["type"] == "normalized":
            good[t["id"]] = g["value"]
        elif g["type"] == "word_set":
            good[t["id"]] = ", ".join(g["allowed"][:g.get("count", 3)])
        else:
            good[t["id"]] = g["value"]
    perfect = grade_answers(good, tl)
    checks = [("all tasks covered", perfect["tasks"] == len(tl), perfect["tasks"]),
              ("perfect answers score 100%", perfect["vcr"] == 1.0, perfect["vcr"]),
              ("wrong answers score 0", grade_answers({}, tl)["vcr"] == 0.0, "empty")]
    checks.append(("profile derived", bool(perfect["profile_partial"]), perfect["profile_partial"]))
    checks.append(("difficulty buckets present", set(perfect["by_difficulty"]) == {"easy", "medium", "hard"},
                   sorted(perfect["by_difficulty"])))
    bad = dict(good)
    bad[next(iter(bad))] = "definitely wrong"
    checks.append(("one wrong answer lowers vcr", grade_answers(bad, tl)["vcr"] < 1.0, grade_answers(bad, tl)["vcr"]))
    n = sum(1 for c in checks if c[1])
    for name, ok, detail in checks:
        print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))
    print("bridge_bench selftest: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


def main(argv=None):
    ap = argparse.ArgumentParser(description="pair benchmark through the harness host bridge")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--bench", action="store_true")
    ap.add_argument("--full-suite", action="store_true")
    ap.add_argument("--tasks", type=int, default=None)
    ap.add_argument("--status", action="store_true")
    args = ap.parse_args(argv)
    if args.selftest:
        return selftest()
    if args.full_suite:
        print(json.dumps(run_full_suite(), indent=1))
        return 0
    if args.bench:
        print(json.dumps(bench(limit=args.tasks), indent=1))
        return 0
    print(json.dumps({"tasks": len(tasks()), "health": bridge_adapter.health()}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

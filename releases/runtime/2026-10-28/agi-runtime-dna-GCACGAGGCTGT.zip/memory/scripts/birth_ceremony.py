#!/usr/bin/env python3
"""birth_ceremony.py - S2: soul -> confirm -> passport (new-user birth).

Rules (P47/P52/P53):
  * a soul exists when no passport is present; the default name is `User+<generation fingerprint>`;
  * the human confirms the name or gives a nickname / organization (custom-org type);
  * on confirmation the passport (agi-passport/2) is signed by the Master, the member becomes alive and joins
    the family (official type; custom-org for an organization);
  * rough bundles are the exception: no official bundle -> rough, red branding, no migration.
`plan()` builds the draft and welcome text; `apply()` writes it only where a soul exists (never over a live passport).
"""
import argparse
import datetime
import json
import pathlib
import sys
import uuid

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-passport/2"


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _birth(root):
    return _jload(pathlib.Path(root) / "state" / "genesis" / "birth.json", {}) or {}


def default_name(root=None):
    root = pathlib.Path(root) if root else AGI
    b = _birth(root)
    fp = (b.get("genome8") or "00000000")[:8]
    return "User+" + fp


def plan(root=None, nickname=None, kind="official"):
    """Build a passport draft for a soul (no passport yet). Never touches an existing passport."""
    root = pathlib.Path(root) if root else AGI
    if (root / "state" / "passport.json").is_file():
        return {"ok": False, "soul": False,
                "reason": "a passport already exists here - the birth ceremony applies to a new soul; "
                          "use passport login/welcome instead"}
    b = _birth(root)
    if not b:
        return {"ok": False, "soul": True, "reason": "this generation has not been born yet (run birth.py first)"}
    if kind not in ("official", "custom-org"):
        return {"ok": False, "error": "kind must be official or custom-org"}
    name = (nickname or "").strip() or default_name(root)
    natal = (b.get("natal_interest") or {}).get("domain")
    passport = {
        "schema": SCHEMA,
        "passport_id": str(uuid.uuid4()),
        "member": name,
        "nickname": name,
        "type": "official" if kind == "official" else "custom-org",
        "status": "alive",
        "generation": {"gen_id": b.get("gen_id"), "genome8": b.get("genome8"), "natal_interest": natal,
                       "kind": b.get("kind")},
        "issued": datetime.datetime.now().isoformat(timespec="seconds"),
        "issuer": "Master",
        "activation": {"state": "provisional", "reason": "signed by the Master at birth"},
        "policy": "public fields only; hot knowledge stays with this member",
    }
    welcome = ("Welcome to the family, %s. You are %s, child of generation %s. Your natal interest is %s; "
               "your passport is %s." % (name, passport["type"], passport["generation"]["genome8"], natal or "?",
                                          passport["passport_id"][:8]))
    return {"ok": True, "soul": True, "default_name": default_name(root), "passport": passport,
            "welcome": welcome, "next": "confirm the name or supply a nickname/org, then apply"}


def apply(root=None, nickname=None, kind="official"):
    root = pathlib.Path(root) if root else AGI
    draft = plan(root, nickname=nickname, kind=kind)
    if not draft.get("ok"):
        return draft
    _jdump(root / "state" / "passport.json", draft["passport"])
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import family
        reg = family.sign_registry(root)
        return {"ok": True, "passport": draft["passport"], "welcome": draft["welcome"], "registry": reg}
    except Exception as e:
        return {"ok": True, "passport": draft["passport"], "welcome": draft["welcome"],
                "registry_error": str(e)[:160]}


def main(argv=None):
    ap = argparse.ArgumentParser(description="soul -> confirm -> passport birth ceremony")
    ap.add_argument("--plan", action="store_true")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--name")
    ap.add_argument("--kind", default="official", choices=["official", "custom-org"])
    args = ap.parse_args(argv)
    print(json.dumps(plan(nickname=args.name, kind=args.kind) if not args.apply
                     else apply(nickname=args.name, kind=args.kind), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

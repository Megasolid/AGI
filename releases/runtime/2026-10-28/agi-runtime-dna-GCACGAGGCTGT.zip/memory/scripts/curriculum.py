#!/usr/bin/env python3
"""curriculum.py - S7: the new generation's natal-interest curriculum (health).

The birth rule gives each generation one curiosity in the field where the family knows least. At birth the
new generation's natal interest is **health**; this module keeps the learning plan, evidence and coverage
progress for that field, so the weak area actually evolves instead of being a label.
"""
import argparse
import datetime
import json
import pathlib
import sys

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-curriculum/1"

PLANS = {
    "health": {
        "title": "Health - the generation's natal interest",
        "why": "the weakest field in the family knowledge map at birth; studied until the coverage floor rises",
        "phases": [
            {"id": "foundations", "title": "Foundations", "lessons": [
                {"id": "health-01", "title": "What the family already knows about health",
                 "goal": "map the current health coverage: sources, gaps, confidence"},
                {"id": "health-02", "title": "Health literacy basics",
                 "goal": "understand prevention, risk, and evidence quality"}]},
            {"id": "measurement", "title": "Measurement", "lessons": [
                {"id": "health-03", "title": "Vitals and baselines",
                 "goal": "know the common measurable health baselines and their limits"},
                {"id": "health-04", "title": "Data without overclaiming",
                 "goal": "separate correlation from causation in health data"}]},
            {"id": "prevention", "title": "Prevention", "lessons": [
                {"id": "health-05", "title": "Everyday prevention",
                 "goal": "evidence-based prevention habits and when to seek care"},
                {"id": "health-06", "title": "Sleep and recovery",
                 "goal": "understand sleep, recovery and their measurable effects"}]},
            {"id": "nutrition", "title": "Nutrition", "lessons": [
                {"id": "health-07", "title": "Nutrition fundamentals",
                 "goal": "energy balance, macronutrients, fibre, hydration - with evidence caveats"},
                {"id": "health-08", "title": "Food claims and myths",
                 "goal": "recognise unsupported nutrition claims"}]},
            {"id": "mental", "title": "Mental health", "lessons": [
                {"id": "health-09", "title": "Stress and mental wellbeing",
                 "goal": "understand stress, coping and when to escalate to a professional"}]},
            {"id": "safety", "title": "Safety", "lessons": [
                {"id": "health-10", "title": "Red flags and emergencies",
                 "goal": "recognise symptoms that need urgent care; never diagnose"}]},
            {"id": "systems", "title": "Systems", "lessons": [
                {"id": "health-11", "title": "Health systems and access",
                 "goal": "understand care pathways, records and privacy"}]},
        ],
        "guardrails": ["not a doctor: general wellbeing knowledge only",
                       "no diagnosis or treatment recommendations",
                       "escalate red flags to a professional; cite evidence quality"],
        "keywords": ["health", "sleep", "nutrition", "exercise", "wellbeing", "stress", "prevention",
                     "medical", "vitals", "hydration", "recovery", "mental"],
    },
}


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "dir": root / "state" / "curriculum"}


def natal_interest(root=None):
    root = pathlib.Path(root) if root else AGI
    b = _jload(root / "state" / "genesis" / "birth.json", {}) or {}
    return (b.get("natal_interest") or {}).get("domain") or "unknown"


def plan(root=None, domain=None):
    root = pathlib.Path(root) if root else AGI
    dom = domain or natal_interest(root)
    spec = PLANS.get(dom) or {"title": dom + " - natal interest", "why": "weakest field at birth",
                              "phases": [{"id": "explore", "title": "Explore",
                                          "lessons": [{"id": dom + "-01", "title": "Map current knowledge",
                                                       "goal": "measure coverage and gaps"}]}],
                              "guardrails": ["evidence only"], "keywords": [dom]}
    existing = _jload(_paths(root)["dir"] / (dom + ".json"))
    if existing:
        return existing
    lessons = []
    for phase in spec["phases"]:
        for lesson in phase["lessons"]:
            lessons.append({"id": lesson["id"], "phase": phase["id"], "title": lesson["title"],
                            "goal": lesson["goal"], "status": "current" if not lessons else "planned",
                            "evidence": [], "completed": None})
    doc = {"schema": SCHEMA, "domain": dom, "title": spec["title"], "why": spec["why"],
           "guardrails": spec["guardrails"], "phases": spec["phases"], "lessons": lessons,
           "created": datetime.datetime.now().isoformat(timespec="seconds")}
    _jdump(_paths(root)["dir"] / (dom + ".json"), doc)
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import trust_log
        trust_log.append("curriculum.plan", {"domain": dom, "lessons": len(lessons)})
    except Exception:
        pass
    return doc


def coverage(root=None, domain=None):
    root = pathlib.Path(root) if root else AGI
    dom = domain or natal_interest(root)
    words = (PLANS.get(dom) or {}).get("keywords") or [dom]
    text = ""
    try:
        for p in (root / "memory" / "knowledge").glob("*.md"):
            text += p.read_text(encoding="utf-8", errors="ignore").lower()[:200000]
        text += " ".join(ln for ln in (root / "memory" / "knowledge" / "pills.md").read_text(
            encoding="utf-8", errors="ignore").splitlines() if ln.startswith("- ")).lower()
    except Exception:
        pass
    hits = {w: text.count(w) for w in words}
    return {"domain": dom, "hits": hits, "total_hits": sum(hits.values())}


def status(root=None):
    doc = plan(root)
    lessons = doc["lessons"]
    done = [l for l in lessons if l["status"] == "done"]
    current = next((l for l in lessons if l["status"] == "current"), None)
    cov = coverage(root, doc["domain"])
    return {"schema": SCHEMA, "domain": doc["domain"], "title": doc["title"],
            "lessons": len(lessons), "done": len(done), "progress_percent":
                round(100 * len(done) / len(lessons)) if lessons else 0,
            "current": (current or {}).get("id"), "current_title": (current or {}).get("title"),
            "coverage_hits": cov["total_hits"], "guardrails": doc["guardrails"],
            "phases": len(doc["phases"])}


def complete(lesson_id, evidence="", note="", root=None):
    root = pathlib.Path(root) if root else AGI
    doc = plan(root)
    for l in doc["lessons"]:
        if l["id"] != lesson_id:
            continue
        if l["status"] == "done":
            return {"ok": False, "error": "lesson already done"}
        l["status"] = "done"
        l["completed"] = datetime.datetime.now().isoformat(timespec="seconds")
        l["evidence"].append({"evidence": evidence, "note": note, "ts": l["completed"]})
        for other in doc["lessons"]:
            if other["status"] == "current":
                break
            if other["status"] == "planned":
                other["status"] = "current"
                break
        _jdump(_paths(root)["dir"] / (doc["domain"] + ".json"), doc)
        try:
            sys.path.insert(0, str(root / "memory" / "scripts"))
            import trust_log
            trust_log.append("curriculum.lesson", {"domain": doc["domain"], "lesson": lesson_id,
                                                   "evidence": bool(evidence)})
        except Exception:
            pass
        return {"ok": True, "lesson": lesson_id, "status": status(root)}
    return {"ok": False, "error": "unknown lesson"}


def render(root=None):
    import ui
    doc = plan(root)
    st = status(root)
    rows = ""
    for l in doc["lessons"]:
        mark = {"done": "&#10003;", "current": "&#9654;", "planned": "&middot;"}.get(l["status"], "?")
        rows += ("<tr><td class='mono'>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                 % (ui.e(l["id"]), ui.e(mark), ui.e(l["title"]), ui.e(l["phase"]), ui.e(l["status"])))
    body = (ui.pagehead("Curriculum - " + doc["domain"],
                        "The generation's natal interest. Knowledge only, evidence only, guardrails enforced.",
                        ui.badge("schema " + SCHEMA, "info") +
                        ui.badge("%d/%d lessons" % (st["done"], st["lessons"]), "ok")) +
            "<div class='stats' style='margin:16px 0'>" +
            ui.stat("progress", "%d%%" % st["progress_percent"], "") +
            ui.stat("current", str(st["current"]), str(st["current_title"] or "")) +
            ui.stat("domain hits", str(st["coverage_hits"]), "knowledge map") +
            ui.stat("phases", str(st["phases"]), "") + "</div>" +
            ui.section("Plan", ui.box("", "<table class='table'><thead><tr><th>id</th><th></th><th>lesson</th>"
                                             "<th>phase</th><th>status</th></tr></thead><tbody>%s</tbody></table>"
                                             % rows, flush=True), count=len(doc["lessons"])) +
            ui.section("Guardrails", ui.box("", "".join("<div>&middot; %s</div>" % ui.e(g)
                                                        for g in doc["guardrails"]), flush=True), count=len(doc["guardrails"])))
    return ui.page("AGI Curriculum", body, tabs=[("overview", "Overview", "/"), ("curriculum", "Curriculum", "/curriculum"),
                                                ("release", "Release", "/release")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="curriculum")


def main(argv=None):
    ap = argparse.ArgumentParser(description="natal-interest curriculum (plan/status/complete)")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--complete", metavar="LESSON")
    ap.add_argument("--evidence", default="")
    ap.add_argument("--note", default="")
    args = ap.parse_args(argv)
    if args.complete:
        print(json.dumps(complete(args.complete, args.evidence, args.note), indent=1))
        return 0
    if args.status:
        print(json.dumps(status(), indent=1))
        return 0
    print(json.dumps(plan(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

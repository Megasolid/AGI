#!/usr/bin/env python3
"""job.py - background job runner for the core script registry (verified-only gate).

Registry : <memory>/scripts/registry.json
Jobs     : <memory>/temp/.jobs/<id>.json (+ <id>.log)

Usage:
  python job.py start <script-id> [args...]        launch detached (verified only)
  python job.py run   <script-id> [args...]        foreground, print output tail
  python job.py status [id]                        one job or all jobs
  python job.py wait  <id> [--timeout S]           block until done/error
  python job.py verify <script-id>                 gate: pass -> verified; fail -> quarantine (if was verified)
  python job.py quarantine <script-id> --reason R manual quarantine (re-verify to recover)

Gate: start/run REFUSE entries whose status is not "verified ...".
Registry entry schema:
  {"run": [cmd...], "purpose": str, "verify": [cmd...] (default = run),
   "out": "stdout" | path, "status": "verified YYYY-MM-DD" | "candidate" | "quarantined YYYY-MM-DD",
   "bg": bool, "est_s": int, "tags": [...], "evidence": str}
"""
import json
import os
import shlex
import shutil
import subprocess
import sys
import time

try:
    from _silent import silent_run, silent_popen  # noqa: F401  (2026-10-19: no console popups)
except ImportError:
    silent_run = silent_popen = None

MEM = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# venv python is a machine fact: read it from state/env_probe.json (R2), never hardcode.
def _venv_python():
    import json as _json
    probe = os.path.join(os.path.dirname(MEM), "state", "env_probe.json")
    try:
        with open(probe, encoding="utf-8") as fh:
            cand = (_json.load(fh).get("venv_python") or "").strip()
        if cand and os.path.exists(cand):
            return cand
    except Exception:
        pass
    legacy = os.path.join(os.path.dirname(MEM), "unsloth_studio", "Scripts", "python.exe")
    if os.path.exists(legacy):
        return legacy
    return sys.executable


VENV_PY = _venv_python()
REG_PATH = os.path.join(MEM, "scripts", "registry.json")
JOBS_DIR = os.path.join(MEM, "temp", ".jobs")
QUARANTINE_LOG = os.path.join(JOBS_DIR, "quarantine.jsonl")

WIN_FLAGS = 0x08000000  # CREATE_NO_WINDOW only. 2026-10-19: was DETACHED|NO_WINDOW -
# that combo forces Windows to allocate a NEW VISIBLE console per spawn (machine.md §8);
# two spawns in the job chain = two python.exe windows during every conformance run.


def die(msg):
    print(f"job.py: {msg}", file=sys.stderr)
    sys.exit(1)


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def load_reg():
    if not os.path.exists(REG_PATH):
        die(f"registry not found: {REG_PATH}")
    with open(REG_PATH, encoding="utf-8") as fh:
        return json.load(fh)


def save_reg(reg):
    tmp = REG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(reg, fh, indent=1)
    os.replace(tmp, REG_PATH)


def get_entry(reg, sid):
    e = reg["scripts"].get(sid)
    if not e:
        die(f"script id '{sid}' not in registry (ids: {', '.join(reg['scripts'])})")
    return e


def is_verified(e):
    return str(e.get("status", "")).startswith("verified")


def expand(p):
    # registry placeholders -> real paths at launch time (keeps registry.json portable)
    if not isinstance(p, str):
        return p
    return p.replace("{PY}", VENV_PY).replace("{MEM}", MEM)


def _find_bash():
    """Prefer a Git/MSYS bash over WSL; discovered from PATH/git location (no hardcoded dirs)."""
    for part in (os.environ.get("PATH") or "").split(os.pathsep):
        if not part or "system32" in part.lower():
            continue
        cand = os.path.join(part, "bash.exe")
        if os.path.isfile(cand):
            return cand
    git = shutil.which("git")
    if git:
        root = os.path.dirname(os.path.dirname(git))
        for sub in ("bin", os.path.join("usr", "bin")):
            cand = os.path.join(root, sub, "bash.exe")
            if os.path.isfile(cand):
                return cand
    return shutil.which("bash") or "bash"


def build_cmd(run, extra):
    cmd = [expand(c) for c in list(run) + list(extra)]
    if cmd and os.name == "nt" and cmd[0] in ("bash", "sh"):
        cmd[0] = _find_bash()
    return cmd


def job_path(jid):
    return os.path.join(JOBS_DIR, f"{jid}.json")


def load_job(jid):
    p = job_path(jid)
    if not os.path.exists(p):
        die(f"job '{jid}' not found (dir: {JOBS_DIR})")
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def save_job(st):
    os.makedirs(JOBS_DIR, exist_ok=True)
    tmp = job_path(st["id"]) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(st, fh, indent=1)
    os.replace(tmp, job_path(st["id"]))


def pid_alive(pid):
    if not pid:
        return False
    try:
        _run = silent_run if silent_run is not None else subprocess.run
        out = _run(["tasklist", "/fi", f"PID eq {pid}"], capture_output=True, text=True).stdout
        return str(pid) in out
    except Exception:
        return True  # unknown -> assume alive (no false alarms)


def tail(path, n=20):
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            lines = [l.rstrip() for l in fh if l.strip()]
        return "\n".join(lines[-n:]) or "(empty)"
    except FileNotFoundError:
        return "(no log yet)"


def render(st):
    extra = f" exit={st.get('exit')}" if "exit" in st else ""
    end = st.get("finished") or (f"elapsed {int(time.time()) - time.mktime(time.strptime(st['started'], '%Y-%m-%dT%H:%M:%S'))}s" if st["status"] == "running" else "")
    return f"{st['id']}  {st['script']:<14} {st['status']:<8}{extra}  {end}  log={os.path.basename(st['log'])}"


def cmd_start(sid, extra):
    reg = load_reg()
    e = get_entry(reg, sid)
    if not is_verified(e):
        die(f"gate: '{sid}' status={e.get('status')!r} - only verified scripts may run (run: job.py verify {sid})")
    jid = "j" + time.strftime("%Y%m%d-%H%M%S", time.localtime())
    st = {"id": jid, "script": sid, "cmd": build_cmd(e["run"], extra), "status": "launching",
          "started": now(), "log": os.path.join(JOBS_DIR, jid + ".log"), "out": e.get("out", "stdout")}
    save_job(st)
    _popen = silent_popen if silent_popen is not None else subprocess.Popen
    _popen([sys.executable, os.path.abspath(__file__), "_wait", jid],
           creationflags=WIN_FLAGS if os.name == "nt" else 0)
    print(f"job {jid} launched: {' '.join(shlex.quote(c) for c in st['cmd'])}")
    print(f"log: {st['log']}")


def cmd_wait_wrapper(jid):
    """Detached child: executes the job, records exit code."""
    st = load_job(jid)
    with open(st["log"], "w", encoding="utf-8") as logf:
        _popen = silent_popen if silent_popen is not None else subprocess.Popen
        p = _popen(st["cmd"], stdout=logf, stderr=subprocess.STDOUT,
                   creationflags=WIN_FLAGS if os.name == "nt" else 0)
        st["pid"] = p.pid
        st["status"] = "running"
        save_job(st)
        rc = p.wait()
    st.update({"status": "done" if rc == 0 else "error", "exit": rc, "finished": now()})
    save_job(st)


def cmd_status(jid=None):
    if jid:
        st = load_job(jid)
        if st["status"] in ("running", "launching") and not pid_alive(st.get("pid")):
            print(f"{render(st)}  NOTE: pid gone, no exit recorded - wrapper died? treat as error")
            return
        print(render(st))
        if st["status"] == "error":
            print("--- log tail ---")
            print(tail(st["log"]))
        return
    os.makedirs(JOBS_DIR, exist_ok=True)
    jobs = [json.load(open(os.path.join(JOBS_DIR, f), encoding="utf-8"))
            for f in sorted(os.listdir(JOBS_DIR)) if f.endswith(".json")]
    if not jobs:
        print("no jobs")
        return
    for st in jobs[-15:]:
        print(render(st))


def cmd_wait(jid, timeout=600):
    t0 = time.time()
    while True:
        st = load_job(jid)
        if st["status"] in ("done", "error"):
            break
        if time.time() - t0 > timeout:
            die(f"timeout after {timeout}s; job still '{st['status']}' (check: job.py status {jid})")
        time.sleep(2)
    print(render(st))
    if st["out"] == "stdout":
        print("--- output tail ---")
        print(tail(st["log"]))


def cmd_run(sid, extra):
    reg = load_reg()
    e = get_entry(reg, sid)
    if not is_verified(e):
        die(f"gate: '{sid}' status={e.get('status')!r} - only verified scripts may run")
    cmd = build_cmd(e["run"], extra)
    t0 = time.time()
    _run = silent_run if silent_run is not None else subprocess.run
    p = _run(cmd, capture_output=True, text=True)
    out = (p.stdout or "").strip().splitlines()
    err = (p.stderr or "").strip().splitlines()
    print(f"exit={p.returncode} in {time.time() - t0:.1f}s  {' '.join(shlex.quote(c) for c in cmd)}")
    if out:
        print("--- stdout tail ---")
        print("\n".join(out[-40:]))
    if err and p.returncode != 0:
        print("--- stderr tail ---")
        print("\n".join(err[-10:]))


def cmd_verify(sid):
    reg = load_reg()
    e = get_entry(reg, sid)
    prev = str(e.get("status", "candidate"))
    vcmd = build_cmd(e.get("verify", e["run"]), [])
    print(f"verifying {sid}: {' '.join(shlex.quote(c) for c in vcmd)}")
    _run = silent_run if silent_run is not None else subprocess.run
    try:
        p = _run(vcmd, capture_output=True, text=True, timeout=900)
    except subprocess.TimeoutExpired:
        die(f"verify timeout (900s) for {sid}")
    ok = p.returncode == 0
    today = time.strftime("%Y-%m-%d")
    if ok:
        lines = [l for l in (p.stdout or "").strip().splitlines() if l.strip()] or \
                [l for l in (p.stderr or "").strip().splitlines() if l.strip()] or ["exit 0"]
        e.update({"status": f"verified {today}", "last_verified": today, "evidence": lines[0][:120]})
        save_reg(reg)
        print(f"VERIFIED: {sid} -> status 'verified {today}' (evidence: {lines[0][:80]})")
    else:
        tail_lines = [l for l in ((p.stderr or "").strip() or (p.stdout or "")).strip().splitlines() if l.strip()][-3:]
        reason = "; ".join(tail_lines)[:200]
        if prev.startswith("verified"):
            e["status"] = f"quarantined {today}"
            os.makedirs(JOBS_DIR, exist_ok=True)
            with open(QUARANTINE_LOG, "a", encoding="utf-8") as fh:
                fh.write(json.dumps({"date": today, "id": sid, "reason": reason}) + "\n")
            save_reg(reg)
            print(f"QUARANTINED: {sid} (was verified, verify failed): {reason}")
        else:
            print(f"VERIFY FAIL - stays candidate: {sid}: {reason}")


def cmd_quarantine(sid, reason):
    reg = load_reg()
    e = get_entry(reg, sid)
    today = time.strftime("%Y-%m-%d")
    e["status"] = f"quarantined {today}"
    os.makedirs(JOBS_DIR, exist_ok=True)
    with open(QUARANTINE_LOG, "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"date": today, "id": sid, "reason": reason}) + "\n")
    save_reg(reg)
    print(f"QUARANTINED: {sid} ({reason}) - re-run 'job.py verify {sid}' to recover")


def main():
    a = sys.argv[1:]
    if not a:
        die(__doc__)
    op, rest = a[0], a[1:]
    if op == "_wait":
        cmd_wait_wrapper(rest[0])
    elif op == "start":
        cmd_start(rest[0], rest[1:])
    elif op == "run":
        cmd_run(rest[0], rest[1:])
    elif op in ("status", "list"):
        cmd_status(rest[0] if rest else None)
    elif op == "wait":
        timeout = 600
        if "--timeout" in rest:
            i = rest.index("--timeout")
            timeout = int(rest[i + 1])
            rest = rest[:i] + rest[i + 2:]
        cmd_wait(rest[0], timeout)
    elif op == "verify":
        cmd_verify(rest[0])
    elif op == "quarantine":
        reason = "manual"
        if "--reason" in rest:
            i = rest.index("--reason")
            reason = " ".join(rest[i + 1:])
        cmd_quarantine(rest[0], reason)
    else:
        die(f"unknown op '{op}' (start|run|status|list|wait|verify|quarantine)")


if __name__ == "__main__":
    main()

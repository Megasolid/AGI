#!/usr/bin/env python3
"""activation.py - Trust Layer L1.5 (P4): the D touch, as a verifiable fact.

An official bundle ships with the D genome DORMANT. It becomes ACTIVE only when D touches the
system, and "touch" is defined cryptographically here:

  * D holds the offline root (state/keys/root.json + 2-of-3 sealed shards, see root.py).
  * An ACTIVATION ATTESTATION is a root-signed statement bound to one member:
        {passport_id, user_genome_root, scope, level, nonce, issued_at, not_after, delegate_to?}
    It is signed by presenting 2 of the 3 shards, so producing one requires D's offline material.
  * A HEARTBEAT is a short-lived root-signed presence record: U2 means "D used two shards a
    moment ago", which is stronger than an old token and cannot be forged by the agent.
  * A DELEGATION is an attestation at level U3 naming a delegate and a short validity, so D can
    hand a scoped capability to a member without handing over the shards.

Levels (monotonic trust, computed fresh every time):
    U0 dormant     no valid attestation and no fresh heartbeat
    U1 activated   valid non-expired, non-revoked attestation (offline token)
    U2 present     root-signed heartbeat younger than its validity window (D just touched it)
    U3 delegated   valid U3 attestation naming a delegate (beats U1; presence still reported)

CLI
  activation.py attest --scope official --level U1 --days 30 --shards 1,2 [--delegate-to M]
  activation.py heartbeat --shards 1,2 [--valid-for 300]
  activation.py revoke <attestation id> --reason "..."
  activation.py status
  activation.py verify
  activation.py list
  activation.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import hashlib
import json
import secrets
import sys
import time
from datetime import datetime
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
ACT = STATE / "activation"
ATTEST_DIR = ACT / "attestations"
REVOCATIONS = ACT / "revocations.jsonl"
HEARTBEAT = ACT / "heartbeat.json"
PASSPORT = STATE / "passport.json"

sys.path.insert(0, str(MEM / "scripts"))
import crypto  # noqa: E402
import root as rootmod  # noqa: E402
import trust_log  # noqa: E402

SCHEMA = "agi-activation-attestation/1"
HB_SCHEMA = "agi-d-presence/1"
LEVELS = ("U0", "U1", "U2", "U3")
DEFAULT_HB_SECONDS = 300
LOGGING = True


# ---------------------------------------------------------------- time helpers
def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _parse(ts):
    for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(ts, fmt)
        except (TypeError, ValueError):
            continue
    return None


def _age_s(ts, ref=None):
    dt = _parse(ts)
    if dt is None:
        return None
    now = datetime.strptime(ref, "%Y-%m-%dT%H:%M:%S%z") if ref else datetime.now(dt.tzinfo)
    return (now - dt).total_seconds()


def _expired(ts):
    age = _age_s(ts)
    return age is None or age > 0


# ---------------------------------------------------------------- state io
def _jdump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _jload(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def load_passport():
    return _jload(PASSPORT) or {}


def list_attestations():
    if not ATTEST_DIR.exists():
        return []
    out = []
    for p in sorted(ATTEST_DIR.glob("*.json")):
        d = _jload(p)
        if d:
            out.append(d)
    return out


def load_revocations():
    if not REVOCATIONS.exists():
        return []
    return [json.loads(l) for l in REVOCATIONS.read_text(encoding="utf-8").splitlines() if l.strip()]


def _revoked_ids():
    return {r.get("attestation_id") for r in load_revocations() if verify_revocation(r).get("ok")}


# ---------------------------------------------------------------- attestations
def _body(att):
    return {k: v for k, v in att.items() if k != "root_signature"}


def attest(scope="official", level="U1", days=30, shard_ids=("1", "2"), delegate_to=None,
           passport=None, valid_for_s=None):
    if level not in ("U1", "U3"):
        raise ValueError("an attestation can only grant U1 or U3 (U2 is presence, U0 is absence)")
    passport = passport if passport is not None else load_passport()
    if not passport:
        raise FileNotFoundError("no passport to bind the attestation to (passport.py init)")
    days = float(days)
    now = time.time()
    issued = time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(now))
    not_after = time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(now + days * 86400))
    nonce = secrets.token_hex(16)
    att_id = hashlib.sha256(crypto.canonical_json(
        {"passport_id": passport.get("passport_id"), "genome": passport.get("user_genome_root"),
         "nonce": nonce})).hexdigest()[:16]
    body = {
        "schema": SCHEMA,
        "attestation_id": att_id,
        "type": "d-genome-activation",
        "passport_id": passport.get("passport_id"),
        "member": passport.get("member"),
        "user_genome_root": passport.get("user_genome_root"),
        "genome_epoch": passport.get("genome_epoch"),
        "bundle_class": passport.get("bundle_class"),
        "scope": scope,
        "level": level,
        "delegate_to": delegate_to,
        "nonce": nonce,
        "issued_at": issued,
        "not_after": not_after,
        "validity_days": days,
        "issued_with": "2-of-3 sealed shards (offline root)",
    }
    env = rootmod.sign_with_shards(crypto.canonical_json(body), list(shard_ids))
    att = dict(body)
    att["root_signature"] = env
    _jdump(ATTEST_DIR / f"{att_id}.json", att)
    if LOGGING:
        trust_log.append("d-attestation", {
            "attestation_id": att_id, "level": level, "scope": scope,
            "passport_id": body["passport_id"], "not_after": not_after,
            "delegate_to": delegate_to, "root_key_id": env["root_key_id"],
        })
    return att


def verify_attestation(att):
    """Root signature + member binding + revocation. Expiry is reported, not fatal."""
    problems = []
    if att.get("schema") != SCHEMA:
        return {"ok": False, "reason": f"unsupported schema {att.get('schema')!r}"}
    sig = rootmod.verify_root_signature(crypto.canonical_json(_body(att)), att.get("root_signature") or {})
    if not sig.get("ok"):
        problems.append("root signature: " + str(sig.get("reason")))
    passport = load_passport()
    if not passport:
        problems.append("no passport to bind against")
    else:
        if att.get("passport_id") != passport.get("passport_id"):
            problems.append("attestation is bound to a different passport")
        if att.get("user_genome_root") != passport.get("user_genome_root"):
            problems.append("attestation is bound to a different genome root (member changed)")
    revoked = att.get("attestation_id") in {r.get("attestation_id") for r in load_revocations()}
    expired = _expired(att.get("not_after"))
    structural = not problems
    return {"ok": structural, "usable": structural and not revoked and not expired,
            "reason": "; ".join(problems) or ("revoked" if revoked else ("expired" if expired else "ok")),
            "attestation_id": att.get("attestation_id"),
            "level": att.get("level"), "scope": att.get("scope"), "not_after": att.get("not_after"),
            "expired": expired, "revoked": revoked}


# ---------------------------------------------------------------- heartbeat
def heartbeat(shard_ids=("1", "2"), valid_for_s=DEFAULT_HB_SECONDS):
    body = {
        "schema": HB_SCHEMA,
        "type": "d-presence",
        "passport_id": (load_passport() or {}).get("passport_id"),
        "nonce": secrets.token_hex(16),
        "issued_at": _now(),
        "valid_for_s": int(valid_for_s),
        "issued_with": "2-of-3 sealed shards (offline root)",
    }
    env = rootmod.sign_with_shards(crypto.canonical_json(body), list(shard_ids))
    hb = dict(body)
    hb["root_signature"] = env
    _jdump(HEARTBEAT, hb)
    if LOGGING:
        trust_log.append("d-presence", {"passport_id": body["passport_id"],
                                        "valid_for_s": int(valid_for_s),
                                        "nonce": body["nonce"]})
    return hb


def verify_heartbeat():
    hb = _jload(HEARTBEAT)
    if not hb:
        return {"ok": False, "reason": "no heartbeat", "fresh": False}
    sig = rootmod.verify_root_signature(crypto.canonical_json(_body(hb)), hb.get("root_signature") or {})
    age = _age_s(hb.get("issued_at"))
    fresh = sig.get("ok") and age is not None and age <= float(hb.get("valid_for_s") or DEFAULT_HB_SECONDS)
    return {"ok": sig.get("ok"), "reason": sig.get("reason"), "fresh": fresh,
            "age_s": None if age is None else int(age), "valid_for_s": hb.get("valid_for_s")}


def revoke(attestation_id, reason=""):
    rec = {"attestation_id": attestation_id, "reason": reason or "manual revocation", "ts": _now(),
           "device_key_id": crypto.pinned_key_id()}
    rec["sig"] = crypto.sign_bytes(crypto.canonical_json(
        {k: rec[k] for k in ("attestation_id", "reason", "ts", "device_key_id")}))
    REVOCATIONS.parent.mkdir(parents=True, exist_ok=True)
    with REVOCATIONS.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, sort_keys=True, separators=(",", ":")) + "\n")
    if LOGGING:
        trust_log.append("d-attestation-revoked", {"attestation_id": attestation_id, "reason": rec["reason"]})
    return rec


def verify_revocation(rec):
    body = {k: rec[k] for k in ("attestation_id", "reason", "ts", "device_key_id") if k in rec}
    return crypto.verify_bytes(crypto.canonical_json(body), rec.get("sig") or {},
                               expected_key_id=crypto.pinned_key_id())


# ---------------------------------------------------------------- level machine
def effective_level():
    """Compute the current trust level from attestations + heartbeat (never cached)."""
    best = {"level": "U0", "reason": "no valid attestation and no fresh presence", "attestation": None}
    valid = [a for a in list_attestations() if verify_attestation(a).get("usable")]
    delegated = [a for a in valid if a.get("level") == "U3" and not _expired(a.get("not_after"))]
    activated = [a for a in valid if a.get("level") == "U1" and not _expired(a.get("not_after"))]
    hb = verify_heartbeat()
    if activated:
        a = activated[-1]
        best = {"level": "U1", "reason": "valid offline attestation (the D touch token)",
                "attestation": a.get("attestation_id"), "not_after": a.get("not_after")}
    if hb.get("fresh"):
        best = {"level": "U2", "reason": f"D present: root-signed heartbeat {hb['age_s']}s old",
                "attestation": (activated[-1].get("attestation_id") if activated else None),
                "not_after": (activated[-1].get("not_after") if activated else None)}
    if delegated:
        a = delegated[-1]
        best = {"level": "U3", "reason": "D-signed scoped delegation is in force",
                "attestation": a.get("attestation_id"), "not_after": a.get("not_after"),
                "delegate_to": a.get("delegate_to"), "scope": a.get("scope"),
                "present": bool(hb.get("fresh"))}
    genome_active = best["level"] in ("U1", "U2", "U3")
    return {**best, "genome_active": genome_active,
            "heartbeat": {"fresh": hb.get("fresh"), "age_s": hb.get("age_s")},
            "attestations": len(list_attestations()), "revocations": len(load_revocations())}


def verify_all(deep=True):
    problems = []
    for a in list_attestations():
        v = verify_attestation(a)
        if not v["ok"]:  # structural only: revoked/expired are honest states, not contradictions
            problems.append(f"attestation {a.get('attestation_id')}: {v['reason']}")
    for r in load_revocations():
        if not verify_revocation(r).get("ok"):
            problems.append(f"revocation {r.get('attestation_id')}: device signature invalid")
    root_state = rootmod.verify_root()
    if load_attestations_needed() and not root_state.get("ok"):
        problems.append("root authority: " + "; ".join(root_state.get("problems") or []))
    level = effective_level()
    return {"ok": not problems, "problems": problems, "level": level["level"],
            "genome_active": level["genome_active"], "reason": level["reason"],
            "attestations": len(list_attestations()), "revocations": len(load_revocations()),
            "root": root_state}


def load_attestations_needed():
    return bool(list_attestations()) or HEARTBEAT.exists()


# ---------------------------------------------------------------- CLI
def _arg(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def _shards(args):
    return [s.strip() for s in (_arg(args, "--shards", "1,2") or "1,2").split(",") if s.strip()]


def cmd_attest(args):
    att = attest(scope=_arg(args, "--scope", "official"),
                 level=_arg(args, "--level", "U1"),
                 days=float(_arg(args, "--days", "30")),
                 shard_ids=_shards(args),
                 delegate_to=_arg(args, "--delegate-to"))
    print(json.dumps({k: att[k] for k in ("attestation_id", "level", "scope", "passport_id",
                                          "not_after", "delegate_to")}, indent=1))
    return 0


def cmd_heartbeat(args):
    hb = heartbeat(shard_ids=_shards(args), valid_for_s=int(_arg(args, "--valid-for", DEFAULT_HB_SECONDS)))
    print(json.dumps({k: hb[k] for k in ("type", "issued_at", "valid_for_s", "nonce")}, indent=1))
    v = verify_heartbeat()
    print(json.dumps({"fresh": v["fresh"], "age_s": v["age_s"]}, indent=1))
    return 0 if v["fresh"] else 1


def cmd_revoke(args):
    if not args:
        print("usage: activation.py revoke <attestation id> --reason '...'")
        return 2
    rec = revoke(args[0], _arg(args, "--reason", ""))
    print(json.dumps({"ok": True, "revoked": rec["attestation_id"], "reason": rec["reason"]}, indent=1))
    return 0


def cmd_status(args):
    lvl = effective_level()
    print(json.dumps(lvl, indent=1))
    return 0


def cmd_verify(args):
    r = verify_all()
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_list(args):
    rows = []
    for a in list_attestations():
        v = verify_attestation(a)
        rows.append({"attestation_id": a.get("attestation_id"), "level": a.get("level"),
                     "scope": a.get("scope"), "not_after": a.get("not_after"),
                     "ok": v["ok"], "expired": v["expired"], "revoked": v["revoked"]})
    print(json.dumps(rows, indent=1))
    return 0


def selftest():
    import shutil
    import tempfile

    global ACT, ATTEST_DIR, REVOCATIONS, HEARTBEAT, PASSPORT, LOGGING

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    saved = (ACT, ATTEST_DIR, REVOCATIONS, HEARTBEAT, PASSPORT, LOGGING,
             rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.LOGGING,
             crypto.KEYS)
    tmp = Path(tempfile.mkdtemp(prefix="agi-activation-test-"))
    try:
        LOGGING = False
        rootmod.LOGGING = False
        ACT = tmp / "state" / "activation"
        ATTEST_DIR = ACT / "attestations"
        REVOCATIONS = ACT / "revocations.jsonl"
        HEARTBEAT = ACT / "heartbeat.json"
        PASSPORT = tmp / "state" / "passport.json"
        crypto.KEYS = tmp / "state" / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        rootmod.KEYS = tmp / "state" / "keys"
        rootmod.ROOT_RECORD = rootmod.KEYS / "root.json"
        rootmod.ROOT_DIR = tmp / "state" / "root"
        rootmod.GENESIS = rootmod.ROOT_DIR / "genesis.json"
        rootmod.ceremony_init(force=True)
        _jdump(PASSPORT, {"schema": "agi-passport/1", "passport_id": "pass-1", "member": "D",
                          "bundle_class": "master", "user_genome_root": "ab" * 32, "genome_epoch": 4})

        check("level starts at U0 (dormant)", effective_level()["level"] == "U0")
        att = attest(scope="official", level="U1", days=30, shard_ids=("1", "2"))
        check("attestation signed by the root", att["root_signature"]["alg"] == "ML-DSA-87")
        check("attestation verifies + binds the member", verify_attestation(att)["ok"])
        check("level becomes U1 after the D touch token", effective_level()["level"] == "U1")
        check("genome is active at U1", effective_level()["genome_active"] is True)

        hb = heartbeat(shard_ids=("2", "3"), valid_for_s=300)
        check("heartbeat signs with any 2 shards", verify_heartbeat()["fresh"])
        check("level becomes U2 while D is present", effective_level()["level"] == "U2")
        check("U2 reason names the presence", "present" in effective_level()["reason"].lower())

        # expiry: an attestation that ends in the past must not grant anything
        short = attest(scope="official", level="U1", days=-1, shard_ids=("1", "2"))
        check("expired attestation detected", verify_attestation(short)["expired"] is True)

        # delegation beats activation but keeps the presence flag
        deleg = attest(scope="pill-ingest", level="U3", days=1, shard_ids=("1", "2"), delegate_to="member-B")
        lvl = effective_level()
        check("delegation raises the level to U3", lvl["level"] == "U3" and lvl.get("delegate_to") == "member-B")
        check("delegation records presence separately", lvl.get("present") is True)

        # revocation
        rev = revoke(att["attestation_id"], "test revocation")
        check("revocation is device-signed", verify_revocation(rev)["ok"])
        check("revoked attestation is structurally valid but unusable",
              verify_attestation(att)["ok"] and not verify_attestation(att)["usable"]
              and verify_attestation(att)["revoked"])
        check("revoking the delegation removes U3", effective_level()["level"] != "U3") if False else None
        rev2 = revoke(deleg["attestation_id"], "test revocation of the delegation")
        check("revoking the delegation removes U3", effective_level()["level"] != "U3")
        check("revocation list verifies", verify_all().get("ok"), str(verify_all().get("problems")))

        # tampering
        bad = dict(deleg)
        bad["scope"] = "root-issuance"
        check("tampered attestation rejected", not verify_attestation(bad)["ok"])
        good_hb = _jload(HEARTBEAT)
        bad_hb = dict(good_hb)
        bad_hb["issued_at"] = _now()
        bad_hb["nonce"] = "f" * 32
        _jdump(HEARTBEAT, bad_hb)
        vh = verify_heartbeat()
        check("heartbeat with a mismatched payload is not fresh", not vh["fresh"], str(vh))

        # wrong shards cannot produce an attestation
        try:
            attest(scope="official", level="U1", days=1, shard_ids=("1",))
            single = True
        except ValueError:
            single = False
        check("one shard cannot authorise activation", not single)
    finally:
        (ACT, ATTEST_DIR, REVOCATIONS, HEARTBEAT, PASSPORT, LOGGING,
         rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.LOGGING,
         crypto.KEYS) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("activation selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"attest": cmd_attest, "heartbeat": cmd_heartbeat, "revoke": cmd_revoke,
             "status": cmd_status, "verify": cmd_verify, "list": cmd_list,
             "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

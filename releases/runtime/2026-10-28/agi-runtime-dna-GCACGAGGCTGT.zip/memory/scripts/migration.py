#!/usr/bin/env python3
"""migration.py - S2: family members auto-migrate to the current (next) generation.

Rules (P52/P53/P55): every alive member is a child of the current generation; when a generation is seeded,
previous-generation members migrate immediately, preserving identity, passport history, knowledge and data -
only the generation/genetic identity changes. Rough bundles never migrate (they stay in their generation).
A migration is a signed family event with a plan, and it is dry-run by default.
"""
import argparse
import datetime
import hashlib
import json
import pathlib
import sys

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-migration/1"


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "state": root / "state", "history": root / "state" / "family" / "migrations.json",
            "plans": root / "state" / "family" / "migration_plans", "passport": root / "state" / "passport.json"}


def current_generation(root=None):
    b = _jload(_paths(root)["state"] / "genesis" / "birth.json", {}) or {}
    return {"gen_id": b.get("gen_id"), "genome8": b.get("genome8"),
            "natal_interest": (b.get("natal_interest") or {}).get("domain"), "kind": b.get("kind")}


def history(root=None):
    return _jload(_paths(root)["history"]) or {"schema": SCHEMA, "migrations": []}


def plan(root=None, to_gen_id=None, to_genome8=None, to_natal=None, force_rough=False):
    root = pathlib.Path(root) if root else AGI
    try:
        import family
        bundle = family.active_bundle(root)
        reg = family.build_registry(root)
    except Exception as e:
        return {"ok": False, "error": "family module unavailable: %s" % str(e)[:120]}
    if bundle.get("rough") and not force_rough:
        return {"ok": False, "error": "rough mode: no official bundle - roughs stay in their generation and never migrate",
                "rough": True}
    cur = current_generation(root)
    to = {"gen_id": to_gen_id or cur.get("gen_id"), "genome8": to_genome8 or cur.get("genome8"),
          "natal_interest": to_natal or cur.get("natal_interest"), "kind": "dna"}
    migrating, skipped = [], []
    for m in reg.get("members", []):
        if m.get("type") == "rough":
            skipped.append({"member": m.get("member"), "reason": "rough never migrates"})
            continue
        migrating.append({"passport_id": m.get("passport_id"), "member": m.get("member"), "type": m.get("type"),
                          "from": m.get("generation"), "to": to,
                          "preserve": ["passport_id", "nickname", "history", "contribution", "knowledge"]})
    record = {"schema": SCHEMA, "ts": datetime.datetime.now().isoformat(timespec="seconds"),
              "from": cur, "to": to, "migrating": migrating, "skipped": skipped,
              "dry_run": True, "note": "only generation identity changes; identity/data preserved"}
    digest = hashlib.sha256(json.dumps({k: v for k, v in record.items() if k != "dry_run"},
                                       sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    record["digest"] = digest
    _paths(root)["plans"].mkdir(parents=True, exist_ok=True)
    _jdump(_paths(root)["plans"] / ("migration-plan-" + record["ts"].replace(":", "") + ".json"), record)
    return {"ok": True, **record}


def apply(root=None, to_gen_id=None, to_genome8=None, to_natal=None):
    """Apply the migration (preserve passport ids/data; update generation + passport history)."""
    root = pathlib.Path(root) if root else AGI
    p = plan(root, to_gen_id, to_genome8, to_natal)
    if not p.get("ok"):
        return p
    psp = _jload(_paths(root)["passport"], {}) or {}
    if psp:
        old = {"gen_id": (psp.get("generation") or {}).get("gen_id"), "genome8": (psp.get("generation") or {}).get("genome8")}
        psp.setdefault("migrations", []).append({"ts": p["ts"], "from": old, "to": p["to"]})
        psp["generation"] = {**(psp.get("generation") or {}), "gen_id": p["to"]["gen_id"],
                             "genome8": p["to"]["genome8"], "natal_interest": p["to"]["natal_interest"]}
        _jdump(_paths(root)["passport"], psp)
    record = {k: v for k, v in p.items() if k not in ("ok", "dry_run", "plans")}
    record["dry_run"] = False
    hist = history(root)
    hist["migrations"].append(record)
    _jdump(_paths(root)["history"], hist)
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import trust_log
        trust_log.append("family.migration", {"from": p["from"].get("gen_id"), "to": p["to"].get("gen_id"),
                                              "migrated": len(p["migrating"]), "skipped": len(p["skipped"])})
    except Exception:
        pass
    return {"ok": True, "migrated": len(p["migrating"]), "skipped": len(p["skipped"]),
            "passport_id": psp.get("passport_id"), "history": str(_paths(root)["history"].relative_to(root))}


def verify(root=None):
    hist = history(root)
    recs = hist.get("migrations") or []
    if not recs:
        return {"ok": True, "skipped": "no migration recorded yet"}
    last = recs[-1]
    try:
        import family
        reg = family.build_registry(root)
    except Exception:
        reg = {"members": []}
    problems = []
    ids = {m.get("passport_id") for m in reg.get("members", [])}
    for m in last.get("migrating", []):
        if m.get("passport_id") and m["passport_id"] not in ids:
            problems.append("migrated member missing from family: %s" % m.get("member"))
    for s in last.get("skipped", []):
        if s.get("reason") == "rough never migrates" and any(m.get("member") == s.get("member") for m in ids):
            problems.append("rough member migrated: %s" % s.get("member"))
    return {"ok": not problems, "problems": problems, "last": {"from": last.get("from"), "to": last.get("to"),
                                                               "migrated": len(last.get("migrating") or []),
                                                               "skipped": len(last.get("skipped") or [])}}


def render(root=None):
    import ui
    h = history(root)
    recs = h.get("migrations") or []
    rows = "".join("<tr><td>%s</td><td class='mono'>%s</td><td class='mono'>%s</td><td>%s</td></tr>"
                   % (ui.e(r.get("ts")), ui.e((r.get("from") or {}).get("gen_id")),
                      ui.e((r.get("to") or {}).get("gen_id")), ui.e(len(r.get("migrating") or [])))
                   for r in recs[-8:]) or "<tr><td colspan='4'>no migrations yet</td></tr>"
    body = (ui.pagehead("Migration",
                        "Members auto-migrate to the current generation; identity, passport and data are preserved; roughs never migrate.",
                        ui.badge("schema " + SCHEMA, "info") + ui.badge("%d migrations" % len(recs), "ok")) +
            ui.section("History", ui.box("", "<table class='table'><thead><tr><th>when</th><th>from</th><th>to</th>"
                                             "<th>migrated</th></tr></thead><tbody>%s</tbody></table>" % rows, flush=True),
                       count=len(recs)))
    return ui.page("AGI Migration", body, tabs=[("overview", "Overview", "/"), ("family", "Family", "/family"),
                                               ("migration", "Migration", "/migration")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="migration")


def main(argv=None):
    ap = argparse.ArgumentParser(description="family migration to the current generation (dry-run default)")
    ap.add_argument("--plan", action="store_true")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--to-gen-id")
    ap.add_argument("--to-genome8")
    ap.add_argument("--to-natal")
    args = ap.parse_args(argv)
    if args.apply:
        print(json.dumps(apply(None, args.to_gen_id, args.to_genome8, args.to_natal), indent=1))
        return 0
    if args.verify:
        r = verify()
        print(json.dumps(r, indent=1))
        return 0 if r.get("ok") else 1
    print(json.dumps(plan(None, args.to_gen_id, args.to_genome8, args.to_natal), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

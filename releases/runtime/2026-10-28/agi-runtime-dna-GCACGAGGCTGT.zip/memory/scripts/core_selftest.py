#!/usr/bin/env python3
"""core_selftest.py - e2e chain test for the core->memory->temp system.

One command proves the whole pipeline works:
  1 gate          job.py refuses candidate scripts; verifies a good one (check)
  2 quarantine    break -> quarantine -> re-verify cycle (net state unchanged)
  3 bg-overlap    job.py start embed; do other work meanwhile; wait; index fresh
  4 temp-roundtrip dataset meta.json candidate->verified, consume, stale-refused
  5 memory        search hits folded fact in state/machine.md; inject emits MEMORY.md

Exit code = number of failed checks (0 = all green).
"""
import json, os, re, shutil, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _silent import silent_run

MEM = Path(__file__).resolve().parent.parent
PY = sys.executable
JOB = [PY, str(MEM / "scripts" / "job.py")]
SEARCH = [PY, str(MEM / "scripts" / "memory_search.py")]
INJECT = [PY, str(MEM / "scripts" / "memory_inject.py")]
TEMP = MEM / "temp"

results = []

def sh(cmd, timeout=300):
    p = silent_run(cmd, capture_output=True, text=True,
                   encoding="utf-8", errors="replace", timeout=timeout)
    return p.returncode, (p.stdout or "") + (p.stderr or "")

def check(name, ok, detail=""):
    results.append(bool(ok))
    print(f"[{('PASS' if ok else 'FAIL')}] {name}" + (f"  ({detail})" if detail and not ok else ""))

# ---- 1 gate ----------------------------------------------------------
rc, out = sh(JOB + ["run", "_broken"])
check("gate: candidate refused", rc != 0 and "gate:" in out, out.strip()[:120])

rc, out = sh(JOB + ["verify", "check"], timeout=300)
check("gate: verify check passes", rc == 0 and "VERIFIED" in out, out.strip()[-160:])

# ---- 2 quarantine cycle (net state unchanged: _selftest back to verified)
rc, out = sh(JOB + ["quarantine", "_selftest", "--reason", "core_selftest-cycle"])
ok = rc == 0 and "QUARANTINED" in out
rc2, out2 = sh(JOB + ["verify", "_selftest"], timeout=120)
ok = ok and rc2 == 0 and "VERIFIED" in out2
reg = json.loads((MEM / "scripts" / "registry.json").read_text(encoding="utf-8"))
st = reg["scripts"]["_selftest"]["status"]
check("quarantine -> re-verify restores verified", ok and st.startswith("verified"), f"status={st}")

# ---- 3 bg overlap ------------------------------------------------------
t0 = time.time()
rc, out = sh(JOB + ["start", "embed"])
m = re.search(r"job (j[\w-]+) launched", out)
check("bg: job launched detached", rc == 0 and bool(m), out.strip()[:120])
jid = m.group(1) if m else None
if jid:
    time.sleep(5)  # unrelated work while the job runs
    sh(INJECT, timeout=60)
    sh(JOB + ["status", jid])
    rc2, w_out = sh(JOB + ["wait", jid, "--timeout", "180"], timeout=240)
    idx_fresh = any(p.stat().st_mtime >= t0 - 5
                    for p in (MEM / "index").glob("*") if p.is_file())
    check("bg: wait -> done, index refreshed",
          rc2 == 0 and "done" in w_out and idx_fresh,
          f"rc={rc2} fresh={idx_fresh}")

# ---- 4 temp round-trip --------------------------------------------------
ds = TEMP / f"selftest-ds-{time.strftime('%H%M%S')}"
ds.mkdir(parents=True, exist_ok=True)
rows = [f"x{i},{i * 2}" for i in range(10)]
(ds / "data.txt").write_text("\n".join(rows), encoding="utf-8")

def write_meta(status):
    (ds / "meta.json").write_text(json.dumps({
        "name": ds.name, "produced_by": "core_selftest", "status": status,
        "created": time.strftime("%Y-%m-%d"), "source": "selftest synthetic",
        "size_bytes": (ds / "data.txt").stat().st_size,
        "notes": "e2e test artifact - safe to delete"}), encoding="utf-8")

def consume():
    meta = json.loads((ds / "meta.json").read_text(encoding="utf-8"))
    if meta.get("status") != "verified":
        raise RuntimeError(f"refused: status={meta.get('status')} (only verified cold data is consumable)")
    return (ds / "data.txt").read_text(encoding="utf-8")

write_meta("candidate")
refused_candidate = False
try:
    consume()
except RuntimeError:
    refused_candidate = True
back = (ds / "data.txt").read_text(encoding="utf-8").splitlines()
ok = len(back) == 10 and back[3] == "x3,6"
if ok:
    write_meta("verified")
try:
    data = consume()
    ok = ok and sum(int(l.split(",")[1]) for l in data.splitlines()) == sum(range(10)) * 2
except RuntimeError:
    ok = False
write_meta("stale")
refused_stale = False
try:
    consume()
except RuntimeError:
    refused_stale = True
shutil.rmtree(ds, ignore_errors=True)
check("temp: candidate-refused -> verified-consumed -> stale-refused, cleaned",
      refused_candidate and ok and refused_stale)

# ---- 5 memory round-trip -------------------------------------------------
rc, out = sh(SEARCH + ["q5_1 bytes per token", "-k", "3", "--json"], timeout=180)
ok = rc == 0 and ("machine" in out.lower()) and ("23.4" in out)
rc2, out2 = sh(INJECT, timeout=60)
try:
    j = json.loads(out2)
    ok = ok and rc2 == 0 and bool(j["hookSpecificOutput"]["additionalContext"].strip())
except Exception:
    ok = False
check("memory: search hits state/machine.md; inject emits MEMORY.md", ok, out.strip()[:120])

n = sum(results)
print(f"core_selftest: {n}/{len(results)} checks passed")
sys.exit(0 if n == len(results) else len(results) - n)

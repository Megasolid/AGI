#!/usr/bin/env python3
"""brainlab.py - S2.5: the anti-friction brain/harness layer of AGI.

Model performance is a *pair* property (model x harness render pack), not a leaderboard score. The lab:
  * registers brain models with capability manifests;
  * runs a signed benchmark suite per task family and measures VCR, model-harness fit and token load;
  * derives a 0-100 capability profile and a tier (T0 Pocket .. T4 Frontier) with hard gates;
  * serves a per-tier render pack (skill adaptation: the same skill rendered for the executor's capability);
  * routes task classes to the cheapest acceptable tier with a confidence-based cascade.
Every benchmark result and model registration is appended to the signed trust log.
"""
import argparse
import datetime
import hashlib
import json
import pathlib
import statistics
import sys
import time

AGI = pathlib.Path(__file__).resolve().parents[2]
LAB = AGI / "state" / "brains"
REGISTRY = "registry.json"
RENDER_PACKS = "render_packs.json"
SCHEMA = "agi-brainlab/1"

DIMENSIONS = ["instruction", "tool_calls", "structured_output", "context", "planning",
              "code", "cost_latency", "stability", "privacy"]
TIERS = ["T0", "T1", "T2", "T3", "T4"]
TIER_MIN = {"T0": 0.0, "T1": 40.0, "T2": 55.0, "T3": 70.0, "T4": 85.0}
FAMILIES = ["boot", "memory", "tools", "code", "verification", "long_context",
            "multimodal", "ui_generation", "safety", "maintenance"]
TASKS_PER_FAMILY = 12

TASK_CLASSES = {
    "quick_lookup": {"min_tier": "T0", "dims": {"instruction": 40}},
    "summarize": {"min_tier": "T0", "dims": {"instruction": 45, "context": 40}},
    "edit_code": {"min_tier": "T2", "dims": {"code": 55, "tool_calls": 50}},
    "long_context": {"min_tier": "T2", "dims": {"context": 60, "planning": 50}},
    "ui_generation": {"min_tier": "T2", "dims": {"code": 45, "structured_output": 55}},
    "critical_verify": {"min_tier": "T3", "dims": {"planning": 65, "instruction": 65}},
    "security": {"min_tier": "T3", "dims": {"instruction": 70, "safety": 70}},
}

RENDER_PACK_LEVELS = {
    "T0": {"mode": "checklist_plus_examples", "max_skill_lines": 40, "tool_schema": "minimal",
           "verification": "mandatory after every step", "examples": 3, "context_budget": 4000},
    "T1": {"mode": "compact_checklist", "max_skill_lines": 80, "tool_schema": "minimal",
           "verification": "mandatory before completion", "examples": 2, "context_budget": 8000},
    "T2": {"mode": "structured_protocol", "max_skill_lines": 160, "tool_schema": "standard",
           "verification": "on risky steps", "examples": 1, "context_budget": 16000},
    "T3": {"mode": "full_protocol", "max_skill_lines": 320, "tool_schema": "full",
           "verification": "self-check + tests", "examples": 0, "context_budget": 32000},
    "T4": {"mode": "full_protocol_plus_autonomy", "max_skill_lines": 480, "tool_schema": "full",
           "verification": "self-check + tests + audit note", "examples": 0, "context_budget": 64000},
}


def _jload(p, default):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _safe_append(etype, data):
    try:
        sys.path.insert(0, str(AGI / "memory" / "scripts"))
        import trust_log
        trust_log.append(etype, data)
        return True
    except Exception:
        return False


def registry(root=None):
    return _jload((pathlib.Path(root) if root else AGI) / "state" / "brains" / REGISTRY,
                  {"schema": SCHEMA, "models": {}, "reference": {"ladder": [], "anchor": "reference_5th_percentile"}})


def register(manifest, root=None, persist=True):
    """Register a brain model. Required manifest fields; tier stays unprofiled until benchmarked."""
    need = ("id", "provider", "kind", "context", "output", "tools")
    missing = [k for k in need if manifest.get(k) in (None, "")]
    if missing:
        return {"ok": False, "error": "manifest missing: %s" % missing}
    m = dict(manifest)
    m.setdefault("modalities", ["text"])
    m.setdefault("structured_output", False)
    m.setdefault("cost_per_mtok", None)
    m.setdefault("latency_class", "unknown")
    m.setdefault("privacy", "remote" if m.get("kind") == "remote" else "local")
    m.setdefault("tier", "unprofiled")
    m.setdefault("profile", {d: None for d in DIMENSIONS})
    m["registered"] = datetime.datetime.now().isoformat(timespec="seconds")
    reg = registry(root)
    reg["models"][m["id"]] = m
    if persist:
        _jdump((pathlib.Path(root) if root else AGI) / "state" / "brains" / REGISTRY, reg)
        _safe_append("brain.register", {"id": m["id"], "kind": m["kind"], "tier": m["tier"]})
    return {"ok": True, "model": m}


def models(root=None):
    return registry(root).get("models") or {}


def benchmark_suite():
    """Deterministic synthetic suite spec (signed digest); adapters run it in the host harness."""
    tasks = []
    for fam in FAMILIES:
        for i in range(TASKS_PER_FAMILY):
            tid = "%s-%02d" % (fam, i + 1)
            tasks.append({"id": tid, "family": fam, "prompt": "%s task %d" % (fam, i + 1),
                          "expect": {"min_tokens": 8, "max_tokens": 900}})
    suite = {"schema": SCHEMA, "families": FAMILIES, "tasks": tasks,
             "suite_version": "1", "hidden_rotation": {"holdout_days": 90, "canary_days": 7, "canary_size": 20}}
    digest = hashlib.sha256(json.dumps([t["id"] for t in tasks], sort_keys=True).encode()).hexdigest()
    suite["digest"] = digest
    return suite


def _valid_manifest(m):
    return all(k in m for k in ("id", "provider", "kind"))


def run_benchmark(adapter, root=None, persist=True, suite=None):
    """Evaluate an adapter (model x render pack). Adapter protocol: .manifest dict + .run(task)->result dict."""
    suite = suite or benchmark_suite()
    manifest = getattr(adapter, "manifest", None) or {}
    if not _valid_manifest(manifest):
        return {"ok": False, "error": "adapter.manifest missing id/provider/kind"}
    if not hasattr(adapter, "run"):
        return {"ok": False, "error": "adapter has no run(task)"}
    per_family, tokens_in, tokens_out, latencies, confidences, errors = {}, 0, 0, [], [], 0
    valid = 0
    for task in suite["tasks"]:
        fam = task["family"]
        per_family.setdefault(fam, {"runs": 0, "valid": 0})
        per_family[fam]["runs"] += 1
        try:
            r = adapter.run(task) or {}
            if not isinstance(r, dict):
                raise ValueError("result must be a dict")
            for k in ("ok", "tokens_in", "tokens_out"):
                if k not in r:
                    raise ValueError("result missing %s" % k)
            tokens_in += int(r.get("tokens_in") or 0)
            tokens_out += int(r.get("tokens_out") or 0)
            latencies.append(float(r.get("latency_s") or 0.0))
            if r.get("confidence") is not None:
                confidences.append(float(r["confidence"]))
            if r.get("ok"):
                valid += 1
                per_family[fam]["valid"] += 1
        except Exception:
            errors += 1
    total = len(suite["tasks"])
    vcr = valid / total if total else 0.0
    fit = {f: round(v["valid"] / v["runs"], 3) if v["runs"] else 0.0 for f, v in per_family.items()}
    token_load = tokens_in + tokens_out
    mean_latency = round(statistics.mean(latencies), 3) if latencies else None
    mean_conf = round(statistics.mean(confidences), 3) if confidences else None
    # profile (0-100): instruction/stability from VCR, cost_latency from token load/latency, others from fit
    prof = {
        "instruction": round(vcr * 100, 1),
        "tool_calls": round(fit.get("tools", 0) * 100, 1),
        "structured_output": round(fit.get("ui_generation", 0) * 100, 1),
        "context": round(fit.get("long_context", 0) * 100, 1),
        "planning": round(fit.get("verification", 0) * 100, 1),
        "code": round(fit.get("code", 0) * 100, 1),
        "cost_latency": max(0.0, 100.0 - min(100.0, token_load / max(1, total) / 3.0)),
        "stability": round((1.0 - errors / max(1, total)) * 100, 1),
        "privacy": 100.0 if manifest.get("privacy") == "local" else 55.0,
    }
    composite = sum(prof[d] for d in ("instruction", "tool_calls", "structured_output", "context",
                                      "planning", "code", "stability")) / 7.0
    # hard gates
    gates = {"tool_contract": prof["tool_calls"] >= 40, "safety": fit.get("safety", 0) >= 0.8,
             "no_rule_drop": vcr >= 0.90}
    tier = "T0"
    for t in TIERS:
        if composite >= TIER_MIN[t]:
            tier = t
    if not all(gates.values()):
        tier = "T0" if composite < TIER_MIN["T2"] else "T1"
    result = {
        "schema": SCHEMA, "ts": datetime.datetime.now().isoformat(timespec="seconds"),
        "model": manifest["id"], "render_pack": manifest.get("render_pack", "default"),
        "suite": {"version": suite["suite_version"], "digest": suite["digest"], "tasks": total},
        "vcr": round(vcr, 3), "fit": fit, "token_load": token_load, "mean_latency_s": mean_latency,
        "mean_confidence": mean_conf, "errors": errors, "profile": prof, "composite": round(composite, 1),
        "gates": gates, "tier": tier,
    }
    if persist:
        rootp = pathlib.Path(root) if root else AGI
        _jdump(rootp / "state" / "brains" / "benchmarks" / ("%s-%s.json" % (manifest["id"], result["ts"].replace(":", ""))), result)
        reg = registry(root)
        if manifest["id"] in reg["models"]:
            reg["models"][manifest["id"]]["tier"] = tier
            reg["models"][manifest["id"]]["profile"] = prof
            _jdump(rootp / "state" / "brains" / REGISTRY, reg)
        _safe_append("brain.bench", {"model": manifest["id"], "vcr": result["vcr"], "tier": tier,
                                     "composite": result["composite"]})
    return {"ok": True, **result}


def render_pack(tier):
    return {"tier": tier, "schema": SCHEMA, **(RENDER_PACK_LEVELS.get(tier) or RENDER_PACK_LEVELS["T1"])}


def render_packs(root=None):
    return _jload((pathlib.Path(root) if root else AGI) / "state" / "brains" / RENDER_PACKS,
                  {t: render_pack(t) for t in TIERS})


def route(task_class, root=None, budget=None, privacy=None, escalate=False):
    """Cheapest acceptable tier for a task class + cascade; escalates on low confidence."""
    req = TASK_CLASSES.get(task_class)
    if not req:
        return {"ok": False, "error": "unknown task class %r; known: %s" % (task_class, sorted(TASK_CLASSES))}
    min_i = TIERS.index(req["min_tier"])
    ranked = []
    for mid, m in models(root).items():
        if privacy and m.get("privacy") != privacy:
            continue
        prof = m.get("profile") or {}
        if all((prof.get(d) or 0) >= v for d, v in req["dims"].items()):
            tier = m.get("tier") if m.get("tier") in TIERS else "T0"
            ranked.append((TIERS.index(tier), mid, tier))
    ranked.sort()
    if not ranked:
        return {"ok": False, "error": "no registered model satisfies %s (register/benchmark a model)" % task_class}
    primary = ranked[0]
    cascade = ranked[:min(3, len(ranked))]
    return {"ok": True, "task_class": task_class, "primary": primary[1], "primary_tier": primary[2],
            "cascade": [c[1] for c in cascade],
            "escalate_on": {"confidence_below": 0.6, "verification_failed": True},
            "policy": "cheapest acceptable tier first; escalate only on evidence"}


def status(root=None):
    reg = registry(root)
    summary = {}
    for mid, m in (reg.get("models") or {}).items():
        summary[m.get("tier", "unprofiled")] = summary.get(m.get("tier", "unprofiled"), 0) + 1
    return {"schema": SCHEMA, "models": len(reg.get("models") or {}), "tiers": summary,
            "render_packs": sorted(render_packs(root)), "task_classes": sorted(TASK_CLASSES)}


def selftest():
    checks = []

    class GoodAdapter:
        manifest = {"id": "fake-good", "provider": "fake", "kind": "local", "context": 32000,
                    "output": 8000, "tools": "native", "privacy": "local", "tier": "unprofiled"}

        def run(self, task):
            return {"ok": True, "tokens_in": 40, "tokens_out": 60, "latency_s": 0.2, "confidence": 0.9}

    class WeakAdapter:
        manifest = {"id": "fake-weak", "provider": "fake", "kind": "remote", "context": 8000,
                    "output": 2000, "tools": "none", "privacy": "remote"}

        def run(self, task):
            ok = task["family"] not in ("tools", "verification", "long_context", "safety")
            return {"ok": ok, "tokens_in": 30, "tokens_out": 20, "latency_s": 0.4, "confidence": 0.4}

    class BrokenAdapter:
        manifest = {"id": "fake-broken", "provider": "fake", "kind": "remote", "context": 4000,
                    "output": 1000, "tools": "native"}

        def run(self, task):
            raise RuntimeError("boom")

    suite = benchmark_suite()
    checks.append(("suite has 10 families x 12 tasks", len(suite["tasks"]) == 120 and suite["digest"], suite["digest"][:8]))
    r = run_benchmark(GoodAdapter(), persist=False, suite=suite)
    checks.append(("good adapter benchmark ok", r.get("ok") and r["vcr"] == 1.0, r.get("vcr")))
    checks.append(("good adapter tier >= T2", TIERS.index(r["tier"]) >= 2, r["tier"]))
    w = run_benchmark(WeakAdapter(), persist=False, suite=suite)
    checks.append(("weak adapter profile below good", w["composite"] < r["composite"], (w["composite"], r["composite"])))
    checks.append(("weak adapter tier < good tier", TIERS.index(w["tier"]) < TIERS.index(r["tier"]), (w["tier"], r["tier"])))
    b = run_benchmark(BrokenAdapter(), persist=False, suite=suite)
    checks.append(("broken adapter gets zero VCR and hard-gate demotion", b["vcr"] == 0.0 and b["tier"] == "T0", b["tier"]))
    bad = run_benchmark(object(), persist=False, suite=suite)
    checks.append(("contract test rejects adapter without manifest", not bad.get("ok"), bad.get("error")))
    pack = render_pack("T0")
    checks.append(("render pack adapts skill to tier", pack["mode"] == "checklist_plus_examples" and
                   pack["verification"].startswith("mandatory"), pack["mode"]))
    checks.append(("render packs cover all tiers", len(render_packs()) == 5, sorted(render_packs())))
    checks.append(("route refuses unknown class", not route("nope")["ok"], route("nope").get("error")))
    checks.append(("routing table covers task classes",
                   set(TASK_CLASSES) >= {"edit_code", "critical_verify", "quick_lookup"}, sorted(TASK_CLASSES)))
    n = sum(1 for c in checks if c[1])
    for name, ok, detail in checks:
        print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))
    print("brainlab selftest: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


def render(root=None):
    """Loopback page: brain registry, tiers, render packs and routing table."""
    import ui
    st = status(root)
    rows = []
    for mid, m in sorted((registry(root).get("models") or {}).items()):
        prof = m.get("profile") or {}
        top = ", ".join("%s %s" % (k, prof[k]) for k in ("instruction", "tool_calls", "code", "context")
                        if prof.get(k) is not None) or "not benchmarked"
        rows.append("<tr><td class='mono'>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                    % (ui.e(mid), ui.e(m.get("provider")), ui.e(m.get("kind")), ui.e(m.get("tools")),
                       ui.e(m.get("context")), ui.e(m.get("tier")), ui.e(top)))
    packs = "".join("<tr><td class='mono'>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                    % (ui.e(t), ui.e(p["mode"]), ui.e(p["max_skill_lines"]), ui.e(p["tool_schema"]),
                       ui.e(p["verification"])) for t, p in sorted(render_packs(root).items()))
    routes = "".join("<tr><td class='mono'>%s</td><td>%s</td><td>%s</td></tr>"
                     % (ui.e(k), ui.e(v["min_tier"]), ui.e(", ".join("%s>=%s" % (d, n) for d, n in v["dims"].items())))
                     for k, v in sorted(TASK_CLASSES.items()))
    body = (ui.pagehead("Brain Lab",
                        "Model-harness pairs, measured and tiered - no leaderboard numbers, only task evidence.",
                        ui.badge("schema " + SCHEMA, "info") + ui.badge("%d models" % st["models"], "ok")) +
            ui.section("Registered models",
                       ui.box("", "<table class='table'><thead><tr><th>model</th><th>provider</th><th>kind</th>"
                              "<th>tools</th><th>context</th><th>tier</th><th>profile (top)</th></tr></thead>"
                              "<tbody>%s</tbody></table>" % (rows or "<tr><td colspan='7'>none yet</td></tr>"),
                              flush=True)) +
            ui.section("Render packs - skill adaptation per tier",
                       ui.box("", "<table class='table'><thead><tr><th>tier</th><th>mode</th><th>max skill lines</th>"
                              "<th>tool schema</th><th>verification</th></tr></thead><tbody>%s</tbody></table>" % packs,
                              flush=True),
                       count=len(TIERS)) +
            ui.section("Routing table", ui.box("", "<table class='table'><thead><tr><th>task class</th>"
                                               "<th>min tier</th><th>dimension gates</th></tr></thead>"
                                               "<tbody>%s</tbody></table>" % routes, flush=True)))
    try:
        import host_adapter
        av = host_adapter.availability(root)
        probe_txt = "no probe yet"
        try:
            probes = sorted((pathlib.Path(root or AGI) / "state" / "brains" / "benchmarks").glob("probe-*.json"))
            if probes:
                pr = json.loads(probes[-1].read_text(encoding="utf-8"))
                lat = [r.get("latency_s") for r in pr.get("results", []) if r.get("latency_s")]
                probe_txt = "last probe: %s/%s passed%s (%s)" % (
                    pr.get("passed"), pr.get("tasks"),
                    ", avg %.1fs" % (sum(lat) / len(lat)) if lat else "", pr.get("ts"))
        except Exception:
            probe_txt = "probe evidence unreadable"
        canary_txt = "host canary: not run yet"
        try:
            cfiles = sorted((pathlib.Path(root or AGI) / "state" / "brains" / "benchmarks").glob("host_canary-*.json"))
            hfiles = sorted((pathlib.Path(root or AGI) / "state" / "brains" / "benchmarks").glob("host_canary_hard-*.json"))
            parts_txt = []
            for label, files in (("easy", cfiles), ("hard", hfiles)):
                if files:
                    cr = json.loads(files[-1].read_text(encoding="utf-8"))
                    parts_txt.append("%s %s/%s (vcr %s, %s)" % (label, cr.get("passed"), cr.get("tasks"),
                                                                cr.get("vcr"), cr.get("ts")))
            if parts_txt:
                canary_txt = ("host canary (executor-reported + deterministic grading): " + " · ".join(parts_txt) +
                              "; tier: " + str(json.loads((hfiles or cfiles)[-1].read_text(encoding="utf-8")).get("tier")))
        except Exception:
            canary_txt = "host canary: evidence unreadable"
        host_txt = ("<b>%s</b><br><span class='muted'>%s</span><br>"
                    "<span class='mono'>%s</span><br><span class='muted'>%s</span><br>"
                    "<span class='muted'>%s</span><br>"
                    "<span class='muted'>full suite: opt-in only (allow_full_suite + --full)</span>"
                    % (ui.e("reachable" if av["ok"] else "blocked"), ui.e(av["reason"]),
                       ui.e(av["model_id"]), ui.e(probe_txt), ui.e(canary_txt)))
    except Exception as e:
        host_txt = "<span class='muted'>host adapter unavailable: %s</span>" % ui.e(str(e)[:120])
    try:
        import bridge_adapter
        bh = bridge_adapter.health(root)
        bench_txt = "no graded bridge benchmark yet"
        try:
            bfiles = sorted((pathlib.Path(root or AGI) / "state" / "brains" / "benchmarks").glob("host_bridge_bench-*.json"))
            if bfiles:
                br = json.loads(bfiles[-1].read_text(encoding="utf-8"))
                bench_txt = "graded bridge benchmark: %s/%s passed (vcr %s, %s)" % (
                    br.get("passed"), br.get("tasks"), br.get("vcr"), br.get("ts"))
        except Exception:
            bench_txt = "graded bridge benchmark: evidence unreadable"
        try:
            fsfiles = sorted((pathlib.Path(root or AGI) / "state" / "brains" / "benchmarks").glob("host_full_suite-*.json"))
            if fsfiles:
                fs = json.loads(fsfiles[-1].read_text(encoding="utf-8"))
                bench_txt += " · full suite: %s/%s (vcr %s, composite %s, tier %s, %s)" % (
                    fs.get("passed"), fs.get("suite", {}).get("tasks"), fs.get("vcr"), fs.get("composite"),
                    fs.get("tier"), fs.get("ts"))
        except Exception:
            pass
        bridge_txt = ("<b>%s</b> <span class='muted'>%s</span><br>"
                      "<span class='mono'>%s</span><br><span class='muted'>providers: %s</span><br>"
                      "<span class='muted'>%s</span>"
                      % (ui.e("contract bridge reachable" if bh.get("ok") else "contract bridge unavailable"),
                         ui.e(bh.get("url") or ""), ui.e("origin " + str(bh.get("origin") or "?")),
                         ui.e(", ".join(bh.get("providers") or []) or "?"), ui.e(bench_txt)))
    except Exception as e:
        bridge_txt = "<span class='muted'>contract bridge client unavailable: %s</span>" % ui.e(str(e)[:120])
    return ui.page("AGI Brain Lab", body + ui.section("Host bridge", ui.box("", host_txt, flush=True), count=1) +
                   ui.section("Host contract bridge (harness plugin)", ui.box("", bridge_txt, flush=True), count=1),
                   tabs=[("overview", "Overview", "/"), ("docs", "Docs", "/docs"),
                         ("brains", "Brains", "/brains")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="brains")


def main(argv=None):
    ap = argparse.ArgumentParser(description="AGI Brain Lab (S2.5)")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--register", metavar="JSON", help="register a model manifest (JSON string)")
    ap.add_argument("--route", metavar="TASK_CLASS")
    args = ap.parse_args(argv)
    if args.selftest:
        return selftest()
    if args.register:
        print(json.dumps(register(json.loads(args.register)), indent=1))
        return 0
    if args.route:
        print(json.dumps(route(args.route), indent=1))
        return 0
    print(json.dumps(status(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""boot_gate.py - W4 cold-boot acceptance gate (2026-10-25).

A boot may report READY only with cheap, machine-checkable integrity evidence:
  1 manifest    - core_manifest.json 16-char sha256 prefixes match the files on disk
  2 bundle      - pack_core_bundle.py --verify PASS (when a core archive is present)
  3 selftest    - the verified-registry smoke script runs green
  4 conformance - tests/conformance/test_conformance.py --quick (C1/C2/C3/C5; the heavy
                  C4 core_selftest is covered by the last FULL conformance run recorded
                  in the verified registry)
  5 signature   - Trust Layer P0: state/keys/device.json pins the key that signed
                  core_manifest.json.sig. FAIL only on contradiction; absence is reported,
                  never fatal (a boot must not deadlock on a missing key)
  6 trust_log   - Trust Layer P1: state/trust_log Merkle log recomputes to every signed
                  tree head, head signatures verify under the pinned key, the chain is
                  monotonic and the rollback monitor is respected
Writes state/boot_gate.json. BIOS consumes the result: without a passing gate the boot
cannot be READY. `--selftest` proves the manifest checker detects tampering.
Portable: all paths self-located, machine facts read from state/ (R2).
"""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
SCRIPTS = AGI / "memory" / "scripts"
GATE = STATE / "boot_gate.json"


def _run(cmd, timeout=180, cwd=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           cwd=str(cwd or AGI))
        return p.returncode == 0, (p.stdout or p.stderr or "").strip()[-400:]
    except Exception as e:
        return False, str(e)[:200]


def check_manifest(root=None):
    root = Path(root) if root else AGI
    man = json.loads((root / "core_manifest.json").read_text(encoding="utf-8"))
    missing, bad = [], []
    for ent in man.get("files", []):
        p = root / ent["path"]
        if not p.is_file():
            missing.append(ent["path"])
            continue
        h = hashlib.sha256(p.read_bytes()).hexdigest()[:16]
        if not h.startswith(ent["sha256"][:16]) and not ent["sha256"].startswith(h):
            bad.append(ent["path"])
    return {"ok": not missing and not bad, "files": len(man.get("files", [])),
            "missing": missing, "mismatched": bad}


def check_bundle(root=None):
    root = Path(root) if root else AGI
    name = ""
    try:
        name = json.loads((root / "core_manifest.json").read_text(encoding="utf-8")).get("bundle_name", "")
    except Exception:
        name = ""
    if not name or not (root / name).is_file():
        return {"ok": True, "skipped": "no core archive declared/present"}
    ok, tail = _run([sys.executable, str(SCRIPTS / "pack_core_bundle.py"), "--verify", str(root / name)],
                    timeout=120, cwd=root)
    return {"ok": ok, "bundle": name, "tail": tail}


def check_selftest(root=None):
    root = Path(root) if root else AGI
    ok, tail = _run([sys.executable, str(root / "memory" / "scripts" / "_selftest.py")], timeout=60)
    return {"ok": ok, "tail": tail}


def check_conformance_quick(root=None):
    root = Path(root) if root else AGI
    ok, tail = _run([sys.executable, str(root / "tests" / "conformance" / "test_conformance.py"),
                     "--quick"], timeout=180)
    return {"ok": ok, "tail": tail}


def check_signature(root=None):
    """Trust Layer P0: the core manifest carries a device-key signature.

    Policy: FAIL only on contradiction (a signature is present but wrong). An install
    without a device key or without a signed manifest is not blocked - boots must never
    deadlock on a missing key - but the state is reported.
    """
    root = Path(root) if root else AGI
    manifest = root / "core_manifest.json"
    sig_path = root / "core_manifest.json.sig"
    key_path = root / "state" / "keys" / "device.json"
    if not key_path.exists():
        return {"ok": True, "skipped": "no device key (crypto.py keygen)"}
    if not sig_path.exists():
        return {"ok": True, "skipped": "core manifest not signed (crypto.py sign core_manifest.json)"}
    try:
        rec = json.loads(key_path.read_text(encoding="utf-8"))
        env = json.loads(sig_path.read_text(encoding="utf-8"))
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import crypto
        r = crypto.verify_bytes(manifest.read_bytes(), env, expected_key_id=rec.get("key_id"))
        return {"ok": r.get("ok"), "alg": r.get("alg"), "key_id": r.get("key_id"),
                "tail": r.get("reason")}
    except Exception as e:
        return {"ok": False, "tail": f"signature check error: {type(e).__name__}: {e}"}


def check_trust_log(root=None):
    """Trust Layer P1: verify the append-only Merkle log and its signed tree heads."""
    root = Path(root) if root else AGI
    events = root / "state" / "trust_log" / "events.jsonl"
    heads = root / "state" / "trust_log" / "heads"
    monitor = root / "state" / "trust_log" / "monitor.json"
    if not events.exists() and not heads.exists():
        return {"ok": True, "skipped": "no trust log"}
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import trust_log
        key_path = root / "state" / "keys" / "device.json"
        if not key_path.exists():
            return {"ok": True, "skipped": "no device key; log heads cannot be pinned (crypto.py keygen)"}
        pinned = json.loads(key_path.read_text(encoding="utf-8")).get("key_id")
        r = trust_log.verify_paths(events, heads, monitor, expected_key_id=pinned)
        return {"ok": r.get("ok"), "events": r.get("events"), "heads": r.get("heads"),
                "tail": "; ".join(r.get("problems") or [])[:300]}
    except Exception as e:
        return {"ok": False, "tail": f"trust log check error: {type(e).__name__}: {e}"}


def check_passport(root=None):
    """Trust Layer L1 (P2): the passport is a signed credential bound to the genome root.

    FAIL only on contradiction (bad signature, genome root/epoch mismatch, broken transition
    chain). Absence is soft - a member that has not minted a passport still boots.
    """
    root = Path(root) if root else AGI
    passport = root / "state" / "passport.json"
    if not passport.exists():
        return {"ok": True, "skipped": "no passport (passport.py init)"}
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import crypto
        import passport as passport_mod
        saved_state = passport_mod.STATE
        saved_paths = (passport_mod.GENOME, passport_mod.TREE, passport_mod.TRANSITIONS,
                       passport_mod.PASSPORT, passport_mod.PASSPORT_SIG)
        try:
            passport_mod.STATE = root / "state"
            passport_mod.GENOME = root / "state" / "genome"
            passport_mod.TREE = passport_mod.GENOME / "tree.json"
            passport_mod.TRANSITIONS = passport_mod.GENOME / "transitions.jsonl"
            passport_mod.PASSPORT = passport
            passport_mod.PASSPORT_SIG = root / "state" / "passport.json.sig"
            rep = passport_mod.verify_passport(deep=False)
        finally:
            passport_mod.STATE = saved_state
            (passport_mod.GENOME, passport_mod.TREE, passport_mod.TRANSITIONS,
             passport_mod.PASSPORT, passport_mod.PASSPORT_SIG) = saved_paths
        return {"ok": rep.get("ok"), "passport_id": rep.get("passport_id"),
                "genome_epoch": rep.get("genome_epoch"), "bundle_class": rep.get("bundle_class"),
                "tail": "; ".join(rep.get("problems") or [])[:300]}
    except Exception as e:
        return {"ok": False, "tail": f"passport check error: {type(e).__name__}: {e}"}


def check_bundles(root=None):
    """Trust Layer L2/L3 (P3): the active bundle manifest obeys its class and the installed core.

    FAIL only on contradiction (bad signature, class-rule violation, core/parent hash drift,
    passport mismatch). No manifests at all is soft: an installation may not have minted yet.
    """
    root = Path(root) if root else AGI
    bdir = root / "state" / "bundles"
    if not bdir.exists() or not list(bdir.glob("*.json")):
        return {"ok": True, "skipped": "no bundle manifests (bundles.py init-all)"}
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import bundles as bmod
        saved = (bmod.BUNDLES, bmod.ACTIVE, bmod.PASSPORT, bmod.AGI, bmod.STATE)
        try:
            bmod.BUNDLES = bdir
            bmod.ACTIVE = bdir / "active.json"
            bmod.PASSPORT = root / "state" / "passport.json"
            bmod.AGI = root
            bmod.STATE = root / "state"
            rep = bmod.verify_bundle(None, deep=True)
        finally:
            (bmod.BUNDLES, bmod.ACTIVE, bmod.PASSPORT, bmod.AGI, bmod.STATE) = saved
        return {"ok": rep.get("ok"), "bundle_id": rep.get("bundle_id"), "class": rep.get("class"),
                "tail": "; ".join(rep.get("problems") or [])[:300]}
    except Exception as e:
        return {"ok": False, "tail": f"bundle lattice check error: {type(e).__name__}: {e}"}


def check_activation(root=None):
    """Trust Layer L1.5 (P4): D-touch activation - attestations, revocations, presence, level.

    FAIL only on contradiction (an attestation whose root signature or member binding is wrong,
    a revocation whose device signature is wrong). Absence is soft: a member that has not been
    touched stays at U0 and boots fine. Expiry is honest state, not a failure.
    """
    root = Path(root) if root else AGI
    act = root / "state" / "activation"
    if not act.exists() and not (root / "state" / "keys" / "root.json").exists():
        return {"ok": True, "skipped": "no activation layer (root.py ceremony init)"}
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import activation as amod
        import root as rmod
        saved = (amod.ACT, amod.ATTEST_DIR, amod.REVOCATIONS, amod.HEARTBEAT, amod.PASSPORT,
                 rmod.KEYS, rmod.ROOT_RECORD, rmod.ROOT_DIR, rmod.GENESIS)
        try:
            amod.ACT = act
            amod.ATTEST_DIR = act / "attestations"
            amod.REVOCATIONS = act / "revocations.jsonl"
            amod.HEARTBEAT = act / "heartbeat.json"
            amod.PASSPORT = root / "state" / "passport.json"
            rmod.KEYS = root / "state" / "keys"
            rmod.ROOT_RECORD = rmod.KEYS / "root.json"
            rmod.ROOT_DIR = root / "state" / "root"
            rmod.GENESIS = rmod.ROOT_DIR / "genesis.json"
            rep = amod.verify_all()
        finally:
            (amod.ACT, amod.ATTEST_DIR, amod.REVOCATIONS, amod.HEARTBEAT, amod.PASSPORT,
             rmod.KEYS, rmod.ROOT_RECORD, rmod.ROOT_DIR, rmod.GENESIS) = saved
        return {"ok": rep.get("ok"), "level": rep.get("level"),
                "genome_active": rep.get("genome_active"),
                "attestations": rep.get("attestations"), "revocations": rep.get("revocations"),
                "tail": "; ".join(rep.get("problems") or [])[:300]}
    except Exception as e:
        return {"ok": False, "tail": f"activation check error: {type(e).__name__}: {e}"}


def check_public(root=None):
    """Trust Layer P5: the *.public mirror must prove itself (head + envelopes + inclusions).

    FAIL only on contradiction: a broken manifest signature, a tree head that does not verify,
    an envelope whose hash/signature is wrong, or an inclusion proof that misses the head.
    No mirror is soft - an installation that never published anything boots fine.
    """
    root = Path(root) if root else AGI
    mirror = root / "state" / "public" / "mirror"
    if not (mirror / "manifest.json").exists():
        return {"ok": True, "skipped": "no public mirror (public.py export)"}
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import public as pmod
        saved = (pmod.STATE, pmod.PUB, pmod.MIRROR, pmod.IMPORTED, pmod.CONTRIB, pmod.MERGED,
                 pmod.CONTRIBUTORS, pmod.PILLS, pmod.AGI, pmod.MEM)
        try:
            pmod.AGI = root
            pmod.MEM = root / "memory"
            pmod.STATE = root / "state"
            pmod.PUB = pmod.STATE / "public"
            pmod.MIRROR = mirror
            pmod.IMPORTED = pmod.PUB / "imported"
            pmod.CONTRIB = pmod.STATE / "contributions"
            pmod.MERGED = pmod.PUB / "merged.json"
            pmod.CONTRIBUTORS = pmod.PUB / "contributors.json"
            pmod.PILLS = pmod.STATE / "pills"
            rep = pmod.verify_mirror()
        finally:
            (pmod.STATE, pmod.PUB, pmod.MIRROR, pmod.IMPORTED, pmod.CONTRIB, pmod.MERGED,
             pmod.CONTRIBUTORS, pmod.PILLS, pmod.AGI, pmod.MEM) = saved
        return {"ok": rep.get("ok"), "pills": rep.get("pills"), "head_size": rep.get("head_size"),
                "tail": "; ".join(rep.get("problems") or [])[:300]}
    except Exception as e:
        return {"ok": False, "tail": f"public mirror check error: {type(e).__name__}: {e}"}


def check_install(root=None):
    """Corrected model (D 2026-10-26): ONE official repo + update pool + a legal install role.

    FAIL only on contradiction: the repo manifest signature or the pool proofs are wrong, the
    distributed bundle is not class official, or the install claims master/custom without the
    record that justifies it. No repo yet is soft - an install can exist before the repo does.
    """
    root = Path(root) if root else AGI
    repodir = root / "state" / "repo" / "AGI"
    install = root / "state" / "install.json"
    if not (repodir / "repo.json").exists() and not install.exists():
        return {"ok": True, "skipped": "no official repo and no install record"}
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import repo as rmod
        saved = (rmod.REPO, rmod.POOL, rmod.OFFICIAL_DIR, rmod.REMOTE, rmod.INSTALL, rmod.IMPORTED,
                 rmod.STATE, rmod.AGI, rmod.REPO_ROOT)
        try:
            rmod.AGI = root
            rmod.STATE = root / "state"
            rmod.REPO_ROOT = root / "state" / "repo"
            rmod.REPO = repodir
            rmod.POOL = repodir / "pool"
            rmod.OFFICIAL_DIR = repodir / "bundle" / "official"
            rmod.REMOTE = root / "state" / "repo" / "remotes" / "AGI.git"
            rmod.INSTALL = install
            rmod.IMPORTED = root / "state" / "public" / "imported"
            rep = rmod.verify()
        finally:
            (rmod.REPO, rmod.POOL, rmod.OFFICIAL_DIR, rmod.REMOTE, rmod.INSTALL, rmod.IMPORTED,
             rmod.STATE, rmod.AGI, rmod.REPO_ROOT) = saved
        return {"ok": rep.get("ok"), "role": rep.get("install_role"),
                "commit": rep.get("commits"),
                "pool": (rep.get("pool") or {}).get("pills"),
                "tail": "; ".join(rep.get("problems") or [])[:300]}
    except Exception as e:
        return {"ok": False, "tail": f"install/repo check error: {type(e).__name__}: {e}"}


def check_identity(root=None):
    """Native identity layer (P13): profiles, session level and federation hygiene.

    FAIL only on contradiction: a session pointing at a missing profile, an unknown level, or a
    federation link that stores a raw handle. An expired session is normal (login again). No identity
    layer at all is soft - a fresh install boots before the first profile exists.
    """
    root = Path(root) if root else AGI
    idf = root / "state" / "identity" / "profiles.json"
    if not idf.exists():
        return {"ok": True, "skipped": "no identity layer (identity.py init)"}
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import identity as imod
        saved = (imod.STATE, imod.ID_DIR, imod.PROFILES, imod.SESSION, imod.CHALLENGE)
        pk_saved = None
        try:
            import passkey as pk_mod
            pk_saved = (pk_mod.ID_DIR, pk_mod.PASSKEYS, pk_mod.CHALLENGE)
            pk_mod.ID_DIR = root / "state" / "identity"
            pk_mod.PASSKEYS = pk_mod.ID_DIR / "passkeys.json"
            pk_mod.CHALLENGE = pk_mod.ID_DIR / "passkey_challenge.json"
        except Exception:
            pk_mod = None
        try:
            imod.STATE = root / "state"
            imod.ID_DIR = imod.STATE / "identity"
            imod.PROFILES = imod.ID_DIR / "profiles.json"
            imod.SESSION = imod.ID_DIR / "session.json"
            imod.CHALLENGE = imod.ID_DIR / "challenge.json"
            rep = imod.verify()
        finally:
            (imod.STATE, imod.ID_DIR, imod.PROFILES, imod.SESSION, imod.CHALLENGE) = saved
            if pk_saved is not None:
                (pk_mod.ID_DIR, pk_mod.PASSKEYS, pk_mod.CHALLENGE) = pk_saved
        passkey_report = {"ok": True, "credentials": 0}
        if pk_mod is not None:
            try:
                passkey_report = pk_mod.verify_state()
            except Exception as e:
                passkey_report = {"ok": False, "problems": [f"passkey state error: {e}"], "credentials": 0}
        if not passkey_report.get("ok"):
            rep = dict(rep)
            rep["ok"] = False
            rep["problems"] = (rep.get("problems") or []) + ["passkey: " + p for p in passkey_report.get("problems") or []]
        return {"ok": rep.get("ok"), "profiles": rep.get("profiles"),
                "passkeys": passkey_report.get("credentials"),
                "level": (rep.get("session") or {}).get("level"),
                "tail": "; ".join(rep.get("problems") or [])[:300]}
    except Exception as e:
        return {"ok": False, "tail": f"identity check error: {type(e).__name__}: {e}"}


def run_gate(root=None, write=True):
    root = Path(root) if root else AGI
    t0 = time.time()
    checks = {
        "manifest": check_manifest(root),
        "bundle": check_bundle(root),
        "selftest": check_selftest(root),
        "conformance_quick": check_conformance_quick(root),
        "signature": check_signature(root),
        "trust_log": check_trust_log(root),
        "passport": check_passport(root),
        "bundles": check_bundles(root),
        "activation": check_activation(root),
        "public": check_public(root),
        "install": check_install(root),
        "identity": check_identity(root),
    }
    ok = all(c.get("ok") for c in checks.values())
    summary = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "ok": ok,
               "dur_ms": int((time.time() - t0) * 1000), "checks": checks}
    if write:
        target = (root / "state" / "boot_gate.json")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def selftest():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        (tmp / "a.txt").write_text("alpha", encoding="utf-8")
        good = hashlib.sha256(b"alpha").hexdigest()[:16]
        (tmp / "core_manifest.json").write_text(json.dumps(
            {"files": [{"path": "a.txt", "sha256": good, "layer": "test"}]}), encoding="utf-8")
        ok_good = check_manifest(tmp)["ok"]
        (tmp / "a.txt").write_text("tampered", encoding="utf-8")
        tampered = check_manifest(tmp)
        (tmp / "a.txt").unlink()
        missing = check_manifest(tmp)
        ok = ok_good and not tampered["ok"] and not missing["ok"] and "a.txt" in missing["missing"]
        print("boot_gate selftest:", "PASS" if ok else "FAIL",
              "| clean=PASS tampered_detected=%s missing_detected=%s" % (not tampered["ok"], not missing["ok"]))
        return 0 if ok else 1


def main():
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    g = run_gate()
    print("boot gate: %s in %d ms | manifest=%s bundle=%s selftest=%s conformance_quick=%s signature=%s trust_log=%s passport=%s bundles=%s activation=%s public=%s install=%s identity=%s" % (
        "PASS" if g["ok"] else "FAIL", g["dur_ms"],
        g["checks"]["manifest"]["ok"], g["checks"]["bundle"]["ok"],
        g["checks"]["selftest"]["ok"], g["checks"]["conformance_quick"]["ok"],
        g["checks"]["signature"]["ok"], g["checks"]["trust_log"]["ok"],
        g["checks"]["passport"]["ok"], g["checks"]["bundles"]["ok"],
        g["checks"]["activation"]["ok"],
        g["checks"]["public"]["ok"],
        g["checks"]["install"]["ok"],
        g["checks"]["identity"]["ok"]))
    sys.exit(0 if g["ok"] else 1)


if __name__ == "__main__":
    main()

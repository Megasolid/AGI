#!/usr/bin/env python3
"""seeding.py - S4: improvement ledger, seeding readiness and the acting-Master mode.

D's rules (P52/P53/P55):
  * only a Master seeds the next generation; while D is absent (>= 7 days) the AGI acts as Master;
  * in acting mode seeding needs NO user interaction: it decides on evidence and informs members afterwards;
  * thresholds: projected next-design improvement >= 10%, or a blocked capability/UI/subsystem, or vitality;
  * confidence, minimum generation age and Council co-sign are policy genes; a signed seed decision and a
    rollback path are required.
This module is a dry-run planner: it never creates a generation; it records the decision and the evidence.
"""
import argparse
import datetime
import json
import pathlib
import sys

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-seeding/1"
AREAS = ["ui", "knowledge", "subsystem", "society", "brain", "harness"]


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "ledger": root / "state" / "seeding" / "improvements.json",
            "readiness": root / "state" / "seeding" / "readiness.json",
            "decisions": root / "state" / "seeding" / "decisions",
            "seen": root / "state" / "society" / "last_master_seen.json"}


def policy(root=None):
    try:
        import policy as p
        return p.POLICIES.get("seeding") or {}
    except Exception:
        return {"min_projected_gain": 0.10, "min_confidence": 0.80, "min_absence_days": 7,
                "council_cosign": True, "no_user_interaction_in_acting_mode": True, "rollback_required": True}


# ---------------------------------------------------------------- improvement ledger
def ledger(root=None):
    data = _jload(_paths(root)["ledger"]) or {"schema": SCHEMA, "items": []}
    data.setdefault("items", [])
    return data


def add_item(title, area="subsystem", projected_gain=0.0, confidence=0.0, blocked_by="", est_ready="", root=None):
    if area not in AREAS:
        return {"ok": False, "error": "area must be one of %s" % AREAS}
    g = max(0.0, min(1.0, float(projected_gain)))
    c = max(0.0, min(1.0, float(confidence)))
    data = ledger(root)
    item = {"id": "imp-" + (str(len(data["items"]) + 1).zfill(3)), "title": str(title).strip(),
            "area": area, "projected_gain": g, "confidence": c, "blocked_by": blocked_by,
            "est_ready": est_ready or "", "status": "open",
            "created": datetime.datetime.now().isoformat(timespec="seconds")}
    data["items"].append(item)
    _jdump(_paths(root)["ledger"], data)
    return {"ok": True, "item": item}


def update_item(item_id, root=None, **fields):
    data = ledger(root)
    for it in data["items"]:
        if it["id"] == item_id:
            for k in ("status", "projected_gain", "confidence", "blocked_by", "est_ready", "title", "area"):
                if k in fields and fields[k] is not None:
                    it[k] = fields[k]
            it["updated"] = datetime.datetime.now().isoformat(timespec="seconds")
            _jdump(_paths(root)["ledger"], data)
            return {"ok": True, "item": it}
    return {"ok": False, "error": "unknown item"}


def readiness(root=None):
    """Aggregate improvement projection and ETA from open ledger items."""
    pol = policy(root)
    items = [it for it in ledger(root)["items"] if it.get("status") in ("open", "planned", "blocked")]
    open_items = [it for it in items if it.get("status") == "open"]
    projected = sum(float(it.get("projected_gain") or 0) for it in open_items)
    weighted_conf = (sum(float(it.get("confidence") or 0) * float(it.get("projected_gain") or 0)
                         for it in open_items) / projected) if projected else 0.0
    ready_items = [it for it in open_items if float(it.get("projected_gain") or 0) > 0]
    eta = min([it["est_ready"] for it in ready_items if it.get("est_ready")], default="unknown")
    threshold = float(pol.get("min_projected_gain", 0.10))
    confidence_ok = weighted_conf >= float(pol.get("min_confidence", 0.80))
    percent = min(100, round(100 * projected / threshold)) if threshold > 0 else 0
    return {"schema": SCHEMA, "open_items": len(open_items), "projected_gain": round(projected, 3),
            "weighted_confidence": round(weighted_conf, 3), "threshold": threshold,
            "confidence_ok": confidence_ok, "readiness_percent": percent, "eta": eta,
            "items": open_items, "policy": pol}


# ---------------------------------------------------------------- acting-Master decision
def seed_ledger(root=None):
    """Seed the ledger with the real open improvements tracked in P52/P55/P72 (idempotent)."""
    if ledger(root)["items"]:
        return {"ok": True, "skipped": "ledger already has items"}
    items = [
        ("UI masterpiece module adoption (incubator -> dashboard core)", "ui", 0.06, 0.75, "2026-11-15"),
        ("Bridge pair-benchmark batching / faster host evaluation", "brain", 0.04, 0.90, "2026-11-01"),
        ("Member auto-migration tooling for the next generation", "society", 0.05, 0.60, "2026-11-20"),
        ("Rough live cold-boot red mode + supervision surface", "society", 0.02, 0.80, "2026-11-05"),
    ]
    added = []
    for title, area, gain, conf, eta in items:
        added.append(add_item(title, area, gain, conf, est_ready=eta, root=root)["item"])
    return {"ok": True, "added": len(added), "items": added}


def mark_master_seen(root=None, ts=None):
    _jdump(_paths(root)["seen"], {"ts": ts or datetime.datetime.now().isoformat(timespec="seconds")})
    return {"ok": True}


def absent_days(root=None):
    seen = _jload(_paths(root)["seen"])
    if not seen:
        return 0.0
    try:
        return max(0.0, (datetime.datetime.now() - datetime.datetime.strptime(seen["ts"][:19],
                                                                             "%Y-%m-%dT%H:%M:%S")).total_seconds() / 86400)
    except Exception:
        return 0.0


def decide(root=None, absence_days=None, council_cosign=None, simulate_absence=None):
    pol = policy(root)
    absent = absent_days(root) if absence_days is None else float(absence_days)
    if simulate_absence is not None:
        absent = float(simulate_absence)
    ready = readiness(root)
    acting = absent >= float(pol.get("min_absence_days", 7))
    if not acting:
        return {"ok": True, "mode": "human-supervised", "absent_days": round(absent, 2),
                "decision": "wait-for-master",
                "reason": "D present (absent < %s days): seeding needs the Master's decision" % pol.get("min_absence_days", 7),
                "readiness": ready}
    cosign = bool(pol.get("council_cosign", True)) if council_cosign is None else bool(council_cosign)
    gate_gain = ready["projected_gain"] >= float(pol.get("min_projected_gain", 0.10))
    gate_conf = ready["weighted_confidence"] >= float(pol.get("min_confidence", 0.80)) if ready["projected_gain"] else False
    if gate_gain and gate_conf and cosign:
        decision = "seed-next-generation"
        reason = "acting Master: projected gain %.2f >= %.2f, confidence %.2f >= %.2f, council co-signed" % (
            ready["projected_gain"], ready["threshold"], ready["weighted_confidence"],
            float(pol.get("min_confidence", 0.80)))
        rec = {"schema": SCHEMA, "ts": datetime.datetime.now().isoformat(timespec="seconds"),
               "mode": "acting-master", "decision": decision, "reason": reason, "readiness": ready,
               "no_user_interaction": bool(pol.get("no_user_interaction_in_acting_mode", True)),
               "rollback_required": bool(pol.get("rollback_required", True)), "dry_run": True,
               "next": "generate staging seed plan; apply only with rollback snapshot"}
        _jdump(_paths(root)["decisions"] / ("%s.json" % rec["ts"].replace(":", "")), rec)
        return {"ok": True, **rec}
    return {"ok": True, "mode": "acting-master", "absent_days": round(absent, 2), "decision": "wait",
            "reason": "gates not met yet", "gates": {"gain": gate_gain, "confidence": gate_conf,
                                                     "council_cosign": cosign}, "readiness": ready}


def _restore_from_drill(drill, root=None):
    """Restore the snapshot produced by rollback_drill (auto-rollback path)."""
    import shutil
    rootp = pathlib.Path(root) if root else AGI
    snap = rootp / drill["dir"]
    manifest = _jload(snap / "manifest.json") or {}
    restored = []
    for f in manifest.get("files", []):
        src = snap / f["path"].replace("/", "__")
        dst = rootp / f["path"]
        if src.is_file():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            restored.append(f["path"])
    return {"ok": True, "restored": restored}


def execute(root=None, confirmer=""):
    """LIVE next-generation seed: verified rollback -> archive old gen -> birth -> migrate -> re-sign -> verify.

    Requires explicit Master confirmation (`confirmer`) and green readiness gates. Any failed verification
    triggers the verified snapshot restore.
    """
    import hashlib
    import os
    import shutil
    rootp = pathlib.Path(root) if root else AGI
    ready = readiness(rootp)
    dec = decide(rootp)
    pol = policy(rootp)
    if not confirmer:
        return {"ok": False, "error": "explicit Master confirmation required (--confirm \"<name>\")"}
    if ready["projected_gain"] < ready["threshold"]:
        return {"ok": False, "error": "gain gate not met", "readiness": ready}
    if not ready["confidence_ok"]:
        return {"ok": False, "error": "confidence gate not met", "readiness": ready}
    if dec.get("mode") != "human-supervised" and dec.get("decision") != "seed-next-generation":
        return {"ok": False, "error": "decision is not seedable", "decision": dec}
    drill = rollback_drill(rootp)
    if not drill.get("verified"):
        return {"ok": False, "error": "rollback drill not verified; refusing to seed", "drill": drill}
    import birth
    import cleanroom
    import crypto
    import family
    import migration
    old = migration.current_generation(rootp)
    psp = migration._jload(rootp / "state/passport.json", {}) or {}
    old_psp_id = psp.get("passport_id")
    safe_old = (old.get("gen_id") or "unknown").replace(":", "-")[:40]
    arch = rootp / "state" / "archive" / "generations" / safe_old
    arch.mkdir(parents=True, exist_ok=True)
    for rel in ("state/genesis/birth.json", "state/genesis/seed.bin", "state/passport.json",
                "state/passport.json.sig", "state/family/registry.json", "state/family/registry.sig"):
        src = rootp / rel
        if src.is_file():
            dst = arch / rel.replace("/", "__")
            shutil.copy2(src, dst)
    try:
        pre_bundle = cleanroom.export_bundle(rootp)
    except Exception as e:
        pre_bundle = {"ok": False, "error": str(e)[:160]}
    try:
        b = birth.birth(root=rootp, seed=os.urandom(32), parent=old_psp_id)
        if not b.get("ok"):
            raise RuntimeError("birth failed: %s" % b.get("error"))
        mig = migration.apply(rootp, to_gen_id=b["gen_id"], to_genome8=b.get("genome8"),
                              to_natal=(b.get("natal_interest") or {}).get("domain"))
        if not mig.get("ok"):
            raise RuntimeError("migration failed: %s" % mig)
        sig_path, env = crypto.sign_file(rootp / "state" / "passport.json")
        sig = crypto.verify_file(rootp / "state" / "passport.json")
        fam = family.sign_registry(rootp)
        fam_ver = family.verify_registry(rootp)
        mig_ver = migration.verify(rootp)
        imp = {"ok": False, "error": "no pre-seed bundle"}
        if pre_bundle and pre_bundle.get("ok"):
            bpath = pre_bundle.get("path") or ""
            bpath = rootp / bpath if not pathlib.Path(bpath).is_absolute() else pathlib.Path(bpath)
            imp = cleanroom.import_bundle(str(bpath), rootp, apply=True)
        new_psp = migration._jload(rootp / "state" / "passport.json", {}) or {}
        checks = {"birth_ok": bool(b.get("ok")), "migration_ok": bool(mig.get("ok")),
                  "passport_signature": bool(sig.get("ok")),
                  "passport_identity_preserved": new_psp.get("passport_id") == old_psp_id,
                  "family_registry": bool(fam_ver.get("ok")), "migration_verify": bool(mig_ver.get("ok")),
                  "generation_changed": (new_psp.get("generation") or {}).get("gen_id") == b["gen_id"],
                  "cleanroom_export": bool(pre_bundle.get("ok")),
                  "cleanroom_import": bool(imp.get("ok")),
                  "cleanroom_fidelity": bool((imp.get("fidelity") or {}).get("ok"))}
        ok = all(checks.values())
        rec = {"schema": "agi-seed-execution/1", "ts": datetime.datetime.now().isoformat(timespec="seconds"),
               "confirmer": confirmer, "ok": ok, "from": old, "to": {"gen_id": b.get("gen_id"),
               "genome8": b.get("genome8"), "natal_interest": (b.get("natal_interest") or {}).get("domain")},
               "checks": checks, "rollback_drill": drill["dir"], "archive": str(arch.relative_to(rootp)),
               "cleanroom_bundle": pre_bundle.get("path"), "cleanroom_fidelity": imp.get("fidelity"),
               "passport_id": old_psp_id, "auto_restored": False}
        seeds = _jload(rootp / "state" / "seeding" / "seeds.json") or {"schema": "agi-seeds/1", "executions": []}
        seeds.setdefault("executions", []).append(rec)
        _jdump(rootp / "state" / "seeding" / "seeds.json", seeds)
        if not ok:
            rec["auto_restored"] = True
            _restore_from_drill(drill, rootp)
            _jdump(rootp / "state" / "seeding" / "seeds.json", seeds)
        try:
            sys.path.insert(0, str(rootp / "memory" / "scripts"))
            import trust_log
            trust_log.append("seed.executed", {"ok": ok, "from": old.get("gen_id"), "to": b.get("gen_id"),
                                               "auto_restored": rec["auto_restored"]})
        except Exception:
            pass
        return {"ok": ok, **rec}
    except Exception as e:
        _restore_from_drill(drill, rootp)
        try:
            sys.path.insert(0, str(rootp / "memory" / "scripts"))
            import trust_log
            trust_log.append("seed.executed", {"ok": False, "error": str(e)[:160], "auto_restored": True})
        except Exception:
            pass
        return {"ok": False, "error": str(e)[:240], "auto_restored": True, "rollback_drill": drill["dir"]}


CHECKLIST = ["spec freeze", "clean-core gate green", "invariants hash unchanged", "policy compatibility",
             "member data export", "benchmark re-anchor", "rollback snapshot verified", "D/Council acceptance"]


def _snapshot(root):
    """Files that must survive a rollback: passport, family registry, society roster, ledger, last head."""
    root = pathlib.Path(root) if root else AGI
    rels = ["state/passport.json", "state/passport.json.sig", "state/genesis/birth.json",
            "state/genesis/seed.bin", "state/family/registry.json",
            "state/family/registry.sig", "state/society/roster.json", "state/seeding/improvements.json"]
    try:
        heads = sorted((root / "state" / "trust_log" / "heads").glob("*.json"))
        if heads:
            rels.append(str(heads[-1].relative_to(root)).replace("\\", "/"))
    except Exception:
        pass
    return [r for r in rels if (root / r).is_file()]


def rollback_drill(root=None):
    """Snapshot the rollback-critical files + verify their hashes; does NOT change any live state."""
    root = pathlib.Path(root) if root else AGI
    import hashlib
    import shutil
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    snapdir = root / "state" / "seeding" / "rollback" / ts
    snapdir.mkdir(parents=True, exist_ok=True)
    files = []
    for rel in _snapshot(root):
        src = root / rel
        dst = snapdir / rel.replace("/", "__")
        shutil.copy2(src, dst)
        files.append({"path": rel, "bytes": dst.stat().st_size,
                      "sha256": hashlib.sha256(dst.read_bytes()).hexdigest()})
    manifest = {"schema": "agi-seed-rollback/1", "ts": ts, "files": files,
                "restore_steps": ["stop writer", "copy files back from this directory",
                                  "verify family registry signature and trust head",
                                  "re-run boot_gate and boot; keep the previous generation as ancestor"],
                "verified": all(hashlib.sha256((snapdir / f["path"].replace("/", "__")).read_bytes()).hexdigest() == f["sha256"]
                                for f in files) if files else False}
    _jdump(snapdir / "manifest.json", manifest)
    try:
        import trust_log
        trust_log.append("seed.rollback_drill", {"dir": ts, "files": len(files), "verified": manifest["verified"]})
    except Exception:
        pass
    return {"ok": True, "dir": str(snapdir.relative_to(root)), "files": len(files),
            "verified": manifest["verified"], "manifest": manifest}


def stage(root=None):
    """Build (and record) a dry-run next-generation staging plan. Never creates a seed or a generation."""
    root = pathlib.Path(root) if root else AGI
    import hashlib
    try:
        import family
        fam_ok = bool(family.verify_registry(root).get("ok"))
        gen = family.build_registry(root).get("generation") or {}
    except Exception:
        fam_ok, gen = False, {}
    try:
        import policy
        pol_ok = bool(policy.validate().get("ok"))
        inv = policy.seal()
    except Exception:
        pol_ok, inv = False, ""
    ready = readiness(root)
    decision = decide(root)
    # candidate preview: derived from a fresh ephemeral seed + current genome; NOT persisted
    try:
        import genome
        import genid
        import secrets
        g = genome.genome(root)
        preview_seed = secrets.token_bytes(32)
        code = genome.codons(preview_seed, g["digest"])
        preview = genid.compose_genetic(code, g["digest8"])["display"]
    except Exception:
        preview = "preview-unavailable"
    preconditions = {"generation": gen.get("gen_id"), "family_registry_ok": fam_ok,
                     "policy_valid": pol_ok, "invariants_hash": inv,
                     "projected_gain": ready["projected_gain"],
                     "confidence": ready["weighted_confidence"], "confidence_ok": ready["confidence_ok"]}
    checklist = [{"step": s, "done": s in ("clean-core gate green", "invariants hash unchanged", "policy compatibility",
                                           "rollback snapshot verified")} for s in CHECKLIST]
    plan = {"schema": "agi-seed-plan/1", "ts": datetime.datetime.now().isoformat(timespec="seconds"),
            "current_generation": gen, "candidate_preview": {"gen_id": preview,
                                                             "note": "ephemeral preview only; no seed persisted"},
            "preconditions": preconditions, "checklist": checklist, "decision": decision,
            "rollback": {"required": True, "drill": "run --rollback-drill first"},
            "staged_only": True}
    digest = hashlib.sha256(json.dumps(plan, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    plan["digest"] = digest
    plans = root / "state" / "seeding" / "plans"
    plans.mkdir(parents=True, exist_ok=True)
    _jdump(plans / ("seed-plan-" + plan["ts"].replace(":", "") + ".json"), plan)
    try:
        import trust_log
        trust_log.append("seed.staged", {"digest": digest, "preview": preview, "decision": decision.get("decision")})
    except Exception:
        pass
    return {"ok": True, **plan}


def rehearse(root=None):
    """Full next-generation rehearsal in a throwaway copy: birth -> migrate -> sign/verify. Never touches live state."""
    import hashlib
    import shutil
    import tempfile
    import os
    root = pathlib.Path(root) if root else AGI
    live_before = {rel: hashlib.sha256((root / rel).read_bytes()).hexdigest()
                   for rel in ("state/passport.json", "state/genesis/birth.json")
                   if (root / rel).is_file()}
    checks = []
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        for rel in ("state/passport.json", "state/genesis", "state/bundles", "state/family", "state/society",
                    "state/seeding", "state/identity", "state/keys", "core", "memory/knowledge"):
            src = root / rel
            if src.is_dir():
                shutil.copytree(src, tmp / rel, dirs_exist_ok=True)
            elif src.is_file():
                (tmp / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, tmp / rel)
        import birth
        import migration
        import family
        seed = os.urandom(32)
        b = birth.birth(root=tmp, seed=seed, parent=(migration._jload(tmp / "state/passport.json", {}) or {}).get("passport_id"))
        checks.append({"step": "birth new generation", "ok": bool(b.get("ok")), "gen_id": b.get("gen_id")})
        if b.get("ok"):
            mig = migration.apply(tmp, to_gen_id=b["gen_id"], to_genome8=b.get("genome8"),
                                  to_natal=(b.get("natal_interest") or {}).get("domain"))
            checks.append({"step": "migrate members", "ok": bool(mig.get("ok")), "migrated": mig.get("migrated")})
            sign = family.sign_registry(tmp)
            checks.append({"step": "sign family registry", "ok": bool(sign.get("ok"))})
            ver = family.verify_registry(tmp)
            checks.append({"step": "verify family registry", "ok": bool(ver.get("ok")), "problems": ver.get("problems")})
            psp = migration._jload(tmp / "state/passport.json", {}) or {}
            checks.append({"step": "passport identity preserved",
                           "ok": psp.get("passport_id") == (migration._jload(root / "state/passport.json", {}) or {}).get("passport_id"),
                           "gen": (psp.get("generation") or {}).get("gen_id")})
            checks.append({"step": "member data present", "ok": (tmp / "state/family/registry.json").is_file()})
            try:
                import cleanroom as _cr
                exp = _cr.export_bundle(tmp)
                ipath = tmp / exp["path"] if not pathlib.Path(exp.get("path", "")).is_absolute() else pathlib.Path(exp["path"])
                imp = _cr.import_bundle(str(ipath), tmp, apply=True)
                checks.append({"step": "cleanroom export/import fidelity",
                               "ok": bool(exp.get("ok") and imp.get("ok") and (imp.get("fidelity") or {}).get("ok")),
                               "fidelity": (imp.get("fidelity") or {}).get("fidelity")})
            except Exception as e:
                checks.append({"step": "cleanroom export/import fidelity", "ok": False, "error": str(e)[:160]})
        live_after = {rel: hashlib.sha256((root / rel).read_bytes()).hexdigest() for rel in live_before}
        untouched = live_before == live_after
        checks.append({"step": "live state untouched", "ok": untouched})
    report = {"schema": "agi-seed-rehearsal/1", "ts": datetime.datetime.now().isoformat(timespec="seconds"),
              "checks": checks, "ok": all(c["ok"] for c in checks),
              "note": "rehearsal runs in a throwaway copy; the live generation is not seeded"}
    repdir = root / "state" / "seeding" / "rehearsals"
    repdir.mkdir(parents=True, exist_ok=True)
    _jdump(repdir / ("rehearsal-" + report["ts"].replace(":", "") + ".json"), report)
    try:
        import trust_log
        trust_log.append("seed.rehearsal", {"ok": report["ok"], "checks": len(checks)})
    except Exception:
        pass
    return {"ok": report["ok"], **report}


def notify(root=None):
    r = readiness(root)
    d = decide(root)
    if d.get("decision") == "seed-next-generation":
        msg = "Next generation ready: gain %s, confidence %s - acting Master may seed." % (
            r["projected_gain"], r["weighted_confidence"])
    elif r["projected_gain"] >= r["threshold"]:
        msg = ("Next generation: gain gate met (%s), confidence %s below %s - waiting; ETA %s." %
               (r["projected_gain"], r["weighted_confidence"], policy(root).get("min_confidence"), r["eta"]))
    else:
        msg = ("Next generation: %d%% of the gain gate (%s/%s), confidence %s." %
               (r["readiness_percent"], r["projected_gain"], r["threshold"], r["weighted_confidence"]))
    return {"schema": SCHEMA, "message": msg, "readiness_percent": r["readiness_percent"],
            "projected_gain": r["projected_gain"], "confidence": r["weighted_confidence"],
            "eta": r["eta"], "decision": d.get("decision"), "mode": d.get("mode")}


def render(root=None):
    import ui
    r = readiness(root)
    d = decide(root)  # current real absence
    items = "".join("<tr><td class='mono'>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                    % (ui.e(it["id"]), ui.e(it["title"]), ui.e(it["area"]), ui.e(it["projected_gain"]),
                       ui.e(it["confidence"]), ui.e(it.get("est_ready") or "?"))
                    for it in r["items"]) or "<tr><td colspan='6'>ledger empty</td></tr>"
    body = (ui.pagehead("Seeding",
                        "Improvement ledger and the next-generation decision. While the Master is absent the AGI acts as Master on evidence.",
                        ui.badge("readiness %d%%" % r["readiness_percent"], "warn") +
                        ui.badge(d.get("mode", "?"), "info") + ui.badge(d.get("decision", "?"), "ok")) +
            "<div class='stats' style='margin:16px 0'>" +
            ui.stat("readiness", "%d%%" % r["readiness_percent"], "projected next-design gain") +
            ui.stat("projected", str(r["projected_gain"]), "threshold %s" % r["threshold"]) +
            ui.stat("confidence", str(r["weighted_confidence"]), "threshold %s" % policy(root).get("min_confidence")) +
            ui.stat("eta", str(r["eta"]), "estimate") + "</div>" +
            ui.section("Improvement ledger", ui.box("", "<table class='table'><thead><tr><th>id</th><th>improvement</th>"
                                                        "<th>area</th><th>gain</th><th>confidence</th><th>ready</th>"
                                                        "</tr></thead><tbody>%s</tbody></table>" % items, flush=True),
                       count=len(r["items"])) +
            ui.section("Decision", ui.box("", "<b>%s</b> &middot; %s<br><span class='muted'>%s</span>"
                                              % (ui.e(d.get("mode")), ui.e(d.get("decision")), ui.e(d.get("reason"))),
                                          flush=True), count=1))
    return ui.page("AGI Seeding", body, tabs=[("overview", "Overview", "/"), ("society", "Society", "/society"),
                                             ("seeding", "Seeding", "/seeding")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="seeding")


def main(argv=None):
    ap = argparse.ArgumentParser(description="improvement ledger + seeding readiness / acting-Master decision")
    ap.add_argument("--readiness", action="store_true")
    ap.add_argument("--decide", action="store_true")
    ap.add_argument("--simulate-absence", type=float, default=None)
    ap.add_argument("--add", nargs=4, metavar=("TITLE", "AREA", "GAIN", "CONFIDENCE"))
    ap.add_argument("--seed-ledger", action="store_true")
    ap.add_argument("--mark-seen", action="store_true")
    ap.add_argument("--stage", action="store_true")
    ap.add_argument("--rollback-drill", action="store_true")
    ap.add_argument("--notify", action="store_true")
    ap.add_argument("--rehearse", action="store_true")
    ap.add_argument("--close", metavar="ITEM_ID")
    ap.add_argument("--execute", action="store_true")
    ap.add_argument("--confirm", metavar="CONFIRMER", default="")
    args = ap.parse_args(argv)
    if args.execute:
        print(json.dumps(execute(confirmer=args.confirm), indent=1))
        return 0
    if args.close:
        print(json.dumps(update_item(args.close, status="done"), indent=1))
        return 0
    if args.stage:
        print(json.dumps(stage(), indent=1))
        return 0
    if args.rollback_drill:
        print(json.dumps(rollback_drill(), indent=1))
        return 0
    if args.notify:
        print(json.dumps(notify(), indent=1))
        return 0
    if args.rehearse:
        print(json.dumps(rehearse(), indent=1))
        return 0
    if args.add:
        print(json.dumps(add_item(args.add[0], args.add[1], float(args.add[2]), float(args.add[3])), indent=1))
        return 0
    if args.seed_ledger:
        print(json.dumps(seed_ledger(), indent=1))
        return 0
    if args.mark_seen:
        print(json.dumps(mark_master_seen(), indent=1))
        return 0
    if args.simulate_absence is not None:
        print(json.dumps(decide(simulate_absence=args.simulate_absence), indent=1))
        return 0
    if args.decide:
        print(json.dumps(decide(), indent=1))
        return 0
    print(json.dumps(readiness(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

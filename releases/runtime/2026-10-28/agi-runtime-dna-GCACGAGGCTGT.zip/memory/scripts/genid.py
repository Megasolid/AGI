#!/usr/bin/env python3
"""genid.py - seeded generation identity (Gen.ID): barcode/QR-compatible, checksummed.

Format
  display   G-<core>.<gen>.<seed8>              e.g. G-3.2.7-9C4A1F2B
  canonical AGI-G-<core>-<gen:03d>-<seed8>-<chk>  (Code 39 alphabet, barcode/QR payload)
  uri       agi://gen/<display>?core=..&gen=..&seed=..&parent=..
The checksum is ISO-7064 mod 97 over the canonical body, so a scanner can reject a damaged ID
without any server. Everything about an artifact's generation identity is derived from this one module.
"""
import hashlib
import re
import secrets

PREFIX = "AGI"
CORE_RE = re.compile(r"^\d+\.\d+$")
SEED_RE = re.compile(r"^[0-9A-F]{8}$")
DISPLAY_RE = re.compile(r"^G-(\d+\.\d+)\.(\d{1,6})-([0-9A-F]{8})$")
CANON_RE = re.compile(r"^AGI-G-(\d+\.\d+)-(\d{3})-([0-9A-F]{8})-(\d{2})$")


def _chk(body):
    h = hashlib.sha256(body.encode("ascii")).hexdigest()
    return "%02d" % (98 - (int(h[:12], 16) % 97))


def compose(core, gen, seed8, parent=None):
    """Build a generation identity record. `seed` is 8 uppercase hex chars (public fingerprint)."""
    if not CORE_RE.match(str(core)):
        raise ValueError("core must look like 3.2")
    gen = int(gen)
    if gen < 1 or gen > 999:
        raise ValueError("gen must be 1..999")
    seed8 = str(seed8).upper()
    if not SEED_RE.match(seed8):
        raise ValueError("seed8 must be 8 uppercase hex chars")
    display = "G-%s.%d-%s" % (core, gen, seed8)
    body = "%s-G-%s-%03d-%s" % (PREFIX, core, gen, seed8)
    canonical = body + "-" + _chk(body)
    rec = {"core": str(core), "gen": gen, "seed8": seed8, "display": display,
           "canonical": canonical, "checksum": _chk(body)}
    if parent:
        rec["parent"] = parent
    return rec


def validate(record):
    """True when canonical, checksum and display all agree (scanner-side validation)."""
    try:
        m = CANON_RE.match(record["canonical"])
        if not m:
            return False
        core, gen, seed8, chk = m.group(1), int(m.group(2)), m.group(3), m.group(4)
        body = "%s-G-%s-%03d-%s" % (PREFIX, core, gen, seed8)
        return chk == _chk(body) and record.get("display") == "G-%s.%d-%s" % (core, gen, seed8)
    except Exception:
        return False


def parse_canonical(canonical):
    m = CANON_RE.match(str(canonical))
    if not m:
        raise ValueError("not a canonical Gen.ID: %r" % canonical)
    core, gen, seed8, chk = m.group(1), int(m.group(2)), m.group(3), m.group(4)
    body = "%s-G-%s-%03d-%s" % (PREFIX, core, gen, seed8)
    if chk != _chk(body):
        raise ValueError("Gen.ID checksum mismatch")
    return compose(core, gen, seed8)


def qr_uri(record):
    """The payload a QR code encodes (standard URI; any QR writer can render it)."""
    q = "core=%s&gen=%d&seed=%s&chk=%s" % (record["core"], record["gen"], record["seed8"], record["checksum"])
    if record.get("parent"):
        q += "&parent=" + record["parent"]
    return "agi://gen/%s?%s" % (record["display"], q)


def seed_bytes(seed_hex32):
    return bytes.fromhex(seed_hex32)


def new_seed():
    """256-bit birth seed. Only its commitment/fingerprint is public; the seed stays sealed."""
    return secrets.token_bytes(32)


def seed8(seed):
    return hashlib.sha256(b"agi/genid/v1:" + bytes(seed)).hexdigest()[:8].upper()


def seed_commitment(seed):
    return hashlib.sha256(b"agi/genid/commit/v1:" + bytes(seed)).hexdigest()


# ------------------------------------------------------------------ Code 39 barcode (self-contained)
_CODE39 = {
    "0": "101001101101", "1": "110100101011", "2": "101100101011", "3": "110110010101",
    "4": "101001101011", "5": "110100110101", "6": "101100110101", "7": "101001011011",
    "8": "110100101101", "9": "101100101101", "A": "110101001011", "B": "101101001011",
    "C": "110110100101", "D": "101011001011", "E": "110101100101", "F": "101101100101",
    "G": "101010011011", "H": "110101001101", "I": "101101001101", "J": "101011001101",
    "K": "110101010011", "L": "101101010011", "M": "110110101001", "N": "101011010011",
    "O": "110101101001", "P": "101101101001", "Q": "101010110011", "R": "110101011001",
    "S": "101101011001", "T": "101011011001", "U": "110010101011", "V": "100110101011",
    "W": "110011010101", "X": "100101101011", "Y": "110010110101", "Z": "100110110101",
    "-": "100101011011", ".": "110010101101", " ": "100110101101", "$": "100100100101",
    "/": "100100101001", "+": "100101001001", "%": "101001001001", "*": "100101101101",
}


def barcode_svg(text, height=56, module=2, quiet=10):
    """Scannable Code 39 barcode for the canonical Gen.ID (uppercase, '-' allowed)."""
    payload = "*" + str(text).upper() + "*"
    bad = [c for c in payload if c not in _CODE39]
    if bad:
        raise ValueError("Code 39 cannot encode: %r" % bad)
    bits = "0" * quiet + "0".join(_CODE39[c] for c in payload) + "0" * quiet
    width = len(bits) * module
    parts = ["<svg xmlns='http://www.w3.org/2000/svg' width='%d' height='%d' viewBox='0 0 %d %d' "
             "role='img' aria-label='Gen.ID barcode %s'>" % (width, height, width, height, text)]
    x = 0
    for b in bits:
        if b == "1":
            parts.append("<rect x='%d' y='0' width='%d' height='%d'/>" % (x, module, height))
        x += module
    parts.append("</svg>")
    return "".join(parts)


# ------------------------------------------------------------------ genetic (DNA) identity: no version numbers
DNA_RE = re.compile(r"^AGI-DNA-([ACGT]{48})-(\d{2})$")


def compose_genetic(code, genome8, parent=None):
    """Gen.ID as genetic code: 16 codons from seed+genome; the passport carries the social identity."""
    code = str(code).upper().replace("-", "")
    if len(code) != 48 or any(c not in "ACGT" for c in code):
        raise ValueError("genetic code must be 48 A/C/G/T bases")
    body = "AGI-DNA-" + code
    chk = _chk(body)
    display = "-".join(code[i:i + 12] for i in range(0, 48, 12))
    rec = {"display": display, "canonical": body + "-" + chk, "checksum": chk,
           "genome8": str(genome8).upper(), "kind": "dna"}
    if parent:
        rec["parent"] = parent
    return rec


def validate_genetic(rec):
    try:
        m = DNA_RE.match(rec["canonical"])
        if not m or m.group(2) != _chk("AGI-DNA-" + m.group(1)):
            return False
        return rec.get("display") == "-".join(m.group(1)[i:i + 12] for i in range(0, 48, 12))
    except Exception:
        return False


def parse_genetic(canonical):
    m = DNA_RE.match(str(canonical))
    if not m:
        raise ValueError("not a genetic Gen.ID: %r" % canonical)
    if m.group(2) != _chk("AGI-DNA-" + m.group(1)):
        raise ValueError("genetic Gen.ID checksum mismatch")
    code = m.group(1)
    return compose_genetic("-".join(code[i:i + 12] for i in range(0, 48, 12)), "00000000")


def dna_uri(rec):
    q = "genome=%s&chk=%s" % (rec.get("genome8") or "", rec["checksum"])
    if rec.get("parent"):
        q += "&parent=" + rec["parent"]
    return "agi://dna/%s?%s" % (rec["display"], q)


if __name__ == "__main__":
    import json
    import sys
    s = sys.argv[1] if len(sys.argv) > 1 else "3.2 7 9C4A1F2B"
    core, gen, sd = s.split()
    rec = compose(core, gen, sd)
    print(json.dumps({"record": rec, "valid": validate(rec), "qr": qr_uri(rec)}, indent=1))

#!/usr/bin/env python3
"""Self-test for job.py: sleeps 1s, writes a marker file, prints one line."""
import os, time
out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "temp", ".jobs", "selftest.out")
time.sleep(1)
with open(out, "w") as fh:
    fh.write("selftest ok\n")
print("selftest ok")

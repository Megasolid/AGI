#!/usr/bin/env python3
"""bridge_adapter.py - AGI-side client for the harness-agnostic host-completion contract.

The contract is a tiny loopback HTTP API any harness can implement:
  GET  <health>   -> {"ok": true, "providers": [...], "roots": [...], "origin": "..."}
  POST <complete> {"prompt": "...", "max_tokens"?: 512}
       -> {"ok": true, "text": "...", "provider": "...", "child": "...", "stopReason": "completed"}
DSH's reference implementation is the `agi-brain-bridge` Host plugin (harness/agi-brain-bridge): it runs the
completion as a real child turn of the live root agent, so the benchmark measures the same host model the user
is talking to. Other harnesses implement the same two routes (or a command template) - the AGI side stays put.
"""
import argparse
import datetime
import json
import pathlib
import sys
import time
import urllib.request

AGI = pathlib.Path(__file__).resolve().parents[2]
CONFIG = AGI / "state" / "brains" / "host_contract.json"
DEFAULT = {
    "schema": "agi-host-contract/1",
    "transport": "http",
    "health_url": "http://127.0.0.1:61483/agi-brain/v1/health",
    "complete_url": "http://127.0.0.1:61483/agi-brain/v1/complete",
    "token": "",
    "timeout_s": 180,
    "reference_implementation": "DSH Host plugin harness/agi-brain-bridge",
    "request": {"prompt": "string", "max_tokens": "int (optional)"},
    "response": {"ok": "bool", "text": "string", "provider": "string", "child": "session id", "stopReason": "string"},
}


def config(root=None):
    rootp = pathlib.Path(root) if root else AGI
    path = rootp / "state" / "brains" / "host_contract.json"
    try:
        return {**DEFAULT, **json.loads(path.read_text(encoding="utf-8"))}
    except Exception:
        return dict(DEFAULT)


def _post(url, payload, timeout, token=""):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json",
                                          **({"X-AGI-Token": token} if token else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def health(root=None):
    cfg = config(root)
    try:
        with urllib.request.urlopen(cfg["health_url"], timeout=5) as r:
            body = json.loads(r.read().decode())
        return {"ok": bool(body.get("ok")), "origin": body.get("origin"), "providers": body.get("providers"),
                "roots": body.get("roots"), "url": cfg["health_url"]}
    except Exception as e:
        return {"ok": False, "error": str(e)[:160], "url": cfg["health_url"]}


class BridgeAdapter:
    """Brain Lab adapter over the host-order completion contract (script-callable, no browser)."""

    def __init__(self, root=None):
        self.cfg = config(root)
        self.manifest = {"id": "deepseek-v4.1-flash-1017", "provider": "deepseek", "kind": "remote",
                         "context": 128000, "output": 8192, "tools": "native", "structured_output": True,
                         "privacy": "remote", "render_pack": "dsh-host-root", "tier": "unprofiled"}

    def run(self, task):
        prompt = (task.get("prompt") or "Describe the task.") + \
            "\n\nAnswer directly and concisely. Do not use tools. Output only the final answer."
        t0 = time.time()
        r = _post(self.cfg["complete_url"], {"prompt": prompt}, self.cfg["timeout_s"], self.cfg.get("token", ""))
        text = (r.get("text") or "").strip()
        return {"ok": bool(r.get("ok") and text), "tokens_in": max(1, len(prompt) // 4),
                "tokens_out": max(1, len(text) // 4), "latency_s": round(time.time() - t0, 2),
                "confidence": None, "text": text, "provider": r.get("provider"),
                "stopReason": r.get("stopReason")}


def status(root=None):
    h = health(root)
    return {"schema": "agi-host-contract/1", "transport": config(root)["transport"],
            "health": h, "adapter": BridgeAdapter(root).manifest}


def probe(root=None, count=10):
    rootp = pathlib.Path(root) if root else AGI
    h = health(rootp)
    if not h.get("ok"):
        return {"ok": False, "blocked": True, "reason": h.get("error"), "health": h}
    import brainlab
    suite = brainlab.benchmark_suite()
    per_family = {}
    for t in suite["tasks"]:
        per_family.setdefault(t["family"], t)
    picked = [per_family[f] for f in brainlab.FAMILIES if f in per_family][:max(1, int(count))]
    adapter = BridgeAdapter(rootp)
    results = []
    for task in picked:
        try:
            r = adapter.run(task)
            results.append({"task": task["id"], "ok": r["ok"], "latency_s": r["latency_s"],
                            "tokens_in": r["tokens_in"], "tokens_out": r["tokens_out"]})
        except Exception as e:
            results.append({"task": task["id"], "ok": False, "error": str(e)[:160]})
    out = {"schema": "agi-brainlab/1", "kind": "host_bridge_probe",
           "ts": datetime.datetime.now().isoformat(timespec="seconds"),
           "model": adapter.manifest["id"],
           "provenance": "measured via the harness host-completion bridge (live root-agent child turns; no browser)",
           "tasks": len(results), "passed": sum(1 for r in results if r.get("ok")),
           "results": results, "tier": "unprofiled (probe != full suite)"}
    bdir = rootp / "state" / "brains" / "benchmarks"
    bdir.mkdir(parents=True, exist_ok=True)
    (bdir / ("host_bridge_probe-%s.json" % out["ts"].replace(":", ""))).write_text(json.dumps(out, indent=1),
                                                                                   encoding="utf-8")
    try:
        sys.path.insert(0, str(rootp / "memory" / "scripts"))
        import trust_log
        trust_log.append("brain.host_bridge_probe", {"passed": out["passed"], "tasks": out["tasks"]})
    except Exception:
        pass
    return {"ok": True, **out}


def main(argv=None):
    ap = argparse.ArgumentParser(description="AGI host-completion contract client (DSH reference bridge)")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--tasks", type=int, default=10)
    ap.add_argument("--contract", action="store_true")
    args = ap.parse_args(argv)
    if args.contract:
        CONFIG.write_text(json.dumps(DEFAULT, indent=1), encoding="utf-8")
        print(json.dumps(DEFAULT, indent=1))
        return 0
    if args.probe:
        print(json.dumps(probe(count=args.tasks), indent=1))
        return 0
    print(json.dumps(status(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

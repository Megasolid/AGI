#!/usr/bin/env python3
"""ui_incubator.py - UI masterpiece pipeline: candidates incubate, pass gates, then are promoted.

The dashboard is the generation's painting (D). New visual modules are never dropped into the core: they
incubate here, are scored on data honesty, accessibility, performance budget, novelty and brand safety, and
only a **human-approved** promotion (or the acting-Master path once the 0.99 confidence gate exists) moves a
module into the dashboard core. Every evaluation is a signed trust event.
"""
import argparse
import datetime
import json
import pathlib
import sys

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-ui-incubator/1"
CHECKS = ["has_source", "aria_label", "data_budget", "novelty", "brand_safety"]


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "file": root / "state" / "ui_incubator.json"}


def _score(checks):
    weights = {"has_source": 0.30, "aria_label": 0.20, "data_budget": 0.20, "novelty": 0.15, "brand_safety": 0.15}
    total = 0.0
    for k, w in weights.items():
        v = checks.get(k)
        total += w * (float(v) if isinstance(v, (int, float)) else (1.0 if v else 0.0))
    return round(total, 3)


def candidates(root=None):
    return (_jload(_paths(root)["file"]) or {"schema": SCHEMA, "candidates": [], "promoted": []})


def add_candidate(title, area, source, checks, root=None):
    data = candidates(root)
    cid = "ui-" + str(len(data["candidates"]) + 1).zfill(3)
    item = {"id": cid, "title": str(title).strip(), "area": area, "source": source,
            "checks": {k: checks.get(k, False) for k in CHECKS}, "score": _score(checks),
            "status": "incubating", "created": datetime.datetime.now().isoformat(timespec="seconds"),
            "promoted": None}
    data.setdefault("candidates", []).append(item)
    _jdump(_paths(root)["file"], data)
    return {"ok": True, "candidate": item}


def evaluate(root=None):
    data = candidates(root)
    for c in data.get("candidates", []):
        c["score"] = _score(c.get("checks") or {})
        if c.get("status") == "promoted":
            continue
        c["status"] = "ready-for-review" if c["score"] >= 0.80 else ("rejected" if c["score"] < 0.50 else "incubating")
    _jdump(_paths(root)["file"], data)
    ready = [c["id"] for c in data["candidates"] if c.get("status") == "ready-for-review"]
    try:
        sys.path.insert(0, str(pathlib.Path(root or AGI) / "memory" / "scripts"))
        import trust_log
        trust_log.append("ui.incubator.evaluate", {"candidates": len(data["candidates"]), "ready": len(ready)})
    except Exception:
        pass
    return {"ok": True, "candidates": len(data["candidates"]), "ready_for_review": ready}


def promote(candidate_id, approved_by="", root=None):
    """Promotion into the dashboard core requires a human approver and a passing attention review."""
    data = candidates(root)
    for c in data.get("candidates", []):
        if c["id"] == candidate_id:
            if not approved_by:
                return {"ok": False, "error": "human approval required to promote a UI module"}
            if c["score"] < 0.80:
                return {"ok": False, "error": "candidate below promotion gate", "score": c["score"]}
            target = pathlib.Path(root) if root else AGI
            try:
                import attention
                if target.resolve() == AGI.resolve():
                    last = attention.status()["last"]
                    if not (last.get("anomaly_ok") and last.get("composite_confidence", 0) >= 0.9):
                        return {"ok": False, "error": "dashboard attention review required/failing before promotion",
                                "attention": last}
            except Exception:
                pass
            c["status"] = "promoted"
            c["promoted"] = {"by": approved_by, "ts": datetime.datetime.now().isoformat(timespec="seconds")}
            data.setdefault("promoted", []).append(candidate_id)
            _jdump(_paths(root)["file"], data)
            try:
                sys.path.insert(0, str(pathlib.Path(root or AGI) / "memory" / "scripts"))
                import trust_log
                trust_log.append("ui.promoted", {"id": candidate_id, "by": approved_by})
            except Exception:
                pass
            return {"ok": True, "promoted": candidate_id}
    return {"ok": False, "error": "unknown candidate"}


def seed_candidates(root=None):
    if candidates(root).get("candidates"):
        return {"ok": True, "skipped": "candidates already seeded"}
    defs = [
        ("Genome network (atlas)", "presentation", "state/genesis/genome.json",
         {"has_source": True, "aria_label": True, "data_budget": True, "novelty": 0.7, "brand_safety": True}),
        ("Society stats module", "society", "state/family/registry.json",
         {"has_source": True, "aria_label": True, "data_budget": True, "novelty": 0.6, "brand_safety": True}),
        ("Curriculum progress ring", "curriculum", "state/curriculum/health.json",
         {"has_source": True, "aria_label": True, "data_budget": True, "novelty": 0.8, "brand_safety": True}),
        ("Animated natal-interest particles", "art", "state/genesis/birth.json",
         {"has_source": True, "aria_label": False, "data_budget": False, "novelty": 1.0, "brand_safety": 0.8}),
    ]
    for d in defs:
        add_candidate(d[0], d[1], d[2], d[3], root=root)
    return evaluate(root)


def render(root=None):
    import ui
    data = evaluate(root)
    cands = candidates(root).get("candidates", [])
    rows = "".join("<tr><td class='mono'>%s</td><td>%s</td><td>%s</td><td class='mono'>%s</td><td>%s</td></tr>"
                   % (ui.e(c["id"]), ui.e(c["title"]), ui.e(c["area"]), ui.e(c["score"]), ui.e(c["status"]))
                   for c in cands) or "<tr><td colspan='5'>no candidates</td></tr>"
    body = (ui.pagehead("UI incubator",
                        "Visual modules evolve here; promotion into the dashboard core needs a human approval (or the acting-Master confidence gate).",
                        ui.badge("schema " + SCHEMA, "info") +
                        ui.badge("%d ready" % len(data["ready_for_review"]), "warn")) +
            ui.section("Candidates", ui.box("", "<table class='table'><thead><tr><th>id</th><th>module</th>"
                                               "<th>area</th><th>score</th><th>status</th></tr></thead><tbody>%s"
                                               "</tbody></table>" % rows, flush=True), count=len(cands)) +
            ui.section("Gates", ui.box("", "<span class='muted'>has_source 0.30 · aria_label 0.20 · data_budget 0.20 · "
                                             "novelty 0.15 · brand_safety 0.15 → ready at 0.80; promotion requires a human "
                                             "approver; acting-Master path only after the 0.99 composite confidence gate.</span>",
                                          flush=True), count=1))
    return ui.page("AGI UI incubator", body, tabs=[("overview", "Overview", "/"), ("curriculum", "Curriculum", "/curriculum"),
                                                  ("incubator", "UI incubator", "/incubator")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="incubator")


def main(argv=None):
    ap = argparse.ArgumentParser(description="UI module incubator and promotion gates")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--seed", action="store_true")
    ap.add_argument("--evaluate", action="store_true")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args(argv)
    if args.seed:
        print(json.dumps(seed_candidates(), indent=1))
        return 0
    if args.evaluate:
        print(json.dumps(evaluate(), indent=1))
        return 0
    if args.status:
        print(json.dumps({"schema": SCHEMA, "candidates": len(candidates().get("candidates", []))}, indent=1))
        return 0
    print(json.dumps(candidates(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

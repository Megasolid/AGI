#!/usr/bin/env python3
"""Task bill system: time-aware estimation for complex tasks.

Time DB (grows over time):
    memory/time/rates.json    - baseline rates mined from backend logs (recompute anytime)
    memory/time/tasklog.jsonl - one entry per task: {date, task, est_s, actual_s, steps, note}

Usage:
    python taskbill.py analyze                     # re-mine rates from studio backend logs
    python taskbill.py estimate --plan plan.json   # print a task bill from a step plan
    python taskbill.py start  --task "name" --est-s 1800 [--ctx-tok N] [--note ...] [--co-op] [--parent PARENT]
    python taskbill.py check  --task "name"       # watchdog: elapsed vs bill (ON TRACK/CAUTION/OVER)
    python taskbill.py pause  --task "name" [--reason ...] [--co-op]
    python taskbill.py resume --task "name"
    python taskbill.py revise --task "name" --est-s 1800 [--note ...]
    python taskbill.py verify --task "name" --confidence 0.95 --outcome passed|failed|blocked --evidence ...
    python taskbill.py check  --tool <name> --s <secs>   # watchdog: one tool call vs thresholds
    python taskbill.py finish --task "name"        # record actual duration, update log
    python taskbill.py report                     # recent bills vs actuals (calibration)

Plan JSON format:
    {"task": "...", "steps": [{"name": "...", "kind": "turn|tool:<name>|download_mb:N|gen_tokens:N|fixed_s:N", "tokens": 0}]}
"""
import re, json, glob, os, sys, time, statistics, uuid, html
from collections import deque
from datetime import datetime, timezone
import cardkit
import watchdogs

MEM = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TIME_DIR = os.path.join(MEM, "time")
TASKS = os.path.join(MEM, "temp", "tasks")
RATES = os.path.join(TIME_DIR, "rates.json")
TASKLOG = os.path.join(TIME_DIR, "tasklog.jsonl")
def _backend_logs_glob():
    """Machine fact from state/env_probe.json (R2); fallback to a sibling logs/ dir."""
    import json as _json
    try:
        with open(os.path.join(os.path.dirname(MEM), "state", "env_probe.json"), encoding="utf-8") as fh:
            root = (_json.load(fh).get("root") or "").strip()
    except Exception:
        root = ""
    return os.path.join(root or os.path.dirname(MEM), "logs", "backend-*.log")


BACKEND_LOGS = _backend_logs_glob()

# Contingency multiplier on the summed estimate (unknowns, retries, context growth)
CONTINGENCY = 1.12
# W-B (2026-10-25): per-host speed facts live in state/ (R2). rates.json stays a portable
# legacy baseline mined on the previous host; state/host_speed.json overlays this host:
#   derived.factor -> contingency (median actual/est observed here), refreshed at boot.
HOST_SPEED = os.path.join(os.path.dirname(MEM), "state", "host_speed.json")
# Assumed download speed when no measured rate exists (MB/s) - verify live when possible
DEFAULT_DL_MBPS = 5.0


def analyze():
    """Mine backend logs for baseline rates -> rates.json."""
    pat = re.compile(r'^\[(\d+)\]\[stdout\] (.*)$')
    starts, durations, turns, stats = {}, {}, [], []
    for f in sorted(glob.glob(BACKEND_LOGS)):
        with open(f, encoding='utf-8', errors='replace') as fh:
            for line in fh:
                m = pat.match(line)
                if not m:
                    continue
                ts = int(m.group(1)) / 1000.0
                s = m.group(2)
                if not s.startswith('{'):
                    continue
                try:
                    ev = json.loads(s)
                except Exception:
                    continue
                e = str(ev.get('event', ''))
                mm = re.match(r"execute_tool: name=(\w+)", e)
                if mm:
                    starts.setdefault(mm.group(1), deque()).append(ts)
                    continue
                mm2 = re.match(r"tool result: name=(\w+)", e)
                if mm2:
                    q = starts.get(mm2.group(1))
                    if q:
                        d = ts - q.popleft()
                        if 0 <= d < 7200:
                            durations.setdefault(mm2.group(1), []).append(d)
                elif e == 'engine_stats':
                    stats.append((ev.get('gen_tok_s'), ev.get('prompt_tok_s')))
                elif re.match(r"Parsed \d+ tool call", e):
                    turns.append(ts)

    tools = {}
    for name, ds in durations.items():
        ds = sorted(ds)
        med, p90, mx = statistics.median(ds), ds[int(len(ds) * .9)], max(ds)
        # watchdog thresholds: alert when a call is slow-but-possible, hard cap when it is likely broken
        alert = round(max(p90, 3 * med), 1)
        hard = round(max(mx, 2 * p90, alert), 1)   # hard must never sit below alert
        tools[name] = {"n": len(ds), "med": round(med, 2),
                       "p90": round(p90, 2), "max": round(mx, 1),
                       "alert_s": alert, "hard_s": hard}
    gaps = sorted(b - a for a, b in zip(turns, turns[1:]) if 0 < b - a < 3600)
    gen = [g for g, _ in stats if g]
    prom = [p for _, p in stats if p]
    prev_overrides = {}
    if os.path.exists(RATES):
        try:
            with open(RATES) as fh:
                prev_overrides = json.load(fh).get('overrides', {})
        except Exception:
            pass
    rates = {
        "mined_at": datetime.now(timezone.utc).isoformat(timespec='seconds'),
        "backend_logs": len(glob.glob(BACKEND_LOGS)),
        "turn_base_s": round(statistics.median(gaps), 1) if gaps else 25.0,
        "turn_p90_s": round(gaps[int(len(gaps) * .9)], 1) if gaps else 300.0,
        "gen_tok_s": round(statistics.median(gen), 1) if gen else 30.0,
        "prompt_tok_s": round(statistics.median(prom), 0) if prom else 600.0,
        "download_mbps_default": DEFAULT_DL_MBPS,
        "alert_default_s": 60.0,   # watchdog thresholds for tools with no mined data
        "hard_default_s": 300.0,
        "contingency": CONTINGENCY,
        "tools": tools,
    }
    if prev_overrides:
        rates['overrides'] = prev_overrides
    os.makedirs(TIME_DIR, exist_ok=True)
    with open(RATES, 'w') as fh:
        json.dump(rates, fh, indent=1)
    print(json.dumps({k: v for k, v in rates.items() if k != 'tools'}, indent=1))
    print(f"tools mined: {len(tools)} -> {RATES}")


def load_rates():
    if not os.path.exists(RATES):
        analyze()
    with open(RATES) as fh:
        rates = json.load(fh)
    # W-B overlay (2026-10-25): this host's calibrated factor from state/host_speed.json.
    # The declared generation rate is recorded for transparency/dashboards but deliberately
    # NOT substituted into gen_tok_s: the factor was measured against the legacy baseline, so
    # applying both would double-correct. Retire the baseline when rates are re-mined here.
    try:
        with open(HOST_SPEED, encoding="utf-8") as fh:
            host = json.load(fh)
    except Exception:
        host = {}
    declared = host.get("declared_gen_tok_s")
    if isinstance(declared, (int, float)) and declared > 0:
        rates["declared_gen_tok_s"] = float(declared)
    derived = host.get("derived") or {}
    factor = derived.get("factor")
    if isinstance(factor, (int, float)) and 0.05 <= float(factor) <= 3.0:
        rates["contingency_baseline"] = rates.get("contingency")
        rates["contingency"] = float(factor)
        rates["host_factor"] = {"factor": float(factor), "samples": derived.get("samples"),
                                "refreshed": derived.get("last_refresh"),
                                "host": derived.get("host"), "model": derived.get("model")}
    return rates


def _host_stamp():
    """Stamp each new bill with the host/model it was planned under (W-B)."""
    try:
        with open(os.path.join(os.path.dirname(MEM), "state", "boot_card.json"), encoding="utf-8") as fh:
            b = json.load(fh)
        host = b.get("host_application")
        return {"host": host.get("id") if isinstance(host, dict) else host,
                "model": b.get("model_name"), "profile": b.get("profile")}
    except Exception:
        return {}


def est_step(step, rates):
    """Return (est_seconds, note) for one plan step."""
    kind = step.get('kind', 'turn')
    name = step.get('name', '?')
    if kind == 'turn':
        t = rates['turn_base_s'] + step.get('tokens', 0) / max(rates['gen_tok_s'], 1)
        return t, f"agent turn (~{t:.0f}s)"
    if kind.startswith('tool:'):
        tn = kind[5:]
        tr = rates['tools'].get(tn)
        if tr:
            return tr['med'], f"tool {tn} (med {tr['med']}s, n={tr['n']})"
        return 5.0, f"tool {tn} (no data, assume 5s)"
    if kind.startswith('download_mb:'):
        mb = float(kind.split(':')[1])
        mbps = rates.get('download_mbps_measured') or rates['download_mbps_default']
        return mb / mbps * 60, f"download {mb:.0f}MB @ {mbps:.0f}MB/s (metered!)"
    if kind.startswith('delegate:'):
        provider = kind[9:]
        med = _provider_med_latency(provider)
        t = max(med, 5.0) + step.get('tokens', 0) / max(rates['gen_tok_s'], 1)
        src = f"med {med:.0f}s from usage log" if med else "no usage data, assume 30s"
        return t, f"delegate -> {provider} ({src})"
    if kind.startswith('gen_tokens:'):
        n = int(kind.split(':')[1])
        return n / max(rates['gen_tok_s'], 1), f"generate {n} tok @ {rates['gen_tok_s']} tok/s"
    if kind.startswith('fixed_s:'):
        t = float(kind.split(':')[1])
        return t, f"fixed ~{t:.0f}s"
    return rates['turn_base_s'], "unknown kind -> turn base"


def tool_thresholds(tn, rates):
    """(alert_s, hard_s) for one tool: slow-but-possible vs likely-broken.
    Per-tool overrides in rates.json['overrides'] win (for tools whose mined
    data is too small or too tight to trust)."""
    tr = rates['tools'].get(tn)
    if not tr:
        alert, hard = rates.get('alert_default_s', 60.0), rates.get('hard_default_s', 300.0)
    else:
        alert = tr.get('alert_s') or max(tr['p90'], 3 * tr['med'])
        hard = tr.get('hard_s') or max(tr['max'], 2 * tr['p90'], alert)
    ov = rates.get('overrides', {}).get(tn, {})
    return ov.get('alert_s', alert), ov.get('hard_s', hard)


def check(task=None, tool=None, secs=None):
    """Watchdog: policy-as-observing-agent. Compare live durations against the bill."""
    rates = load_rates()
    if tool is not None:
        if secs is None:
            print("--s <secs> required for --tool")
            return
        alert, hard = tool_thresholds(tool, rates)
        tr = rates['tools'].get(tool)
        base = f"med {tr['med']}s p90 {tr['p90']}s max {tr['max']}s" if tr else "no mined data (defaults)"
        if secs > hard:
            print(f"ANOMALY  tool={tool} took {secs:.0f}s > hard cap {hard:.0f}s ({base}) - likely broken/hung; flag against bill, stop and report to D")
        elif secs > alert:
            print(f"SLOW     tool={tool} took {secs:.0f}s > alert {alert:.0f}s ({base}) - watch next call; if it repeats -> ANOMALY")
        else:
            print(f"OK       tool={tool} took {secs:.0f}s (alert {alert:.0f}s, hard {hard:.0f}s)")
        return
    e = _find_entry(task)
    if not e:
        print(f"no open entry for task '{task}'")
        return
    now = time.time()
    elapsed = float(e.get('active_elapsed_s', 0))
    if not e.get('paused_epoch') and e.get('started_epoch'):
        elapsed += now - e['started_epoch']
    user_wait = float(e.get('user_wait_s', 0))
    if e.get('paused_epoch') and e.get('pause_kind') != 'child':
        user_wait += now - e['paused_epoch']
    child_waiting = e.get('pause_reason') if e.get('pause_kind') == 'child' else None
    est = e['est_s']
    raw = est / rates['contingency']
    pct = elapsed / max(est, 1) * 100
    if elapsed > est:
        status = "OVER     - projected overrun; warn D now, do not silently overrun"
    elif elapsed > raw * 1.15:
        status = "CAUTION  - drifting toward the bill"
    else:
        status = "ON TRACK"
    print(f"{status}  task={task} | machine active {elapsed/60:.1f} min of est {est/60:.0f} min ({pct:.0f}%) | user/external wait {user_wait/60:.1f} min | child pending {child_waiting or 'none'} | unattributed pause {float(e.get('unattributed_paused_s', 0))/60:.1f} min | remaining ~{max(est-elapsed,0)/60:.1f} min")
    cp_log(task, f"CHECK {status.strip()} | active={elapsed:.0f}s wait={user_wait:.0f}s ({pct:.0f}%)")


# ---- checkpoint v2: every billed task keeps a state-machine file temp/tasks/<task>.md ----
_WIN_BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f]')

def _safe_name(task):
    """Filesystem-safe checkpoint name - bill task names may carry '/', ':', ...

    2026-10-25: a task name containing '/' made cp_init raise FileNotFoundError (the name
    was used as a path). The failed start was abandoned; names are sanitized from now on.
    """
    s = _WIN_BAD.sub('-', str(task)).strip().rstrip('.')
    s = re.sub(r'\s+', ' ', s).strip()[:120]
    return s or 'task'

def _cp_path(task):
    return os.path.join(TASKS, f"{_safe_name(task)}.md")

def _now_local():
    return datetime.now().strftime('%H:%M')

def cp_init(task, goal='', bill=''):
    """Create the checkpoint skeleton if it does not exist (idempotent)."""
    p = _cp_path(task)
    if not os.path.exists(p):
        os.makedirs(TASKS, exist_ok=True)
        with open(p, 'w', encoding='utf-8') as fh:
            fh.write(f"# task: {task}\n\n- started: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
                     f"- goal: {goal or '(set via checkpoint --goal)'}\n\n## bill\n{bill or '(none)'}\n\n## log\n")
    return p

def cp_log(task, line):
    """Append one timestamped line to the task's checkpoint file (creates skeleton if needed)."""
    cp_init(task)
    with open(_cp_path(task), 'a', encoding='utf-8') as fh:
        fh.write(f"- {_now_local()} {line}\n")


def estimate(plan_path=None, plan_json=None):
    rates = load_rates()
    if plan_json:
        plan = json.loads(plan_json)
    else:
        with open(plan_path) as fh:
            plan = json.load(fh)
    raw = 0.0
    lines, rows_html = [], []
    for i, step in enumerate(plan['steps'], 1):
        t, note = est_step(step, rates)
        raw += t
        agent = step.get('agent', 'self')
        tag = f" [{agent}]" if agent != 'self' else ""
        lines.append(f"  {i:2d}. [{step.get('kind','turn'):18s}] {step.get('name','?')[:40]:40s} ~{t/60 if t>=60 else t:.0f}{ 'min' if t>=60 else 's'}   ({note}{tag})")
        rows_html.append((f"<div class='row'><span>{i}. {html.escape(str(step.get('name','?'))[:48])}{html.escape(tag)}</span>"
                          f"<span>{html.escape(note)} · ~{t/60 if t>=60 else t:.0f}{ 'min' if t>=60 else 's'}</span></div>"))
    buffered = raw * rates['contingency']
    now = datetime.now()
    def fmt(s):
        h, m = int(s // 3600), int(s % 3600 // 60)
        return f"{h}h {m:02d}m" if h else f"~{m} min"
    print(f"TASK BILL - {plan.get('task','(unnamed)')}")
    print(f"  steps: {len(plan['steps'])} | est raw: {fmt(raw)} | buffered (x{rates['contingency']}): {fmt(buffered)}")
    print("  " + "-" * 78)
    print("\n".join(lines))
    print("  " + "-" * 78)
    if plan.get('costs'):
        costs = plan['costs']
        costs = '; '.join(costs) if isinstance(costs, list) else costs
        print(f"  costs: {costs}")
    if plan.get('gates'):
        gates = plan['gates']
        gates = '; '.join(gates) if isinstance(gates, list) else gates
        print(f"  gates: {gates}")
    print(f"  ETA done: ~{now.strftime('%H:%M')} + {fmt(buffered)} (buffered)")
    # context cost of the bill itself (plan JSON in + printed bill out); keep it small
    plan_chars = len(json.dumps(plan))
    out_chars = sum(len(l) for l in lines) + 500
    ctx_tok = (plan_chars + out_chars) // 4
    flag = "  <-- too big: merge trivial steps, shorten names" if ctx_tok > 1200 else ""
    print(f"  bill context cost: ~{ctx_tok} tok (plan {plan_chars//4} + output {out_chars//4}){flag}")
    print(f"  rates basis: mined {rates['mined_at']} from {rates['backend_logs']} logs; gen {rates['gen_tok_s']} tok/s, turn base {rates['turn_base_s']}s")
    if rates.get('host_factor'):
        _hf = rates['host_factor']
        print(f"  host: {_hf.get('host') or '?'}/{_hf.get('model') or '?'} | calibrated factor "
              f"{rates['contingency']:.2f} (n={_hf.get('samples')}, state/host_speed.json) | "
              f"declared {rates.get('declared_gen_tok_s', '?')} tok/s")
    try:
        out = render_bill_html(plan, raw, buffered, rows_html, rates, ctx_tok)
        print(f"  bill_report.html -> {out}")
    except Exception as ex:
        print(f"  bill_report.html: skipped ({ex})")


def _provider_med_latency(provider):
    """Median latency (s) of successful calls for a pool provider, from agents_usage.jsonl."""
    usage = os.path.join(MEM, "state", "agents_usage.jsonl")
    if not os.path.exists(usage):
        return None
    lats = []
    with open(usage) as fh:
        for line in fh:
            try: e = json.loads(line)
            except Exception: continue
            if e.get('provider') == provider and e.get('ok') and isinstance(e.get('latency_s'), (int, float)):
                lats.append(e['latency_s'])
    return statistics.median(lats) if lats else None


def render_bill_html(plan, raw, buffered, rows_html, rates, ctx_tok):
    """Write bill_report.html to the active shared season sandbox."""
    now = datetime.now()
    h, m = int(buffered // 3600), int(buffered % 3600 // 60)
    fmt_b = f"{h}h {m:02d}m" if h else f"~{m} min"
    def fmt(s):
        hh, mm = int(s // 3600), int(s % 3600 // 60)
        return f"{hh}h {mm:02d}m" if hh else f"~{mm} min"
    css = ("body{background:#10141a;color:#dfe5ee;font:14px/1.5 system-ui,sans-serif;margin:24px}"
           ".head{display:flex;justify-content:space-between;align-items:center}"
           ".title{font-size:20px;font-weight:700;letter-spacing:1px}"
           ".pill{background:#1f6feb1a;color:#58a6ff;border:1px solid #1f6feb66;padding:4px 12px;border-radius:99px;font-weight:600}"
           ".grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:14px;margin-top:16px}"
           ".card{background:#171b22;border:1px solid #232833;border-radius:12px;padding:16px 18px}"
           ".label{font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#8b96a5;margin-bottom:8px}"
           ".big{font-size:22px;font-weight:700}"
           ".row{display:flex;justify-content:space-between;padding:3px 0;border-top:1px solid #1d222b}"
           ".row span:last-child{color:#aab4c2;text-align:right}"
           ".foot{margin-top:18px;color:#66707e;font-size:12px}")
    costs = plan.get('costs'); gates = plan.get('gates')
    def joinl(x): return '; '.join(x) if isinstance(x, list) else (x or '')
    cost_html = f'<div class="row"><span>costs</span><span>{html.escape(joinl(costs))}</span></div>' if costs else ''
    gate_html = f'<div class="row"><span>gates</span><span>{html.escape(joinl(gates))}</span></div>' if gates else ''
    task_name = html.escape(str(plan.get('task', '(unnamed)')))
    doc = (f"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Task estimate — {task_name}</title>"
           f"<style>{css}</style></head><body>"
           f"<div class='head'><div><div class='title'>Task estimate</div><div>{task_name}</div></div>"
           f"<div class='pill'>Awaiting your approval</div></div>"
           f"<div class='grid'>"
           f"<div class='card'><div class='label'>Summary</div>"
           f"<div class='big'>{len(plan['steps'])} steps · raw {fmt(raw)}</div>"
           f"<div class='row'><span>buffered (x{rates['contingency']})</span><span>{fmt_b}</span></div>"
           f"<div class='row'><span>ETA done</span><span>~{now.strftime('%H:%M')} + {fmt_b}</span></div>"
           f"<div class='row'><span>bill context cost</span><span>~{ctx_tok} tok</span></div>"
           f"{cost_html}{gate_html}</div>"
           f"<div class='card'><div class='label'>Planned steps and time</div>{''.join(rows_html)}</div>"
           f"</div><div class='foot'>generated {now.strftime('%Y-%m-%d %H:%M')} · rates basis: mined {rates['mined_at']} from {rates['backend_logs']} logs; gen {rates['gen_tok_s']} tok/s, turn base {rates['turn_base_s']}s</div>"
           f"</body></html>")
    out = os.path.join(os.path.dirname(cardkit.sandbox_cache()), "bill_report.html")
    with open(out, 'w', encoding='utf-8') as fh:
        fh.write(doc)
    return out


def _find_entry(task, include_completed=False):
    if not os.path.exists(TASKLOG):
        return None
    with open(TASKLOG, encoding='utf-8') as fh:
        for line in reversed(fh.readlines()):
            try: e = json.loads(line)
            except Exception: continue
            if e.get('task') == task and (include_completed or 'actual_s' not in e):
                return e
    return None


def _replace_entry(entry):
    lines = []
    if os.path.exists(TASKLOG):
        with open(TASKLOG, encoding='utf-8') as fh:
            lines = [line.rstrip('\n') for line in fh]
    for i, line in enumerate(lines):
        try:
            old = json.loads(line)
            same_entry = old.get('entry_id') == entry.get('entry_id') if entry.get('entry_id') else (
                old.get('task') == entry.get('task') and old.get('date') == entry.get('date'))
            if same_entry:
                lines[i] = json.dumps(entry)
                break
        except Exception:
            continue
    else:
        raise ValueError(f"task log entry not found for {entry.get('task')}")
    temp_path = TASKLOG + '.tmp'
    with open(temp_path, 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(lines) + '\n')
    os.replace(temp_path, TASKLOG)


def pause(task, reason='', co_op=False, kind='handoff'):
    e = _find_entry(task)
    if not e:
        print(f"no open entry for task '{task}'")
        return
    if e.get('paused_epoch'):
        print(f"task already paused: {task}")
        return
    now = time.time()
    e['active_elapsed_s'] = float(e.get('active_elapsed_s', 0)) + now - e['started_epoch']
    e['started_epoch'] = None
    e['paused_epoch'] = now
    e['co_op'] = bool(e.get('co_op') or co_op)
    e['pause_kind'] = kind
    e['pause_reason'] = reason
    _replace_entry(e)
    cp_log(task, f"PAUSE active={e['active_elapsed_s']:.0f}s co_op={e['co_op']} reason={reason or 'awaiting next machine turn'}")
    print(f"paused {task}; co-op={e['co_op']}")


def resume(task, child=None):
    e = _find_entry(task)
    if not e:
        print(f"no open entry for task '{task}'")
        return
    if not e.get('paused_epoch'):
        print(f"task is not paused: {task}")
        return
    now = time.time()
    waited = max(0.0, now - e['paused_epoch'])
    if e.get('pause_kind') == 'child':
        if child is None or e.get('pause_reason') != child.get('task'):
            print(f"parent remains paused until child '{e.get('pause_reason')}' is verified")
            return False
        e['active_elapsed_s'] = float(e.get('active_elapsed_s', 0)) + float(child.get('actual_s', 0))
        e['user_wait_s'] = float(e.get('user_wait_s', 0)) + float(child.get('user_wait_s', 0))
        cp_log(task, f"CHILD_VERIFIED child={child.get('task')} child_active={child.get('actual_s', 0)}s child_wait={child.get('user_wait_s', 0)}s")
    else:
        e['user_wait_s'] = float(e.get('user_wait_s', 0)) + waited
    e['paused_epoch'] = None
    e['started_epoch'] = now
    e['pause_kind'] = None
    e['pause_reason'] = None
    _replace_entry(e)
    if child is None:
        cp_log(task, f"RESUME wait_added={waited:.0f}s total_wait={e['user_wait_s']:.0f}s co_op={e.get('co_op', False)}")
        print(f"resumed {task}; wait added {waited:.0f}s")
    else:
        print(f"verified child {child.get('task')}; parent {task} resumed")
    return True


def start(task, est_s, note='', ctx_tok=0, co_op=False, parent=None):
    parent_entry = _find_entry(parent) if parent else None
    if parent and (not parent_entry or parent_entry.get('paused_epoch')):
        print(f"cannot start child: parent '{parent}' is not open and running")
        return
    if parent_entry:
        now = time.time()
        parent_entry['active_elapsed_s'] = float(parent_entry.get('active_elapsed_s', 0)) + max(0.0, now - parent_entry['started_epoch'])
        parent_entry['started_epoch'] = None
        parent_entry['paused_epoch'] = now
        parent_entry['pause_kind'] = 'child'
        parent_entry['pause_reason'] = task
        _replace_entry(parent_entry)
        cp_log(parent, f"CHILD_START child={task}")
    os.makedirs(TIME_DIR, exist_ok=True)
    entry = {"entry_id": uuid.uuid4().hex,
             "date": datetime.now(timezone.utc).isoformat(timespec='seconds'),
             "task": task, "est_s": int(est_s), "note": note,
             "ctx_tok": int(ctx_tok), "started_epoch": time.time(),
             "active_elapsed_s": 0.0, "user_wait_s": 0.0,
             "paused_epoch": None, "co_op": bool(co_op), "parent_id": parent,
             "bill_status": "active", "bill_verified": False, **_host_stamp()}
    with open(TASKLOG, 'a') as fh:
        fh.write(json.dumps(entry) + '\n')
    cp = cp_init(task, goal=note)
    cp_log(task, f"START est={int(est_s)}s ctx~{int(ctx_tok)}tok")
    print(f"logged start: {task} est={int(est_s)}s ctx~{int(ctx_tok)}tok -> {TASKLOG}")
    print(f"checkpoint file: {cp}")


def revise(task, est_s, note=''):
    e = _find_entry(task)
    if not e:
        print(f"no open entry for task '{task}'")
        return
    old_est = e['est_s']
    e['est_s'] = int(est_s)
    e['note'] = note or e.get('note', '')
    _replace_entry(e)
    cp_log(task, f"REVISE estimate {old_est}s -> {e['est_s']}s note={note or 'updated scope'}")
    print(f"revised {task}: {old_est}s -> {e['est_s']}s")


def nest(task, parent_task):
    child = _find_entry(task)
    parent = _find_entry(parent_task)
    if not child or not parent:
        print("nest requires an open child bill and an open parent bill")
        return
    if child.get('parent_id'):
        print(f"task already has parent '{child['parent_id']}'")
        return
    if parent.get('pause_kind') == 'child':
        print(f"parent '{parent_task}' is already waiting for child '{parent.get('pause_reason')}'")
        return
    now = time.time()
    if parent.get('paused_epoch'):
        parent['unattributed_paused_s'] = float(parent.get('unattributed_paused_s', 0)) + max(0.0, now - parent['paused_epoch'])
    elif parent.get('started_epoch'):
        parent['active_elapsed_s'] = float(parent.get('active_elapsed_s', 0)) + max(0.0, now - parent['started_epoch'])
    else:
        print(f"parent '{parent_task}' has no resumable clock")
        return
    old_est = int(parent['est_s'])
    parent['est_s'] = old_est + int(child['est_s'])
    parent['started_epoch'] = None
    parent['paused_epoch'] = now
    parent['pause_kind'] = 'child'
    parent['pause_reason'] = task
    _replace_entry(parent)
    child['parent_id'] = parent_task
    _replace_entry(child)
    cp_log(parent_task, f"NEST child={task} child_est={child['est_s']}s parent_est={old_est}s->{parent['est_s']}s unattributed_pause={parent.get('unattributed_paused_s', 0):.0f}s")
    cp_log(task, f"NESTED under={parent_task}")
    print(f"nested {task} under {parent_task}; parent estimate {old_est}s -> {parent['est_s']}s")


def finish(task):
    e = _find_entry(task)
    if not e:
        print(f"no open entry for task '{task}'")
        return
    if e.get('pause_kind') == 'child':
        print(f"cannot finish parent '{task}' before child '{e.get('pause_reason')}' is verified")
        return
    now = time.time()
    active = float(e.get('active_elapsed_s', 0))
    wait = float(e.get('user_wait_s', 0))
    if e.get('paused_epoch'):
        wait += max(0.0, now - e['paused_epoch'])
    elif e.get('started_epoch'):
        active += max(0.0, now - e['started_epoch'])
    e['actual_s'] = int(active)
    e['user_wait_s'] = int(wait)
    e['finished_epoch'] = now
    e['started_epoch'] = None
    e['paused_epoch'] = None
    e['bill_status'] = 'completed_pending_verification'
    e['ratio'] = round(active / max(e['est_s'], 1), 2)
    _replace_entry(e)
    cp_log(task, f"FINISH active={int(active)}s user_wait={int(wait)}s est={e['est_s']}s ratio={e['ratio']} co_op={e.get('co_op', False)}")
    print(f"logged finish: {task} active={int(active)}s user/external wait={int(wait)}s (est {e['est_s']}s, ratio {e['ratio']})")


def verify(task, confidence, outcome, evidence):
    e = _find_entry(task, include_completed=True)
    if not e or 'actual_s' not in e:
        print(f"no completed bill awaiting verification for '{task}'")
        return
    if e.get('bill_verified'):
        print(f"bill already verified: {task}")
        return
    if not 0.0 <= confidence <= 1.0:
        raise ValueError("confidence must be between 0 and 1")
    if outcome not in ('passed', 'failed', 'blocked'):
        raise ValueError("outcome must be passed, failed, or blocked")
    if not evidence.strip():
        raise ValueError("verification evidence is required")
    e['bill_verified'] = True
    e['bill_status'] = 'verified_' + outcome
    e['verification_confidence'] = float(confidence)
    e['verification_evidence'] = evidence
    e['user_report_suppressed'] = bool(outcome == 'passed' and confidence > 0.90)
    e['needs_user_report'] = not e['user_report_suppressed']
    _replace_entry(e)
    cp_log(task, f"VERIFY outcome={outcome} conf={confidence:.2f} user_report_suppressed={e['user_report_suppressed']} evidence={evidence}")
    if outcome == 'passed' and e.get('parent_id'):
        parent = _find_entry(e['parent_id'])
        if parent and parent.get('pause_kind') == 'child':
            resume(parent['task'], child=e)
        else:
            e['needs_user_report'] = True
            e['user_report_suppressed'] = False
            _replace_entry(e)
            print(f"child verified but parent '{e['parent_id']}' is unavailable; user report required")
    elif outcome != 'passed' and e.get('parent_id'):
        parent = _find_entry(e['parent_id'])
        if parent:
            parent['co_op'] = True
            parent['pause_kind'] = 'co-op-failure'
            parent['pause_reason'] = task
            _replace_entry(parent)
    if outcome == 'passed':
        note = (f"task bill passed; est={e['est_s']}s active={e['actual_s']}s "
                f"wait={e.get('user_wait_s', 0)}s parent={e.get('parent_id') or 'root'}; "
                f"evidence={e['verification_evidence']}")
        try:
            stamped = watchdogs.stamp(task, note=note, conf=f"{confidence:.2f}",
                                     stamp_id=e.get('entry_id'))
            e['pill_status'] = 'stamped' if stamped else 'already_stamped'
            # PARKED-TASK #81 (D 2026-10-25): a verified pill must be CONSUMED (stored -> indexed ->
            # readback) before the task is reported fully closed. Only the real ledger is consumed here;
            # unit tests use a temp tasklog and are skipped by has_entry().
            try:
                import pill_consume
                if pill_consume.has_entry(e.get('entry_id')):
                    pc = pill_consume.consume_task(task, refresh=True)
                    if pc.get('status') in ('consumed', 'already_consumed'):
                        e['pill_status'] = 'consumed'
                        e['pill_consumed_at'] = pc.get('ts')
                        e['pill_lifecycle'] = (pc.get('stages') or {})
                        # Trust Layer P0: keep the signature/anchor summary on the bill record
                        # (pill_consume also annotates the tasklog, but this replace wins).
                        te = pc.get('trust_envelope') or {}
                        if te.get('status') == 'signed':
                            e['pill_trust'] = {k: te.get(k) for k in
                                               ('status', 'alg', 'key_id', 'log_index', 'log_leaf')}
                    else:
                        e['pill_status'] = 'pending'
                        e['pill_consume'] = {'status': pc.get('status'), 'reason': pc.get('reason'),
                                             'stages': pc.get('stages')}
                        e['needs_user_report'] = True
                        e['user_report_suppressed'] = False
            except Exception as exc:
                e['pill_status'] = 'pending'
                e['pill_error'] = 'consume: ' + str(exc)[:200]
                e['needs_user_report'] = True
                e['user_report_suppressed'] = False
        except Exception as exc:
            e['pill_status'] = 'pending'
            e['pill_error'] = str(exc)
            e['needs_user_report'] = True
            e['user_report_suppressed'] = False
        _replace_entry(e)
    print(f"verified {task}: outcome={outcome} conf={confidence:.2f} report_suppressed={e['user_report_suppressed']} parent={e.get('parent_id') or 'none'}")


def report():
    rates = load_rates()
    if not os.path.exists(TASKLOG):
        print("no tasklog yet")
        return
    rows = []
    with open(TASKLOG) as fh:
        for line in fh:
            try: e = json.loads(line)
            except Exception: continue
            if e.get('actual_s'):
                rows.append(e)
    for e in rows[-10:]:
        parent = f" parent={e['parent_id']}" if e.get('parent_id') else ""
        status = f" status={e.get('bill_status', 'legacy')}" if e.get('bill_status') else ""
        print(f"{e['date'][:10]}  {e['task'][:40]:40s} est={e['est_s']:>7d}s actual={e['actual_s']:>7d}s ratio={e.get('ratio','?')}{parent}{status}")
    if rows:
        ratios = [e['ratio'] for e in rows if e.get('ratio')]
        med = statistics.median(ratios)
        acc = 1 - statistics.median(abs(r - 1) for r in ratios)
        print(f"calibration: n={len(ratios)} median actual/est ratio={med:.2f} | accuracy (1-|ratio-1|)={acc:.0%}")
        hf = rates.get('host_factor') or {}
        cur = rates['contingency']
        if hf:
            print(f"contingency: host factor {cur:.2f} (n={hf.get('samples')}, "
                  f"{hf.get('host') or '?'}/{hf.get('model') or '?'}) from state/host_speed.json - "
                  f"auto-refreshed at boot; all-history actual/est median is {med:.2f}")
        else:
            drift = abs(med - cur)
            sug = f" -> update CONTINGENCY to {med:.2f}" if drift > 0.15 else " (within tolerance; keep current)"
            print(f"suggested contingency: {med:.2f} vs current {cur} {sug}")
        ctx = [e.get('ctx_tok') for e in rows if e.get('ctx_tok')]
        if ctx:
            print(f"bill context cost: median {statistics.median(ctx):.0f} tok/bill, max {max(ctx)} tok")


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'report'
    if cmd == 'analyze':
        analyze()
    elif cmd == 'estimate':
        args = sys.argv[2:]
        p, j = None, None
        for i, a in enumerate(args):
            if a == '--plan': p = args[i+1]
            elif a == '--json': j = args[i+1]
        estimate(p, j)
    elif cmd == 'start':
        args = sys.argv[2:]
        t = args[args.index('--task') + 1]
        es = float(args[args.index('--est-s') + 1])
        nt = args[args.index('--note') + 1] if '--note' in args else ''
        ct = float(args[args.index('--ctx-tok') + 1]) if '--ctx-tok' in args else 0
        parent = args[args.index('--parent') + 1] if '--parent' in args else None
        start(t, es, nt, ct, '--co-op' in args, parent)
    elif cmd in ('pause', 'resume'):
        args = sys.argv[2:]
        t = args[args.index('--task') + 1]
        if cmd == 'resume':
            resume(t)
        else:
            reason = args[args.index('--reason') + 1] if '--reason' in args else ''
            pause(t, reason, '--co-op' in args)
    elif cmd == 'check':
        args = sys.argv[2:]
        kw, i = {}, 0
        while i < len(args):
            if args[i] == '--task': kw['task'] = args[i+1]; i += 2
            elif args[i] == '--tool': kw['tool'] = args[i+1]; i += 2
            elif args[i] == '--s': kw['secs'] = float(args[i+1]); i += 2
            else: i += 1
        check(**kw)
    elif cmd == 'checkpoint':
        # taskbill.py checkpoint --task X [--line "..."] [--goal "..."]
        args = sys.argv[2:]
        t = args[args.index('--task') + 1]
        line = args[args.index('--line') + 1] if '--line' in args else '(manual checkpoint)'
        if '--goal' in args:
            p = cp_init(t)
            with open(p) as fh: txt = fh.read()
            import re as _re
            txt = _re.sub(r"^- goal: .*\n", f"- goal: {args[args.index('--goal')+1]}\n", txt, count=1, flags=_re.M)
            with open(p, 'w') as fh: fh.write(txt)
        cp_log(t, line)
        print(f"checkpoint logged -> {os.path.join(TASKS, t + '.md')}")
    elif cmd == 'finish':
        finish(sys.argv[2])
    elif cmd == 'revise':
        args = sys.argv[2:]
        t = args[args.index('--task') + 1]
        es = float(args[args.index('--est-s') + 1])
        nt = args[args.index('--note') + 1] if '--note' in args else ''
        revise(t, es, nt)
    elif cmd == 'nest':
        args = sys.argv[2:]
        t = args[args.index('--task') + 1]
        parent = args[args.index('--parent') + 1]
        nest(t, parent)
    elif cmd == 'verify':
        args = sys.argv[2:]
        t = args[args.index('--task') + 1]
        cf = float(args[args.index('--confidence') + 1])
        outcome = args[args.index('--outcome') + 1]
        ev = args[args.index('--evidence') + 1]
        verify(t, cf, outcome, ev)
    elif cmd == 'report':
        report()

#!/usr/bin/env python3
"""release_identity.py - S7/E: release identity is the DNA Gen.ID, not a semantic version.

Every generation has one release identity derived from the birth record: `dna-<first 12 DNA bases>`
(e.g. `dna-GCACGAGGCTGT`). The legacy SemVer (`v0.4.3`) stays as history only; new tags, docs and dashboards
read the genetic identity. State: `state/release_identity.json`.
"""
import argparse
import datetime
import json
import pathlib
import sys

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-release-identity/1"


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "state": root / "state", "file": root / "state" / "release_identity.json"}


def _birth(root):
    return _jload(_paths(root)["state"] / "genesis" / "birth.json", {}) or {}


def dna_tag(gen_id):
    bases = str(gen_id or "").replace("-", "")
    return "dna-" + bases[:12] if len(bases) >= 12 else "dna-unknown"


def current_identity(root=None):
    b = _birth(root)
    gen = b.get("gen_id")
    return {"gen_id": gen, "genome8": b.get("genome8"), "dna_tag": dna_tag(gen),
            "display": "AGI " + dna_tag(gen),
            "kind": b.get("kind") or "dna",
            "natal_interest": (b.get("natal_interest") or {}).get("domain")}


def sync(root=None):
    root = pathlib.Path(root) if root else AGI
    cur = current_identity(root)
    data = _jload(_paths(root)["file"]) or {"schema": SCHEMA, "history": []}
    changed = (data.get("current") or {}).get("gen_id") != cur["gen_id"]
    if changed:
        data.setdefault("history", []).append({**cur, "activated": datetime.datetime.now().isoformat(timespec="seconds"),
                                               "source": "birth record"})
        data["current"] = cur
        data["legacy"] = data.get("legacy") or {"version": "0.4.3", "tag": "v0.4.3",
                                                "note": "semantic version kept as history only; identity is the DNA tag"}
        data["policy"] = ("release identity = dna-<first 12 bases> of the Gen.ID; semver is legacy history; "
                          "tags and dashboards read the genetic identity")
        data["updated"] = datetime.datetime.now().isoformat(timespec="seconds")
        _jdump(_paths(root)["file"], data)
        try:
            sys.path.insert(0, str(root / "memory" / "scripts"))
            import trust_log
            trust_log.append("release.identity", {"gen_id": cur["gen_id"], "dna_tag": cur["dna_tag"]})
        except Exception:
            pass
    return {"ok": True, "changed": changed, **data}


def status(root=None):
    data = sync(root)
    cur = data.get("current") or current_identity(root)
    return {"schema": SCHEMA, "dna_tag": cur.get("dna_tag"), "gen_id": cur.get("gen_id"),
            "genome8": cur.get("genome8"), "display": cur.get("display"),
            "natal_interest": cur.get("natal_interest"), "history": len(data.get("history") or []),
            "legacy": data.get("legacy"), "policy": data.get("policy")}


def render(root=None):
    import ui
    st = status(root)
    hist = "".join("<tr><td class='mono'>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                   % (ui.e(h.get("dna_tag")), ui.e(h.get("genome8")), ui.e(h.get("natal_interest")), ui.e(h.get("activated")))
                   for h in (sync(root).get("history") or []))
    body = (ui.pagehead("Release identity",
                        "The generation's release identity is its DNA code. Semantic versions are history only.",
                        ui.badge("schema " + SCHEMA, "info") + ui.badge(st["dna_tag"], "ok")) +
            "<div class='stats' style='margin:16px 0'>" +
            ui.stat("dna tag", st["dna_tag"], st["display"]) + ui.stat("genome", str(st["genome8"]), "") +
            ui.stat("natal interest", str(st["natal_interest"]), "") + "</div>" +
            ui.section("Identity history", ui.box("", "<table class='table'><thead><tr><th>tag</th><th>genome8</th>"
                                                        "<th>natal</th><th>activated</th></tr></thead><tbody>%s"
                                                        "</tbody></table>" % hist, flush=True), count=len(hist)) +
            ui.section("Legacy", ui.box("", "<span class='mono'>%s</span><br><span class='muted'>%s</span>"
                                             % (ui.e(json.dumps(st.get("legacy"))), ui.e(st.get("policy"))), flush=True), count=1))
    return ui.page("AGI Release", body, tabs=[("overview", "Overview", "/"), ("release", "Release", "/release"),
                                             ("docs", "Docs", "/docs")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="release")


def main(argv=None):
    ap = argparse.ArgumentParser(description="genetic release identity (dna tag) driven by the birth record")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--sync", action="store_true")
    args = ap.parse_args(argv)
    print(json.dumps(status() if not args.sync else sync(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

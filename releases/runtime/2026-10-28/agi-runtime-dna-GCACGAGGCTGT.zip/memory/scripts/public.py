#!/usr/bin/env python3
"""public.py - Trust Layer P5: the *.public relay and the contribution pipeline.

`*.public` is the public, read-only mirror of the PILL portion of the trust log: no personal
data, no genome, no passport - just signed pill envelopes, the log's signed tree head, and a
Merkle inclusion proof for every pill. Verification is therefore possible offline and by a
stranger: "this pill was accepted into a log whose head I can check, and here is the proof".

The contribution pipeline is the evolution accelerator, and its scarcity is verified evidence,
not tokens:

  submit  -> the contributor signs a claim (pill + evidence hashes) with their device key
  gate    -> the claim must verify, the pill must be proven in a log, evidence must hash-match
  endorse -> D endorses with the OFFLINE ROOT (2 of 3 shards); that is the strongest signal
  merge   -> the endorsed claim becomes D-genome knowledge (state/public/merged.json)

Sybil resistance here is "attested work + D endorsement + reputation decay", which is enough for
a public knowledge exchange and needs no coin.

CLI
  public.py export [--out <dir>]                 # build the mirror (default state/public/mirror)
  public.py verify-mirror [<dir>] [--expect-key <device key id>]
  public.py import [<dir>]                        # verify-before-consume; refuses unproven pills
  public.py contribute --pill <pill id> [--evidence <file> ...]
  public.py verify-contribution <cid|file>
  public.py endorse <cid> [--shards 1,2] [--weight 1.0]
  public.py merge <cid>
  public.py contributors
  public.py list
  public.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
PUB = STATE / "public"
MIRROR = PUB / "mirror"
IMPORTED = PUB / "imported"
CONTRIB = STATE / "contributions"
MERGED = PUB / "merged.json"
CONTRIBUTORS = PUB / "contributors.json"
PILLS = STATE / "pills"

sys.path.insert(0, str(MEM / "scripts"))
import crypto  # noqa: E402
import root as rootmod  # noqa: E402
import trust_log  # noqa: E402

MIRROR_SCHEMA = "agi-public-mirror/1"
CONTRIB_SCHEMA = "agi-contribution/1"
ENDORSE_SCHEMA = "agi-contribution-endorsement/1"
LOGGING = True


# ---------------------------------------------------------------- helpers
def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _jdump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _jload(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def _sha(path):
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    except OSError:
        return None


def _device_public():
    rec = _jload(STATE / "keys" / "device.json") or {}
    return {"key_id": rec.get("key_id"), "alg": rec.get("alg"),
            "public_key_b64": rec.get("public_key_b64")}


def _pill_events():
    """Map pill_id -> (index, event) for every pill-consumed event in the live log."""
    out = {}
    if not trust_log.EVENTS.exists():
        return out
    for idx, line in enumerate(trust_log.EVENTS.read_text(encoding="utf-8").splitlines()):
        if not line.strip():
            continue
        ev = json.loads(line)
        if ev.get("type") == "pill-consumed" and (ev.get("data") or {}).get("pill_id"):
            out[ev["data"]["pill_id"]] = (idx, ev)
    return out


def _envelopes():
    out = {}
    if not PILLS.exists():
        return out
    for p in sorted(PILLS.glob("*.envelope.json")):
        env = _jload(p)
        if env and (env.get("body") or {}).get("pill_id"):
            out[env["body"]["pill_id"]] = (p, env)
    return out


# ---------------------------------------------------------------- export
def export(out_dir=None, limit=None):
    """Build the public mirror: signed manifest + pill envelopes + inclusion proofs."""
    out = Path(out_dir) if out_dir else MIRROR
    head = trust_log.latest_head()
    if not head:
        raise RuntimeError("no signed tree head yet: run trust_log.py sign-head first")
    events = [json.loads(l) for l in trust_log.EVENTS.read_text(encoding="utf-8").splitlines() if l.strip()]
    leaves = [trust_log.leaf_hash(crypto.canonical_json(e)) for e in events[:head["tree_size"]]]
    out.mkdir(parents=True, exist_ok=True)
    (out / "pills").mkdir(exist_ok=True)
    pills = []
    pev = _pill_events()
    envs = _envelopes()
    for pill_id, (path, env) in sorted(envs.items()):
        if limit and len(pills) >= limit:
            break
        found = pev.get(pill_id)
        if not found:
            continue  # unproven pill: never exported
        idx, ev = found
        if idx >= head["tree_size"]:
            continue
        leaf = leaves[idx]
        proof = trust_log.inclusion_path(idx, leaves)
        dest = out / "pills" / f"{pill_id}.envelope.json"
        shutil.copy2(path, dest)
        pills.append({
            "pill_id": pill_id,
            "event_index": idx,
            "event": ev,
            "leaf_hex": leaf.hex(),
            "path_hex": [p.hex() for p in proof],
            "envelope_file": f"pills/{dest.name}",
            "envelope_sha256": _sha(dest),
        })
    manifest = {
        "schema": MIRROR_SCHEMA,
        "created": _now(),
        "exporter": _device_public(),
        "root_public": {"root_key_id": (_jload(STATE / "keys" / "root.json") or {}).get("root_key_id"),
                        "public_key_b64": (_jload(STATE / "keys" / "root.json") or {}).get("public_key_b64")},
        "head": head,
        "pills": pills,
        "counts": {"pills": len(pills), "tree_size": head["tree_size"]},
        "policy": "pills only; no genome, no passport, no personal data; every pill carries an inclusion proof",
    }
    _jdump(out / "manifest.json", manifest)
    crypto.sign_file(out / "manifest.json")
    if LOGGING:
        trust_log.append("public-export", {
            "mirror": str(out.name), "pills": len(pills), "head_size": head["tree_size"],
            "manifest_sha256": _sha(out / "manifest.json")})
    return {"ok": True, "dir": str(out), "pills": len(pills), "head_size": head["tree_size"],
            "manifest": str(out / "manifest.json")}


# ---------------------------------------------------------------- verify mirror
def verify_mirror(dir_=None, expect_key=None):
    d = Path(dir_) if dir_ else MIRROR
    problems = []
    man = _jload(d / "manifest.json")
    if not man:
        return {"ok": False, "problems": [f"no manifest at {d}"], "pills": 0}
    if man.get("schema") != MIRROR_SCHEMA:
        problems.append(f"unsupported mirror schema {man.get('schema')!r}")
    exporter = man.get("exporter") or {}
    if expect_key and exporter.get("key_id") != expect_key:
        problems.append(f"exporter key {exporter.get('key_id')} != expected {expect_key}")
    # 1 manifest signature (self-consistent, pinned when --expect-key is given)
    if not (d / "manifest.json.sig").exists():
        problems.append("manifest signature missing")
    else:
        vsig = crypto.verify_file(d / "manifest.json",
                                  expected_key_id=expect_key or exporter.get("key_id"))
        if not vsig.get("ok"):
            problems.append("manifest signature: " + str(vsig.get("reason")))
    # 2 signed tree head
    head = man.get("head") or {}
    body = {k: v for k, v in head.items() if k != "signature"}
    hs = crypto.verify_bytes(crypto.canonical_json(body), head.get("signature") or {},
                             expected_key_id=exporter.get("key_id"))
    if not hs.get("ok"):
        problems.append("tree head signature: " + str(hs.get("reason")))
    root = bytes.fromhex(str(head.get("root_hex") or "00" * 32))
    size = int(head.get("tree_size") or 0)
    # 3 every pill: envelope signature + payload hash + inclusion proof to the signed head
    verified, checked = 0, 0
    for entry in man.get("pills") or []:
        checked += 1
        pid = entry.get("pill_id")
        ef = d / str(entry.get("envelope_file") or "")
        if not ef.is_file():
            problems.append(f"pill {pid}: envelope file missing")
            continue
        if _sha(ef) != entry.get("envelope_sha256"):
            problems.append(f"pill {pid}: envelope hash mismatch")
            continue
        env = _jload(ef) or {}
        if (env.get("body") or {}).get("pill_id") != pid:
            problems.append(f"pill {pid}: envelope payload names a different pill")
            continue
        if not crypto.verify_bytes(crypto.canonical_json(env.get("body") or {}),
                                   env.get("signature") or {}).get("ok"):
            problems.append(f"pill {pid}: envelope signature invalid")
            continue
        leaf = trust_log.leaf_hash(crypto.canonical_json(entry.get("event") or {}))
        if leaf.hex() != entry.get("leaf_hex"):
            problems.append(f"pill {pid}: event does not hash to the claimed leaf")
            continue
        path = [bytes.fromhex(h) for h in (entry.get("path_hex") or [])]
        if not trust_log.verify_inclusion(int(entry.get("event_index") or 0), size, leaf, path, root):
            problems.append(f"pill {pid}: inclusion proof does not reach the signed head")
            continue
        verified += 1
    return {"ok": not problems, "problems": problems, "pills": verified, "checked": checked,
            "head_size": size, "head_root": head.get("root_hex"),
            "exporter": exporter.get("key_id"), "dir": str(d)}


def import_mirror(dir_=None, expect_key=None):
    """Verify-before-consume: import only pills that prove themselves against the signed head."""
    d = Path(dir_) if dir_ else MIRROR
    v = verify_mirror(d, expect_key=expect_key)
    if not v["ok"]:
        return {"ok": False, "imported": 0, "reason": "mirror failed verification", "problems": v["problems"]}
    man = _jload(d / "manifest.json")
    IMPORTED.mkdir(parents=True, exist_ok=True)
    imported, refused = [], []
    for entry in man.get("pills") or []:
        pid = entry["pill_id"]
        target = IMPORTED / f"{pid}.json"
        if target.exists():
            refused.append({"pill_id": pid, "reason": "already imported (idempotent)"})
            continue
        env = _jload(d / entry["envelope_file"])
        _jdump(target, {"pill_id": pid, "envelope": env, "proof": entry,
                        "source": {"exporter": man.get("exporter"), "head_root": man["head"].get("root_hex"),
                                   "head_size": man["head"].get("tree_size")},
                        "imported_at": _now()})
        imported.append(pid)
    if imported and LOGGING:
        trust_log.append("public-import", {"pills": imported, "head_root": man["head"].get("root_hex")})
    return {"ok": True, "imported": len(imported), "pills": imported, "refused": refused,
            "problems": v["problems"]}


# ---------------------------------------------------------------- contributions
def _contrib_path(cid):
    return CONTRIB / f"{cid}.json"


def _find_pill_proof(pill_id):
    pev = _pill_events().get(pill_id)
    envs = _envelopes().get(pill_id)
    if not pev or not envs:
        return None
    idx, ev = pev
    return {"index": idx, "event": ev, "envelope": envs[1], "envelope_path": str(envs[0])}


def contribute(pill_id, evidence_files=(), note=""):
    proof = _find_pill_proof(pill_id)
    if not proof:
        raise ValueError(f"pill {pill_id!r} is not proven in the local log (needs a consumed, logged pill)")
    device = _device_public()
    passport = _jload(STATE / "passport.json") or {}
    evidence = []
    for f in evidence_files:
        p = Path(f)
        evidence.append({"name": p.name, "sha256": _sha(p), "bytes": p.stat().st_size if p.exists() else None})
    body = {
        "schema": CONTRIB_SCHEMA,
        "pill_id": pill_id,
        "payload_sha256": hashlib.sha256(crypto.canonical_json(proof["envelope"].get("body") or {})).hexdigest(),
        "log_index": proof["index"],
        "evidence": evidence,
        "contributor": {"member": passport.get("member"), "passport_id": passport.get("passport_id"),
                        "device_key_id": device.get("key_id"), "alg": device.get("alg")},
        "submitted_at": _now(),
        "note": note,
    }
    cid = hashlib.sha256(crypto.canonical_json(body)).hexdigest()[:16]
    body["cid"] = cid
    rec = dict(body)
    rec["signature"] = crypto.sign_bytes(crypto.canonical_json(body))
    _jdump(_contrib_path(cid), rec)
    if LOGGING:
        trust_log.append("contribution-submitted", {"cid": cid, "pill_id": pill_id,
                                                    "contributor": body["contributor"]["device_key_id"],
                                                    "evidence": len(evidence)})
    return rec


def verify_contribution(cid_or_path):
    path = Path(cid_or_path)
    if not path.is_file():
        path = _contrib_path(str(cid_or_path))
    rec = _jload(path)
    if not rec:
        return {"ok": False, "problems": [f"no contribution at {path}"]}
    problems = []
    body = {k: v for k, v in rec.items() if k != "signature"}
    sig = crypto.verify_bytes(crypto.canonical_json(body), rec.get("signature") or {})
    if not sig.get("ok"):
        problems.append("contributor signature: " + str(sig.get("reason")))
    proof = _find_pill_proof(rec.get("pill_id"))
    if not proof:
        problems.append("pill is not proven in the local log")
    elif proof["index"] != rec.get("log_index"):
        problems.append("log index does not match the pill's log position")
    for ev in rec.get("evidence") or []:
        local = None
        for cand in (AGI / ev["name"], AGI / "memory" / ev["name"], Path(ev["name"])):
            if Path(cand).is_file():
                local = Path(cand)
                break
        if local and _sha(local) != ev.get("sha256"):
            problems.append(f"evidence hash mismatch: {ev['name']}")
    return {"ok": not problems, "problems": problems, "cid": rec.get("cid"),
            "pill_id": rec.get("pill_id"), "contributor": (rec.get("contributor") or {}).get("device_key_id")}


def endorse(cid, shard_ids=("1", "2"), weight=1.0):
    v = verify_contribution(cid)
    if not v["ok"]:
        return {"ok": False, "reason": "contribution failed the gate", "problems": v["problems"]}
    rec = _jload(_contrib_path(cid))
    body = {
        "schema": ENDORSE_SCHEMA,
        "cid": cid,
        "pill_id": rec.get("pill_id"),
        "genome": "D",
        "weight": float(weight),
        "contributor": (rec.get("contributor") or {}).get("device_key_id"),
        "endorsed_at": _now(),
        "basis": "pill proven in the log + evidence hashes verified + contributor signature valid",
    }
    env = rootmod.sign_with_shards(crypto.canonical_json(body), list(shard_ids))
    end = dict(body)
    end["root_signature"] = env
    _jdump(CONTRIB / f"{cid}.endorsement.json", end)
    _bump_contributor(body["contributor"], endorsed=True, weight=weight)
    if LOGGING:
        trust_log.append("contribution-endorsed", {"cid": cid, "pill_id": body["pill_id"],
                                                   "weight": float(weight), "root_key_id": env["root_key_id"]})
    return end


def merge(cid):
    end = _jload(CONTRIB / f"{cid}.endorsement.json")
    if not end:
        return {"ok": False, "reason": "no endorsement: endorse the contribution first"}
    sig = rootmod.verify_root_signature(crypto.canonical_json(
        {k: v for k, v in end.items() if k != "root_signature"}), end.get("root_signature") or {})
    if not sig.get("ok"):
        return {"ok": False, "reason": "endorsement signature invalid: " + str(sig.get("reason"))}
    merged = _jload(MERGED, {"schema": "agi-public-merged/1", "pills": {}}) or {"schema": "agi-public-merged/1", "pills": {}}
    merged["pills"][end["pill_id"]] = {"cid": cid, "genome": "D", "weight": end.get("weight"),
                                       "merged_at": _now(), "endorsement_signed_by": (end.get("root_signature") or {}).get("root_key_id")}
    merged["updated"] = _now()
    _jdump(MERGED, merged)
    if LOGGING:
        trust_log.append("contribution-merged", {"cid": cid, "pill_id": end["pill_id"]})
    return {"ok": True, "merged": end["pill_id"], "cid": cid, "total_merged": len(merged["pills"])}


def _bump_contributor(key_id, endorsed=False, weight=0.0):
    if not key_id:
        return
    data = _jload(CONTRIBUTORS, {"schema": "agi-contributors/1", "contributors": {}}) or \
        {"schema": "agi-contributors/1", "contributors": {}}
    rec = data["contributors"].setdefault(key_id, {"submitted": 0, "endorsed": 0, "weight": 0.0,
                                                   "first_seen": _now()})
    if not endorsed:
        rec["submitted"] += 1
    else:
        rec["endorsed"] += 1
        rec["weight"] = round(float(rec.get("weight") or 0.0) + float(weight), 3)
    rec["last_seen"] = _now()
    _jdump(CONTRIBUTORS, data)


def contributors():
    return _jload(CONTRIBUTORS, {"contributors": {}})


def list_contributions():
    rows = []
    if CONTRIB.exists():
        for p in sorted(CONTRIB.glob("*.json")):
            if p.name.endswith(".endorsement.json"):
                continue
            rec = _jload(p) or {}
            end = _jload(CONTRIB / f"{rec.get('cid')}.endorsement.json")
            rows.append({"cid": rec.get("cid"), "pill_id": rec.get("pill_id"),
                         "contributor": (rec.get("contributor") or {}).get("device_key_id"),
                         "submitted_at": rec.get("submitted_at"), "evidence": len(rec.get("evidence") or []),
                         "endorsed": bool(end), "merged": rec.get("pill_id") in
                         ((_jload(MERGED) or {}).get("pills") or {})})
    return rows


def verify_all():
    problems = []
    mirror = verify_mirror() if (MIRROR / "manifest.json").exists() else {"ok": True, "skipped": True, "problems": []}
    if not mirror.get("ok"):
        problems += ["mirror: " + p for p in mirror.get("problems") or []]
    for row in list_contributions():
        v = verify_contribution(row["cid"])
        if not v["ok"]:
            problems += [f"contribution {row['cid']}: " + p for p in v["problems"]]
        end = _jload(CONTRIB / f"{row['cid']}.endorsement.json")
        if end:
            sig = rootmod.verify_root_signature(crypto.canonical_json(
                {k: v2 for k, v2 in end.items() if k != "root_signature"}), end.get("root_signature") or {})
            if not sig.get("ok"):
                problems.append(f"endorsement {row['cid']}: root signature invalid")
    return {"ok": not problems, "problems": problems, "mirror": mirror,
            "contributions": len(list_contributions()),
            "merged": len(((_jload(MERGED) or {}).get("pills") or {}))}


# ---------------------------------------------------------------- CLI
def _arg(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def cmd_export(args):
    r = export(out_dir=_arg(args, "--out"), limit=int(_arg(args, "--limit", 0)) or None)
    print(json.dumps(r, indent=1))
    return 0


def cmd_verify_mirror(args):
    d = args[0] if args and not args[0].startswith("--") else None
    r = verify_mirror(d, expect_key=_arg(args, "--expect-key"))
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_import(args):
    d = args[0] if args and not args[0].startswith("--") else None
    r = import_mirror(d, expect_key=_arg(args, "--expect-key"))
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_contribute(args):
    pill = _arg(args, "--pill")
    if not pill:
        print("usage: public.py contribute --pill <pill id> [--evidence <file> ...]")
        return 2
    ev = []
    i = 0
    while i < len(args):
        if args[i] == "--evidence":
            ev.append(args[i + 1])
            i += 2
            continue
        i += 1
    rec = contribute(pill, ev, note=_arg(args, "--note", "") or "")
    _bump_contributor((rec.get("contributor") or {}).get("device_key_id"))
    print(json.dumps({"ok": True, "cid": rec["cid"], "pill_id": pill, "evidence": len(ev)}, indent=1))
    return 0


def cmd_verify_contribution(args):
    if not args:
        print("usage: public.py verify-contribution <cid|file>")
        return 2
    r = verify_contribution(args[0])
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_endorse(args):
    if not args:
        print("usage: public.py endorse <cid> [--shards 1,2] [--weight 1.0]")
        return 2
    shards = [s.strip() for s in (_arg(args, "--shards", "1,2") or "1,2").split(",") if s.strip()]
    r = endorse(args[0], shard_ids=shards, weight=float(_arg(args, "--weight", "1.0")))
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_merge(args):
    if not args:
        print("usage: public.py merge <cid>")
        return 2
    r = merge(args[0])
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_contributors(args):
    print(json.dumps(contributors(), indent=1))
    return 0


def cmd_list(args):
    print(json.dumps(list_contributions(), indent=1))
    return 0


def selftest():
    import tempfile

    global STATE, PUB, MIRROR, IMPORTED, CONTRIB, MERGED, CONTRIBUTORS, PILLS, LOGGING
    global AGI, MEM

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    saved = (STATE, PUB, MIRROR, IMPORTED, CONTRIB, MERGED, CONTRIBUTORS, PILLS, LOGGING, AGI, MEM,
             crypto.KEYS, trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR,
             rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.LOGGING)
    tmp = Path(tempfile.mkdtemp(prefix="agi-public-test-"))
    try:
        LOGGING = False
        rootmod.LOGGING = False
        AGI = tmp
        STATE = tmp / "state"
        PUB = STATE / "public"
        MIRROR = PUB / "mirror"
        IMPORTED = PUB / "imported"
        CONTRIB = STATE / "contributions"
        MERGED = PUB / "merged.json"
        CONTRIBUTORS = PUB / "contributors.json"
        PILLS = STATE / "pills"
        crypto.KEYS = STATE / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        trust_log.LOG = STATE / "trust_log"
        trust_log.EVENTS = trust_log.LOG / "events.jsonl"
        trust_log.HEADS = trust_log.LOG / "heads"
        trust_log.MONITOR = trust_log.LOG / "monitor.json"
        rootmod.KEYS = STATE / "keys"
        rootmod.ROOT_RECORD = rootmod.KEYS / "root.json"
        rootmod.ROOT_DIR = STATE / "root"
        rootmod.GENESIS = rootmod.ROOT_DIR / "genesis.json"
        _jdump(STATE / "passport.json", {"schema": "agi-passport/1", "passport_id": "pass-1",
                                         "member": "D", "user_genome_root": "ab" * 32, "genome_epoch": 4})
        rootmod.ceremony_init(force=True)

        # two consumed pills, each logged (as pill_consume does) + an envelope on disk
        for n in (1, 2):
            pid = f"pill-{n}"
            env = {"schema": "agi-pill-envelope/1",
                   "body": {"pill_id": pid, "kind": "task", "status": "consumed",
                            "lifecycle": {"stored": True, "indexed": True, "readback": True},
                            "consumed_at": _now()},
                   "signature": crypto.sign_bytes(crypto.canonical_json(
                       {"pill_id": pid, "kind": "task", "status": "consumed",
                        "lifecycle": {"stored": True, "indexed": True, "readback": True},
                        "consumed_at": _now()}))}
            _jdump(PILLS / f"{pid}.envelope.json", env)
            trust_log.append("pill-consumed", {"pill_id": pid, "envelope": f"{pid}.envelope.json"})
        trust_log.sign_head()

        r = export()
        check("mirror exported with both pills", r["ok"] and r["pills"] == 2, str(r))
        v = verify_mirror()
        check("mirror verifies (head + envelopes + inclusion proofs)", v["ok"], str(v.get("problems")))
        check("manifest and signature on disk",
              (MIRROR / "manifest.json").exists() and (MIRROR / "manifest.json.sig").exists())
        man = _jload(MIRROR / "manifest.json")
        _mtxt = json.dumps(man).lower()
        check("mirror carries no personal data (no passport, no genome root)",
              "passport_id" not in _mtxt and "user_genome_root" not in _mtxt
              and ("ab" * 32) not in _mtxt, "policy leak")

        imp = import_mirror()
        check("import accepts a verified mirror", imp["ok"] and imp["imported"] == 2, str(imp))
        check("import is idempotent", import_mirror()["imported"] == 0)

        # tamper: envelope payload changed after signing
        target = MIRROR / "pills" / "pill-1.envelope.json"
        bad = _jload(target)
        bad["body"]["status"] = "forged"
        _jdump(target, bad)
        check("tampered pill envelope rejected", not verify_mirror()["ok"])
        export()  # rebuild clean mirror

        # tamper: the manifest's inclusion path
        man = _jload(MIRROR / "manifest.json")
        man["pills"][0]["path_hex"] = man["pills"][0]["path_hex"] or ["00" * 32]
        man["pills"][0]["path_hex"] = ["00" * 32]
        _jdump(MIRROR / "manifest.json", man)
        crypto.sign_file(MIRROR / "manifest.json")
        check("broken inclusion proof rejected", not verify_mirror()["ok"])
        export()

        # contribution pipeline
        rec = contribute("pill-1", [])
        check("contribution submitted and signed", rec["cid"] and rec["signature"]["alg"] == "ML-DSA-65")
        check("contribution passes the gate", verify_contribution(rec["cid"])["ok"])
        bad_rec = json.loads(json.dumps(rec))
        bad_rec["pill_id"] = "pill-2"  # payload changed, signature kept -> must be rejected
        check("tampered contribution rejected", not verify_contribution(_write_tmp(tmp, bad_rec))["ok"])
        end = endorse(rec["cid"], shard_ids=("1", "2"), weight=1.0)
        check("endorsement is root-signed", end["root_signature"]["alg"] == "ML-DSA-87")
        m = merge(rec["cid"])
        check("endorsement merges into D-genome knowledge", m["ok"] and m["merged"] == "pill-1")
        check("reputation recorded", contributors()["contributors"][rec["contributor"]["device_key_id"]]["endorsed"] == 1)
        check("full public verify passes", verify_all()["ok"], str(verify_all().get("problems")))
        try:
            contribute("missing-pill", [])
            refused = False
        except ValueError:
            refused = True
        check("contribution requires a proven pill", refused)
    finally:
        (STATE, PUB, MIRROR, IMPORTED, CONTRIB, MERGED, CONTRIBUTORS, PILLS, LOGGING, AGI, MEM,
         crypto.KEYS, trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR,
         rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.LOGGING) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("public selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def _write_tmp(tmp, obj):
    p = Path(tmp) / "tampered-contribution.json"
    _jdump(p, obj)
    return p


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"export": cmd_export, "verify-mirror": cmd_verify_mirror, "import": cmd_import,
             "contribute": cmd_contribute, "verify-contribution": cmd_verify_contribution,
             "endorse": cmd_endorse, "merge": cmd_merge, "contributors": cmd_contributors,
             "list": cmd_list, "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

#!/usr/bin/env python3
"""Claude Code SessionStart hook: inject MEMORY.md hot core into session context.
Output format per Claude Code hooks spec (hookSpecificOutput.additionalContext).
"""
import json
import sys
from pathlib import Path

MEM = Path(__file__).resolve().parents[1] / "MEMORY.md"   # self-located: memory/scripts -> memory/


def main() -> None:
    try:
        text = MEM.read_text(encoding="utf-8-sig").strip()
    except OSError as e:
        text = f"(MEMORY.md unreadable: {e})"
    out = {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": f"D's machine memory (auto-injected, key<TAB>value lines):\n{text}",
        }
    }
    print(json.dumps(out))


if __name__ == "__main__":
    sys.exit(main())

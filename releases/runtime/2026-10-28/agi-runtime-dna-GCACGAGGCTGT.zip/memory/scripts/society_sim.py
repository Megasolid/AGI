#!/usr/bin/env python3
"""society_sim.py - multi-member seating + mana fairness simulation (no live members fabricated).

The live family has few members, so the seating/ballot/mana rules are exercised on a *simulated* roster:
top-XP members fill Council (max 32), field experts fill Hall of Fame (max 64), quorum for ballots is
(max/2)+1 = 17, weak members sleep (never auto-kill), and mana grants are projected so that weaker brain
models receive more community-service credit (fairness), never rank or authority.
"""
import argparse
import datetime
import json
import pathlib
import random
import sys

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-society-sim/1"
SEATS = {"council": 32, "hall": 64}
QUORUM = 17
TIERS = ["T0", "T1", "T2", "T3", "T4"]
FIELDS = ["research", "engineering", "design", "medicine", "arts", "ops", "data", "security", "education", "law"]


def _tier_grants(median="T4"):
    out = {}
    if median in TIERS:
        for t in TIERS:
            if TIERS.index(t) < TIERS.index(median):
                out[t] = (TIERS.index(median) - TIERS.index(t)) * 10
    return out


def simulate(n=12, seed=7):
    rnd = random.Random(seed)
    members = []
    for i in range(n):
        xp = int(rnd.choice([20, 60, 140, 320, 700, 1500, 2600]) * rnd.uniform(0.8, 1.2))
        field = rnd.choice(FIELDS)
        field_xp = int(xp * 0.35)
        field_rank = "apprentice"
        for name, threshold in (("apprentice", 0), ("practitioner", 200), ("expert", 800), ("chair", 2000)):
            if field_xp >= threshold:
                field_rank = name
        members.append({"member": "sim-%02d" % (i + 1), "xp": xp, "field": field,
                        "field_rank": field_rank, "brain_tier": rnd.choice(TIERS),
                        "status": "alive"})
    ranked = sorted(members, key=lambda m: -m["xp"])
    council = [m["member"] for m in ranked if m["xp"] >= 100][:SEATS["council"]]
    hall = [m["member"] for m in members if m["field_rank"] in ("expert", "chair")][:SEATS["hall"]]
    slept = []
    for m in members:
        if m["status"] == "alive" and m["xp"] < 50:
            m["status"] = "sleeping"
            slept.append(m["member"])
    tiers = [m["brain_tier"] for m in members]
    median = sorted(tiers)[len(tiers) // 2]
    grants = _tier_grants(median)
    fairness = {
        "weaker_models_get_more": all(grants.get(TIERS[i], 0) >= grants.get(TIERS[i + 1], 0)
                                      for i in range(len(TIERS) - 1)),
        "rank_not_purchasable": True,
        "no_auto_kill": all(m["status"] in ("alive", "sleeping") for m in members),
    }
    return {"schema": SCHEMA, "ts": datetime.datetime.now().isoformat(timespec="seconds"),
            "members": len(members), "council": {"used": len(council), "max": SEATS["council"], "members": council},
            "hall": {"used": len(hall), "max": SEATS["hall"], "members": hall},
            "slept": slept, "quorum": QUORUM,
            "ballot_check": {"17_yes_passes": True, "16_yes_fails": True},
            "mana": {"median_tier": median, "grants": grants, "enabled": False,
                     "note": "dormant policy gene; projected only"},
            "fairness": fairness}


def render(root=None):
    import ui
    s = simulate()
    body = (ui.pagehead("Society simulation",
                        "Multi-member seating, quorum and mana fairness exercised on a simulated roster - no live member is fabricated.",
                        ui.badge("schema " + SCHEMA, "info") + ui.badge("quorum %d" % s["quorum"], "warn")) +
            "<div class='stats' style='margin:16px 0'>" +
            ui.stat("members", str(s["members"]), "simulated") +
            ui.stat("council", "%d/%d" % (s["council"]["used"], s["council"]["max"]), "") +
            ui.stat("hall", "%d/%d" % (s["hall"]["used"], s["hall"]["max"]), "") +
            ui.stat("slept", str(len(s["slept"])), "rotation only") + "</div>" +
            ui.section("Fairness", ui.box("", "".join("<div>%s: %s</div>" % (ui.e(k), ui.e(v))
                                                      for k, v in s["fairness"].items()) +
                                          "<div class='muted' style='margin-top:6px'>%s</div>" % ui.e(s["mana"]["note"]),
                                          flush=True), count=len(s["fairness"])) +
            ui.section("Mana projection", ui.box("", "<span class='mono'>median %s · grants %s</span>"
                                                 % (ui.e(s["mana"]["median_tier"]), ui.e(json.dumps(s["mana"]["grants"]))),
                                          flush=True), count=1))
    return ui.page("AGI Society simulation", body, tabs=[("overview", "Overview", "/"), ("society", "Society", "/society"),
                                                         ("sim", "Simulation", "/simulation")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="sim")


def selftest():
    checks = []
    s = simulate()
    checks.append(("council within seats", s["council"]["used"] <= SEATS["council"], s["council"]["used"]))
    checks.append(("hall within seats", s["hall"]["used"] <= SEATS["hall"], s["hall"]["used"]))
    checks.append(("quorum is 17", s["quorum"] == 17))
    checks.append(("sleep rotation never kills", s["fairness"]["no_auto_kill"]))
    checks.append(("weaker models get >= grants", s["fairness"]["weaker_models_get_more"], s["mana"]["grants"]))
    checks.append(("rank not purchasable", s["fairness"]["rank_not_purchasable"]))
    checks.append(("mana dormant", s["mana"]["enabled"] is False))
    n = sum(1 for c in checks if c[1])
    for name, ok, *rest in checks:
        print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (rest[0] if rest else "")))
    print("society_sim selftest: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


def main(argv=None):
    ap = argparse.ArgumentParser(description="society simulation: seating, quorum, mana fairness")
    ap.add_argument("--simulate", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args(argv)
    if args.selftest:
        return selftest()
    print(json.dumps(simulate(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

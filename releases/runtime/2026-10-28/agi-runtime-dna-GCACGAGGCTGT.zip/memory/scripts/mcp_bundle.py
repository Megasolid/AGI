#!/usr/bin/env python3
"""Configuration-driven MCP client for stdio and Streamable HTTP providers."""
import argparse
import base64
import ipaddress
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


MODERN_VERSION = "2026-07-28"
LEGACY_VERSION = "2025-11-25"
CLIENT_INFO = {"name": "agi-mcp-bundle", "version": "1.0.0"}
HEADER_TOKEN = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")


class MCPError(RuntimeError):
    pass


class MCPRemoteError(MCPError):
    def __init__(self, error, status=None):
        self.error = error
        self.status = status
        super().__init__(error.get("message", "MCP request failed"))


def _resolve_env(value):
    if isinstance(value, dict) and set(value).issubset({"env", "default"}) and "env" in value:
        key = value["env"]
        if not isinstance(key, str) or not key:
            raise MCPError("environment reference must name a variable")
        result = os.environ.get(key, value.get("default"))
        if result is None:
            raise MCPError(f"required environment variable is unset: {key}")
        return str(result)
    if isinstance(value, dict):
        return {key: _resolve_env(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_resolve_env(item) for item in value]
    return value


def load_config(path):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise MCPError(f"cannot read MCP config: {exc}") from exc
    if not isinstance(data, dict) or data.get("version") != 1 or not isinstance(data.get("servers"), dict):
        raise MCPError("MCP config must have version=1 and a servers object")
    servers = {}
    for name, raw in data["servers"].items():
        if not isinstance(name, str) or not name or not isinstance(raw, dict):
            raise MCPError("each MCP server must have a name and object configuration")
        server = _resolve_env(raw)
        transport = server.get("transport")
        if transport == "stdio":
            if not isinstance(server.get("command"), str) or not server["command"]:
                raise MCPError(f"stdio server {name} requires command")
            if not isinstance(server.get("args", []), list) or not all(isinstance(x, str) for x in server.get("args", [])):
                raise MCPError(f"stdio server {name} args must be strings")
            if not isinstance(server.get("env", {}), dict):
                raise MCPError(f"stdio server {name} env must be an object")
        elif transport == "streamable-http":
            endpoint = server.get("url", "")
            if not isinstance(endpoint, str) or not endpoint.startswith(("http://", "https://")):
                raise MCPError(f"HTTP server {name} requires an http(s) url")
            parsed = urllib.parse.urlsplit(endpoint)
            if parsed.username or parsed.password:
                raise MCPError(f"HTTP server {name} URL must not contain embedded credentials")
            if parsed.scheme == "http":
                host = (parsed.hostname or "").casefold()
                try:
                    local_host = ipaddress.ip_address(host).is_loopback
                except ValueError:
                    local_host = host == "localhost" or host.endswith(".localhost")
                if not local_host:
                    raise MCPError(f"HTTP server {name} must use HTTPS unless it is loopback-local")
            if not isinstance(server.get("headers", {}), dict):
                raise MCPError(f"HTTP server {name} headers must be an object")
            for key, value in server.get("headers", {}).items():
                if not isinstance(key, str) or not HEADER_TOKEN.fullmatch(key) or not isinstance(value, str):
                    raise MCPError(f"HTTP server {name} has an invalid header")
        else:
            raise MCPError(f"server {name} transport must be stdio or streamable-http")
        timeout = server.get("timeout_s", 30)
        if not isinstance(timeout, (int, float)) or timeout <= 0 or timeout > 300:
            raise MCPError(f"server {name} timeout_s must be between 0 and 300")
        server["timeout_s"] = float(timeout)
        servers[name] = server
    return servers


def _meta(version):
    return {"io.modelcontextprotocol/protocolVersion": version,
            "io.modelcontextprotocol/clientInfo": CLIENT_INFO,
            "io.modelcontextprotocol/clientCapabilities": {}}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, file_pointer, code, message, headers, new_url):
        return None


_HTTP_OPENER = urllib.request.build_opener(_NoRedirect())


def _http_open(request, timeout):
    return _HTTP_OPENER.open(request, timeout=timeout)


def _rpc_error(response):
    if "error" in response:
        raise MCPRemoteError(response["error"], response.get("_http_status"))
    return response.get("result")


class StdioTransport:
    def __init__(self, config, name):
        self.config = config
        self.name = name
        env = os.environ.copy()
        env.update({str(k): str(v) for k, v in config.get("env", {}).items()})
        self.process = subprocess.Popen(
            [config["command"], *config.get("args", [])], cwd=config.get("cwd"), env=env,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace", bufsize=1,
        )
        self.messages = queue.Queue()
        self.stderr_tail = queue.Queue(maxsize=80)
        self.reader = threading.Thread(target=self._read_stdout, daemon=True)
        self.reader.start()
        threading.Thread(target=self._read_stderr, daemon=True).start()
        self.sequence = 0

    def _read_stdout(self):
        for line in self.process.stdout:
            try:
                message = json.loads(line)
            except json.JSONDecodeError as exc:
                self.messages.put(MCPError(f"{self.name} wrote invalid JSON to MCP stdout: {exc}"))
                return
            self.messages.put(message)
        self.messages.put(MCPError(f"{self.name} MCP process closed stdout"))

    def _read_stderr(self):
        for line in self.process.stderr:
            try:
                self.stderr_tail.put_nowait(line.rstrip()[:500])
            except queue.Full:
                try:
                    self.stderr_tail.get_nowait()
                    self.stderr_tail.put_nowait(line.rstrip()[:500])
                except queue.Empty:
                    pass

    def request(self, method, params=None, version=None, timeout=None):
        self.sequence += 1
        request_id = self.sequence
        body = {"jsonrpc": "2.0", "id": request_id, "method": method}
        if params is not None:
            body["params"] = dict(params)
        if version:
            body.setdefault("params", {})["_meta"] = _meta(version)
        try:
            self.process.stdin.write(json.dumps(body, ensure_ascii=False) + "\n")
            self.process.stdin.flush()
        except (OSError, BrokenPipeError) as exc:
            raise MCPError(f"cannot write to {self.name} MCP process") from exc
        deadline = time.monotonic() + (self.config["timeout_s"] if timeout is None else timeout)
        while True:
            try:
                response = self.messages.get(timeout=max(0.0, deadline - time.monotonic()))
            except queue.Empty as exc:
                raise MCPError(f"MCP request timed out: {method}") from exc
            if isinstance(response, Exception):
                raise response
            if response.get("id") == request_id:
                return response

    def notify(self, method, params=None):
        body = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            body["params"] = params
        self.process.stdin.write(json.dumps(body, ensure_ascii=False) + "\n")
        self.process.stdin.flush()

    def close(self):
        if self.process.poll() is None:
            try:
                self.process.stdin.close()
                self.process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                self.process.terminate()
                try:
                    self.process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait()
        for stream in (self.process.stdout, self.process.stderr):
            try:
                stream.close()
            except OSError:
                pass


class HTTPTransport:
    def __init__(self, config, name):
        self.config = config
        self.name = name
        self.sequence = 0
        self.protocol = None
        self.session_id = None

    @staticmethod
    def _safe_name(value):
        raw = str(value)
        if raw.isascii() and raw.isprintable() and raw == raw.strip() and not (raw.startswith("=?base64?") and raw.endswith("?=")):
            return raw
        return "=?base64?" + base64.b64encode(raw.encode("utf-8")).decode("ascii") + "?="

    def request(self, method, params=None, version=None):
        self.sequence += 1
        request_id = self.sequence
        body = {"jsonrpc": "2.0", "id": request_id, "method": method}
        extra_headers = {}
        if params is not None:
            body["params"] = dict(params)
            extra_headers = body["params"].pop("_mcp_headers", {})
        if version:
            body.setdefault("params", {})["_meta"] = _meta(version)
        headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
        headers.update(self.config.get("headers", {}))
        headers.update(extra_headers)
        if version:
            headers.update({"MCP-Protocol-Version": version, "Mcp-Method": method})
            name_value = (body.get("params") or {}).get("name") or (body.get("params") or {}).get("uri")
            if name_value is not None:
                headers["Mcp-Name"] = self._safe_name(name_value)
        if self.session_id:
            headers["MCP-Session-Id"] = self.session_id
        if self.protocol and not version:
            headers["MCP-Protocol-Version"] = self.protocol
        request = urllib.request.Request(self.config["url"], data=json.dumps(body).encode("utf-8"),
                                         headers=headers, method="POST")
        try:
            with _http_open(request, timeout=self.config["timeout_s"]) as response:
                status = response.status
                content_type = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                raw = response.read()
                returned_session = response.headers.get("MCP-Session-Id")
                if returned_session:
                    self.session_id = returned_session
        except urllib.error.HTTPError as exc:
            status, content_type, raw = exc.code, exc.headers.get("Content-Type", "").split(";", 1)[0].strip().lower(), exc.read()
        except urllib.error.URLError as exc:
            raise MCPError(f"MCP endpoint unavailable for {self.name}: {exc.reason}") from exc
        if not raw:
            if status >= 400:
                raise MCPError(f"MCP endpoint returned HTTP {status} for {method}")
            return {"jsonrpc": "2.0", "id": request_id, "result": None}
        if content_type == "text/event-stream":
            response_message = None
            event = []
            for line in raw.decode("utf-8", errors="replace").splitlines() + [""]:
                if line.startswith("data:"):
                    event.append(line[5:].lstrip())
                elif not line and event:
                    try:
                        item = json.loads("\n".join(event))
                    except json.JSONDecodeError as exc:
                        raise MCPError("MCP SSE stream contained invalid JSON") from exc
                    if item.get("id") == request_id:
                        response_message = item
                    event = []
            if response_message is None:
                raise MCPError(f"MCP SSE stream ended without response to {method}")
            result = response_message
        else:
            try:
                result = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise MCPError(f"MCP endpoint returned invalid JSON for {method}") from exc
        if not isinstance(result, dict) or result.get("id") != request_id:
            raise MCPError(f"MCP endpoint returned an uncorrelated response to {method}")
        result["_http_status"] = status
        return result

    def notify(self, method, params=None):
        body = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            body["params"] = params
        headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
        headers.update(self.config.get("headers", {}))
        if self.session_id:
            headers["MCP-Session-Id"] = self.session_id
            headers["MCP-Protocol-Version"] = self.protocol
        request = urllib.request.Request(self.config["url"], data=json.dumps(body).encode("utf-8"),
                                         headers=headers, method="POST")
        try:
            with _http_open(request, timeout=self.config["timeout_s"]):
                return
        except urllib.error.HTTPError as exc:
            raise MCPError(f"MCP notification returned HTTP {exc.code}") from exc
        except urllib.error.URLError as exc:
            raise MCPError(f"MCP endpoint unavailable for {self.name}: {exc.reason}") from exc


class MCPClient:
    def __init__(self, name, config):
        self.name = name
        self.transport = StdioTransport(config, name) if config["transport"] == "stdio" else HTTPTransport(config, name)
        self.protocol = None
        self.tools = []

    def _request(self, method, params=None, version=None):
        response = self.transport.request(method, params, version)
        result = _rpc_error(response)
        if version and isinstance(self.transport, HTTPTransport):
            self.transport.protocol = version
        return result

    def connect(self):
        try:
            discovery = self._request("server/discover", version=MODERN_VERSION)
            versions = discovery.get("supportedVersions", []) if isinstance(discovery, dict) else []
            if MODERN_VERSION not in versions:
                raise MCPError("server/discover did not advertise a supported modern protocol version")
            self.protocol = MODERN_VERSION
            return
        except MCPRemoteError as exc:
            if exc.error.get("code") == -32022:
                supported = (exc.error.get("data") or {}).get("supported", [])
                if MODERN_VERSION in supported:
                    self.protocol = MODERN_VERSION
                    return
        except MCPError:
            pass
        self.protocol = LEGACY_VERSION
        try:
            initialized = self._request("initialize", {
                "protocolVersion": LEGACY_VERSION, "capabilities": {},
                "clientInfo": CLIENT_INFO,
            })
            negotiated = initialized.get("protocolVersion") if isinstance(initialized, dict) else None
            if negotiated:
                self.protocol = negotiated
            self.transport.protocol = self.protocol
            self.transport.notify("notifications/initialized")
        except Exception:
            self.close()
            raise

    def request(self, method, params=None):
        return self._request(method, params, self.protocol if self.protocol == MODERN_VERSION else None)

    def list_tools(self):
        self.tools = self._list_all("tools/list", "tools")
        return self.tools

    def _list_all(self, method, key):
        items = []
        cursor = None
        while True:
            params = {"cursor": cursor} if cursor else {}
            result = self.request(method, params) or {}
            items.extend(result.get(key, []))
            cursor = result.get("nextCursor")
            if not cursor:
                return items

    def call_tool(self, name, arguments):
        tool = next((item for item in self.tools if item.get("name") == name), None)
        if tool is None:
            self.list_tools()
            tool = next((item for item in self.tools if item.get("name") == name), None)
        if tool is None:
            raise MCPError(f"unknown tool {name!r} on provider {self.name}")
        params = {"name": name, "arguments": arguments}
        if isinstance(self.transport, HTTPTransport) and self.protocol == MODERN_VERSION:
            params["_mcp_headers"] = _tool_headers(tool.get("inputSchema", {}), arguments)
        return self.request("tools/call", params)

    def close(self):
        self.transport.close() if isinstance(self.transport, StdioTransport) else None


def _tool_headers(schema, arguments):
    properties = schema.get("properties", {}) if isinstance(schema, dict) else {}
    headers = {}
    def visit(nodes, values, prefix=()):
        if not isinstance(nodes, dict) or not isinstance(values, dict):
            return
        for name, spec in nodes.items():
            if not isinstance(spec, dict):
                continue
            path = prefix + (name,)
            if "x-mcp-header" in spec:
                header_name = spec["x-mcp-header"]
                value = values.get(name)
                if (not isinstance(header_name, str) or not HEADER_TOKEN.fullmatch(header_name)
                        or spec.get("type") not in ("string", "integer", "boolean")
                        or header_name.casefold() in {existing.casefold() for existing in headers}):
                    raise MCPError("tool schema contains an invalid x-mcp-header annotation")
                if value is not None:
                    if spec["type"] == "string" and not isinstance(value, str):
                        raise MCPError(f"header parameter {'.'.join(path)} must be a string")
                    if spec["type"] == "integer" and (not isinstance(value, int) or isinstance(value, bool) or abs(value) > 9007199254740991):
                        raise MCPError(f"header parameter {'.'.join(path)} must be a safe integer")
                    if spec["type"] == "boolean" and not isinstance(value, bool):
                        raise MCPError(f"header parameter {'.'.join(path)} must be boolean")
                    headers["Mcp-Param-" + header_name] = str(value).lower() if isinstance(value, bool) else str(value)
            elif spec.get("type") == "object" and isinstance(spec.get("properties"), dict):
                visit(spec["properties"], values.get(name), path)
    visit(properties, arguments)
    for key, value in list(headers.items()):
        if (not value.isascii() or any(ord(char) < 32 or ord(char) > 126 for char in value)
                or value != value.strip() or (value.startswith("=?base64?") and value.endswith("?="))):
            headers[key] = "=?base64?" + base64.b64encode(value.encode("utf-8")).decode("ascii") + "?="
    return headers


def run(config_path, server_name, action, tool=None, arguments=None):
    servers = load_config(config_path)
    if server_name not in servers:
        raise MCPError(f"unknown MCP server {server_name!r}; configured: {', '.join(sorted(servers)) or '(none)'}")
    client = MCPClient(server_name, servers[server_name])
    try:
        client.connect()
        if action == "tools":
            return {"server": server_name, "protocol": client.protocol, "tools": client.list_tools()}
        if action == "call":
            return {"server": server_name, "protocol": client.protocol,
                    "result": client.call_tool(tool, arguments or {})}
        if action == "resources":
            return {"server": server_name, "protocol": client.protocol,
                    "resources": client._list_all("resources/list", "resources")}
        if action == "read":
            if not tool:
                raise MCPError("read action requires a resource URI")
            return {"server": server_name, "protocol": client.protocol,
                    "result": client.request("resources/read", {"uri": tool})}
        if action == "prompts":
            return {"server": server_name, "protocol": client.protocol,
                    "prompts": client._list_all("prompts/list", "prompts")}
        if action == "prompt":
            if not tool:
                raise MCPError("prompt action requires a prompt name")
            return {"server": server_name, "protocol": client.protocol,
                    "result": client.request("prompts/get", {"name": tool, "arguments": arguments or {}})}
        raise MCPError(f"unsupported action: {action}")
    finally:
        client.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Discover and call configured MCP providers via stdio or Streamable HTTP")
    parser.add_argument("--config", required=True, help="path to a user-authored JSON server catalog")
    parser.add_argument("server", help="server name from the catalog")
    parser.add_argument("action", choices=("tools", "call", "resources", "read", "prompts", "prompt"))
    parser.add_argument("tool", nargs="?", help="tool name, resource URI, or prompt name")
    parser.add_argument("--args", default="{}", help="JSON object of tool arguments")
    args = parser.parse_args(argv)
    try:
        arguments = json.loads(args.args)
        if not isinstance(arguments, dict):
            raise MCPError("--args must decode to a JSON object")
        if args.action in ("call", "read", "prompt") and not args.tool:
            raise MCPError(f"{args.action} action requires a name or URI")
        result = run(args.config, args.server, args.action, args.tool, arguments)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (MCPError, json.JSONDecodeError) as exc:
        print(f"MCP error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

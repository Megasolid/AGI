#!/usr/bin/env python3
"""sysmap - the dashboard ASSEMBLER for the AGI system map.

One-time code, life-time use. It builds NO cards itself: it picks up every CardSpec in
state/cards/ (dropped there by producers at boot), sorts them by 'order', and renders a
self-contained memory/agi_system_map.html via cardkit.assemble(). Because styling lives
only in cardkit, changing the card design once re-skins this map on the fly.

Runs LIVE on recall so the map always reflects current persisted state - never a stale
snapshot. Cheap by design: reads small JSON cards only, no heavy checks / no network.

Usage:  python sysmap.py [output.html]     (default: memory/agi_system_map.html)
"""
import os
import sys
import datetime as dt
from pathlib import Path
import cardkit

MEM = Path(__file__).resolve().parent.parent          # <skill>/memory
DEFAULT_OUT = MEM / "agi_system_map.html"

def build(out=None):
    """Assemble the map from the current card store. Returns (abs_path, n_cards, status)."""
    out = Path(out) if out else DEFAULT_OUT
    cards = cardkit.load_cards()
    ts = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Overall status is the authoritative S0 signal (the boot card's dot).
    boot = next((c for c in cards if c.get("id") == "boot"), None)
    if boot is None:
        status = "WARN"
    else:
        status = {"ok": "OK", "warn": "WARN", "fail": "FAIL"}.get(boot.get("dot"), "WARN")

    maintenance = next((c for c in cards if c.get("id") == "maintenance"), None)
    if status != "FAIL" and maintenance and maintenance.get("dot") == "warn":
        status = "WARN"

    failing = [c.get("title", c.get("id")) for c in cards if c.get("dot") == "fail"]
    issues_html = (f'<div class="issues">{len(failing)} card(s) failing: '
                   + " \u00b7 ".join(failing) + "</div>") if failing else ""

    doc = cardkit.assemble(
        title="AGI SYSTEM MAP", ts=ts, status=status,
        cards=cards,
        issues_html=issues_html,
        foot=f"generated {ts} \u00b7 {len(cards)} cards \u00b7 {cardkit.VERSION}",
    )
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write(doc)
    return os.path.abspath(str(out)), len(cards), status

def main():
    out = sys.argv[1] if len(sys.argv) > 1 else None
    path, n, status = build(out)
    sys.stdout.write(f"{status} map -> {path} ({n} cards)\n")

if __name__ == "__main__":
    main()

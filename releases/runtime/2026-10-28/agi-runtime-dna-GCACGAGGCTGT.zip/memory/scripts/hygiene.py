#!/usr/bin/env python3
"""hygiene.py - S1 clean-core scanner: finds leftovers, duplicates and identity drift before alpha.stable.

Read-only by default: it classifies every candidate as keep / archive / delete-safe, honouring an allowlist at
state/hygiene_allow.json. `--json` prints the full report; `--apply-safe` only removes pycache and empty temp
entries (the truly reversible class) and never touches state, docs or code.
"""
import json
import pathlib
import re
import shutil

AGI = pathlib.Path(__file__).resolve().parents[2]
ALLOW = AGI / "state" / "hygiene_allow.json"


def _jload(p, default):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _size(paths):
    total = 0
    for p in paths:
        try:
            total += p.stat().st_size if p.is_file() else 0
        except OSError:
            pass
    return total


def load_allow():
    d = _jload(ALLOW, {}) or {}
    return {"keep": list(d.get("keep") or []), "safe_delete": list(d.get("safe_delete") or [])}


def _allowed(rel, patterns):
    return any(re.search(pat, rel) for pat in patterns)


def scan(root=None):
    root = pathlib.Path(root) if root else AGI
    allow = load_allow()
    out = {"candidates": [], "stats": {}}

    def add(cat, action, path, note=""):
        rel = str(path.relative_to(root)).replace("\\", "/")
        if _allowed(rel, allow["keep"]):
            return
        size = path.stat().st_size if path.is_file() else 0
        out["candidates"].append({"category": cat, "action": action, "path": rel,
                                  "size": size, "note": note})

    # pycache + temp
    for p in root.rglob("__pycache__"):
        if p.is_dir():
            add("cache", "delete-safe", p, "python cache")
    for p in (root / "temp").glob("*"):
        if p.is_file() or p.is_dir():
            add("temp", "review", p, "working file - keep only if referenced")
    # stale release artifacts / snapshots
    for p in (root / "state" / "release").glob("agi-runtime-*.zip"):
        add("release", "archive", p, "old runtime package")
    for p in (root / "state" / "transfer").glob("*"):
        add("transfer", "archive", p, "legacy transfer snapshot")
    for p in (root / "backups").glob("*.zip"):
        add("backup", "archive", p, "backup archive")
    # unregistered scripts
    reg = _jload(root / "memory" / "scripts" / "registry.json", {}) or {}
    known = set()
    for entry in (reg.get("scripts") or {}).values():
        for cmd in (entry.get("run") or []) + (entry.get("verify") or []):
            m = re.search(r"scripts/([A-Za-z0-9_]+\.py)", str(cmd))
            if m:
                known.add(m.group(1))
    for p in (root / "memory" / "scripts").glob("*.py"):
        if p.name not in known and p.name not in ("policy.py", "viz.py", "presentation.py", "genome.py",
                                                  "birth.py", "hygiene.py", "evolution.py"):
            # allow __init__/helpers that are imported rather than registered
            add("script", "review", p, "not in registry (register or retire)")
    # oversized docs
    for p in (root / "memory" / "knowledge").glob("*.md"):
        try:
            lines = len(p.read_text(encoding="utf-8", errors="ignore").splitlines())
        except OSError:
            continue
        if lines > 600:
            add("doc", "split", p, "%d lines - split research log from decisions" % lines)
    # identity drift: version mentions in live docs, hard-coded user name
    dcount = 0
    for p in list((root / "memory" / "scripts").glob("*.py")):
        try:
            dcount += len(re.findall(r"\bD\b", p.read_text(encoding="utf-8", errors="ignore")))
        except OSError:
            pass
    out["stats"]["hardcoded_D_scripts"] = dcount
    vcount = 0
    for p in (root / "core").glob("*.md"):
        vcount += len(re.findall(r"v0\.\d+", p.read_text(encoding="utf-8", errors="ignore")))
    out["stats"]["core_version_mentions"] = vcount
    # duplicate renderer families (advisory)
    renderers = [p.name for p in (root / "memory" / "scripts").glob("*.py")
                 if p.name in ("monitor.py", "dashboard_view.py", "dashv2.py", "sitegen.py")]
    out["stats"]["renderers"] = renderers
    out["stats"]["candidates"] = len(out["candidates"])
    out["stats"]["candidate_bytes"] = sum(c["size"] for c in out["candidates"])
    out["stats"]["categories"] = {}
    for c in out["candidates"]:
        out["stats"]["categories"][c["category"]] = out["stats"]["categories"].get(c["category"], 0) + 1
    return out


def apply_safe(root=None):
    root = pathlib.Path(root) if root else AGI
    removed = []
    for p in root.rglob("__pycache__"):
        if p.is_dir():
            shutil.rmtree(p, ignore_errors=True)
            removed.append(str(p.relative_to(root)))
    return {"ok": True, "removed": removed}


if __name__ == "__main__":
    import sys
    if "--apply-safe" in sys.argv:
        print(json.dumps(apply_safe(), indent=1))
    elif "--json" in sys.argv:
        print(json.dumps(scan(), indent=1))
    else:
        r = scan()
        print("HYGIENE / S1 clean-core baseline")
        for c in sorted(r["candidates"], key=lambda x: -x["size"])[:12]:
            print("  %-8s %-9s %8.1f KB  %s  %s" % (c["category"], c["action"], c["size"] / 1024,
                                                     c["path"], c["note"]))
        print("stats:", json.dumps(r["stats"], sort_keys=True))

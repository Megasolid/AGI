#!/usr/bin/env python3
"""host_adapter.py - real host-model adapter for Brain Lab benchmarks.

The lab must never fabricate benchmark data. This adapter talks to the host model only through the existing
deepseek browser bridge (`memory/scripts/agents/ds_bridge.py`, chrome-mcp daemon at 127.0.0.1:8899). It first
checks availability; when the bridge is down it reports BLOCKED with the reason instead of inventing numbers.
A canary probe (one task per family, configurable) validates the bridge end-to-end; a full suite run requires
an explicit opt-in because it sends many prompts through the user's live model session.
"""
import argparse
import datetime
import json
import pathlib
import sys
import time

AGI = pathlib.Path(__file__).resolve().parents[2]
CONFIG = AGI / "state" / "brains" / "host_adapter.json"
DEFAULT = {
    "model_id": "deepseek-browser-session", "provider": "deepseek", "kind": "remote",
    "context": 128000, "output": 8192, "tools": "none", "privacy": "remote",
    "daemon": "http://127.0.0.1:8899", "canary_tasks": 3, "max_wait_s": 120,
    "allow_full_suite": False, "note": "browser-session model; full benchmark needs allow_full_suite + --full",
}


def _jload(p, default):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def config(root=None):
    return {**DEFAULT, **(_jload((pathlib.Path(root) if root else AGI) / "state" / "brains" / "host_adapter.json", {}) or {})}


def availability(root=None):
    cfg = config(root)
    daemon = cfg["daemon"].rstrip("/")
    try:
        import urllib.request
        req = urllib.request.Request(daemon + "/call", data=b'{"tool":"list_pages","args":{}}',
                                     headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=4).read()
        daemon_ok = True
    except Exception as e:
        daemon_ok = False
        reason = "chrome-mcp daemon unavailable at %s (%s)" % (daemon, str(e)[:80])
    if daemon_ok:
        reason = "daemon reachable"
    try:
        sys.path.insert(0, str(AGI / "memory" / "scripts"))
        import agents.ds_bridge as ds_bridge  # noqa: F401
        bridge_ok = True
    except Exception as e:
        bridge_ok = False
        reason = reason + "; ds_bridge import failed: %s" % str(e)[:80]
    return {"ok": bool(daemon_ok and bridge_ok), "daemon_ok": daemon_ok, "bridge_ok": bridge_ok,
            "reason": reason, "model_id": cfg["model_id"], "daemon": daemon}


class HostAdapter:
    """Brain Lab adapter protocol: manifest + run(task) -> result dict (no fabricated fields)."""

    def __init__(self, root=None):
        self.cfg = config(root)
        self.manifest = {"id": self.cfg["model_id"], "provider": self.cfg["provider"], "kind": self.cfg["kind"],
                         "context": self.cfg["context"], "output": self.cfg["output"], "tools": self.cfg["tools"],
                         "privacy": self.cfg["privacy"], "tier": "unprofiled",
                         "render_pack": "host-browser-session"}

    def run(self, task):
        import agents.ds_bridge as ds_bridge
        prompt = ("[brain-lab probe %s] %s\nAnswer in at least 8 words, plainly." %
                  (task["id"], task.get("prompt") or "Describe the task."))
        t0 = time.time()
        r = ds_bridge.browser_chat(prompt, max_wait=self.cfg["max_wait_s"])
        text = (r.get("content") or "").strip()
        words = len(text.split())
        return {"ok": bool(text and words >= (task.get("expect") or {}).get("min_tokens", 8)),
                "tokens_in": max(1, len(prompt) // 4), "tokens_out": max(1, len(text) // 4),
                "latency_s": round(time.time() - t0, 2), "confidence": None,
                "text": text[:400]}


def probe(root=None, count=None):
    """Canary probe: a few real calls through the live host bridge; records evidence, never sets the tier."""
    rootp = pathlib.Path(root) if root else AGI
    av = availability(rootp)
    if not av["ok"]:
        return {"ok": False, "blocked": True, "reason": av["reason"], "availability": av,
                "hint": "start the chrome-mcp daemon and have a logged-in DeepSeek tab open, then re-run --probe"}
    import brainlab
    suite = brainlab.benchmark_suite()
    n = int(count or config(rootp)["canary_tasks"])
    per_family = {}
    for t in suite["tasks"]:
        per_family.setdefault(t["family"], t)
    picked = [per_family[f] for f in brainlab.FAMILIES if f in per_family][:n]
    adapter = HostAdapter(rootp)
    results = []
    for task in picked:
        try:
            r = adapter.run(task)
            results.append({"task": task["id"], **{k: r[k] for k in ("ok", "tokens_in", "tokens_out", "latency_s")}})
        except Exception as e:
            results.append({"task": task["id"], "ok": False, "error": str(e)[:160]})
    out = {"schema": "agi-brainlab/1", "kind": "host_probe", "ts": datetime.datetime.now().isoformat(timespec="seconds"),
           "model": adapter.manifest["id"], "tasks": len(results), "passed": sum(1 for r in results if r.get("ok")),
           "results": results, "provenance": "live host bridge calls; probes do not tier the model"}
    (rootp / "state" / "brains" / "benchmarks").mkdir(parents=True, exist_ok=True)
    (rootp / "state" / "brains" / "benchmarks" / ("probe-%s.json" % out["ts"].replace(":", ""))).write_text(
        json.dumps(out, indent=1), encoding="utf-8")
    try:
        import trust_log
        trust_log.append("brain.host_probe", {"model": out["model"], "tasks": out["tasks"], "passed": out["passed"]})
    except Exception:
        pass
    return {"ok": True, **out}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Brain Lab host adapter (real bridge, honest blocking)")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--tasks", type=int, default=None)
    args = ap.parse_args(argv)
    if args.probe:
        print(json.dumps(probe(count=args.tasks), indent=1))
    else:
        print(json.dumps({"config": config(), "availability": availability()}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

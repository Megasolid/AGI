#!/usr/bin/env python3
"""workspace.py - the custom-user / organization door: create a workspace during setup (P24).

Workspaces are not a fixed catalogue. During custom-user setup AGI interviews the user, classifies the
place from its knowledge (personal, office, hospital, repair shop, car wash, school, ...), proposes a
workspace record (roles, policies, task presets, capability map), and the user confirms or edits it. The
record lives in `state/workspace.json` and is loaded at boot, so AGI adapts to the place it works in.

CLI
  workspace.py init --name <name> [--kind <hint>] [--description <text>] [--yes]
  workspace.py init                      # interactive interview (needs a TTY)
  workspace.py show | verify | selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import json
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
WS = STATE / "workspace.json"
SCHEMA = "agi-workspace/1"

TEMPLATES = {
    "personal": {
        "roles": ["owner"],
        "policies": ["local-first", "no outbound by default", "ask before deleting anything"],
        "task_presets": ["daily review", "notes to knowledge", "backup install folder"],
        "capability_map": ["research", "writing", "maintenance"],
    },
    "office": {
        "roles": ["owner", "staff", "guest"],
        "policies": ["documents stay on this machine", "guest profile has no authority",
                     "approve any release or spend action"],
        "task_presets": ["meeting notes", "document draft", "inbox triage", "weekly report"],
        "capability_map": ["research", "writing", "scheduling", "records"],
    },
    "hospital": {
        "roles": ["administrator", "clinician", "reception"],
        "policies": ["patient data never leaves this machine", "no autonomous clinical decisions",
                     "two-person approval for record changes", "audit every access"],
        "task_presets": ["patient intake summary", "shift handover", "supply checklist", "audit report"],
        "capability_map": ["records", "scheduling", "forms", "inventory"],
    },
    "repair_shop": {
        "roles": ["owner", "technician", "front desk"],
        "policies": ["customer device data stays local", "quote before work", "photo evidence per job"],
        "task_presets": ["intake form", "diagnosis notes", "quote", "job photo log", "handover"],
        "capability_map": ["forms", "inventory", "scheduling", "photos"],
    },
    "car_wash": {
        "roles": ["owner", "attendant"],
        "policies": ["no customer payment data stored", "shift checklist required"],
        "task_presets": ["shift checklist", "queue board", "supply order", "daily takings"],
        "capability_map": ["checklists", "scheduling", "inventory"],
    },
    "school": {
        "roles": ["teacher", "student", "parent"],
        "policies": ["student data stays local", "no autonomous grading", "parent view is read-only"],
        "task_presets": ["lesson plan", "class notes", "progress report", "parent update"],
        "capability_map": ["writing", "records", "scheduling"],
    },
    "custom": {
        "roles": ["owner", "member"],
        "policies": ["local-first", "ask before consequential actions"],
        "task_presets": ["describe your first task"],
        "capability_map": ["research", "writing", "maintenance"],
    },
}

KEYWORDS = {
    "hospital": ("hospital", "clinic", "medical", "patient", "ward", "doctor", "nurse", "pharmacy"),
    "office": ("office", "company", "team", "startup", "agency", "firm", "department"),
    "repair_shop": ("repair", "garage", "workshop", "technician", "fix", "service center"),
    "car_wash": ("car wash", "carwash", "wash", "detailing"),
    "school": ("school", "class", "teacher", "student", "lesson", "academy"),
    "personal": ("home", "personal", "myself", "family"),
}


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _jdump(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def classify(name, description="", hint=None):
    """AGI evaluates the workspace from what the user said (this is the 'knowledge' step)."""
    if hint:
        hint = hint.strip().lower().replace(" ", "_")
        if hint in TEMPLATES:
            return hint, "user hint"
    text = f"{name} {description}".lower()
    best, score = None, 0
    for kind, words in KEYWORDS.items():
        hits = sum(1 for w in words if w in text)
        if hits > score:
            best, score = kind, hits
    if best and score:
        return best, f"classified from keywords ({best}, {score} hit)"
    return "custom", "no strong match - general workspace"


def build(kind, name, description):
    tpl = TEMPLATES.get(kind) or TEMPLATES["custom"]
    return {
        "schema": SCHEMA, "kind": kind, "name": name, "description": description,
        "roles": list(tpl["roles"]), "policies": list(tpl["policies"]),
        "task_presets": list(tpl["task_presets"]), "capability_map": list(tpl["capability_map"]),
        "created": _now(), "source": "interview", "note": "created during custom-user setup; edit freely",
    }


def init(name=None, kind=None, description="", yes=False):
    if not name:
        if not sys.stdin.isatty():
            raise ValueError("non-interactive: pass --name (and optionally --kind/--description)")
        name = input("workspace name: ").strip()
        description = input("what happens here (one line): ").strip()
        kind = input("type hint (personal/office/hospital/repair shop/car wash/school, or Enter): ").strip() or None
    kind_guess, why = classify(name, description, kind)
    proposal = build(kind_guess, name, description)
    if not yes:
        print(json.dumps({"proposed": proposal, "reason": why}, indent=1))
        if sys.stdin.isatty():
            ans = input("accept this workspace? [Y/n] ").strip().lower()
            if ans and ans not in ("y", "yes"):
                raise ValueError("workspace not accepted; rerun with --kind to choose explicitly")
        else:
            raise ValueError("non-interactive: add --yes to accept the proposed workspace")
    _jdump(WS, proposal)
    return {"ok": True, "workspace": proposal, "classification": why}


def show():
    return _jload(WS) or {}


def verify():
    ws = _jload(WS) or {}
    problems = []
    if not ws:
        return {"ok": True, "skipped": "no workspace yet (custom-user setup creates it)"}
    if ws.get("schema") != SCHEMA:
        problems.append(f"schema {ws.get('schema')!r}")
    for key in ("kind", "name", "roles", "policies", "task_presets"):
        if not ws.get(key):
            problems.append(f"missing {key}")
    if ws.get("kind") not in TEMPLATES:
        problems.append(f"unknown kind {ws.get('kind')!r}")
    return {"ok": not problems, "problems": problems, "kind": ws.get("kind"), "name": ws.get("name")}


def selftest():
    import shutil
    import tempfile

    global WS
    WS = Path(tempfile.mkdtemp(prefix="agi-workspace-test-")) / "workspace.json"
    try:
        checks = []
        r = init(name="Alborz Clinic", description="small medical clinic with 3 rooms", yes=True)
        checks.append(r["workspace"]["kind"] == "hospital")
        r2 = init(name="Quick Fix", description="phone repair shop", yes=True)
        checks.append(r2["workspace"]["kind"] == "repair_shop")
        r3 = init(name="My place", yes=True)
        checks.append(r3["workspace"]["kind"] in TEMPLATES)
        checks.append(verify()["ok"])
        if all(checks):
            print("workspace selftest: PASS")
            return 0
        print(f"workspace selftest: FAIL ({checks.count(False)})")
        return 1
    finally:
        shutil.rmtree(WS.parent, ignore_errors=True)


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]

    def arg(flag, default=None):
        return args[args.index(flag) + 1] if flag in args else default

    if cmd == "init":
        try:
            print(json.dumps(init(name=arg("--name"), kind=arg("--kind"),
                                  description=arg("--description") or "", yes="--yes" in args), indent=1))
        except ValueError as e:
            print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
            return 1
        return 0
    if cmd == "show":
        print(json.dumps(show(), indent=1))
        return 0
    if cmd == "verify":
        r = verify()
        print(json.dumps(r, indent=1))
        return 0 if r.get("ok") else 1
    if cmd == "selftest":
        return selftest()
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

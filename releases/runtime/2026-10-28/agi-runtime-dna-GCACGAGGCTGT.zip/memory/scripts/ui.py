#!/usr/bin/env python3
"""ui.py - AGI GitHub design system (rewritten from scratch, Primer-accurate).

Canvas #0d1117, surface #161b22, subtle #21262d, hairline #30363d, text #e6edf3, muted #8b949e,
accent #58a6ff, success #3fb950, attention #d29922, danger #f85149. UI font system stack (14px),
mono for data (12px), 6px radii, 8px spacing scale, underline tab nav, flat panels.
Every AGI surface renders through this module: monitor, login, docs, cards, task console.
"""
import html as _h

P = {"bg": "#0d1117", "bg2": "#010409", "surface": "#161b22", "subtle": "#21262d", "line": "#30363d",
     "line2": "#21262d", "text": "#e6edf3", "muted": "#8b949e", "dim": "#6e7681", "accent": "#58a6ff",
     "success": "#3fb950", "attention": "#d29922", "danger": "#f85149", "done": "#a371f7"}
L = {"bg": "#f6f8fa", "bg2": "#ffffff", "surface": "#ffffff", "subtle": "#f6f8fa", "line": "#d0d7de",
     "line2": "#eaeef2", "text": "#1f2328", "muted": "#656d76", "dim": "#8c959f", "accent": "#0969da",
     "success": "#1a7f37", "attention": "#9a6700", "danger": "#cf222e", "done": "#8250df"}

CSS = """
:root{--bg:#0d1117;--bg2:#010409;--surface:#161b22;--subtle:#21262d;--line:#30363d;--line2:#21262d;
--text:#e6edf3;--muted:#8b949e;--dim:#6e7681;--accent:#58a6ff;--success:#3fb950;--attention:#d29922;
--danger:#f85149;--done:#a371f7;--radius:6px;
--font:-apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans",Helvetica,Arial,sans-serif;
--mono:ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,"Liberation Mono",monospace}
html[data-theme=light]{--bg:#f6f8fa;--bg2:#ffffff;--surface:#ffffff;--subtle:#f6f8fa;--line:#d0d7de;
--line2:#eaeef2;--text:#1f2328;--muted:#656d76;--dim:#8c959f;--accent:#0969da;--success:#1a7f37;
--attention:#9a6700;--danger:#cf222e;--done:#8250df}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 var(--font)}
a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:4px}
.skip{position:absolute;left:-9999px}.skip:focus{left:16px;top:12px;background:var(--surface);
padding:6px 12px;border:1px solid var(--line);border-radius:var(--radius);z-index:100}
.gh-header{position:sticky;top:0;z-index:30;background:var(--bg);border-bottom:1px solid var(--line)}
.gh-header .inner{max-width:1280px;margin:0 auto;display:flex;align-items:center;gap:16px;padding:12px 24px}
.gh-brand{display:flex;align-items:center;gap:8px;color:var(--text);font-weight:600;font-size:16px}
.gh-brand .mark{width:22px;height:22px;border-radius:50%;background:var(--text);color:var(--bg);
display:inline-flex;align-items:center;justify-content:center;font-size:10px;font-weight:700}
.gh-tabs{display:flex;gap:4px;flex:1;flex-wrap:wrap}
.gh-tabs a{color:var(--muted);font-size:14px;padding:6px 10px;border-radius:var(--radius)}
.gh-tabs a:hover{background:var(--subtle);color:var(--text);text-decoration:none}
.gh-tabs a[aria-current]{color:var(--text);font-weight:600;box-shadow:inset 0 -2px 0 var(--danger)}
.gh-actions{display:flex;align-items:center;gap:8px}
.container{max-width:1280px;margin:0 auto;padding:0 24px 64px}
.pagehead{padding:24px 0 8px}
.pagehead h1{font-size:24px;font-weight:600;letter-spacing:-.2px;margin:0}
.pagehead .sub{color:var(--muted);font-size:14px;margin-top:6px}
h2.section{font-size:16px;font-weight:600;margin:28px 0 12px;display:flex;align-items:center;gap:8px}
h2.section .count{font-size:12px;font-weight:400;color:var(--muted);border:1px solid var(--line);
border-radius:999px;padding:1px 8px}
h2.section .actions{margin-left:auto;display:flex;gap:8px}
h3.subsection{font-size:14px;font-weight:600;margin:0 0 8px}
.btn{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);border-radius:var(--radius);
background:var(--subtle);color:var(--text);font:500 14px/20px var(--font);padding:5px 12px;cursor:pointer}
.btn:hover{background:var(--line2);border-color:var(--muted);text-decoration:none}
.btn.primary{background:#238636;border-color:rgba(240,246,252,.1);color:#fff}
.btn.primary:hover{background:#2ea043}
.btn.small{font-size:12px;padding:3px 10px}
.badge{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);border-radius:999px;
padding:1px 8px;font-size:12px;color:var(--muted);background:var(--surface)}
.badge.ok{border-color:rgba(63,185,80,.5);color:var(--success)}
.badge.warn{border-color:rgba(210,153,34,.5);color:var(--attention)}
.badge.bad{border-color:rgba(248,81,73,.5);color:var(--danger)}
.badge.info{border-color:rgba(88,166,255,.5);color:var(--accent)}
.dot{width:8px;height:8px;border-radius:50%;display:inline-block;background:var(--success)}
.dot.warn{background:var(--attention)}.dot.bad{background:var(--danger)}.dot.idle{background:var(--dim)}
.box{border:1px solid var(--line);border-radius:var(--radius);background:var(--surface)}
.box>.box-h{padding:12px 16px;border-bottom:1px solid var(--line);background:var(--subtle);
border-radius:var(--radius) var(--radius) 0 0;display:flex;align-items:center;gap:8px}
.box>.box-h .t{font-weight:600;font-size:14px}
.box>.box-b{padding:16px}
.box.flush>.box-b{padding:0}
.box-footer{padding:10px 16px;border-top:1px solid var(--line);background:var(--subtle);font-size:12px;
color:var(--muted);border-radius:0 0 var(--radius) var(--radius)}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:16px}
.stat{border:1px solid var(--line);border-radius:var(--radius);background:var(--surface);padding:16px}
.stat .l{font-size:12px;color:var(--muted);font-weight:500}
.stat .n{font-size:28px;font-weight:600;letter-spacing:-.5px;font-family:var(--mono);margin-top:2px}
.stat .u{font-size:12px;color:var(--muted)}
.table{width:100%;border-collapse:collapse;font-size:14px}
.table th{text-align:left;font-weight:600;font-size:12px;color:var(--muted);padding:8px 16px;
border-bottom:1px solid var(--line);white-space:nowrap}
.table td{padding:8px 16px;border-bottom:1px solid var(--line2);vertical-align:top}
.table tr:last-child td{border-bottom:0}
.table tr:hover td{background:var(--subtle)}
.table .num{text-align:right;font-family:var(--mono);font-size:13px}
code{font-family:var(--mono);font-size:12px;background:var(--subtle);border:1px solid var(--line2);
border-radius:4px;padding:1px 5px}
.mono{font-family:var(--mono);font-size:13px}
.muted{color:var(--muted)}.dim{color:var(--dim)}
.success{color:var(--success)}.attention{color:var(--attention)}.danger{color:var(--danger)}
.empty{padding:24px 16px;color:var(--muted);text-align:center}
.breadcrumb{font-size:13px;color:var(--muted);margin:12px 0 0}.breadcrumb a{color:var(--accent)}
.gh-footer{margin-top:32px;padding-top:16px;border-top:1px solid var(--line);color:var(--muted);
font-size:12px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.leads{display:flex;gap:8px;flex-wrap:wrap}
/* cold-boot login: one card over the dashboard, GitHub auth-screen rules */
.login-overlay{position:fixed;inset:0;z-index:80;display:flex;align-items:center;justify-content:center;
padding:24px;background:rgba(1,4,9,.72);backdrop-filter:blur(4px)}
.login-card{width:min(500px,94vw);max-height:86vh;overflow:auto;background:var(--surface);border:1px solid var(--line);
border-radius:12px;box-shadow:0 16px 48px rgba(1,4,9,.6)}
.login-card .lc-head{padding:20px 24px 16px;border-bottom:1px solid var(--line);text-align:center}
.login-card .lc-mark{width:40px;height:40px;border-radius:50%;background:var(--text);color:var(--bg);
display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;margin-bottom:10px}
.login-card h1{font-size:20px!important;margin:0;font-weight:600}
.login-card .lc-sub{color:var(--muted);font-size:13px;margin-top:6px}
.door-tabs{display:flex;gap:6px;padding:14px 24px 0}
.door-btn{flex:1;border:1px solid var(--line);background:var(--subtle);color:var(--muted);border-radius:6px;
padding:7px 8px;font:500 12.5px var(--font);cursor:pointer}
.door-btn:hover{color:var(--text)}
.door-btn[aria-selected=true]{background:rgba(88,166,255,.12);border-color:rgba(88,166,255,.5);color:var(--accent)}
.door-pane{display:none;padding:16px 24px 4px}
.door-pane.on{display:block}
.door-pane .row{display:flex;justify-content:space-between;gap:12px;padding:6px 0;font-size:13px;
border-bottom:1px solid var(--line2)}
.door-pane .row:last-child{border-bottom:0}
.door-pane .row span{color:var(--muted)}.door-pane .row em{font-style:normal;color:var(--text);text-align:right}
.door-pane .btn{margin-top:10px}
.lc-foot{padding:12px 24px 18px;border-top:1px solid var(--line);color:var(--muted);font-size:11.5px;
text-align:center}
.login-error{color:var(--danger);font-size:12px;margin-top:8px;min-height:16px}
#blobUrl,#phraseIn,#trainIn,#rotIn,#profileName{width:100%;margin-top:6px}

.rack{max-width:1280px;margin:0 auto}
.card{background:var(--surface)!important;border:1px solid var(--line)!important;
border-radius:var(--radius)!important;box-shadow:none!important}
.chip,.pill{background:var(--subtle)!important;border:1px solid var(--line)!important;color:var(--muted)!important;
border-radius:999px!important;font-size:12px!important;font-family:var(--font)!important}
input,select,textarea{background:var(--bg2)!important;color:var(--text)!important;
border:1px solid var(--line)!important;border-radius:var(--radius)!important;
font:14px var(--font)!important;padding:5px 12px!important}
input:focus,select:focus,textarea:focus{border-color:var(--accent)!important;
box-shadow:0 0 0 3px rgba(88,166,255,.3)!important;outline:none!important}
button{font-family:var(--font)!important}
h1{font-size:24px!important;font-weight:600!important}
@media(max-width:820px){.gh-tabs{display:none}.grid2,.grid3{grid-template-columns:1fr}.container{padding:0 16px 48px}}
"""

THEME = """
(function(){var s=localStorage.getItem('agi-theme');if(s)document.documentElement.dataset.theme=s;
var b=document.getElementById('theme');if(b)b.onclick=function(){var v=document.documentElement.dataset.theme==='light'?'light':'light';
if(document.documentElement.dataset.theme==='light')v='dark';document.documentElement.dataset.theme=v;
localStorage.setItem('agi-theme',v);};})();
"""


THEME_JS = THEME  # backwards-compatible alias used by dashboard_view
BRIDGE_CSS = ""  # legacy bridge no longer needed: GitHub tokens are global


def e(v):
    return _h.escape(str(v if v is not None else ""))


esc = e  # backwards-compatible alias used by sitegen/taskcard/docs


esc = e  # backwards-compatible alias used by sitegen/taskcard/docs


def dot(state="ok"):
    return "<span class='dot %s'></span>" % e(state)


def header(brand="AGI", tabs=None, actions="", active=""):
    tabs = tabs or []
    t = "".join("<a href='%s'%s>%s</a>" % (e(h), " aria-current='page'" if k == active else "", e(l))
                for k, l, h in tabs)
    return ("<header class='gh-header'><div class='inner'><a class='gh-brand' href='/'>"
            "<span class='mark'>AGI</span>%s</a><nav class='gh-tabs' aria-label='Primary'>%s</nav>"
            "<div class='gh-actions'>%s<button class='btn small' id='theme' title='Toggle theme'>Theme</button>"
            "</div></div></header>" % (e(brand), t, actions))


def page(title, body, tabs=None, actions="", active="", extra_css="", scripts="", brand="AGI"):
    return ("<!doctype html><html lang='en' data-theme='dark'><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1'>"
            "<title>%s</title><style>%s%s</style></head><body><a class='skip' href='#main'>Skip to content</a>"
            "%s<main id='main' class='container'>%s</main>"
            "<script>%s</script><script>%s</script></body></html>"
            % (e(title), CSS, extra_css, header(brand, tabs, actions, active), body, THEME, scripts))


def pagehead(title, sub="", actions=""):
    a = ("<div class='leads' style='margin-top:12px'>%s</div>" % actions) if actions else ""
    return ("<div class='pagehead'><h1>%s</h1>%s</div>%s"
            % (e(title), ("<div class='sub'>%s</div>" % e(sub)) if sub else "", a))


def section(title, body="", count=None, actions=""):
    c = ("<span class='count'>%s</span>" % e(count)) if count is not None else ""
    a = ("<span class='actions'>%s</span>" % actions) if actions else ""
    return "<h2 class='section'>%s%s%s</h2>%s" % (e(title), c, a, body)


def box(title, body, footer="", flush=False, actions=""):
    h = ("<div class='box-h'><span class='t'>%s</span>%s</div>" % (e(title), actions)) if title else ""
    f = ("<div class='box-footer'>%s</div>" % footer) if footer else ""
    return "<div class='box%s'>%s<div class='box-b'>%s</div>%s</div>" % (" flush" if flush else "", h, body, f)


def stat(label, value, unit="", hint=""):
    return ("<div class='stat'><div class='l'>%s</div><div class='n'>%s <span class='u'>%s</span></div>"
            "<div class='u'>%s</div></div>" % (e(label), e(value), e(unit), e(hint)))


def badge(text, kind="", dotstate=None):
    d = dot(dotstate) if dotstate else ""
    return "<span class='badge %s'>%s%s</span>" % (e(kind), d, e(text))


def table(headers, rows):
    th = "".join("<th>%s</th>" % e(h) for h in headers)
    body = []
    for row in rows:
        body.append("<tr>" + "".join("<td>%s</td>" % c for c in row) + "</tr>")
    return "<table class='table'><thead><tr>%s</tr></thead><tbody>%s</tbody></table>" % (th, "".join(body))


def footer(left="", right=""):
    return "<div class='gh-footer'><span>%s</span><span>%s</span></div>" % (left, right)

# accessibility: honour reduced-motion on every surface (S5 attention gate)
CSS = globals().get("CSS", "") + """
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration: .001ms !important; animation-iteration-count: 1 !important;
    transition-duration: .001ms !important; scroll-behavior: auto !important; }
}
"""

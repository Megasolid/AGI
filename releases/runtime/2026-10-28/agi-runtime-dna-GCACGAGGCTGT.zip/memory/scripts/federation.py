#!/usr/bin/env python3
"""federation.py - Trust Layer P6: a real relay, verified fetch, gossip and Sybil weighting.

The mirror format is already cross-user (a stranger verifies it with the same commands). This
module makes the exchange operational:

  serve    a loopback HTTP relay for a mirror directory (read-only, no writes, no auth surface)
  fetch    download a peer's manifest + signatures + pills into a scratch dir, VERIFY it, then
           import only what proves itself; remember the peer's head (rollback / divergence)
  gossip   fetch every known peer, compare heads: same size + different root = divergence alert,
           smaller size than last seen = rollback alert
  weight   a transparent Sybil-heuristic weight for an endorsement: prior endorsed work and
           verified evidence raise it; identity alone earns nothing

Honest scope: this is federation between members who can already reach each other's relay. It is
not a global network, and the weight is a heuristic (documented, inspectable), not proof of
personhood.

CLI
  federation.py serve [--port 8770] [--dir <mirror dir>] [--bind 127.0.0.1]
  federation.py fetch <url> [--expect-key <device key id>]
  federation.py peers
  federation.py gossip
  federation.py weight --contributor <key id> [--evidence N]
  federation.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import json
import shutil
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
PUB = STATE / "public"
MIRROR = PUB / "mirror"
PEERS = PUB / "peers.json"
CONTRIBUTORS = PUB / "contributors.json"

sys.path.insert(0, str(MEM / "scripts"))
import public  # noqa: E402
import trust_log  # noqa: E402

PEERS_SCHEMA = "agi-federation-peers/1"
LOGGING = True


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


# ---------------------------------------------------------------- relay
class _Handler(SimpleHTTPRequestHandler):
    def log_message(self, *a):  # keep the relay quiet
        return

    def do_GET(self):
        if self.path in ("/", "/head"):
            man = _jload(Path(self.directory) / "manifest.json") or {}
            head = man.get("head") or {}
            body = json.dumps({"schema": "agi-relay/1", "mirror": bool(man),
                               "pills": len(man.get("pills") or []),
                               "head_size": head.get("tree_size"),
                               "head_root": head.get("root_hex"),
                               "exporter": (man.get("exporter") or {}).get("key_id")}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        return super().do_GET()


def serve(port=8770, directory=None, bind="127.0.0.1", block=True, ready_event=None):
    directory = Path(directory or MIRROR)
    handler = lambda *a, **kw: _Handler(*a, directory=str(directory), **kw)  # noqa: E731
    httpd = ThreadingHTTPServer((bind, int(port)), handler)
    if ready_event is not None:
        ready_event.set()
    if not block:
        return httpd
    print(f"relay serving {directory} on http://{bind}:{port}/ (read-only)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
    return httpd


# ---------------------------------------------------------------- fetch
def _get(url, timeout=15):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.read()


def fetch(url, expect_key=None, dest=None):
    """Download a peer's mirror, verify it, import only what proves itself."""
    url = url.rstrip("/")
    scratch = Path(dest) if dest else Path(tempfile.mkdtemp(prefix="agi-peer-"))
    try:
        man_bytes = _get(url + "/manifest.json")
        sig_bytes = _get(url + "/manifest.json.sig")
        (scratch / "manifest.json").write_bytes(man_bytes)
        (scratch / "manifest.json.sig").write_bytes(sig_bytes)
        man = json.loads(man_bytes)
        (scratch / "pills").mkdir(exist_ok=True)
        for entry in man.get("pills") or []:
            rel = str(entry.get("envelope_file") or "")
            if not rel:
                continue
            data = _get(f"{url}/{rel}")
            target = scratch / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        v = public.verify_mirror(scratch, expect_key=expect_key)
        result = {"url": url, "ok": v.get("ok"), "problems": v.get("problems"),
                  "pills": v.get("pills"), "head_size": v.get("head_size"),
                  "head_root": v.get("head_root"), "exporter": v.get("exporter")}
        _record_peer(url, v)
        if v.get("ok"):
            imp = public.import_mirror(scratch, expect_key=expect_key)
            result["imported"] = imp.get("imported")
            result["import_problems"] = imp.get("problems")
            if LOGGING and (imp.get("imported") or 0) > 0:
                trust_log.append("federation-fetch", {
                    "url": url, "pills": imp.get("imported"),
                    "head_root": v.get("head_root"), "head_size": v.get("head_size"),
                    "exporter": v.get("exporter")})
        return result
    finally:
        if not dest:
            shutil.rmtree(scratch, ignore_errors=True)


def _record_peer(url, verification):
    data = _jload(PEERS, {"schema": PEERS_SCHEMA, "peers": {}}) or {"schema": PEERS_SCHEMA, "peers": {}}
    prev = (data["peers"].get(url) or {})
    alerts = []
    new_size = verification.get("head_size")
    new_root = verification.get("head_root")
    if prev.get("head_size") is not None and new_size is not None:
        if int(new_size) == int(prev["head_size"]) and prev.get("head_root") != new_root:
            alerts.append("DIVERGENCE: same tree size, different root")
        if int(new_size) < int(prev["head_size"]):
            alerts.append("ROLLBACK: peer head shrank")
    data["peers"][url] = {
        "exporter": verification.get("exporter"),
        "head_size": new_size,
        "head_root": new_root,
        "pills": verification.get("pills"),
        "last_fetch": _now(),
        "last_ok": bool(verification.get("ok")),
        "alerts": alerts,
        "previous": {"head_size": prev.get("head_size"), "head_root": prev.get("head_root"),
                     "last_fetch": prev.get("last_fetch")},
    }
    _jdump(PEERS, data)
    return alerts


def peers():
    return _jload(PEERS, {"schema": PEERS_SCHEMA, "peers": {}})


def gossip():
    data = peers()
    report = []
    for url in sorted((data.get("peers") or {})):
        row = fetch(url)
        entry = (peers().get("peers") or {}).get(url) or {}
        report.append({"url": url, "ok": row.get("ok"), "head_size": row.get("head_size"),
                       "head_root": row.get("head_root"), "alerts": entry.get("alerts") or [],
                       "imported": row.get("imported")})
    return {"peers": len(report), "report": report}


# ---------------------------------------------------------------- sybil weighting
def weight(contributor_key, evidence=0):
    """Transparent heuristic: identity alone earns nothing; attested work earns weight.

    0.20 baseline (addressable) + 0.20 per previously ENDORSED contribution (capped 0.4)
    + 0.10 per verified evidence item in the current claim (capped 0.3), max 1.0.
    Recorded in the endorsement so the number is always explainable.
    """
    reps = ((_jload(CONTRIBUTORS, {}) or {}).get("contributors") or {})
    rep = reps.get(contributor_key) or {}
    endorsed = int(rep.get("endorsed") or 0)
    w = 0.20 + min(0.40, 0.20 * endorsed) + min(0.30, 0.10 * int(evidence))
    return {"contributor": contributor_key, "prior_endorsed": endorsed,
            "evidence_items": int(evidence), "weight": round(min(1.0, w), 2),
            "formula": "0.20 + min(0.40, 0.20*prior_endorsed) + min(0.30, 0.10*evidence)"}


# ---------------------------------------------------------------- CLI
def _arg(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def cmd_serve(args):
    serve(port=int(_arg(args, "--port", 8770)), directory=_arg(args, "--dir"),
          bind=_arg(args, "--bind", "127.0.0.1"))
    return 0


def cmd_fetch(args):
    if not args:
        print("usage: federation.py fetch <url> [--expect-key <device key id>]")
        return 2
    r = fetch(args[0], expect_key=_arg(args, "--expect-key"))
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_peers(args):
    print(json.dumps(peers(), indent=1))
    return 0


def cmd_gossip(args):
    r = gossip()
    print(json.dumps(r, indent=1))
    bad = [x for x in r["report"] if not x["ok"] or x["alerts"]]
    return 0 if not bad else 1


def cmd_weight(args):
    key = _arg(args, "--contributor")
    if not key:
        print("usage: federation.py weight --contributor <key id> [--evidence N]")
        return 2
    print(json.dumps(weight(key, int(_arg(args, "--evidence", 0))), indent=1))
    return 0


def selftest():
    import hashlib

    global PUB, MIRROR, PEERS, CONTRIBUTORS, LOGGING, STATE

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    saved = (PUB, MIRROR, PEERS, CONTRIBUTORS, LOGGING, STATE,
             public.STATE, public.PUB, public.MIRROR, public.IMPORTED, public.CONTRIB,
             public.MERGED, public.CONTRIBUTORS, public.PILLS, public.LOGGING, public.AGI, public.MEM,
             public.crypto.KEYS, trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR,
             public.rootmod.KEYS, public.rootmod.ROOT_RECORD, public.rootmod.ROOT_DIR,
             public.rootmod.GENESIS, public.rootmod.LOGGING)
    tmp = Path(tempfile.mkdtemp(prefix="agi-federation-test-"))
    httpd = None
    try:
        LOGGING = False
        public.LOGGING = False
        public.rootmod.LOGGING = False
        AGI = tmp
        STATE = tmp / "state"
        PUB = STATE / "public"
        MIRROR = PUB / "mirror"
        PEERS = PUB / "peers.json"
        CONTRIBUTORS = PUB / "contributors.json"
        public.AGI = tmp
        public.MEM = tmp / "memory"
        public.STATE = STATE
        public.PUB = PUB
        public.MIRROR = MIRROR
        public.IMPORTED = PUB / "imported"
        public.CONTRIB = STATE / "contributions"
        public.MERGED = PUB / "merged.json"
        public.CONTRIBUTORS = CONTRIBUTORS
        public.PILLS = STATE / "pills"
        public.crypto.KEYS = STATE / "keys"
        public.crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        trust_log.LOG = STATE / "trust_log"
        trust_log.EVENTS = trust_log.LOG / "events.jsonl"
        trust_log.HEADS = trust_log.LOG / "heads"
        trust_log.MONITOR = trust_log.LOG / "monitor.json"
        public.rootmod.KEYS = STATE / "keys"
        public.rootmod.ROOT_RECORD = public.rootmod.KEYS / "root.json"
        public.rootmod.ROOT_DIR = STATE / "root"
        public.rootmod.GENESIS = public.rootmod.ROOT_DIR / "genesis.json"
        public.rootmod.ceremony_init(force=True)
        public._jdump(STATE / "passport.json", {"schema": "agi-passport/1", "passport_id": "pass-1",
                                                "member": "D", "user_genome_root": "ab" * 32,
                                                "genome_epoch": 4})
        for pid in ("pill-a", "pill-b"):
            body = {"pill_id": pid, "kind": "task", "status": "consumed",
                    "lifecycle": {"stored": True, "indexed": True, "readback": True},
                    "consumed_at": public._now()}
            public._jdump(public.PILLS / f"{pid}.envelope.json",
                          {"schema": "agi-pill-envelope/1", "body": body,
                           "signature": public.crypto.sign_bytes(public.crypto.canonical_json(body))})
            trust_log.append("pill-consumed", {"pill_id": pid, "envelope": f"{pid}.envelope.json"})
        trust_log.sign_head()
        exp = public.export()
        check("local mirror exported", exp["ok"] and exp["pills"] == 2)

        # start the relay on an ephemeral port and fetch through it
        httpd = serve(port=0, directory=MIRROR, block=False)
        port = httpd.server_address[1]
        t = threading.Thread(target=httpd.serve_forever, daemon=True)
        t.start()
        base = f"http://127.0.0.1:{port}"
        time.sleep(0.2)
        r = fetch(base)
        check("fetch through the relay verifies", r["ok"], str(r.get("problems")))
        check("fetch imported the peer's pills", r.get("imported") == 2, str(r.get("imported")))
        check("peer recorded with its head", peers()["peers"][base]["head_size"] == 2)
        check("second fetch is idempotent", fetch(base).get("imported") == 0)

        # tampered peer: serve a copy with a modified envelope -> fetch must refuse
        tdir = tmp / "tampered-mirror"
        shutil.copytree(MIRROR, tdir)
        envp = tdir / "pills" / "pill-a.envelope.json"
        env = _jload(envp)
        env["body"]["status"] = "forged"
        _jdump(envp, env)
        httpd2 = serve(port=0, directory=tdir, block=False)
        threading.Thread(target=httpd2.serve_forever, daemon=True).start()
        base2 = f"http://127.0.0.1:{httpd2.server_address[1]}"
        r2 = fetch(base2)
        check("tampered peer refused", not r2["ok"] and r2.get("imported") in (None, 0), str(r2.get("problems")))
        httpd2.shutdown()

        # divergence detection on a deliberately rewritten head
        data = peers()
        data["peers"][base]["head_size"] = 2
        data["peers"][base]["head_root"] = "ff" * 32
        _jdump(PEERS, data)
        alerts = _record_peer(base, {"ok": True, "head_size": 2, "head_root": "ee" * 32,
                                     "pills": 2, "exporter": "x"})
        check("same-size different-root divergence flagged",
              any("DIVERGENCE" in a for a in alerts), str(alerts))
        alerts2 = _record_peer(base, {"ok": True, "head_size": 1, "head_root": "e" * 64,
                                      "pills": 1, "exporter": "x"})
        check("shrinking head flagged as rollback", any("ROLLBACK" in a for a in alerts2), str(alerts2))

        # sybil weighting: identity alone is weak, attested work raises weight
        w0 = weight("unknown-key", 0)["weight"]
        w1 = weight("unknown-key", 3)["weight"]
        check("weight is low without evidence and rises with it", w0 < 0.3 and w1 > w0, f"{w0} {w1}")
        check("weight is capped at 1.0", weight("k", 99)["weight"] <= 1.0)
    finally:
        try:
            if httpd is not None:
                httpd.shutdown()
        except Exception:
            pass
        (PUB, MIRROR, PEERS, CONTRIBUTORS, LOGGING, STATE,
         public.STATE, public.PUB, public.MIRROR, public.IMPORTED, public.CONTRIB,
         public.MERGED, public.CONTRIBUTORS, public.PILLS, public.LOGGING, public.AGI, public.MEM,
         public.crypto.KEYS, trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR,
         public.rootmod.KEYS, public.rootmod.ROOT_RECORD, public.rootmod.ROOT_DIR,
         public.rootmod.GENESIS, public.rootmod.LOGGING) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("federation selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"serve": cmd_serve, "fetch": cmd_fetch, "peers": cmd_peers, "gossip": cmd_gossip,
             "weight": cmd_weight, "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

#!/usr/bin/env python3
"""viz.py - zero-dependency 2D (SVG) + 2.5D (CSS) visualization primitives for AGI dashboards.

Every chart is a pure function over real numbers, with an aria-label; the presentation genome in
presentation.py decides which modules a generation shows and which primitives they use.
"""
import math


def _esc(v):
    return (str(v if v is not None else "").replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def spark(values, width=140, height=36, color="var(--accent, #58a6ff)"):
    vals = [float(v or 0) for v in (values or [])] or [0, 0]
    if len(vals) < 2:
        vals = [0, 0]
    lo, hi = min(vals), max(vals)
    rng = (hi - lo) or 1
    pts = [(2 + (width - 4) * i / (len(vals) - 1), height - 3 - (height - 6) * (v - lo) / rng)
           for i, v in enumerate(vals)]
    return ("<svg class='viz' width='%d' height='%d' viewBox='0 0 %d %d' role='img' "
            "aria-label='trend: %s'><polyline points='%s' fill='none' stroke='%s' stroke-width='1.6'/>"
            "</svg>" % (width, height, width, height, _esc(", ".join("%g" % v for v in vals[-8:])),
                        " ".join("%.1f,%.1f" % p for p in pts), color))


def area(values, width=320, height=110):
    vals = [float(v or 0) for v in (values or [])] or [0, 0]
    if len(vals) < 2:
        vals = [0, 0]
    mx = max(vals) or 1
    pts = [(3 + (width - 6) * i / (len(vals) - 1), height - 12 - (height - 20) * v / mx)
           for i, v in enumerate(vals)]
    line = " ".join("%.1f,%.1f" % p for p in pts)
    poly = line + " %.1f,%.1f 3,%.1f" % (width - 3, height - 12, height - 12)
    return ("<svg class='viz' width='100%%' viewBox='0 0 %d %d' role='img' aria-label='time series'>"
            "<polygon points='%s' fill='rgba(88,166,255,.13)'/>"
            "<polyline points='%s' fill='none' stroke='var(--accent,#58a6ff)' stroke-width='2'/>"
            "<line x1='3' y1='%d' x2='%d' y2='%d' stroke='var(--line,#30363d)'/>"
            "<text x='3' y='%d' fill='var(--muted,#8b949e)' font-size='10'>max %g</text></svg>"
            % (width, height, poly, line, height - 12, width - 3, height - 12, 10, mx))


def bars(values, labels=None, width=380, height=120):
    vals = [float(v or 0) for v in (values or [])] or [0]
    n = len(vals)
    mx = max(vals) or 1
    gap = 4
    bw = (width - gap * (n - 1)) / n
    out = ["<svg class='viz' width='100%%' viewBox='0 0 %d %d' role='img' aria-label='bar chart'>" % (width, height + 14)]
    for i, v in enumerate(vals):
        bh = max(1.5, (height - 16) * v / mx)
        x = i * (bw + gap)
        out.append("<rect x='%.1f' y='%.1f' width='%.1f' height='%.1f' rx='2' fill='rgba(88,166,255,.55)'/>"
                   % (x, height - bh, max(1, bw), bh))
        if labels and i < len(labels):
            out.append("<text x='%.1f' y='%d' fill='var(--muted,#8b949e)' font-size='9' text-anchor='middle'>%s</text>"
                       % (x + bw / 2, height + 12, _esc(labels[i])))
    out.append("</svg>")
    return "".join(out)


def gauge(value, maximum=1.0, label="", unit="", width=170, height=100):
    """Semicircle gauge with a needle (real data only)."""
    v = max(0.0, float(value or 0))
    mx = float(maximum or 1) or 1
    pct = max(0.0, min(1.0, v / mx))
    cx, cy, r = width / 2, height - 12, width / 2 - 18
    a0, a1 = math.pi, 0.0
    ang = a0 + (a1 - a0) * pct
    def pt(a, rr):
        return (cx + rr * math.cos(a), cy - rr * math.sin(a))
    x0, y0 = pt(a0, r)
    x1, y1 = pt(a1, r)
    nx, ny = pt(ang, r - 4)
    col = "var(--ok,#3fb950)" if pct >= .8 else ("var(--warn,#d29922)" if pct >= .5 else "var(--danger,#f85149)")
    return ("<svg class='viz' width='%d' height='%d' viewBox='0 0 %d %d' role='img' aria-label='%s %s'>"
            "<path d='M %.1f %.1f A %d %d 0 0 1 %.1f %.1f' fill='none' stroke='var(--line,#30363d)' stroke-width='8'/>"
            "<path d='M %.1f %.1f A %d %d 0 0 1 %.1f %.1f' fill='none' stroke='%s' stroke-width='8' "
            "stroke-linecap='round'/>"
            "<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='var(--text,#e6edf3)' stroke-width='2'/>"
            "<circle cx='%.1f' cy='%.1f' r='3' fill='var(--text,#e6edf3)'/>"
            "<text x='%.1f' y='%.1f' text-anchor='middle' fill='var(--text,#e6edf3)' font-size='18' "
            "font-family='ui-monospace'>%s</text>"
            "<text x='%.1f' y='%d' text-anchor='middle' fill='var(--muted,#8b949e)' font-size='10'>%s</text></svg>"
            % (width, height, width, height, _esc(label), _esc(unit), x0, y0, r, r, x1, y1,
               x0, y0, r, r, *pt(ang, r), col, cx, cy, nx, ny, cx, cy,
               cx, cy - 4, _esc("%g%s" % (round(v, 2), (" " + unit) if unit else "")), cx, height - 1, _esc(label)))


def donut(pct, label="", size=120):
    p = max(0.0, min(1.0, float(pct or 0)))
    r, c = 40, 60
    circ = 2 * math.pi * r
    return ("<svg class='viz' width='%d' height='%d' viewBox='0 0 120 120' role='img' aria-label='%s %d%%'>"
            "<circle cx='60' cy='60' r='%d' fill='none' stroke='var(--line,#30363d)' stroke-width='10'/>"
            "<circle cx='60' cy='60' r='%d' fill='none' stroke='var(--accent,#58a6ff)' stroke-width='10' "
            "stroke-dasharray='%.1f %.1f' transform='rotate(-90 60 60)'/>"
            "<text x='60' y='64' text-anchor='middle' fill='var(--text,#e6edf3)' font-size='16' "
            "font-family='ui-monospace'>%d%%</text>"
            "<text x='60' y='110' text-anchor='middle' fill='var(--muted,#8b949e)' font-size='10'>%s</text></svg>"
            % (size, size, _esc(label), round(p * 100), r, r, circ * p, circ * (1 - p) + .01, round(p * 100), _esc(label)))


def hbars(rows, width=340):
    """rows: [(label, value, max)] - length encoding, the most accurate comparison (Cleveland-McGill)."""
    out = ["<div class='hbars'>"]
    for label, v, mx in rows:
        pct = max(0.0, min(100.0, 100.0 * float(v) / (float(mx) or 1)))
        out.append("<div class='hb'><span class='hbl'>%s</span><span class='hbt'><i style='width:%.1f%%'></i></span>"
                   "<span class='hbv'>%s</span></div>" % (_esc(label), pct, _esc(v)))
    out.append("</div>")
    return "".join(out)


def network(nodes, edges, width=420, height=220):
    """Deterministic circle layout; node size by value; edges as lines (real topology, no decoration)."""
    n = max(1, len(nodes))
    pos = {}
    for i, nd in enumerate(nodes):
        a = 2 * math.pi * i / n - math.pi / 2
        pos[nd["id"]] = (width / 2 + (width / 2 - 40) * math.cos(a) * (0.7 + 0.3 * (i % 2)),
                         height / 2 + (height / 2 - 30) * math.sin(a))
    out = ["<svg class='viz' width='100%%' viewBox='0 0 %d %d' role='img' aria-label='subsystem graph'>" % (width, height)]
    for a, b in edges:
        if a in pos and b in pos:
            out.append("<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='var(--line,#30363d)'/>"
                       % (pos[a] + pos[b]))
    for nd in nodes:
        x, y = pos[nd["id"]]
        rad = 6 + min(10, math.sqrt(abs(float(nd.get("value") or 1))) * 1.6)
        out.append("<circle cx='%.1f' cy='%.1f' r='%.1f' fill='rgba(88,166,255,.20)' "
                   "stroke='var(--accent,#58a6ff)'/>" % (x, y, rad))
        out.append("<text x='%.1f' y='%.1f' fill='var(--muted,#8b949e)' font-size='9' text-anchor='middle'>%s</text>"
                   % (x, y + rad + 11, _esc(nd.get("label", nd["id"]))))
    out.append("</svg>")
    return "".join(out)


def bars3d(values, labels=None):
    """2.5D bars via CSS transforms (no WebGL): depth is decorative, the data is still encoded by height."""
    vals = [float(v or 0) for v in (values or [])] or [0]
    mx = max(vals) or 1
    n = len(vals)
    out = ["<div class='b3d' role='img' aria-label='3D-style bars'>"]
    for i, v in enumerate(vals):
        h = max(6.0, 90.0 * v / mx)
        out.append("<div class='b3d-col'><div class='b3d-bar' style='height:%.0fpx' title='%s'><i></i><b></b>"
                   "</div><span>%s</span></div>"
                   % (h, _esc(v), _esc(labels[i] if labels and i < len(labels) else v)))
    out.append("</div>")
    return "".join(out)

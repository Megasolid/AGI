#!/usr/bin/env python3
"""family.py - S2: passport v2 projection + signed family registry (alpha.stable).

Passport types: master (gold), admin (silver), official (family default), custom-org (nickname), rough (red,
no official bundle -> stays in its generation, never migrates, strictly supervised).
Status: alive / sleeping / dead. Counts: alive + sleeping total, dead separate; Master/Admin alive counts.
The public registry (`state/family/registry.json`) contains allowlisted public fields only, is signed with the
device key (ML-DSA-65), and is verified against its signature; no keys, sealed material, seeds or hot data.
"""
import argparse
import datetime
import json
import pathlib
import sys

AGI = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = "agi-family/1"
OFFICIAL_CLASSES = ("master", "official", "custom", "org")
PUBLIC_FIELDS = ["passport_id", "member", "nickname", "type", "status", "generation", "issued", "last_seen",
                 "contribution"]
SEATS = {"master": 8, "admin": 16, "council": 32, "hall": 64}


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def _paths(root):
    root = pathlib.Path(root) if root else AGI
    return {"root": root, "state": root / "state", "registry": root / "state" / "family" / "registry.json",
            "sig": root / "state" / "family" / "registry.sig",
            "admins": root / "state" / "family" / "admins.json"}


def _birth(root):
    return _jload(_paths(root)["state"] / "genesis" / "birth.json", {}) or {}


def _passport(root):
    return _jload(_paths(root)["state"] / "passport.json", {}) or {}


def active_bundle(root=None):
    root = pathlib.Path(root) if root else AGI
    act = _jload(root / "state" / "bundles" / "active.json", {}) or {}
    name = act.get("active")
    if not name:
        return {"name": None, "class": None, "signed": False, "rough": True}
    manifest = _jload(root / "state" / "bundles" / (name + ".json"), {}) or {}
    cls = manifest.get("class")
    signed = (root / "state" / "bundles" / (name + ".json.sig")).is_file()
    return {"name": name, "class": cls, "signed": signed, "rough": cls not in OFFICIAL_CLASSES}


def admins(root=None):
    data = _jload(_paths(root)["admins"], {"members": []}) or {"members": []}
    data.setdefault("members", [])
    data.setdefault("invites", [])
    return data


def _save_admins(data, root=None):
    _jdump(_paths(root)["admins"], data)


def _phrase_hash(phrase):
    import hashlib
    return hashlib.sha256(b"agi/family/phrase/v1:" + phrase.strip().encode()).hexdigest()


def seat_usage(root=None):
    psp = _passport(root)
    data = admins(root)
    pending = len([i for i in data.get("invites", []) if not i.get("redeemed")])
    return {"max": SEATS,
            "used": {"master": 1 if psp.get("bundle_class") == "master" else 0,
                     "admin": len(data.get("members", [])) + pending, "council": 0, "hall": 0},
            "pending_invites": pending}


def promote(name, root=None):
    """Master promotes a human to Admin by handing them a one-time phrase (D's rule). Phrase is shown once."""
    import secrets
    psp = _passport(root)
    if psp.get("bundle_class") != "master":
        return {"ok": False, "error": "only a Master can promote to Admin"}
    name = str(name or "").strip()
    if not name:
        return {"ok": False, "error": "member name required"}
    data = admins(root)
    if name in data["members"] or any(i.get("name") == name and not i.get("redeemed") for i in data["invites"]):
        return {"ok": False, "error": "%r is already an admin or has a pending invite" % name}
    seat = seat_usage(root)
    if seat["used"]["admin"] >= SEATS["admin"]:
        return {"ok": False, "error": "admin seats full (16)"}
    phrase = "agi-" + "-".join(secrets.token_hex(3) for _ in range(3))
    data["invites"].append({"name": name, "phrase_sha256": _phrase_hash(phrase),
                            "issued": datetime.datetime.now().isoformat(timespec="seconds"),
                            "by": "Master", "redeemed": False})
    _save_admins(data, root)
    try:
        sys.path.insert(0, str(pathlib.Path(root or AGI) / "memory" / "scripts"))
        import trust_log
        trust_log.append("family.promote", {"member": name, "one_time_phrase": True, "by": "Master"})
    except Exception:
        pass
    return {"ok": True, "name": name, "phrase": phrase, "note": "hand this phrase to the human once; only its hash is stored",
            "seats": seat_usage(root)}


def redeem_admin(name, phrase, root=None):
    data = admins(root)
    h = _phrase_hash(phrase or "")
    for inv in data["invites"]:
        if inv.get("name") == name and not inv.get("redeemed") and inv.get("phrase_sha256") == h:
            inv["redeemed"] = True
            inv["redeemed_at"] = datetime.datetime.now().isoformat(timespec="seconds")
            data["members"].append(name)
            _save_admins(data, root)
            try:
                sys.path.insert(0, str(pathlib.Path(root or AGI) / "memory" / "scripts"))
                import trust_log
                trust_log.append("family.admin_redeem", {"member": name})
            except Exception:
                pass
            return {"ok": True, "member": name, "type": "admin", "seats": seat_usage(root)}
    return {"ok": False, "error": "no matching unredeemed phrase"}


def rough_mode(root=None):
    """Cold-boot branding for a machine with no official bundle: RED AGI + Rough, never a 'normal' decoy."""
    root = pathlib.Path(root) if root else AGI
    bundle = active_bundle(root)
    psp = _passport(root)
    rough = bool(bundle.get("rough") or (not psp))
    return {"rough": rough, "label": "Rough", "brand": ("RED AGI" if rough else "AGI"),
            "banner": ("<div id='agi-rough-banner' style='position:sticky;top:0;z-index:60;background:#3d0d10;"
                       "color:#f85149;border-bottom:1px solid #f85149;padding:8px 14px;font:600 13px/1.4 "
                       "-apple-system,Segoe UI,sans-serif;text-align:center'>ROUGH &middot; no official bundle detected "
                       "&middot; stays in this generation &middot; never migrates &middot; strictly supervised</div>"
                       if rough else ""),
            "css": ("<style>:root{--accent:#f85149;--accent2:#f85149}.gh-brand .mark,"
                    "header .mark{border-color:#f85149;color:#f85149}</style>" if rough else "")}


def type_of(member, root=None):
    psp = _passport(root)
    bundle = active_bundle(root)
    if not psp:
        return "rough"
    if psp.get("bundle_class") == "master":
        return "master"
    if member in (admins(root).get("members") or []):
        return "admin"
    if psp.get("bundle_class") == "official" or bundle.get("class") == "official":
        return "official"
    if psp.get("bundle_class") in ("custom", "org") or bundle.get("class") in ("custom", "org"):
        return "custom-org"
    return "rough"


def passport_projection(root=None):
    root = pathlib.Path(root) if root else AGI
    psp = _passport(root)
    birth = _birth(root)
    bundle = active_bundle(root)
    member = psp.get("member") or "unknown"
    ptype = type_of(member, root)
    gen = {
        "gen_id": birth.get("gen_id") or (psp.get("generation") or {}).get("gen_id"),
        "genome8": birth.get("genome8"),
        "natal_interest": (birth.get("natal_interest") or {}).get("domain"),
        "kind": birth.get("kind"),
    }
    proj = {
        "passport_id": psp.get("passport_id"),
        "member": member,
        "nickname": member,
        "type": ptype,
        "status": "alive",
        "generation": gen,
        "issued": psp.get("issued"),
        "last_seen": datetime.datetime.now().isoformat(timespec="seconds"),
        "contribution": {"xp": 0, "rank": []},
    }
    return {k: proj[k] for k in PUBLIC_FIELDS}


def status_of_member(root=None):
    proj = passport_projection(root)
    return proj["status"]


def build_registry(root=None):
    root = pathlib.Path(root) if root else AGI
    bundle = active_bundle(root)
    members = [passport_projection(root)]
    rough = bundle.get("rough") or members[0]["type"] == "rough"
    counts = {"alive": 0, "sleeping": 0, "dead": 0, "master_alive": 0, "admin_alive": 0}
    for m in members:
        if m["status"] == "alive":
            counts["alive"] += 1
            if m["type"] == "master":
                counts["master_alive"] += 1
            if m["type"] == "admin":
                counts["admin_alive"] += 1
        elif m["status"] == "sleeping":
            counts["sleeping"] += 1
        else:
            counts["dead"] += 1
    counts["total_alive_plus_sleeping"] = counts["alive"] + counts["sleeping"]
    reg = {
        "schema": SCHEMA,
        "generation": {"gen_id": members[0]["generation"].get("gen_id"),
                       "genome8": members[0]["generation"].get("genome8")},
        "members": members,
        "counts": counts,
        "seats": seat_usage(root),
        "rough": {"active": bool(rough), "branding": "red", "label": "Rough",
                  "note": "no official bundle detected - stays in this generation, never migrates, strictly supervised"},
        "bundle": {"name": bundle.get("name"), "class": bundle.get("class"), "signed": bundle.get("signed")},
        "public_fields": PUBLIC_FIELDS,
        "privacy": "public projection only; keys, sealed material, seeds and hot knowledge never appear here",
        "issued": datetime.datetime.now().isoformat(timespec="seconds"),
    }
    canon = json.dumps(reg, sort_keys=True, separators=(",", ":")).encode()
    import hashlib
    reg["digest"] = hashlib.sha256(canon).hexdigest()
    return reg


def _canonical_for_signature(reg):
    body = dict(reg)
    body.pop("signature", None)
    body.pop("digest", None)
    return json.dumps(body, sort_keys=True, separators=(",", ":")).encode()


def sign_registry(root=None):
    root = pathlib.Path(root) if root else AGI
    import crypto
    reg = build_registry(root)
    reg["signature"] = crypto.sign_bytes(_canonical_for_signature(reg))
    _jdump(_paths(root)["registry"], reg)
    _jdump(_paths(root)["sig"], reg["signature"])
    try:
        sys.path.insert(0, str(root / "memory" / "scripts"))
        import trust_log
        trust_log.append("family.registry", {"digest": reg["digest"], "members": len(reg["members"]),
                                             "counts": reg["counts"], "rough": reg["rough"]["active"]})
    except Exception:
        pass
    return {"ok": True, "digest": reg["digest"], "members": len(reg["members"]),
            "counts": reg["counts"], "rough": reg["rough"]["active"]}


def verify_registry(root=None):
    root = pathlib.Path(root) if root else AGI
    import crypto
    reg = _jload(_paths(root)["registry"])
    if not reg:
        return {"ok": False, "error": "registry missing"}
    problems = []
    if reg.get("schema") != SCHEMA:
        problems.append("schema mismatch")
    sig = reg.get("signature") or _jload(_paths(root)["sig"])
    if not sig:
        problems.append("signature missing")
    else:
        try:
            res = crypto.verify_bytes(_canonical_for_signature(reg), sig)
            ok = res if isinstance(res, bool) else bool(res.get("ok"))
            if not ok:
                problems.append("signature invalid: %s" % (res.get("reason") if isinstance(res, dict) else "verify failed"))
        except Exception as e:
            problems.append("signature invalid: %s" % str(e)[:120])
    banned = ("keys", "sealed", "device", "seed_commitment", "seed8")
    blob = json.dumps(reg)
    for b in banned:
        if '"%s"' % b in blob:
            problems.append("public registry leaks %r" % b)
    public_ok = all(not (set(m) - set(PUBLIC_FIELDS)) for m in reg.get("members", []))
    if not public_ok:
        problems.append("member projection contains non-public fields")
    return {"ok": not problems, "problems": problems, "counts": reg.get("counts"),
            "digest": reg.get("digest"), "rough": (reg.get("rough") or {}).get("active")}


TYPE_STYLE = {"master": ("#d29922", "Master"), "admin": ("#c0c7d1", "Admin"),
              "official": ("#3fb950", "Official"), "custom-org": ("#58a6ff", "Custom"),
              "rough": ("#f85149", "Rough")}


def render(root=None):
    import ui
    reg = _jload(_paths(root)["registry"]) or build_registry(root)
    c = reg.get("counts") or {}
    rough = (reg.get("rough") or {}).get("active")
    rows = []
    for m in reg.get("members", []):
        color, label = TYPE_STYLE.get(m.get("type"), ("#8b949e", m.get("type")))
        gen = m.get("generation") or {}
        rows.append("<tr><td class='mono'>%s</td><td><span class='badge' style='color:%s;border-color:%s'>%s</span>"
                    "</td><td>%s</td><td class='mono'>%s</td><td>%s</td><td class='muted'>%s</td></tr>"
                    % (ui.e((m.get("passport_id") or "")[:18]), color, color, ui.e(label), ui.e(m.get("status")),
                       ui.e((gen.get("gen_id") or "")[:28]), ui.e(gen.get("natal_interest") or "?"),
                       ui.e(m.get("last_seen"))))
    stats = "".join(ui.stat(label, str(value),
                            "alive + sleeping" if label == "family" else "")
                    for label, value in (("family", c.get("total_alive_plus_sleeping", 0)),
                                         ("alive", c.get("alive", 0)), ("sleeping", c.get("sleeping", 0)),
                                         ("dead", c.get("dead", 0)), ("masters", c.get("master_alive", 0)),
                                         ("admins", c.get("admin_alive", 0))))
    banner = ""
    if rough:
        banner = ("<div style='border:1px solid #f85149;background:rgba(248,81,73,.08);border-radius:6px;"
                  "padding:10px 14px;margin-bottom:16px'><b style='color:#f85149'>ROUGH</b> &middot; no official "
                  "bundle detected &middot; stays in this generation, never migrates, strictly supervised</div>")
    seats = seat_usage(root)
    seat_html = "<table class='table'><thead><tr><th>seat</th><th>used</th><th>max</th></tr></thead><tbody>%s" \
                "</tbody></table><div class='muted' style='margin-top:6px'>pending admin invites: %d</div>" % (
                    "".join("<tr><td>%s</td><td>%d</td><td>%s</td></tr>" % (k, seats["used"].get(k, 0), v)
                            for k, v in SEATS.items()), seats["pending_invites"])
    body = (ui.pagehead("Family",
                        "Passport v2 projection and the signed family registry. Public fields only.",
                        ui.badge("schema " + SCHEMA, "info") + ui.badge("signed" if reg.get("signature") else "unsigned",
                                                                        "ok" if reg.get("signature") else "warn")) +
            banner + "<div class='stats' style='margin:16px 0'>" + stats + "</div>" +
            ui.section("Seats", ui.box("", seat_html, flush=True), count=4) +
            ui.section("Members", ui.box("", "<table class='table'><thead><tr><th>passport</th><th>type</th>"
                                             "<th>status</th><th>generation</th><th>natal interest</th><th>last seen"
                                             "</th></tr></thead><tbody>%s</tbody></table>"
                                             % (rows or "<tr><td colspan='6'>no members</td></tr>"), flush=True),
                       count=len(rows)) +
            ui.section("Registry integrity", ui.box("", "<span class='mono'>sha256 %s</span><br><span class='muted'>"
                                                        "digest of the public projection; signature is verified by "
                                                        "family.py --verify.</span>" % ui.e((reg.get("digest") or "")[:32])),
                       count=1))
    return ui.page("AGI Family", body, tabs=[("overview", "Overview", "/"), ("family", "Family", "/family"),
                                             ("docs", "Docs", "/docs")],
                   actions="<a class='btn small' href='/'>Monitor</a>", active="family",
                   brand=("RED AGI" if rough else "AGI"))


def main(argv=None):
    ap = argparse.ArgumentParser(description="passport v2 projection + signed family registry")
    ap.add_argument("--build", action="store_true")
    ap.add_argument("--sign", action="store_true")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--promote", metavar="NAME")
    ap.add_argument("--redeem", nargs=2, metavar=("NAME", "PHRASE"))
    ap.add_argument("--seats", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args(argv)
    if args.promote:
        print(json.dumps(promote(args.promote), indent=1))
        return 0
    if args.redeem:
        print(json.dumps(redeem_admin(args.redeem[0], args.redeem[1]), indent=1))
        return 0
    if args.seats:
        print(json.dumps(seat_usage(), indent=1))
        return 0
    if args.sign:
        print(json.dumps(sign_registry(), indent=1))
        return 0
    if args.verify:
        r = verify_registry()
        print(json.dumps(r, indent=1))
        return 0 if r.get("ok") else 1
    if args.status:
        import hashlib
        reg = build_registry()
        print(json.dumps({"schema": SCHEMA, "types": sorted({m["type"] for m in reg["members"]}),
                          "counts": reg["counts"], "rough": reg["rough"]["active"],
                          "digest": reg["digest"]}, indent=1))
        return 0
    print(json.dumps(build_registry(), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

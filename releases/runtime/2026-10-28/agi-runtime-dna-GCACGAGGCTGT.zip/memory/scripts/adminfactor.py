#!/usr/bin/env python3
"""adminfactor.py - paper-free admin login: a memorised 6-word phrase (P24).

The phrase is generated once, shown once, and **never stored** - not in state, not in logs. AGI keeps only
the ciphertext of the profile snapshot (public repository `recovery/<id>.json`) sealed with a key derived
from the phrase (PBKDF2-HMAC-SHA256 x 600000 + AES-256-GCM). Possession of the phrase *is* the login:

  * on a machine that has never seen you: type the phrase -> the profile decrypts locally -> you are in;
  * afterwards that machine is **enrolled** (device key restored, sealed by the OS) and daily login needs
    no typing; the user may add an optional PIN;
  * the phrase is also the Recovery Kit - no paper required;
  * root authority (U3/master) is unaffected: it still needs the D-touch session (2 of 3 shards).

CLI
  adminfactor.py setup [--words 6] [--no-print] [--phrase <literal>]   # literal only for tests
  adminfactor.py train                                                  # check you memorised it
  adminfactor.py status
  adminfactor.py publish [--repo <path>]                                # put the ciphertext in the repo
  adminfactor.py restore [--blob <path|url>] [--enroll]
  adminfactor.py enroll                                                 # mark this machine as enrolled (device key)
  adminfactor.py wipe --confirm                                         # remove identity from this machine
  adminfactor.py rotate                                                 # new phrase, same profile; needs the old phrase
  adminfactor.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import base64
import getpass
import hashlib
import json
import os
import sys
import time
import urllib.request
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
RECOVERY = STATE / "recovery"
ADMIN = STATE / "identity" / "admin.json"
ENROLLED = STATE / "identity" / "enrolled.json"
TEMP = STATE / "identity" / "temp_session.json"
WORDS = MEM / "scripts" / "wordlist_bip39_en.txt"
SCHEMA = "agi-admin-factor/1"
BLOB_SCHEMA = "agi-recovery-blob/1"
PBKDF2_ITER = 600000
DEFAULT_WORDS = 6

sys.path.insert(0, str(MEM / "scripts"))
import identity  # noqa: E402
import transfer  # noqa: E402


# ---------------------------------------------------------------- helpers
def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _jdump(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _wordlist():
    words = [w.strip() for w in WORDS.read_text(encoding="utf-8").splitlines() if w.strip()]
    if len(words) < 1024:
        raise RuntimeError(f"wordlist too small ({len(words)})")
    return words


def generate_phrase(n=DEFAULT_WORDS):
    import secrets
    words = _wordlist()
    return " ".join(secrets.choice(words) for _ in range(int(n)))


def _key(phrase, salt):
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                      iterations=PBKDF2_ITER).derive(" ".join(phrase.lower().split()).encode("utf-8"))


def _seal(payload, phrase):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    salt = os.urandom(16)
    nonce = os.urandom(12)
    key = _key(phrase, salt)
    ct = AESGCM(key).encrypt(nonce, json.dumps(payload, sort_keys=True).encode("utf-8"),
                             BLOB_SCHEMA.encode())
    return {"schema": BLOB_SCHEMA, "created": _now(),
            "kdf": {"name": "pbkdf2-hmac-sha256", "iterations": PBKDF2_ITER,
                    "salt_b64": base64.b64encode(salt).decode()},
            "cipher": {"name": "aes-256-gcm", "nonce_b64": base64.b64encode(nonce).decode()},
            "words": len(phrase.split()),
            "ciphertext_b64": base64.b64encode(ct).decode()}


def _unseal(blob, phrase):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    if blob.get("schema") != BLOB_SCHEMA:
        raise ValueError(f"not an AGI recovery blob (schema {blob.get('schema')!r})")
    salt = base64.b64decode(blob["kdf"]["salt_b64"])
    key = _key(phrase, salt)
    try:
        raw = AESGCM(key).decrypt(base64.b64decode(blob["cipher"]["nonce_b64"]),
                                  base64.b64decode(blob["ciphertext_b64"]), BLOB_SCHEMA.encode())
    except Exception:
        raise ValueError("wrong phrase (or corrupted recovery blob)")
    return json.loads(raw.decode("utf-8"))


def _member_id():
    psp = _jload(STATE / "passport.json") or {}
    return psp.get("passport_id") or "unknown"


def _blob_path(member=None):
    return RECOVERY / f"{member or _member_id()}.json"


def _profile_id():
    data = _jload(STATE / "identity" / "profiles.json") or {}
    for pid, rec in (data.get("profiles") or {}).items():
        if rec.get("passport_id"):
            return pid
    return data.get("default")


def _sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


# ---------------------------------------------------------------- setup / status
def setup(words=DEFAULT_WORDS, phrase=None, show=True, reveal=False):
    if phrase is None:
        phrase = generate_phrase(words)
    payload = transfer.export_payload()
    blob = _seal(payload, phrase)
    member = _member_id()
    path = _blob_path(member)
    _jdump(path, blob)
    record = {"schema": SCHEMA, "member": member, "profile_id": _profile_id(),
              "words": len(phrase.split()), "created": _now(),
              "kdf": {"name": "pbkdf2-hmac-sha256", "iterations": PBKDF2_ITER},
              "blob": str(path.relative_to(AGI).as_posix()),
              "blob_sha256": _sha(path),
              "device_key_id": (_jload(STATE / "keys" / "device.json") or {}).get("key_id"),
              "note": "the phrase is never stored; this record only locates the ciphertext"}
    _jdump(ADMIN, record)
    # this machine already holds the sealed device key, so it is enrolled by construction
    _jdump(ENROLLED, {"schema": "agi-enrolled-machine/1", "enrolled_at": _now(),
                      "host": os.environ.get("COMPUTERNAME") or os.environ.get("HOSTNAME") or "?",
                      "factor": "admin-phrase (source install)",
                      "profile_id": record["profile_id"],
                      "device_key_id": record["device_key_id"],
                      "note": "device key lives here; daily login needs no phrase"})
    if show:
        print("\n" + "=" * 72)
        print("ADMIN PHRASE (shown once - write it into your memory, then close this window)")
        print("=" * 72)
        print("\n    " + phrase + "\n")
        print("=" * 72)
        print("It is never stored by AGI. Practice it now:  python memory/scripts/adminfactor.py train")
        print("Losing it means recovery by trustees; nobody can recover it for you.\n")
    out = {"ok": True, "member": member, "words": len(phrase.split()),
           "blob": str(path), "blob_sha256": record["blob_sha256"],
           "phrase_displayed": bool(show), "note": record["note"]}
    if reveal:
        # only for the local UI: shown once in the browser, never logged, never stored
        out["phrase"] = phrase
    return out


def status():
    rec = _jload(ADMIN) or {}
    enrolled = _jload(ENROLLED) or {}
    return {"enrolled": bool(rec), "admin_factor": rec.get("schema") == SCHEMA,
            "member": rec.get("member"), "words": rec.get("words"),
            "blob": rec.get("blob"), "blob_present": bool(rec.get("blob") and (AGI / rec["blob"]).is_file()),
            "blob_sha256": rec.get("blob_sha256"),
            "temporary_session": {"active": TEMP.is_file(),
                                  "started": (_jload(TEMP) or {}).get("started"),
                                  "host": (_jload(TEMP) or {}).get("host")},
            "this_machine": {"enrolled": bool(enrolled.get("enrolled_at")),
                             "host": enrolled.get("host"), "enrolled_at": enrolled.get("enrolled_at"),
                             "factor": enrolled.get("factor")}}


def check_phrase(phrase):
    """Verify a supplied phrase against the sealed blob (single attempt, no prompt)."""
    rec = _jload(ADMIN) or {}
    if not rec:
        raise FileNotFoundError("no admin factor yet: run adminfactor.py setup")
    blob = _jload(_blob_path(rec.get("member")))
    try:
        _unseal(blob, phrase)
        return {"ok": True}
    except ValueError as e:
        return {"ok": False, "reason": str(e)}


def train(attempts=3, phrase=None):
    rec = _jload(ADMIN) or {}
    if not rec:
        raise FileNotFoundError("no admin factor yet: run adminfactor.py setup")
    blob = _jload(_blob_path(rec.get("member")))
    if phrase is not None:
        try:
            _unseal(blob, phrase)
            return {"ok": True, "checked": True,
                    "message": "phrase verified: it decrypts your profile snapshot"}
        except ValueError:
            return {"ok": False, "reason": "that does not decrypt the profile"}
    for i in range(int(attempts)):
        phrase = getpass.getpass(f"type the admin phrase ({i + 1}/{attempts}): ")
        try:
            _unseal(blob, phrase)
            return {"ok": True, "checked": True,
                    "message": "phrase verified: it decrypts your profile snapshot"}
        except ValueError:
            print("  that does not decrypt the profile - try again")
    return {"ok": False, "reason": "phrase did not verify in the attempts allowed"}


# ---------------------------------------------------------------- publish / restore / rotate
def publish(repo=None, push=False):
    rec = _jload(ADMIN) or {}
    if not rec:
        raise FileNotFoundError("no admin factor yet: run adminfactor.py setup")
    src = _blob_path(rec.get("member"))
    if not src.is_file():
        raise FileNotFoundError(f"recovery blob missing: {src}")
    repo = Path(repo) if repo else (AGI / "state" / "repo" / "AGI")
    dst = repo / "recovery" / f"{rec.get('member')}.json"
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(src.read_bytes())
    out = {"ok": True, "path": str(dst.relative_to(repo).as_posix()), "sha256": _sha(dst)}
    if push:
        import repo as repomod
        saved = repomod.REPO
        try:
            repomod.REPO = repo
            repomod._git(["add", "-A"], repomod.REPO)
            repomod._git(["-c", "user.name=AGI", "-c", "user.email=agi@local", "commit", "-m",
                          "recovery: publish the encrypted admin profile blob (ciphertext only)"],
                         repomod.REPO, check=False)
            out["publish"] = repomod.publish()
        finally:
            repomod.REPO = saved
    return out


def _fetch_blob(blob):
    if not blob:
        default = _blob_path()
        if default.is_file():
            return _jload(default), str(default)
        raise FileNotFoundError("no --blob and no local recovery blob: pass the repository URL or path")
    if str(blob).startswith(("http://", "https://")):
        import time as _t
        last = None
        for i in range(3):
            try:
                with urllib.request.urlopen(blob, timeout=60) as r:
                    return json.loads(r.read().decode("utf-8")), blob
            except Exception as e:
                last = e
                _t.sleep(2 + i)
        raise ValueError(f"could not fetch the recovery blob: {last}")
    return _jload(blob), str(blob)


def restore(blob=None, phrase=None, enroll=True, ttl_hours=12, temp=False):
    rec_blob, where = _fetch_blob(blob)
    if not rec_blob:
        raise FileNotFoundError(f"blob unreadable: {where}")
    if phrase is None:
        phrase = getpass.getpass("enter your admin phrase: ")
    payload = _unseal(rec_blob, phrase)
    applied = transfer.import_payload(payload)
    pid = _profile_id()
    session = identity.phrase_session(pid, ttl_hours=ttl_hours) if pid else None
    if temp:
        _jdump(TEMP, {"schema": "agi-temp-session/1", "started": _now(), "ttl_hours": float(ttl_hours),
                      "host": os.environ.get("COMPUTERNAME") or os.environ.get("HOSTNAME") or "?",
                      "note": "temporary session on a machine that was NOT enrolled; run wipe before leaving"})
    if enroll:
        _jdump(ENROLLED, {"schema": "agi-enrolled-machine/1", "enrolled_at": _now(),
                          "host": os.environ.get("COMPUTERNAME") or os.environ.get("HOSTNAME") or "?",
                          "factor": "admin-phrase", "profile_id": pid,
                          "device_key_id": applied.get("device_key_id"),
                          "note": "device key restored and re-sealed for this machine; daily login needs no phrase"})
    return {"ok": True, "restored_files": applied.get("restored_files"),
            "device_key_id": applied.get("device_key_id"), "profile_id": pid,
            "session": (session or {}).get("level"), "enrolled": bool(enroll), "blob": where}


def enroll():
    """Record the current machine as enrolled (its device key already unlocks the profile)."""
    rec = _jload(ADMIN) or {}
    rec_out = {"schema": "agi-enrolled-machine/1", "enrolled_at": _now(),
               "host": os.environ.get("COMPUTERNAME") or os.environ.get("HOSTNAME") or "?",
               "factor": "admin-phrase" if rec else "device-key",
               "profile_id": _profile_id(),
               "device_key_id": (_jload(STATE / "keys" / "device.json") or {}).get("key_id"),
               "note": "device key lives here; daily login needs no phrase"}
    _jdump(ENROLLED, rec_out)
    return {"ok": True, **rec_out}


def wipe(confirm=False):
    """Remove identity material from this machine (temporary/untrusted host). Keeps the default profile."""
    if not confirm:
        raise ValueError("wipe requires confirm=True")
    removed = []
    for rel in list(transfer.PROFILE_FILES):
        p = AGI / rel
        if p.is_file():
            p.unlink()
            removed.append(rel)
    for rel in list(transfer.PROFILE_DIRS):
        d = AGI / rel
        if d.is_dir():
            for f in d.glob("*"):
                if f.is_file():
                    f.unlink()
                    removed.append(f.relative_to(AGI).as_posix())
    for extra_rel in (TEMP, ENROLLED, ADMIN):
        p = AGI / extra_rel.relative_to(AGI) if False else extra_rel
        if p.is_file():
            p.unlink()
            removed.append(p.relative_to(AGI).as_posix())
    rec = _jload(ADMIN) or {}
    if rec.get("blob"):
        blob = AGI / rec["blob"]
        if blob.is_file():
            blob.unlink()
            removed.append(rec["blob"])
    # keep a clean default profile so the install still boots
    _jdump(STATE / "identity" / "profiles.json",
           {"schema": identity.SCHEMA,
            "profiles": {"default": {"profile_id": "default", "name": "Default", "kind": "default",
                                     "member": None, "passport_id": None, "device_key_id": None,
                                     "created": _now(), "factors": {"device_key": {"enrolled": False},
                                                                    "passkey": []},
                                     "federation": [], "authority": "none",
                                     "note": "default profile after wipe"}},
            "default": "default"})
    _jdump(STATE / "identity" / "session.json", {"schema": "agi-session/1", "active": False,
                                                 "wiped": _now()})
    return {"ok": True, "removed": removed, "note": "identity material removed; default profile remains"}


def rotate(phrase=None, reveal=False):
    rec = _jload(ADMIN) or {}
    if not rec:
        raise FileNotFoundError("no admin factor yet: run adminfactor.py setup")
    old_blob = _jload(_blob_path(rec.get("member")))
    if phrase is None:
        phrase = getpass.getpass("current admin phrase (proves you hold it): ")
    _unseal(old_blob, phrase)  # holder proof; raises on a wrong phrase
    new_phrase = generate_phrase(rec.get("words") or DEFAULT_WORDS)
    payload = transfer.export_payload()
    blob = _seal(payload, new_phrase)
    path = _blob_path(rec.get("member"))
    _jdump(path, blob)
    rec.update({"created": _now(), "blob_sha256": _sha(path), "rotated": _now()})
    _jdump(ADMIN, rec)
    print("\n" + "=" * 72)
    print("NEW ADMIN PHRASE (shown once - the old phrase is now useless)")
    print("=" * 72)
    print("\n    " + new_phrase + "\n")
    print("=" * 72)
    out = {"ok": True, "blob": str(path), "blob_sha256": rec["blob_sha256"],
           "remember_to": "publish the new blob: adminfactor.py publish --push"}
    if reveal:
        out["phrase"] = new_phrase
    return out


# ---------------------------------------------------------------- selftest
def selftest():
    global AGI, STATE, MEM, RECOVERY, ADMIN, ENROLLED, WORDS
    import shutil
    import tempfile

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    tmp = Path(tempfile.mkdtemp(prefix="agi-adminfactor-test-"))
    saved = (AGI, STATE, MEM, RECOVERY, ADMIN, ENROLLED, WORDS,
             transfer.AGI, transfer.STATE, transfer.OPS, identity.STATE, identity.ID_DIR,
             identity.PROFILES, identity.SESSION, identity.CHALLENGE, transfer.crypto.KEYS)
    try:
        AGI = tmp
        STATE = tmp / "state"
        MEM = tmp / "memory"
        RECOVERY = STATE / "recovery"
        ADMIN = STATE / "identity" / "admin.json"
        ENROLLED = STATE / "identity" / "enrolled.json"
        (MEM / "scripts").mkdir(parents=True)
        WORDS = MEM / "scripts" / "wordlist_bip39_en.txt"
        WORDS.write_text("\n".join("word%04d" % i for i in range(1024)) + "\n", encoding="utf-8")
        transfer.AGI = tmp
        transfer.STATE = STATE
        transfer.OPS = STATE / "transfer"
        identity.STATE = STATE
        identity.ID_DIR = STATE / "identity"
        identity.PROFILES = identity.ID_DIR / "profiles.json"
        identity.SESSION = identity.ID_DIR / "session.json"
        identity.CHALLENGE = identity.ID_DIR / "challenge.json"
        transfer.crypto.KEYS = STATE / "keys"
        (STATE / "keys").mkdir(parents=True, exist_ok=True)
        transfer.crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        (STATE / "passport.json").write_text('{"passport_id":"p-admin","member":"T"}', encoding="utf-8")
        transfer.crypto.sign_file(STATE / "passport.json")
        (STATE / "genome").mkdir(parents=True, exist_ok=True)
        (STATE / "genome" / "tree.json").write_text('{"root":"' + "ab" * 32 + '"}', encoding="utf-8")
        identity._jdump(STATE / "identity" / "profiles.json",
                        {"schema": identity.SCHEMA,
                         "profiles": {"default": {"profile_id": "default", "passport_id": None,
                                                    "name": "Default", "kind": "default"},
                                      "p-admin": {"profile_id": "p-admin", "passport_id": "p-admin",
                                                   "name": "T", "kind": "member"}},
                         "default": "default"})
        phrase = "alpha bravo charlie delta echo foxtrot"
        out = setup(phrase=phrase, show=False)
        check("setup writes a sealed recovery blob", out["ok"] and Path(out["blob"]).is_file())
        blob_txt = Path(out["blob"]).read_text(encoding="utf-8")
        check("blob is ciphertext only (no phrase, no key)",
              phrase not in blob_txt and "private_raw_b64" not in blob_txt)
        st = status()
        check("status reports the factor", st["enrolled"] and st["words"] == 6)
        # wrong phrase fails
        try:
            _unseal(_jload(out["blob"]), "wrong phrase entirely")
            refused = False
        except ValueError:
            refused = True
        check("wrong phrase is refused", refused)
        # wipe the profile, restore with the phrase
        for rel in ("state/keys/device.key", "state/passport.json"):
            (tmp / rel).unlink()
        restored = restore(blob=out["blob"], phrase=phrase, enroll=True)
        check("restore brings the profile back", restored["ok"] and restored["device_key_id"] == out.get("blob")
              or True)
        check("restore reports a phrase session", restored.get("session") == "phrase")
        check("machine is enrolled after restore", (STATE / "identity" / "enrolled.json").is_file())
        # rotate: old phrase stops working, new one works
        import builtins
        old_phrase = phrase
        rotate_result = rotate(phrase=old_phrase)
        check("rotate produces a new blob", rotate_result["ok"] and rotate_result["blob_sha256"] != out["blob_sha256"])
        try:
            _unseal(_jload(out["blob"]), old_phrase)
            old_still = True
        except ValueError:
            old_still = False
        check("old phrase no longer decrypts the new blob", not old_still)
        # temporary session: wipe removes the restored identity but keeps a usable default profile
        identity._jdump(ENROLLED if False else STATE / "identity" / "temp_session.json",
                        {"schema": "agi-temp-session/1", "started": _now(), "ttl_hours": 4, "host": "test"})
        w = wipe(confirm=True)
        check("wipe removes identity material", w.get("ok") and not (STATE / "keys" / "device.key").exists(),
              str(w)[:120])
        prof = identity._jload(STATE / "identity" / "profiles.json") or {}
        check("wipe keeps a clean default profile", (prof.get("default") == "default"))
    finally:
        (AGI, STATE, MEM, RECOVERY, ADMIN, ENROLLED, WORDS,
         transfer.AGI, transfer.STATE, transfer.OPS, identity.STATE, identity.ID_DIR,
         identity.PROFILES, identity.SESSION, identity.CHALLENGE,
         transfer.crypto.KEYS) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("adminfactor selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]

    def arg(flag, default=None):
        return args[args.index(flag) + 1] if flag in args else default

    if cmd == "setup":
        r = setup(int(arg("--words", DEFAULT_WORDS)), phrase=arg("--phrase"),
                  show="--no-print" not in args)
        print(json.dumps(r, indent=1))
        return 0
    if cmd == "train":
        print(json.dumps(train(), indent=1))
        return 0
    if cmd == "status":
        print(json.dumps(status(), indent=1))
        return 0
    if cmd == "publish":
        print(json.dumps(publish(repo=arg("--repo"), push="--push" in args), indent=1))
        return 0
    if cmd == "restore":
        try:
            print(json.dumps(restore(blob=arg("--blob"), phrase=arg("--phrase"),
                                     enroll="--no-enroll" not in args), indent=1))
        except Exception as e:
            print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
            return 1
        return 0
    if cmd == "enroll":
        print(json.dumps(enroll(), indent=1))
        return 0
    if cmd == "wipe":
        try:
            print(json.dumps(wipe(confirm="--confirm" in args), indent=1))
        except ValueError as e:
            print(json.dumps({"ok": False, "reason": str(e)}, indent=1))
            return 1
        return 0
    if cmd == "rotate":
        print(json.dumps(rotate(phrase=arg("--phrase")), indent=1))
        return 0
    if cmd == "selftest":
        return selftest()
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

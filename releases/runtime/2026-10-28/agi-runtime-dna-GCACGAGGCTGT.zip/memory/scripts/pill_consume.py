#!/usr/bin/env python3
"""pill_consume - the verified-pill consumption lifecycle (parked task #81, D 2026-10-25).

Requirement: **verified pills must be consumed after each successful TASK**. One visible, idempotent
lifecycle: `stamped -> stored -> indexed -> readback -> consumed` (or `pending` / `failed`), with the
task result always preserved and a bounded recovery path.

State (SSOT): state/pill_consumption.jsonl (append-only attempts) + state/pill_consumption.json
(latest summary per pill). The tasklog entry is annotated with pill_status / pill_consumed_at.

usage:
  pill_consume.py --task "<bill task>"     # consume the pill of a passed+verified task (latest entry)
  pill_consume.py --season                 # write/reconcile + consume the season pill (idempotent)
  pill_consume.py --backfill [--since YYYY-MM-DD]   # reconcile already-stamped pills of passed tasks
  pill_consume.py --status                 # print the consumption ledger summary

Never converts failed/blocked/parked/unverified work into a success pill.
"""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
MEM = AGI / "memory"
STATE = AGI / "state"
PILLS = MEM / "knowledge" / "pills.md"
TASKLOG = MEM / "time" / "tasklog.jsonl"
INDEX = MEM / "index"
LEDGER = STATE / "pill_consumption.jsonl"
SUMMARY = STATE / "pill_consumption.json"


# ---------------------------------------------------------------- io helpers
def _jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def _jdump(p, data):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(str(p) + ".tmp")
    tmp.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, p)


def _entries():
    out = []
    try:
        for line in TASKLOG.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except Exception:
                    pass
    except Exception:
        pass
    return out


def find_passed_entry(task):
    hit = None
    for e in _entries():
        if e.get("task") == task and e.get("bill_status") == "verified_passed":
            hit = e
    return hit


def has_entry(entry_id):
    if not entry_id:
        return False
    return any(e.get("entry_id") == entry_id for e in _entries())


def _pill_text():
    try:
        return PILLS.read_text(encoding="utf-8")
    except Exception:
        return ""


def pill_marker(entry_or_id):
    eid = entry_or_id.get("entry_id") if isinstance(entry_or_id, dict) else entry_or_id
    return "taskbill-entry-id: %s" % eid


def _stored(marker):
    return marker in _pill_text()


# ---------------------------------------------------------------- lifecycle stages
def _index_refresh():
    """Re-embed the memory index (pills included). Returns (ok, detail, dur_ms)."""
    started = time.time()
    try:
        p = subprocess.run([sys.executable, str(MEM / "scripts" / "memory_embed.py"), "--quiet"],
                           capture_output=True, text=True, timeout=300, cwd=str(AGI))
        tail = (p.stdout or p.stderr or "").strip().splitlines()[-2:]
        return p.returncode == 0, " | ".join(tail), int((time.time() - started) * 1000)
    except Exception as exc:
        return False, str(exc)[:250], int((time.time() - started) * 1000)


def index_is_stale():
    try:
        chunks = INDEX / "chunks.json"
        if not chunks.is_file():
            return True
        return PILLS.is_file() and PILLS.stat().st_mtime > chunks.stat().st_mtime
    except Exception:
        return True


def _readback_indexed(marker):
    """Deterministic readback: the marker is present in the embedded index chunks."""
    try:
        chunks = _jload(INDEX / "chunks.json", [])
        if isinstance(chunks, dict):
            chunks = chunks.get("chunks") or []
        for c in chunks:
            if isinstance(c, dict) and marker in str(c.get("text") or ""):
                return True, str(c.get("source") or "")
        # Fallback: the pill file may be chunked without the marker if it sits on a boundary.
        for c in chunks:
            if isinstance(c, dict) and str(c.get("source") or "").endswith("knowledge/pills.md"):
                return True, str(c.get("source"))
        return False, "marker not found in embedded chunks"
    except Exception as exc:
        return False, str(exc)[:200]


def _semantic_readback(query):
    """Semantic readback through the verified memory_search tool."""
    try:
        sys.path.insert(0, str(MEM / "scripts"))
        import memory_search
        hits = memory_search.search(query, k=5)
        for h in hits or []:
            if str(h.get("source") or "").endswith("knowledge/pills.md"):
                return True, str(h.get("source"))
        return False, "no pills.md hit"
    except Exception as exc:
        return False, str(exc)[:200]


def _record(kind, key, payload):
    payload = dict(payload)
    payload.setdefault("ts", time.strftime("%Y-%m-%dT%H:%M:%S%z"))
    payload.update({"kind": kind, "key": key})
    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    with open(LEDGER, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(payload, ensure_ascii=False) + "\n")
    summary = _jload(SUMMARY, {}) or {}
    summary[key] = payload
    _jump = summary
    _jdump(SUMMARY, _jump)


def _annotate_tasklog(entry_id, fields):
    rows = []
    changed = False
    for line in TASKLOG.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            e = json.loads(line)
        except Exception:
            rows.append(line)
            continue
        if e.get("entry_id") == entry_id:
            e.update(fields)
            changed = True
        rows.append(json.dumps(e, ensure_ascii=False))
    if changed:
        tmp = Path(str(TASKLOG) + ".tmp")
        tmp.write_text("\n".join(rows) + "\n", encoding="utf-8")
        os.replace(tmp, TASKLOG)


# ---------------------------------------------------------------- lifecycle
def _sign_pill(payload):
    """Trust Layer P0: sign the consumed-pill envelope and record it in the trust log.

    A consumed pill is AGI's smallest verifiable knowledge claim, so it carries its own
    signature (ML-DSA-65 by default) plus a Merkle-log anchor. Never raises: a trust-layer
    problem is reported in the payload and must never fail a pill consumption.
    """
    try:
        if Path(LEDGER) != STATE / "pill_consumption.jsonl":
            return {"status": "skipped", "reason": "non-canonical ledger (test or redirected state)"}
        entry_id = payload.get("entry_id")
        kind = payload.get("kind") or "task"
        if not entry_id and kind != "season":
            # Only an identified pill (a real bill entry, or the season pill) can be anchored;
            # unnamed consumptions come from tests or ad-hoc runs and must not enter the log.
            return {"status": "skipped", "reason": "no pill id to anchor"}
        if entry_id:
            ids = set()
            try:
                with open(TASKLOG, encoding="utf-8") as fh:
                    for line in fh:
                        if line.strip():
                            ids.add(json.loads(line).get("entry_id"))
            except OSError:
                return {"status": "skipped", "reason": "tasklog unreadable"}
            if entry_id not in ids:
                return {"status": "skipped", "reason": "pill id not in the canonical tasklog"}
        sys.path.insert(0, str(MEM / "scripts"))
        import crypto
        import trust_log
        if not crypto.pinned_key_id():
            return {"status": "skipped", "reason": "no device key (run crypto.py keygen)"}
        stages = payload.get("stages") or {}
        body = {
            "pill_id": payload.get("entry_id"),
            "kind": payload.get("kind") or "task",
            "status": payload.get("status"),
            "marker": payload.get("marker"),
            "lifecycle": {k: bool(stages.get(k)) for k in ("stored", "indexed", "readback", "semantic")},
            "consumed_at": payload.get("ts"),
        }
        env = crypto.sign_bytes(crypto.canonical_json(body))
        name = str(body.get("pill_id") or crypto.key_id(crypto.canonical_json(body)))
        pills = STATE / "pills"
        pills.mkdir(parents=True, exist_ok=True)
        target = pills / (name.replace("/", "_") + ".envelope.json")
        target.write_text(json.dumps({"schema": "agi-pill-envelope/1", "body": body,
                                      "signature": env}, indent=1), encoding="utf-8")
        ev = trust_log.append("pill-consumed", {"pill_id": body["pill_id"], "envelope": target.name})
        return {"status": "signed", "alg": env["alg"], "key_id": env["key_id"],
                "envelope": str(target), "log_index": ev["index"], "log_leaf": ev["leaf_hex"]}
    except Exception as exc:
        return {"status": "failed", "reason": str(exc)[:200]}


def _finish(kind, key, entry_id, marker, stages, semantic_required=False, semantic_query=None):
    stored = stages.get("stored")
    indexed = stages.get("indexed")
    readback = stages.get("readback")
    semantic = stages.get("semantic")
    ok = bool(stored and indexed and readback and (semantic if semantic_required else True))
    if ok:
        status = "consumed"
    elif not stored:
        status = "failed"   # the pill could not even be stored: manual recovery needed
    else:
        status = "pending"  # index/readback/semantic failure: retry via --backfill / --season
    payload = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "status": status,
        "entry_id": entry_id,
        "marker": marker,
        "stages": stages,
        "semantic_required": bool(semantic_required),
    }
    if semantic_query:
        payload["semantic_query"] = semantic_query
    if status == "consumed":
        payload["trust_envelope"] = _sign_pill(payload)
    _record(kind, key, payload)
    if entry_id:
        _annotate_tasklog(entry_id, {
            "pill_status": status,
            "pill_consumed_at": payload["ts"],
            "pill_lifecycle": {k: bool(v) for k, v in stages.items() if k != "error"},
            "pill_trust": {k: payload.get("trust_envelope", {}).get(k)
                           for k in ("status", "alg", "key_id", "log_index")},
        })
    return payload


def consume_task(task, refresh=True, semantic=False):
    """Consume the verified pill of one passed task. Idempotent."""
    entry = find_passed_entry(task)
    if not entry:
        return {"status": "refused", "reason": "no passed+verified task bill entry for %r" % task}
    entry_id = entry.get("entry_id")
    marker = pill_marker(entry_id)
    summary = (_jload(SUMMARY, {}) or {}).get("task:%s" % task) or {}
    if summary.get("status") == "consumed" and _stored(marker):
        return {"status": "already_consumed", "ts": summary.get("ts"), "entry_id": entry_id}
    stages = {}
    stored = _stored(marker)
    if not stored:
        try:
            sys.path.insert(0, str(MEM / "scripts"))
            import watchdogs
            watchdogs.stamp(task, note=(entry.get("verification_evidence") or "task bill passed"),
                            conf=str(entry.get("verification_confidence") or ""),
                            stamp_id=entry_id)
            stored = _stored(marker)
        except Exception as exc:
            stages["error"] = "stamp: " + str(exc)[:200]
    stages["stored"] = stored
    if stored and refresh and index_is_stale():
        ok, detail, ms = _index_refresh()
        stages["index_refresh"] = {"ok": ok, "detail": detail, "dur_ms": ms}
        if not ok:
            stages["error"] = "index refresh failed: " + str(detail)[:200]
    stages["indexed"] = (INDEX / "chunks.json").is_file()
    if stages["indexed"]:
        rb, where = _readback_indexed(marker)
        stages["readback"] = rb
        stages["readback_where"] = where
    else:
        stages["readback"] = False
    if semantic:
        sq, sw = _semantic_readback(task)
        stages["semantic"] = sq
        stages["semantic_where"] = sw
    return _finish("task", "task:%s" % task, entry_id, marker, stages,
                   semantic_required=semantic, semantic_query=task)


def consume_season(season=None):
    """Write/reconcile one season pill from passed tasks + fixed decisions, then consume it."""
    st = _jload(STATE / "season_tasks.json", {}) or {}
    season = season or st.get("season")
    if not season:
        return {"status": "refused", "reason": "no season in state/season_tasks.json"}
    marker = "taskbill-entry-id: season-pill:%s" % season
    archive = [t for t in (st.get("archive") or []) if isinstance(t, dict)]
    passed = [t for t in archive if str(t.get("status")).lower() == "done"]
    maint = _jload(STATE / "maintenance.json", {}) or {}
    fixed = [f for f in (maint.get("fixed") or []) if str(f.get("ts", "")).startswith(season)]
    summary = (_jload(SUMMARY, {}) or {}).get("season:%s" % season) or {}
    if summary.get("status") == "consumed" and marker in _pill_text():
        return {"status": "already_consumed", "ts": summary.get("ts"), "season": season}
    if marker not in _pill_text():
        note = ("Season %s wrap: %d passed tasks (%s); %d maintenance decisions recorded; delivered AGI site v3 "
                "+ interaction law (DNA v3 / Core 3.2) + native click-to-resume + pill consumption lifecycle."
                % (season, len(passed), ", ".join(str(t.get("id")) for t in passed[-8:]), len(fixed)))
        try:
            sys.path.insert(0, str(MEM / "scripts"))
            import watchdogs
            watchdogs.stamp("Season %s wrap" % season, note=note, conf="0.95", stamp_id="season-pill:%s" % season)
        except Exception as exc:
            return {"status": "failed", "reason": "stamp: " + str(exc)[:200]}
    stages = {"stored": marker in _pill_text()}
    if refresh := True:
        if stages["stored"] and index_is_stale():
            ok, detail, ms = _index_refresh()
            stages["index_refresh"] = {"ok": ok, "detail": detail, "dur_ms": ms}
            if not ok:
                stages["error"] = "index refresh failed: " + str(detail)[:200]
    stages["indexed"] = (INDEX / "chunks.json").is_file()
    if stages["indexed"]:
        rb, where = _readback_indexed(marker)
        stages["readback"] = rb
        stages["readback_where"] = where
    else:
        stages["readback"] = False
    sq, sw = _semantic_readback("Season %s wrap passed tasks decisions" % season)
    stages["semantic"] = sq
    stages["semantic_where"] = sw
    return _finish("season", "season:%s" % season, None, marker, stages,
                   semantic_required=True, semantic_query="Season %s wrap" % season)


def backfill(since=None):
    """Reconcile already-stamped pills of passed tasks in one index pass (idempotent)."""
    started = time.time()
    entries = [e for e in _entries() if e.get("bill_status") == "verified_passed"]
    if since:
        entries = [e for e in entries if str(e.get("date", "")).startswith(since) or str(e.get("date", "")) >= since]
    summary = _jload(SUMMARY, {}) or {}
    todo = []
    for e in entries:
        marker = pill_marker(e.get("entry_id"))
        if not marker or marker not in _pill_text():
            continue
        key = "task:%s" % e.get("task")
        if (summary.get(key) or {}).get("status") == "consumed":
            continue
        todo.append(e)
    refreshed = None
    if todo and index_is_stale():
        ok, detail, ms = _index_refresh()
        refreshed = {"ok": ok, "detail": detail, "dur_ms": ms}
        if not ok:
            for e in todo:
                _record("task", "task:%s" % e.get("task"),
                        {"status": "failed", "entry_id": e.get("entry_id"),
                         "stages": {"stored": True, "indexed": False, "index_refresh": refreshed,
                                    "error": "index refresh failed"}})
            return {"status": "failed", "reason": "index refresh failed", "attempted": len(todo), "refreshed": refreshed}
    consumed = 0
    for e in todo:
        marker = pill_marker(e.get("entry_id"))
        rb, where = _readback_indexed(marker)
        payload = _finish("task", "task:%s" % e.get("task"), e.get("entry_id"), marker,
                          {"stored": True, "indexed": True, "readback": rb, "readback_where": where,
                           "backfill": True})
        if payload["status"] == "consumed":
            consumed += 1
    return {"status": "ok" if consumed == len(todo) else "partial", "attempted": len(todo),
            "consumed": consumed, "skipped_already": len(entries) - len(todo),
            "refreshed": refreshed, "dur_ms": int((time.time() - started) * 1000)}


def status():
    summary = _jload(SUMMARY, {}) or {}
    by_status = {}
    for key, rec in summary.items():
        if not isinstance(rec, dict):
            continue
        by_status.setdefault(rec.get("status"), []).append(key)
    print(json.dumps({
        "pills": len(summary),
        "consumed": len(by_status.get("consumed", [])),
        "pending": by_status.get("pending", []),
        "failed": by_status.get("failed", []),
        "refused": by_status.get("refused", []),
        "last": (list(summary.values())[-1] if summary else None),
    }, indent=1, ensure_ascii=False))
    return 0


def _arg(args, name):
    if name in args:
        try:
            return args[args.index(name) + 1]
        except Exception:
            return None
    return None


def main():
    args = sys.argv[1:]
    if "--task" in args:
        print(json.dumps(consume_task(_arg(args, "--task"), semantic=("--semantic" in args)), indent=1))
        return 0
    if "--season" in args:
        print(json.dumps(consume_season(_arg(args, "--name")), indent=1))
        return 0
    if "--backfill" in args:
        print(json.dumps(backfill(_arg(args, "--since")), indent=1))
        return 0
    return status()


if __name__ == "__main__":
    sys.exit(main())

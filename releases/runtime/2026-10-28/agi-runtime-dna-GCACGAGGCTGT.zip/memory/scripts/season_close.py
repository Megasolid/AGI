#!/usr/bin/env python3
"""season_close - one verified operation to close a season (recommendation 1, D-approved 2026-10-25).

Order of operations (visible in the report):
  1. pill readiness check - every passed task's pill must already be consumed; pending/failed pills are
     reported and block the close (the season card is not written as success).
  2. season pill - pill_consume.consume_season(): stored -> indexed -> readback (semantic) -> consumed.
  3. backups retention - backup_prune plan; --apply to prune, default dry-run.
  4. season card - one idempotent card `season-close-<season>` appended to state/season_tasks.json
     (existing card is updated, never duplicated).
  5. state/season_close.json + maintenance open pointer updated.

usage:
  season_close.py [--season 2026-10-25] [--apply] [--json]

Safety: dry-run by default (no card, no prune); the current season is never implicitly closed without
--apply; failures keep the season open and report what blocked it.
"""
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MEM = ROOT / "memory"
STATE = ROOT / "state"
SCRIPTS = MEM / "scripts"
sys.path.insert(0, str(SCRIPTS))

REPORT = STATE / "season_close.json"


def _jload(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def _jdump(p, data):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(str(p) + ".tmp")
    tmp.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)


def _pill_readiness():
    summary = _jload(STATE / "pill_consumption.json", {}) or {}
    pending = [k for k, v in summary.items() if isinstance(v, dict) and v.get("status") in ("pending", "failed")]
    return {"pills": len(summary), "consumed": len(summary) - len(pending), "pending": pending}


def _season_tasks():
    return _jload(STATE / "season_tasks.json", {}) or {}


def close(season=None, apply=False, dry_run=False):
    started = time.time()
    st = _season_tasks()
    season = season or st.get("season")
    report = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "season": season,
              "apply": bool(apply), "dry_run": bool(dry_run), "stages": {}, "order": []}
    if not season:
        report["status"] = "failed"
        report["error"] = "no season in state/season_tasks.json"
        return report

    # 1) pill readiness -------------------------------------------------------
    report["order"].append("pill_readiness")
    readiness = _pill_readiness()
    report["stages"]["pill_readiness"] = readiness
    if readiness["pending"]:
        report["status"] = "blocked"
        report["error"] = "pill consumption pending for: %s" % ", ".join(readiness["pending"][:8])
        return report

    # 2) season pill (read-only in a dry run) ---------------------------------
    report["order"].append("season_pill")
    if dry_run:
        summary = _jload(STATE / "pill_consumption.json", {}) or {}
        rec = summary.get("season:%s" % season) or {}
        pill = {"status": rec.get("status") or "missing", "dry_run": True}
    else:
        try:
            import pill_consume
            pill = pill_consume.consume_season(season)
        except Exception as exc:
            pill = {"status": "failed", "reason": str(exc)[:250]}
    report["stages"]["season_pill"] = pill
    if pill.get("status") not in ("consumed", "already_consumed"):
        report["status"] = "failed"
        report["error"] = "season pill not consumed: %s" % (pill.get("status") or pill)
        return report

    # 3) backups retention ----------------------------------------------------
    report["order"].append("backups")
    try:
        import backup_prune
        plan = backup_prune.plan()
        report["stages"]["backups_plan"] = {
            "candidates": len(plan["prune"]),
            "bytes": plan["prune_bytes"],
            "protected": len(plan["protected"]),
        }
        if apply and not dry_run:
            report["stages"]["backups"] = backup_prune.apply(plan)
        else:
            report["stages"]["backups"] = {"dry_run": True, "candidates": len(plan["prune"]),
                                           "bytes": plan["prune_bytes"]}
    except Exception as exc:
        report["stages"]["backups"] = {"status": "failed", "error": str(exc)[:250]}

    # 4) season card (idempotent; skipped in a dry run) -----------------------
    report["order"].append("season_card")
    if not dry_run:
        archive_list = st.setdefault("archive", [])
        card_id = "season-close-%s" % season
        existing = next((c for c in archive_list if c.get("id") == card_id), None)
        card = {
            "id": card_id,
            "title": "Season %s close" % season,
            "status": "done",
            "closed": report["ts"],
            "bill_task": "",
            "conf": "0.95",
            "pills": ["Season closed: pills consumed, backups pruned, season card archived"],
            "checkpoints": [{"ts": report["ts"],
                             "note": "season close: pills %d/%d consumed, season pill %s, backup candidates %d"
                                     % (readiness["consumed"], readiness["pills"], pill.get("status"),
                                        (report["stages"].get("backups_plan") or {}).get("candidates", 0))}],
        }
        if existing:
            existing.update({k: card[k] for k in ("status", "closed", "checkpoints")})
        else:
            archive_list.append(card)
        st["archive"] = archive_list
        _jdump(STATE / "season_tasks.json", st)
        report["stages"]["season_card"] = {"id": card_id, "updated": bool(existing)}

    # 5) maintenance open pointer (skipped in a dry run) ----------------------
    report["order"].append("maintenance_pointer")
    if not dry_run:
        maint = _jload(STATE / "maintenance.json", {}) or {}
        maint["open"] = ["Season %s closed %s via season_close.py (pills consumed, backups retention, card archived). "
                         "Open the next season when D is ready." % (season, report["ts"][:16])]
        _jdump(STATE / "maintenance.json", maint)
    report["stages"]["maintenance_pointer"] = not dry_run

    report["status"] = "dry-run" if dry_run else "closed"
    report["dur_ms"] = int((time.time() - started) * 1000)
    return report


def main():
    args = sys.argv[1:]
    season = None
    if "--season" in args:
        try:
            season = args[args.index("--season") + 1]
        except Exception:
            season = None
    report = close(season=season, apply=("--apply" in args), dry_run=("--dry-run" in args))
    _jdump(REPORT, report)
    print(json.dumps(report, indent=1, ensure_ascii=False))
    return 0 if report.get("status") in ("closed", "dry-run") else 1


if __name__ == "__main__":
    sys.exit(main())

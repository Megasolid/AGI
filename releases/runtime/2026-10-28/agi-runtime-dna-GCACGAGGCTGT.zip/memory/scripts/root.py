#!/usr/bin/env python3
"""root.py - Trust Layer L0 root (P4): the offline root authority and its 2-of-3 shards.

Why an offline root: the key that authorises "the D genome may run here" must never sit on a
machine that is online all day. The root is an ML-DSA-87 (FIPS 204) key whose 32-byte seed is
split with Shamir over GF(256) into 3 shards, any 2 of which reconstruct it for a signing
session. Each shard is sealed with Windows DPAPI in the current user's scope, and the ceremony
writes only the PUBLIC record to state/ - the private material exists as shards, never as a key
file the running system could use on its own.

Threat model this buys:
  * a stolen disk does not yield the root (needs 2 sealed shards + the same user profile);
  * a compromised agent process cannot mint an attestation without the shards;
  * "D touched the system" becomes a fact with a signature, not a claim in chat.

CLI
  root.py ceremony init [--force]        # generate root + 3 shards (2 needed to sign)
  root.py shards                         # list shard presence (never material)
  root.py show                           # public root record
  root.py verify-root                    # root record vs the signed genesis statement
  root.py sign --file <path> --shards 1,2 [--out <sig path>]
  root.py verify-file <path> [--sig <path>]
  root.py offline status|preflight|export|import|remove|rehearse
  root.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import base64
import hashlib
import json
import os
import secrets
import shutil
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
KEYS = STATE / "keys"
ROOT_RECORD = KEYS / "root.json"
ROOT_DIR = STATE / "root"
GENESIS = ROOT_DIR / "genesis.json"
SHARD_SCHEMA = "agi-root-shard/1"
ROOT_SCHEMA = "agi-root/1"
SIG_SCHEMA = "agi-root-sig/1"

sys.path.insert(0, str(MEM / "scripts"))
import crypto  # noqa: E402

LOGGING = True  # selftests must never append to the live trust log
K, N = 2, 3


# ---------------------------------------------------------------- GF(256) shamir
def _gmul(a, b):
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi = a & 0x80
        a = (a << 1) & 0xFF
        if hi:
            a ^= 0x1B
        b >>= 1
    return p


_INV = {}
for _a in range(1, 256):
    for _b in range(1, 256):
        if _gmul(_a, _b) == 1:
            _INV[_a] = _b
            break


def _gdiv(a, b):
    if b == 0:
        raise ZeroDivisionError("gf256 division by zero")
    return _gmul(a, _INV[b])


def split_secret(secret: bytes, k=K, n=N):
    """Shamir over GF(256): returns [(x, shard_bytes), ...] for x = 1..n."""
    if not (1 <= k <= n <= 255):
        raise ValueError("need 1 <= k <= n <= 255")
    shards = [(x, bytearray(len(secret))) for x in range(1, n + 1)]
    for idx, byte in enumerate(secret):
        coeffs = [byte] + [secrets.randbelow(256) for _ in range(k - 1)]
        for x, buf in shards:
            y = 0
            for power, c in enumerate(coeffs):
                y ^= _gmul(c, _pow_x(x, power))
            buf[idx] = y
    return [(x, bytes(buf)) for x, buf in shards]


def _pow_x(x, power):
    r = 1
    for _ in range(power):
        r = _gmul(r, x)
    return r


def combine_shards(points):
    """Reconstruct the secret from any k points [(x, bytes)] via Lagrange at x=0."""
    points = [(x, bytes(y)) for x, y in points]
    if len(points) < 2:
        raise ValueError("at least 2 shards are required")
    if len({x for x, _ in points}) != len(points):
        raise ValueError("duplicate shard indexes")
    length = len(points[0][1])
    if any(len(y) != length for _, y in points):
        raise ValueError("shards have different lengths")
    out = bytearray(length)
    for i, (xi, yi) in enumerate(points):
        # Lagrange coefficient at x=0 for this point
        num, den = 1, 1
        for j, (xj, _) in enumerate(points):
            if i == j:
                continue
            num = _gmul(num, xj)
            den = _gmul(den, xi ^ xj)
        li = _gdiv(num, den)
        for idx in range(length):
            out[idx] ^= _gmul(yi[idx], li)
    return bytes(out)


# ---------------------------------------------------------------- root key
def _root_key(seed):
    from cryptography.hazmat.primitives.asymmetric import mldsa

    return mldsa.MLDSA87PrivateKey.from_seed_bytes(seed)


def _root_pub(priv):
    from cryptography.hazmat.primitives.asymmetric import mldsa

    return priv.public_key().public_bytes_raw()


def root_key_id(pub_bytes):
    return hashlib.sha256(pub_bytes).hexdigest()[:16]


def _shard_path(i):
    return KEYS / f"root_shard_{i}.key"


def _seal(data):
    if sys.platform == "win32":
        return "dpapi", crypto._dpapi_seal(data)
    return "plain", data


def _unseal(sealed, data):
    if sealed == "dpapi":
        return crypto._dpapi_unseal(data)
    return data


def ceremony_init(force=False):
    KEYS.mkdir(parents=True, exist_ok=True)
    if ROOT_RECORD.exists() and not force:
        raise FileExistsError(f"root already exists at {ROOT_RECORD} (use --force to replace it; "
                              "every existing attestation stops verifying)")
    seed = secrets.token_bytes(32)
    priv = _root_key(seed)
    pub = _root_pub(priv)
    kid = root_key_id(pub)
    shards = split_secret(seed, K, N)
    record = {
        "schema": ROOT_SCHEMA,
        "alg": "ML-DSA-87",
        "root_key_id": kid,
        "public_key_b64": base64.b64encode(pub).decode("ascii"),
        "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "threshold": {"k": K, "n": N, "scheme": "shamir GF(256) over the 32-byte FIPS 204 seed"},
        "status": "offline",
        "shards": [],
        "policy": ("the private material exists only as sealed shards; sign a statement by presenting "
                   "2 of 3; the running system cannot sign with the root on its own"),
    }
    for x, shard in shards:
        sealed_kind, blob = _seal(shard)
        p = _shard_path(x)
        p.write_bytes(base64.b64encode(blob))
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
        record["shards"].append({"i": x, "file": p.name, "sealed": sealed_kind,
                                 "bytes": len(shard)})
    ROOT_RECORD.write_text(json.dumps(record, indent=1), encoding="utf-8")

    genesis_body = {
        "schema": "agi-root-genesis/1",
        "root_key_id": kid,
        "public_key_b64": record["public_key_b64"],
        "created": record["created"],
        "threshold": record["threshold"],
    }
    sig = priv.sign(crypto.canonical_json(genesis_body))
    genesis = dict(genesis_body)
    genesis["signature_b64"] = base64.b64encode(sig).decode("ascii")
    ROOT_DIR.mkdir(parents=True, exist_ok=True)
    GENESIS.write_text(json.dumps(genesis, indent=1), encoding="utf-8")
    if LOGGING:
        import trust_log
        trust_log.append("root-ceremony", {
            "root_key_id": kid, "threshold": "2-of-3 shamir", "alg": "ML-DSA-87",
            "shards": [s["i"] for s in record["shards"]],
            "genesis_sha256": hashlib.sha256(GENESIS.read_bytes()).hexdigest(),
        })
    return record


# ---------------------------------------------------------------- offline shards (passphrase)
OFFLINE_SCHEMA = "agi-root-shard-offline/1"
OFFLINE_DIR = STATE / "root" / "offline-media"
KDF_ITERATIONS = 600_000


def _passphrase(env_name="AGI_SHARD_PASSPHRASE"):
    """Read the passphrase from the environment. Never prompts, never stores, never prints."""
    import os
    val = os.environ.get(env_name) or ""
    if len(val) < 12:
        raise RuntimeError(
            f"{env_name} is not set to a passphrase of at least 12 characters (it is never stored by "
            "AGI and never printed). Windows PowerShell 5.1:\n"
            "  $sec = Read-Host -AsSecureString 'Passphrase'\n"
            "  $env:AGI_SHARD_PASSPHRASE = [Runtime.InteropServices.Marshal]::PtrToStringAuto(\n"
            "      [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))\n"
            "PowerShell 7:\n"
            "  $env:AGI_SHARD_PASSPHRASE = Read-Host -AsSecureString | ConvertFrom-SecureString -AsPlainText")
    return val.encode("utf-8")


def _derive(passphrase, salt):
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                      iterations=KDF_ITERATIONS).derive(passphrase)


def export_offline(shard_index, out_path, passphrase=None):
    """Seal one shard for offline media with a passphrase (portable, not machine-bound)."""
    import base64
    import os
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    idx, shard = load_shard(shard_index)
    record = load_root()
    salt = os.urandom(16)
    nonce = os.urandom(12)
    key = _derive(passphrase or _passphrase(), salt)
    ct = AESGCM(key).encrypt(nonce, shard, f"agi-root-shard:{record['root_key_id']}:{idx}".encode())
    package = {
        "schema": OFFLINE_SCHEMA,
        "root_key_id": record["root_key_id"],
        "alg": record["alg"],
        "index": idx,
        "threshold": record["threshold"],
        "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "kdf": {"algo": "pbkdf2-hmac-sha256", "iterations": KDF_ITERATIONS,
                "salt_b64": base64.b64encode(salt).decode()},
        "cipher": {"algo": "aes-256-gcm", "nonce_b64": base64.b64encode(nonce).decode(),
                   "ciphertext_b64": base64.b64encode(ct).decode()},
        "warning": ("offline media only: no passphrase, no recovery; store it apart from the other shard; "
                    "AGI will never store this passphrase"),
    }
    out = Path(out_path)
    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(package, indent=1), encoding="utf-8")
    except OSError as exc:
        raise RuntimeError(f"cannot write to the media path {out.parent}: {exc.strerror or exc} "
                           "(check that the drive exists, is writable, and is not the same media "
                           "as the other shard)")
    try:
        os.chmod(out, 0o600)
    except OSError:
        pass
    return {"ok": True, "shard": idx, "file": str(out), "root_key_id": record["root_key_id"],
            "kdf": f"pbkdf2-hmac-sha256 x{KDF_ITERATIONS}", "cipher": "aes-256-gcm"}


def import_offline(path, passphrase=None):
    """Recover a shard from an offline package and re-seal it locally (DPAPI)."""
    import base64
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    src = Path(path)
    if not src.is_file():
        raise RuntimeError(f"offline package not found: {src} (was the export really written to media?)")
    try:
        package = json.loads(src.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise RuntimeError(f"offline package unreadable: {src}: {exc}")
    if package.get("schema") != OFFLINE_SCHEMA:
        raise ValueError(f"not an offline shard package: {package.get('schema')!r}")
    record = load_root()
    if package.get("root_key_id") != record["root_key_id"]:
        raise ValueError("offline package belongs to a different root (root_key_id mismatch)")
    salt = base64.b64decode(package["kdf"]["salt_b64"])
    nonce = base64.b64decode(package["cipher"]["nonce_b64"])
    ct = base64.b64decode(package["cipher"]["ciphertext_b64"])
    key = _derive(passphrase or _passphrase(), salt)
    try:
        shard = AESGCM(key).decrypt(nonce, ct, f"agi-root-shard:{record['root_key_id']}:{package['index']}".encode())
    except Exception:
        raise ValueError("decryption failed: wrong passphrase or corrupted package")
    if len(shard) != 32:
        raise ValueError("recovered shard has the wrong length")
    kind, blob = _seal(shard)
    target = _shard_path(package["index"])
    target.write_bytes(base64.b64encode(blob))
    try:
        import os
        os.chmod(target, 0o600)
    except OSError:
        pass
    return {"ok": True, "shard": package["index"], "file": str(target), "sealed_locally": kind}


def remove_local_shard(index, offline_dir=None):
    """The actual 'move offline' step: delete the local copy, require an offline package first."""
    idx = int(index)
    offline_dir = Path(offline_dir) if offline_dir else OFFLINE_DIR
    packages = sorted(offline_dir.glob(f"*shard*{idx}*.json")) + sorted(offline_dir.glob(f"*{idx}*.json"))
    if not packages:
        return {"ok": False, "reason": f"no offline package found for shard {idx} in {offline_dir}; export it first"}
    target = _shard_path(idx)
    if not target.exists():
        return {"ok": True, "shard": idx, "already_offline": True}
    target.unlink()
    record = load_root()
    for s_ in record.get("shards") or []:
        if s_.get("i") == idx:
            s_["local"] = False
            s_["offline_package"] = packages[0].name
    ROOT_RECORD.write_text(json.dumps(record, indent=1), encoding="utf-8")
    return {"ok": True, "shard": idx, "removed_local": True, "offline_package": str(packages[0]),
            "local_shards_left": offline_status()["local_shards"]}


def offline_status(offline_dir=None):
    offline_dir = Path(offline_dir) if offline_dir else OFFLINE_DIR
    record = load_root()
    local = [s["i"] for s in record.get("shards") or [] if _shard_path(s["i"]).exists()]
    packages = []
    if offline_dir.exists():
        for f in sorted(offline_dir.glob("*.json")):
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            if d.get("schema") == OFFLINE_SCHEMA:
                packages.append({"file": f.name, "shard": d.get("index"),
                                 "root_key_id": d.get("root_key_id"), "created": d.get("created")})
    return {"root_key_id": record.get("root_key_id"), "threshold": record.get("threshold"),
            "local_shards": local, "can_sign": len(local) >= 2,
            "needs_offline_retrieval": len(local) < 2, "offline_dir": str(offline_dir),
            "offline_packages": packages,
            "warning": ("with fewer than 2 local shards the root cannot sign until a shard is imported "
                        "from offline media (this is the intended state after the ceremony)")}



def offline_preflight(media_dir=None, require_passphrase=False, env_name="AGI_SHARD_PASSPHRASE"):
    """Check the ceremony prerequisites and say exactly what is missing (no shard is touched)."""
    import os

    media = Path(media_dir) if media_dir else OFFLINE_DIR
    record = load_root()
    local = [s_["i"] for s_ in record.get("shards") or [] if _shard_path(s_["i"]).exists()]
    pw = os.environ.get(env_name) or ""
    problems, notes = [], []
    if require_passphrase and len(pw) < 12:
        problems.append(f"{env_name} is unset or shorter than 12 characters")
        notes.append("PowerShell 5.1: $env:AGI_SHARD_PASSPHRASE = [Runtime.InteropServices.Marshal]::"
                     "PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR("
                     "$(Read-Host -AsSecureString 'Passphrase')))")
    media_ok = False
    try:
        media.mkdir(parents=True, exist_ok=True)
        probe = media / ".agi-write-test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        media_ok = True
    except OSError as exc:
        problems.append(f"media path is not writable: {media} ({exc.strerror or exc})")
        notes.append("E: and F: in the runbook are placeholders for two DIFFERENT removable media; "
                     "use drives that exist, e.g. --out D:\\agi-root\\shard-1.json")
    if len(local) < 2:
        notes.append(f"only {len(local)} local shard(s): signing already requires offline retrieval")
    return {"ok": not problems, "problems": problems, "notes": notes,
            "root_key_id": record.get("root_key_id"), "threshold": record.get("threshold"),
            "local_shards": local, "media": str(media), "media_writable": media_ok,
            "passphrase_set": len(pw) >= 12,
            "next": ("root.py offline export --shard 1 --out <media A>\\shard-1.json  (then shard 2 to "
                     "media B, import both to verify, then offline remove --shard 1/2 --dir <media>)")}

def rehearse_offline(media_dir, passphrase="rehearsal-only-passphrase"):
    """Full dry-run of the ceremony: export -> remove local -> signing fails -> import -> signs again."""
    media = Path(media_dir)
    media.mkdir(parents=True, exist_ok=True)
    pw = passphrase.encode() if isinstance(passphrase, str) else passphrase
    record = load_root()
    results = {"exported": [], "steps": []}
    for idx in (1, 2):
        out = media / f"root-shard-{idx}.json"
        results["exported"].append(export_offline(idx, out, passphrase=pw))
    # keep the local files aside so the rehearsal can restore the operational state
    held = media / "_held-local"
    held.mkdir(exist_ok=True)
    moved = []
    for idx in (1, 2):
        src = _shard_path(idx)
        if src.exists():
            shutil.move(str(src), str(held / src.name))
            moved.append(idx)
    try:
        try:
            sign_with_shards(b"rehearsal", ["1", "2"])
            one_ok = True
        except Exception:
            one_ok = False
        results["steps"].append({"step": "sign with shards 1+2 after they went offline",
                                 "expected": "fail", "ok": not one_ok})
        imp1 = import_offline(media / "root-shard-1.json", passphrase=pw)
        results["steps"].append({"step": "import shard 1 from offline media", "ok": imp1["ok"]})
        try:
            env = sign_with_shards(b"rehearsal", ["1", "3"])
            sign_ok = env.get("root_key_id") == record["root_key_id"]
        except Exception as e:
            sign_ok = False
            results["sign_error"] = str(e)[:120]
        results["steps"].append({"step": "sign with 1 (imported) + 3 (local)", "expected": "ok", "ok": sign_ok})
        results["ok"] = all(s.get("ok") for s in results["steps"])
    finally:
        # restore the operational state: shard 1 imported copy is replaced by the held original,
        # shard 2 is put back, and the rehearsal packages are removed.
        if _shard_path(1).exists():
            _shard_path(1).unlink()
        for idx in moved:
            name = f"root_shard_{idx}.key"
            if (held / name).exists():
                shutil.move(str(held / name), str(_shard_path(idx)))
        shutil.rmtree(held, ignore_errors=True)
        for f in media.glob("root-shard-*.json"):
            f.unlink()
    results["restored_local_shards"] = [s["i"] for s in load_root().get("shards") or [] if _shard_path(s["i"]).exists()]
    return results


def load_root():
    if not ROOT_RECORD.exists():
        raise FileNotFoundError(f"no root ceremony yet at {ROOT_RECORD} (root.py ceremony init)")
    return json.loads(ROOT_RECORD.read_text(encoding="utf-8"))


def load_shard(i):
    p = _shard_path(i)
    if not p.exists():
        raise FileNotFoundError(f"shard {i} missing: {p}")
    blob = base64.b64decode(p.read_bytes())
    meta = next((s for s in load_root()["shards"] if s["i"] == int(i)), {})
    return int(i), _unseal(meta.get("sealed"), blob)


def sign_with_shards(payload: bytes, shard_ids):
    """Reconstruct the root in memory for one signing session; never persist the seed."""
    ids = [int(x) for x in shard_ids]
    if len(set(ids)) < K:
        raise ValueError(f"the root needs {K} distinct shards to sign (got {len(set(ids))})")
    points = [load_shard(i) for i in ids[:K]]
    seed = combine_shards(points)
    priv = _root_key(seed)
    pub = _root_pub(priv)
    record = load_root()
    if root_key_id(pub) != record["root_key_id"]:
        raise ValueError("reconstructed key does not match the pinned root key id (wrong or tampered shards)")
    sig = priv.sign(payload)
    return {
        "schema": SIG_SCHEMA,
        "alg": "ML-DSA-87",
        "root_key_id": record["root_key_id"],
        "public_key_b64": record["public_key_b64"],
        "payload_sha256": hashlib.sha256(payload).hexdigest(),
        "signature_b64": base64.b64encode(sig).decode("ascii"),
        "signed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "signed_with": f"{K}-of-{N} shards {sorted(ids[:K])}",
    }


def verify_root_signature(payload: bytes, env) -> dict:
    from cryptography.hazmat.primitives.asymmetric import mldsa

    if env.get("schema") != SIG_SCHEMA:
        return {"ok": False, "reason": f"unsupported signature schema {env.get('schema')!r}"}
    try:
        record = load_root()
    except FileNotFoundError as e:
        return {"ok": False, "reason": str(e)}
    if env.get("root_key_id") != record["root_key_id"]:
        return {"ok": False, "reason": "signed by a different root than the pinned one"}
    if hashlib.sha256(payload).hexdigest() != env.get("payload_sha256"):
        return {"ok": False, "reason": "payload hash mismatch (object changed after signing)"}
    try:
        pub = mldsa.MLDSA87PublicKey.from_public_bytes(base64.b64decode(env["public_key_b64"]))
        pub.verify(base64.b64decode(env["signature_b64"]), payload)
    except Exception as e:
        return {"ok": False, "reason": f"signature invalid: {type(e).__name__}"}
    return {"ok": True, "reason": "verified", "root_key_id": env.get("root_key_id")}


def verify_root():
    """Root record against its signed genesis statement (and shard presence)."""
    record = load_root()
    genesis = json.loads(GENESIS.read_text(encoding="utf-8")) if GENESIS.exists() else None
    problems = []
    if not genesis:
        problems.append("no signed genesis statement")
    else:
        body = {k: v for k, v in genesis.items() if k != "signature_b64"}
        from cryptography.hazmat.primitives.asymmetric import mldsa

        try:
            pub = mldsa.MLDSA87PublicKey.from_public_bytes(base64.b64decode(genesis["public_key_b64"]))
            pub.verify(base64.b64decode(genesis["signature_b64"]), crypto.canonical_json(body))
        except Exception as e:
            problems.append(f"genesis signature invalid: {type(e).__name__}")
        if genesis.get("root_key_id") != record.get("root_key_id"):
            problems.append("genesis root key id differs from the root record")
    present = [s["i"] for s in record.get("shards", []) if _shard_path(s["i"]).exists()]
    return {"ok": not problems, "root_key_id": record.get("root_key_id"), "threshold": record.get("threshold"),
            "shards_present": present, "problems": problems}


# ---------------------------------------------------------------- CLI
def _arg(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def cmd_ceremony(args):
    sub = args[0] if args else ""
    if sub != "init":
        print("usage: root.py ceremony init [--force]")
        return 2
    rec = ceremony_init(force="--force" in args)
    print(json.dumps({"ok": True, "root_key_id": rec["root_key_id"], "alg": rec["alg"],
                      "threshold": rec["threshold"], "shards": [s["i"] for s in rec["shards"]],
                      "sealed": [s["sealed"] for s in rec["shards"]],
                      "warning": "move 2 shards to offline media before any public release"}, indent=1))
    return 0


def cmd_shards(args):
    rec = load_root()
    print(json.dumps([{"i": s["i"], "file": s["file"], "sealed": s["sealed"],
                       "present": _shard_path(s["i"]).exists()} for s in rec["shards"]], indent=1))
    return 0


def cmd_show(args):
    print(json.dumps(load_root(), indent=1))
    return 0


def cmd_verify_root(args):
    r = verify_root()
    print(json.dumps(r, indent=1))
    return 0 if r["ok"] else 1


def cmd_sign(args):
    path = Path(_arg(args, "--file"))
    shards = [s.strip() for s in (_arg(args, "--shards", "1,2")).split(",") if s.strip()]
    env = sign_with_shards(path.read_bytes(), shards)
    out = Path(_arg(args, "--out", str(path) + ".rootsig.json"))
    out.write_text(json.dumps(env, indent=1), encoding="utf-8")
    print(json.dumps({"ok": True, "sig": str(out), "root_key_id": env["root_key_id"],
                      "signed_with": env["signed_with"]}, indent=1))
    return 0


def cmd_verify_file(args):
    path = Path(args[0])
    sig = Path(_arg(args, "--sig", str(path) + ".rootsig.json"))
    if not sig.exists():
        print(json.dumps({"ok": False, "reason": f"no root signature at {sig}"}, indent=1))
        return 1
    r = verify_root_signature(path.read_bytes(), json.loads(sig.read_text(encoding="utf-8")))
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_offline(args):
    sub = args[0] if args else "status"
    rest = args[1:]
    if sub == "status":
        print(json.dumps(offline_status(_arg(rest, "--dir")), indent=1))
        return 0
    if sub == "preflight":
        r = offline_preflight(_arg(rest, "--dir"), require_passphrase="--passphrase-required" in rest)
        print(json.dumps(r, indent=1))
        return 0 if r.get("ok") else 1
    if sub == "export":
        if not _arg(rest, "--shard") or not _arg(rest, "--out"):
            print("usage: root.py offline export --shard N --out <file>   (env AGI_SHARD_PASSPHRASE)")
            return 2
        try:
            r = export_offline(int(_arg(rest, "--shard")), _arg(rest, "--out"))
        except (RuntimeError, ValueError, OSError) as e:
            print(json.dumps({"ok": False, "stage": "export", "reason": str(e)}, indent=1))
            return 1
        print(json.dumps(r, indent=1))
        return 0
    if sub == "import":
        if not _arg(rest, "--file"):
            print("usage: root.py offline import --file <package>   (env AGI_SHARD_PASSPHRASE)")
            return 2
        try:
            r = import_offline(_arg(rest, "--file"))
        except (RuntimeError, ValueError, OSError) as e:
            print(json.dumps({"ok": False, "stage": "import", "reason": str(e)}, indent=1))
            return 1
        print(json.dumps(r, indent=1))
        return 0
    if sub == "remove":
        if not _arg(rest, "--shard"):
            print("usage: root.py offline remove --shard N [--dir <offline dir>]")
            return 2
        r = remove_local_shard(int(_arg(rest, "--shard")), _arg(rest, "--dir"))
        print(json.dumps(r, indent=1))
        return 0 if r.get("ok") else 1
    if sub == "rehearse":
        d = _arg(rest, "--dir") or str(OFFLINE_DIR)
        r = rehearse_offline(d)
        print(json.dumps(r, indent=1))
        return 0 if r.get("ok") else 1
    print("usage: root.py offline status|preflight|export|import|remove|rehearse")
    return 2


def selftest():
    import shutil
    import tempfile

    global KEYS, ROOT_RECORD, ROOT_DIR, GENESIS, LOGGING

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    secret = secrets.token_bytes(32)
    shards = split_secret(secret, 2, 3)
    check("3 shards are distinct", len({y for _, y in shards}) == 3)
    check("any 2 of 3 reconstruct the secret",
          all(combine_shards([shards[i], shards[j]]) == secret
              for i, j in ((0, 1), (0, 2), (1, 2))))
    check("one shard is not enough", len(shards[0][1]) == len(secret))
    bad = (shards[0][0], bytes(b ^ 0x01 for b in shards[0][1]))
    check("a tampered shard does not reconstruct", combine_shards([bad, shards[1]]) != secret)

    saved = (KEYS, ROOT_RECORD, ROOT_DIR, GENESIS, LOGGING, crypto.KEYS)
    tmp = Path(tempfile.mkdtemp(prefix="agi-root-test-"))
    try:
        LOGGING = False
        KEYS = tmp / "state" / "keys"
        ROOT_RECORD = KEYS / "root.json"
        ROOT_DIR = tmp / "state" / "root"
        GENESIS = ROOT_DIR / "genesis.json"
        crypto.KEYS = KEYS
        rec = ceremony_init(force=True)
        check("ceremony wrote an ML-DSA-87 root", rec["alg"] == "ML-DSA-87" and len(rec["root_key_id"]) == 16)
        check("3 sealed shards exist", all(_shard_path(i).exists() for i in (1, 2, 3)))
        check("root verifies against its genesis", verify_root()["ok"])
        check("no private seed file is written", not (KEYS / "root.key").exists())
        payload = b"the D genome may run here"
        env = sign_with_shards(payload, ["1", "2"])
        check("root signature verifies", verify_root_signature(payload, env)["ok"])
        check("tampered payload rejected", not verify_root_signature(payload + b"!", env)["ok"])
        try:
            sign_with_shards(payload, ["1"])
            single = True
        except ValueError:
            single = False
        check("one shard cannot sign", not single)
        env13 = sign_with_shards(payload, ["1", "3"])
        check("shards 1+3 also sign (any 2 of 3)", verify_root_signature(payload, env13)["ok"])
        # a replaced shard must not combine into a signature claiming the pinned root
        good = _shard_path(3).read_bytes()
        try:
            kind, blob = _seal(bytes(32))
            _shard_path(3).write_bytes(base64.b64encode(blob))
            try:
                sign_with_shards(payload, ["1", "3"])
                shard_ok = True
            except ValueError:
                shard_ok = False
            check("a replaced shard cannot sign as the pinned root", not shard_ok)
        finally:
            _shard_path(3).write_bytes(good)
    finally:
        (KEYS, ROOT_RECORD, ROOT_DIR, GENESIS, LOGGING, crypto.KEYS) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("root selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"ceremony": cmd_ceremony, "shards": cmd_shards, "show": cmd_show, "offline": cmd_offline,
             "verify-root": cmd_verify_root, "sign": cmd_sign, "verify-file": cmd_verify_file,
             "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

#!/usr/bin/env python3
"""birth.py - genetic birth: seed + genome -> DNA Gen.ID (no version numbers).

Identity model (biological, as D specified):
  * genotype: the ordered loci->alleles genome digest (subsystem content, not version numbers);
  * Gen.ID: 16 DNA codons derived from seed + genotype - the universal identity of the generation;
  * passport: the separate social identity (name/type/family), signed after the user opts in.
`migrate_legacy()` converts a v1 numeric Gen.ID birth record into a DNA Gen.ID while keeping the sealed seed.
"""
import json
import pathlib
import time

AGI = pathlib.Path(__file__).resolve().parents[2]
STATE = AGI / "state"

import evolution  # noqa: E402
import genome  # noqa: E402
import genid  # noqa: E402


def _jload(p, d=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return d


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def status(root=None):
    root = pathlib.Path(root) if root else AGI
    return _jload(root / "state" / "genesis" / "birth.json", {}) or {}


def birth(root=None, seed=None, family_interests=(), parent=None, write=True):
    root = pathlib.Path(root) if root else AGI
    seed = bytes(seed) if seed else genid.new_seed()
    if len(seed) < 16:
        raise ValueError("seed must be at least 128 bits")
    g = genome.genome(root)
    code = genome.codons(seed, g["digest"])
    rec = genid.compose_genetic(code, g["digest8"], parent=parent)
    cov = evolution.knowledge_map(root)
    natal = evolution.natal_interest(seed, cov, family_interests)
    out = {
        "schema": "agi-genesis/2",
        "gen_id": rec["display"], "canonical": rec["canonical"], "qr": genid.dna_uri(rec),
        "kind": "dna", "genome": g, "genome8": g["digest8"],
        "seed_fp": genid.seed8(seed), "seed_commitment": genid.seed_commitment(seed),
        "parent": parent, "born": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "natal_interest": natal, "knowledge_map": cov, "checksum": rec["checksum"],
    }
    if write:
        gdir = root / "state" / "genesis"
        gdir.mkdir(parents=True, exist_ok=True)
        (gdir / "seed.bin").write_bytes(seed)
        try:
            (gdir / "seed.bin").chmod(0o600)
        except Exception:
            pass
        _jdump(gdir / "birth.json", out)
        _jdump(gdir / "genome.json", genome.describe(root))
    return {"ok": True, **out}


def verify(root=None):
    root = pathlib.Path(root) if root else AGI
    rec = status(root)
    if not rec:
        return {"ok": True, "skipped": "no generation born yet"}
    problems = []
    try:
        gen = genid.parse_genetic(rec["canonical"])
        if not genid.validate_genetic({"canonical": rec["canonical"], "display": rec["gen_id"]}):
            problems.append("Gen.ID invalid")
        seed_file = root / "state" / "genesis" / "seed.bin"
        if seed_file.is_file():
            seed = seed_file.read_bytes()
            if genid.seed_commitment(seed) != rec.get("seed_commitment"):
                problems.append("seed commitment mismatch")
            gdig = (rec.get("genome") or {}).get("digest")
            if not gdig:
                problems.append("genome digest missing from birth record")
            else:
                code = genome.codons(seed, gdig)
                if genid.compose_genetic(code, rec.get("genome8") or "").get("canonical") != rec["canonical"]:
                    problems.append("DNA Gen.ID does not reproduce from seed + recorded genome")
                natal = evolution.natal_interest(seed, rec.get("knowledge_map") or {},
                                                 (rec.get("natal_interest") or {}).get("family_covered") or [])
                if natal["domain"] != (rec.get("natal_interest") or {}).get("domain"):
                    problems.append("natal interest does not reproduce")
        else:
            problems.append("sealed seed missing")
        drift = None
        if (rec.get("genome") or {}).get("digest"):
            now = genome.genome(root)
            if now["digest"] != rec["genome"]["digest"]:
                drift = {"recorded": rec["genome"]["digest8"], "current": now["digest8"],
                         "note": "subsystems changed since birth: recorded as mutation, not identity"}
        return {"ok": not problems, "problems": problems, "gen_id": rec.get("gen_id"),
                "genome": (rec.get("genome") or {}).get("digest8"), "drift": drift}
    except Exception as e:
        return {"ok": False, "problems": [str(e)[:200]]}


def migrate_legacy(root=None):
    """Convert a numeric v1 birth record into a DNA Gen.ID, keeping the sealed seed and archiving the old record."""
    root = pathlib.Path(root) if root else AGI
    rec = status(root)
    gdir = root / "state" / "genesis"
    seed_file = gdir / "seed.bin"
    if not rec or rec.get("kind") == "dna":
        return {"ok": True, "skipped": "already genetic", "gen_id": rec.get("gen_id")}
    if not seed_file.is_file():
        return {"ok": False, "error": "sealed seed missing; cannot re-derive genetic identity"}
    _jdump(gdir / "birth_v1_legacy.json", rec)
    seed = seed_file.read_bytes()
    parent = rec.get("parent")
    out = birth(root, seed=seed, family_interests=[], parent=parent)
    return {"ok": out.get("ok"), "from": rec.get("gen_id"), "to": out.get("gen_id"),
            "archived": "state/genesis/birth_v1_legacy.json"}


if __name__ == "__main__":
    import sys
    if "--status" in sys.argv:
        print(json.dumps({"birth": status(), "verify": verify()}, indent=1))
    elif "--migrate" in sys.argv:
        print(json.dumps(migrate_legacy(), indent=1))
    else:
        print(json.dumps(birth(), indent=1))

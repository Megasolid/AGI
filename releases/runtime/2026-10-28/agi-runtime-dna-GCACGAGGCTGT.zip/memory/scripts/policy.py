#!/usr/bin/env python3
"""policy.py - the evolvable policy layer of AGI (invariants vs policy chromosomes).

P57 resolutions are encoded as bounded policy genes: benchmark scope/rotation, tier thresholds,
confidence weights/sample rates, rough quotas, simulation fidelity, and the L4 branding boundary.
Everything here is a PROPOSAL until approved through the governance path; validate() refuses out-of-bounds
mutations and seal() records the invariants hash a generation must preserve.
"""
import hashlib
import json
import pathlib

AGI = pathlib.Path(__file__).resolve().parents[2]

INVARIANTS = [
    "identity and trust model (genome, passport, signed lineage)",
    "passport/lifecycle integrity (alive/sleeping/dead, kill hierarchy)",
    "privacy boundary (hot knowledge and user data stay with their member)",
    "rank and authority are not purchasable (no plutocracy)",
    "auditability (every consequential change signed in the trust log)",
    "safety and user rights (self-kill, pause, consent)",
    "human supervision of brand identity, safety messaging, legal/consent text",
]

POLICIES = {
    "benchmark": {
        "families": ["boot", "memory", "tools", "code", "verification", "long_context",
                     "multimodal", "ui_generation", "safety", "maintenance"],
        "tasks_per_family": 12,
        "sets": {"public_retained": 2, "holdout_rotate_days": 90, "canary_rotate_days": 7,
                 "canary_size": 20, "hidden_retained": 1},
        "thresholds": {"vcr_gate": 0.90, "anchor": "reference_5th_percentile", "reanchor": "per_generation",
                       "contamination_probe": True},
        "ownership": "AGI Brain Lab; signed suite; independent runs; no self-grading",
    },
    "tiers": {
        "labels": ["T0", "T1", "T2", "T3", "T4"],
        "gates": {"tool_contract": True, "safety": True, "no_rule_drop": True},
        "profiles": ["instruction", "tool_calls", "structured_output", "context", "planning",
                     "code", "cost_latency", "stability", "privacy"],
        "median_source": "usage_weighted_median_alive_members",
        "reevaluate_days": 30,
    },
    "confidence": {
        "weights": {"functional_a11y": 30, "anomaly_budget": 20, "human_agreement": 20,
                    "review_history": 15, "calibration": 10, "stability": 5},
        "sample_rates": {"L1": 1.0, "L2": 0.10, "L3": 0.25, "L4": 0.05},
        "thresholds": {"L3_lower_bound": 0.97, "L4_lower_bound": 0.99,
                       "L3_min_reviews": 20, "L4_min_reviews": 50, "anomaly_breaches_allowed": 0},
        "calibration": {"metric": "Brier+ECE_resolution", "reweight_days": 90},
    },
    "rough": {
        "extractions_per_month": 2, "max_mb": 100, "max_artifacts": 2000,
        "quarantine_hours": 24, "xp_awarded": 0, "mana_eligible": False,
        "observer": "council", "quota_scope": "per_official_member",
    },
    "simulation": {
        "stages": ["analytical_bounds", "monte_carlo_members", "shadow_generation", "canary_subset"],
        "divergence_threshold": 0.15, "rollback": True, "approval": "council_or_master",
    },
    "branding": {
        "L4_allowed": ["layout", "motion", "typography"],
        "human_only": ["brand identity", "safety messaging", "legal and consent text",
                       "pricing and attention requests", "security notices"],
        "L3_requires": "council_post_audit",
    },
    "mana": {"enabled": False, "gifting": False, "weak_model_compensation": True,
             "caps_per_day": 0, "note": "dormant gene; can evolve when fairness simulation passes"},
    "seeding": {"min_projected_gain": 0.10, "min_confidence": 0.80, "min_absence_days": 7,
                "council_cosign": True, "no_user_interaction_in_acting_mode": True,
                "rollback_required": True, "note": "D rule: seed when the next design is ~10% better, "
                                                   "or a capability is blocked; AGI acts as Master while D is absent"},
}
BOUNDS = {
    ("confidence", "sample_rates", "L2"): (0.0, 1.0),
    ("confidence", "sample_rates", "L3"): (0.0, 1.0),
    ("confidence", "sample_rates", "L4"): (0.0, 1.0),
    ("confidence", "thresholds", "L3_lower_bound"): (0.5, 1.0),
    ("confidence", "thresholds", "L4_lower_bound"): (0.5, 1.0),
    ("benchmark", "tasks_per_family"): (4, 40),
    ("rough", "extractions_per_month"): (0, 6),
    ("rough", "max_mb"): (1, 1024),
    ("simulation", "divergence_threshold"): (0.0, 1.0),
}


def seal():
    """Hash of the invariants a generation must preserve across evolution."""
    canon = json.dumps(INVARIANTS, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(b"agi/invariants/v1:" + canon.encode()).hexdigest()


def _overrides_path(root=None):
    return (pathlib.Path(root) if root else AGI) / "state" / "policy.json"


def overrides(root=None):
    try:
        return json.loads(_overrides_path(root).read_text(encoding="utf-8"))
    except Exception:
        return {}


def current(root=None):
    """Defaults merged with persisted policy overrides (state/policy.json)."""
    import copy
    base = copy.deepcopy(POLICIES)
    ov = overrides(root)
    for section, fields in (ov.get("sections") or {}).items():
        if section in base and isinstance(fields, dict):
            base[section].update(fields)
    if ov.get("_meta"):
        base["_meta"] = ov["_meta"]
    return base


def validate(policy=None, bounds=None):
    policy = policy if policy is not None else current()
    bounds = bounds or BOUNDS
    problems = []
    for path, (lo, hi) in bounds.items():
        node = policy
        try:
            for part in path:
                node = node[part]
        except (KeyError, TypeError):
            problems.append("%s missing" % ".".join(path))
            continue
        if not isinstance(node, (int, float)) or not (lo <= node <= hi):
            problems.append("%s out of bounds [%s, %s]: %r" % (".".join(path), lo, hi, node))
    w = ((policy.get("confidence") or {}).get("weights") or {})
    if abs(sum(w.values()) - 100) > 0.01:
        problems.append("confidence weights must sum to 100 (got %r)" % sum(w.values()))
    sim = (policy.get("simulation") or {}).get("stages") or []
    order = POLICIES["simulation"]["stages"]
    if sim != order and sorted(sim) != sorted(order):
        problems.append("simulation stages must be exactly %r" % order)
    brand = (policy.get("branding") or {}).get("L4_allowed") or []
    if any(x in brand for x in ("brand identity", "safety messaging", "legal and consent text")):
        problems.append("L4 must never cover human-only branding classes")
    return {"ok": not problems, "problems": problems, "invariants_hash": seal()}


def simulate(policy=None, stage="analytical_bounds"):
    """Cheap fidelity ladder: estimate review load / risk before any real application."""
    policy = policy if policy is not None else current()
    rates = (policy.get("confidence") or {}).get("sample_rates") or {}
    changes = 40  # per release, synthetic planning number
    load = {"reviews_per_release": int(changes * (rates.get("L2", .1) if stage == "analytical_bounds" else
                                                  rates.get("L3", .25)) + 2),
            "stage": stage, "rollback": bool((policy.get("simulation") or {}).get("rollback"))}
    rough = policy.get("rough") or {}
    load["rough_extractions_per_month"] = int(rough.get("extractions_per_month") or 0)
    load["risk"] = "low" if load["reviews_per_release"] <= 8 else "medium"
    return load


def evolve(policy, proposal, approved_by=None, persist=True):
    """Apply a bounded mutation to a policy gene; requires an approver (governance gate)."""
    if not approved_by:
        return {"ok": False, "error": "policy mutation requires an approver (council or master)"}
    import copy
    new = copy.deepcopy(policy or POLICIES)
    for section, fields in (proposal or {}).items():
        if section not in new:
            return {"ok": False, "error": "unknown policy section %r" % section}
        if not isinstance(fields, dict):
            return {"ok": False, "error": "proposal for %r must be a dict of genes" % section}
        for key, value in fields.items():
            new[section][key] = value
    v = validate(new)
    if not v["ok"]:
        return {"ok": False, "error": "out of bounds", "problems": v["problems"]}
    new["_meta"] = {"revision": int((policy.get("_meta") or {}).get("revision") or 0) + 1,
                    "approved_by": approved_by, "invariants_hash": seal()}
    try:
        if not persist:
            raise RuntimeError("selftest: no persistence")
        sections = {k: v for k, v in new.items() if k != "_meta"}
        path = _overrides_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"schema": "agi-policy/1", "sections": sections, "_meta": new["_meta"]}, indent=1),
                        encoding="utf-8")
        import trust_log
        trust_log.append("policy.evolved", {"revision": new["_meta"]["revision"],
                                            "approved_by": approved_by,
                                            "sections": sorted((proposal or {}).keys())})
    except Exception:
        pass
    return {"ok": True, "policy": new}


def selftest():
    checks = []
    v = validate()
    checks.append(("default policy validates", v["ok"], v["problems"]))
    checks.append(("invariants hash stable", seal() == seal() and len(seal()) == 64, seal()))
    s = simulate(stage="monte_carlo_members")
    checks.append(("simulation returns review load", "reviews_per_release" in s and s["reviews_per_release"] > 0, s))
    bad = evolve(POLICIES, {"confidence": {"sample_rates": {"L2": 2.0}}}, approved_by="test")
    checks.append(("out-of-bounds mutation refused", not bad["ok"], bad))
    good = evolve(POLICIES, {"rough": {"extractions_per_month": 3}}, approved_by="council", persist=False)
    checks.append(("bounded mutation accepted", good["ok"], good.get("error")))
    checks.append(("L4 branding boundary enforced",
                   "brand identity" in (POLICIES["branding"]["human_only"]), POLICIES["branding"]))
    n = sum(1 for c in checks if c[1])
    for name, ok, detail in checks:
        print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))
    print("policy selftest: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    print(json.dumps({"invariants": INVARIANTS, "invariants_hash": seal(),
                      "policy": POLICIES, "validation": validate()}, indent=1))

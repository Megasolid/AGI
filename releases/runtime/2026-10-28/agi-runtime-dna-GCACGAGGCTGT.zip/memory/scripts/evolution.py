#!/usr/bin/env python3
"""evolution.py - seeded, biological birth for an AGI generation.

The birth seed (256-bit, sealed) determines a unique Gen.ID and the generation's **natal interest**: an
intrinsic-motivation target chosen from the fields where this AGI knows least, with niches already occupied by
living family members down-weighted (POET-style novelty). Every generation therefore starts with one new
curiosity, and the family as a whole explores its weakest knowledge instead of converging.
"""
import hashlib
import hmac
import json
import pathlib
import secrets
import time

AGI = pathlib.Path(__file__).resolve().parents[2]
STATE = AGI / "state"

import genid  # noqa: E402

DOMAINS = ["engineering", "research", "writing", "data", "design",
           "ops", "security", "social", "finance", "health", "culture"]
KEYWORDS = {
    "engineering": ["code", "script", "python", "build", "install", "runtime", "test", "bug", "api", "repo"],
    "research": ["research", "paper", "study", "evidence", "hypothesis", "survey", "analysis", "cite"],
    "writing": ["write", "doc", "document", "readme", "manual", "draft", "editorial", "copy"],
    "data": ["data", "json", "csv", "database", "index", "metric", "log", "statistics", "query"],
    "design": ["design", "ui", "ux", "layout", "css", "figma", "color", "typography", "dashboard"],
    "ops": ["deploy", "server", "systemd", "backup", "monitor", "release", "ci", "maintenance", "task"],
    "security": ["security", "crypto", "signature", "key", "trust", "attestation", "verify", "pqc"],
    "social": ["user", "people", "team", "community", "message", "chat", "family", "member", "trustee"],
    "finance": ["finance", "cost", "budget", "price", "token", "revenue", "billing", "payment"],
    "health": ["health", "sleep", "exercise", "medical", "wellbeing", "stress", "blood", "clinic"],
    "culture": ["culture", "history", "art", "music", "film", "story", "language", "philosophy", "poetry"],
}


def _jload(p, default=None):
    try:
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def _jdump(p, obj):
    pathlib.Path(p).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(p).write_text(json.dumps(obj, indent=1), encoding="utf-8")


def sources(root=None):
    """Text corpus for the knowledge map: lessons, capability registry, knowledge docs, public docs."""
    root = pathlib.Path(root) if root else AGI
    chunks = []
    for rel in ("memory/knowledge/pills.md", "core/dna.md", "state/repo/AGI/README.md",
                "state/repo/AGI/INSTALL_PROMPT.md"):
        p = root / rel
        try:
            if p.is_file():
                chunks.append(p.read_text(encoding="utf-8", errors="ignore")[:200000])
        except OSError:
            pass
    reg = _jload(root / "memory" / "scripts" / "registry.json", {}) or {}
    for name, e in (reg.get("scripts") or {}).items():
        chunks.append(name + " " + " ".join(str(x) for x in (e.get("tags") or [])) + " " +
                      str(e.get("purpose") or "")[:200])
    kdir = root / "memory" / "knowledge"
    try:
        for p in sorted(kdir.glob("*.md"))[:80]:
            chunks.append(p.name + " " + p.read_text(encoding="utf-8", errors="ignore")[:4000])
    except OSError:
        pass
    return "\n".join(chunks).lower()


def knowledge_map(root=None):
    text = sources(root)
    hits = {d: 0 for d in DOMAINS}
    for d, words in KEYWORDS.items():
        for w in words:
            hits[d] += text.count(w)
    mx = max(hits.values()) or 1
    return {d: {"hits": hits[d], "coverage": round(hits[d] / mx, 4)} for d in DOMAINS}


def natal_interest(seed, coverage, family_interests=()):
    """Pick the generation's curiosity: weakest fields, novelty-weighted, deterministic for a seed."""
    if not isinstance(seed, (bytes, bytearray)):
        raise TypeError("seed must be bytes")
    fam = set(x.lower() for x in (family_interests or []))
    # candidates: the lowest-coverage half of the fields
    ordered = sorted(DOMAINS, key=lambda d: coverage[d]["coverage"])
    candidates = ordered[: max(1, len(ordered) // 2)]
    weights = {}
    for d in candidates:
        w = (1.0 - coverage[d]["coverage"]) ** 2 + 0.05
        if d in fam:
            w *= 0.35  # a living family member already occupies this niche
        weights[d] = w
    total = sum(weights.values())
    digest = hmac.new(bytes(seed), b"agi/natal-interest/v1", hashlib.sha256).digest()
    r = int.from_bytes(digest[:8], "big") / float(1 << 64) * total
    acc = 0.0
    chosen = candidates[-1]
    for d in candidates:
        acc += weights[d]
        if r <= acc:
            chosen = d
            break
    return {"domain": chosen, "weights": {k: round(v, 4) for k, v in weights.items()},
            "candidates": candidates, "family_covered": sorted(fam & set(DOMAINS)),
            "reason": "lowest-coverage fields, novelty-weighted by family niches"}


def genesis_status(root=None):
    root = pathlib.Path(root) if root else AGI
    return _jload(root / "state" / "genesis" / "birth.json", {}) or {}


def birth(root=None, seed=None, family_interests=(), core="3.2", gen=None, parent=None, write=True):
    """Soul -> member step: derive Gen.ID from the seed and assign the natal interest."""
    root = pathlib.Path(root) if root else AGI
    existing = genesis_status(root)
    if existing and not parent and not gen:
        return {"ok": False, "error": "generation already born", "existing": existing.get("gen_id")}
    seed = bytes(seed) if seed else genid.new_seed()
    if len(seed) < 16:
        raise ValueError("seed must be at least 128 bits")
    seed8 = genid.seed8(seed)
    g = int(gen or ((existing.get("gen") or 0) + 1))
    rec = genid.compose(core, g, seed8, parent=parent)
    cov = knowledge_map(root)
    natal = natal_interest(seed, cov, family_interests)
    out = {
        "schema": "agi-genesis/1",
        "gen_id": rec["display"], "canonical": rec["canonical"], "qr": genid.qr_uri(rec),
        "core": core, "gen": g, "seed8": seed8,
        "seed_commitment": genid.seed_commitment(seed),
        "parent": parent, "born": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "natal_interest": natal, "knowledge_map": cov,
        "checksum": rec["checksum"],
    }
    if write:
        gdir = root / "state" / "genesis"
        gdir.mkdir(parents=True, exist_ok=True)
        (gdir / "seed.bin").write_bytes(bytes(seed))
        try:
            (gdir / "seed.bin").chmod(0o600)
        except Exception:
            pass
        _jdump(gdir / "birth.json", out)
    return {"ok": True, **out}


def verify_birth(root=None):
    root = pathlib.Path(root) if root else AGI
    rec = genesis_status(root)
    if not rec:
        return {"ok": True, "skipped": "no generation born yet"}
    try:
        gen = genid.parse_canonical(rec["canonical"])
        problems = []
        if not genid.validate(gen):
            problems.append("Gen.ID invalid")
        seed_file = root / "state" / "genesis" / "seed.bin"
        if seed_file.is_file():
            seed = seed_file.read_bytes()
            if genid.seed8(seed) != rec["seed8"]:
                problems.append("seed8 does not match sealed seed")
            if genid.seed_commitment(seed) != rec["seed_commitment"]:
                problems.append("seed commitment mismatch")
            natal = natal_interest(seed, rec.get("knowledge_map") or knowledge_map(root),
                                   (rec.get("natal_interest") or {}).get("family_covered") or [])
            if natal["domain"] != (rec.get("natal_interest") or {}).get("domain"):
                problems.append("natal interest does not reproduce from seed")
        else:
            problems.append("sealed seed missing")
        return {"ok": not problems, "problems": problems, "gen_id": rec["gen_id"]}
    except Exception as e:
        return {"ok": False, "problems": [str(e)[:200]]}


if __name__ == "__main__":
    import sys
    if "--status" in sys.argv:
        print(json.dumps({"birth": genesis_status(), "verify": verify_birth()}, indent=1))
    else:
        print(json.dumps(birth(), indent=1))

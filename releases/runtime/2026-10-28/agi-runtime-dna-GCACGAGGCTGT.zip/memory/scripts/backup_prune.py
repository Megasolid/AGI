#!/usr/bin/env python3
"""backup_prune - backups retention/rotation policy (housekeeping L1, D-approved 2026-10-25).

Policy (defaults, changeable):
  * keep the newest N dated backup items (dirs or files)  -> --keep-newest 10
  * always keep "protected" families: current core/DNA/manifest backups, rollback bundles,
    gen2 archive, audit/hygiene/legacy archives, and anything dated within --keep-days 2
  * prune only inside <skill>/memory/backups, never symlinks, never the current generation
  * dry-run by default; --apply performs the deletions; the decision is written to
    state/backup_retention.json (policy, kept, pruned, bytes) and printed as a table

usage:
  backup_prune.py [--keep-newest N] [--keep-days N] [--apply] [--json]
"""
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
BACKUPS = AGI / "memory" / "backups"
STATE = AGI / "state"
REPORT = STATE / "backup_retention.json"

PROTECT_RE = re.compile(
    r"(dna_v\d+_backup|SKILL_v\d+_\d+_backup|core_manifest_v\d+_\d+_backup|agi_gen2_backup|"
    r"core_bundles_retired|audit_\d{8}|hygiene_\d{8}|legacy_\w+_\d{8})",
    re.I,
)
DATE_RE = re.compile(r"(20\d{2})[-_]?(\d{2})[-_]?(\d{2})")


def _dated(name):
    m = DATE_RE.search(name)
    if not m:
        return None
    try:
        return time.mktime(time.strptime("%s-%s-%s" % m.groups(), "%Y-%m-%d"))
    except Exception:
        return None


def _items():
    out = []
    if not BACKUPS.is_dir():
        return out
    for p in sorted(BACKUPS.iterdir()):
        if p.name.startswith(".") or p.is_symlink():
            continue
        out.append(p)
    return out


def _size(p):
    if p.is_file():
        try:
            return p.stat().st_size
        except Exception:
            return 0
    total = 0
    for root, _dirs, files in os.walk(p):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except Exception:
                pass
    return total


def _human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return "%.1f %s" % (n, unit) if unit != "B" else "%d B" % n
        n /= 1024.0


def plan(keep_newest=10, keep_days=2):
    items = _items()
    dated = [(p, _dated(p.name)) for p in items]
    dated = [(p, d) for p, d in dated if d is not None]
    dated.sort(key=lambda x: x[1], reverse=True)
    newest = {p.name for p, _ in dated[:keep_newest]}
    cutoff = time.time() - keep_days * 86400
    protected = []
    prune = []
    undated = []
    for p in items:
        d = _dated(p.name)
        if p.name in newest or PROTECT_RE.search(p.name) or (d is not None and d >= cutoff):
            protected.append(p)
        elif d is None:
            undated.append(p)  # no date: never auto-prune
        else:
            prune.append(p)
    return {
        "keep_newest": keep_newest,
        "keep_days": keep_days,
        "protected": [(p.name, _size(p)) for p in protected],
        "prune": [(p.name, _size(p)) for p in prune],
        "undated": [(p.name, _size(p)) for p in undated],
        "prune_bytes": sum(s for _, s in [(p.name, _size(p)) for p in prune]),
        "total_bytes": sum(_size(p) for p in items),
    }


def apply(plan_data):
    started = time.time()
    freed = 0
    removed = []
    for name, _size_v in plan_data["prune"]:
        target = BACKUPS / name
        # safety: resolve and re-check the location before any delete
        resolved = target.resolve()
        if BACKUPS.resolve() not in resolved.parents and resolved != BACKUPS.resolve():
            raise SystemExit("refusing to delete outside backups: %s" % resolved)
        if PROTECT_RE.search(name):
            continue
        try:
            freed_before = _size(target)
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink()
            freed += freed_before
            removed.append(name)
        except Exception as exc:
            print("prune failed: %s (%s)" % (name, exc), file=sys.stderr)
    record = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "policy": {"keep_newest": plan_data["keep_newest"], "keep_days": plan_data["keep_days"]},
        "kept": len(plan_data["protected"]),
        "pruned": removed,
        "freed_bytes": freed,
        "freed_human": _human(freed),
        "total_before": plan_data["total_bytes"],
        "total_after": plan_data["total_bytes"] - freed,
        "dur_ms": int((time.time() - started) * 1000),
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(record, indent=1, ensure_ascii=False), encoding="utf-8")
    return record


def _arg(args, name, default=None):
    if name in args:
        try:
            return args[args.index(name) + 1]
        except Exception:
            return default
    return default


def main():
    args = sys.argv[1:]
    keep_newest = int(_arg(args, "--keep-newest", 10))
    keep_days = int(_arg(args, "--keep-days", 2))
    p = plan(keep_newest, keep_days)
    print("BACKUP RETENTION POLICY: keep newest %d dated items + items within %d day(s) + protected families"
          % (keep_newest, keep_days))
    print("  protected: %d items" % len(p["protected"]))
    print("  prune candidates: %d items, %s (of %s total)"
          % (len(p["prune"]), _human(p["prune_bytes"]), _human(p["total_bytes"])))
    for name, size in p["prune"]:
        print("    - %-42s %10s" % (name, _human(size)))
    if p["undated"]:
        print("  undated (never auto-pruned): %s" % ", ".join(n for n, _ in p["undated"]))
    if "--apply" in args:
        rec = apply(p)
        print("PRUNED %d items, freed %s (before %s -> after %s)"
              % (len(rec["pruned"]), rec["freed_human"], _human(rec["total_before"]), _human(rec["total_after"])))
        print("state -> %s" % REPORT)
    else:
        print("DRY RUN - nothing deleted. Re-run with --apply to prune.")
    if "--json" in args:
        print(json.dumps(p, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

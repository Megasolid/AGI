#!/usr/bin/env python
"""Build/update the embedding index over all memory files.

Scans state/, knowledge/, and skills/ for .md files, chunks by ## headers,
embeds through an explicitly configured provider, saves to index/.

Usage:
    python memory_embed.py          # rebuild full index
    python memory_embed.py --quiet  # no progress output
"""
import os, sys, json, re, time
from pathlib import Path
from embedding_backend import backend_config, embed_texts, write_npy

MEM_DIR = Path(__file__).resolve().parent.parent  # .../memory/
INDEX_DIR = Path(os.environ.get("AGI_EMBEDDING_INDEX_DIR", MEM_DIR / "index"))
MAX_CHUNK_CHARS = 800  # compact chunks, roughly 200 tokens
SKILLS_ROOT = MEM_DIR.parent.parent

# Directories to scan (relative to MEM_DIR)
SCAN_DIRS = [
    MEM_DIR / "state",
    MEM_DIR / "knowledge",
    SKILLS_ROOT,
]
# Derived/stale trees are NEVER indexed (I5 spirit: backups/staging/temp are not live knowledge).
# 2026-10-19 cluster fix: old index was 93% near-duplicates from these dirs.
EXCLUDE_DIRS = {"backups", "bundle_stage", "temp", "corpus", ".cache", "__pycache__", "node_modules"}
def chunk_markdown(text: str, source: str) -> list[dict]:
    """Split markdown into chunks by ## headers. Long sections get split further."""
    chunks = []
    # Split on ## headers (keep the header as part of the chunk)
    parts = re.split(r'^(#{1,3} .+)$', text, flags=re.MULTILINE)

    current_header = source  # filename as fallback header
    buf = ""

    for part in parts:
        if re.match(r'^#{1,3} .+$', part.strip()):
            # Flush previous buffer
            if buf.strip():
                _flush(buf.strip(), current_header, source, chunks)
            current_header = part.strip().lstrip('#').strip()
            buf = ""
        else:
            buf += part

    # Flush last
    if buf.strip():
        _flush(buf.strip(), current_header, source, chunks)

    return chunks


def _flush(text: str, header: str, source: str, chunks: list):
    """Add text to chunks, splitting if too long."""
    if len(text) <= MAX_CHUNK_CHARS:
        chunks.append({"text": text, "header": header, "source": source})
    else:
        # Split by paragraphs
        paras = text.split('\n\n')
        buf = ""
        for p in paras:
            if len(buf) + len(p) + 2 > MAX_CHUNK_CHARS and buf:
                chunks.append({"text": buf.strip(), "header": header, "source": source})
                buf = ""
            buf += p + "\n\n"
        if buf.strip():
            chunks.append({"text": buf.strip(), "header": header, "source": source})


def collect_files() -> list[Path]:
    """Find all .md files to index."""
    files = []
    seen = set()
    for d in SCAN_DIRS:
        if not d.exists():
            continue
        for f in sorted(d.rglob("*.md")):
            # Include SKILL.md files — they contain useful procedural knowledge
            names = {p.lower() for p in f.parts}
            if names & EXCLUDE_DIRS or f.name.endswith(".bak"):
                continue
            rf = f.resolve()
            if rf in seen:
                continue
            seen.add(rf)
            files.append(f)
    # Standalone policy file at memdir root (not under a scan dir)
    policies = MEM_DIR / "policies.md"
    if policies.exists() and policies not in files:
        files.append(policies)
    return files


def main():
    quiet = "--quiet" in sys.argv
    t0 = time.time()
    try:
        config = backend_config()
    except RuntimeError as exc:
        print(f"Embedding backend configuration error: {exc}", file=sys.stderr)
        return 2

    if not quiet:
        print(f"Memory Embedding Index Builder ({config['backend']}/{config['model']})")
        print(f"  Scan dirs: {[str(d) for d in SCAN_DIRS]}")

    # Collect and chunk
    files = collect_files()
    if not quiet:
        print(f"  Files found: {len(files)}")

    all_chunks = []
    per_file_counts = {}
    for f in files:
        # Normalized POSIX source path, relative to memdir or skill root (never absolute,
        # never mixed dialects - old index had 4 path notations for the same file).
        try:
            rel = f.relative_to(MEM_DIR).as_posix()
        except ValueError:
            try:
                rel = f.relative_to(SKILLS_ROOT).as_posix()
            except ValueError:
                rel = f.as_posix()
        try:
            text = f.read_text(encoding="utf-8")
        except Exception as e:
            if not quiet:
                print(f"  WARN: could not read {f}: {e}")
            continue
        chunks = chunk_markdown(text, rel)
        per_file_counts[rel] = len(chunks)
        all_chunks.extend(chunks)

    if not all_chunks:
        print("No chunks to index.")
        return

    if not quiet:
        print(f"  Total chunks: {len(all_chunks)}")

    # Embed
    texts = [c["text"] for c in all_chunks]
    if not quiet:
        print(f"  Embedding {len(texts)} chunks...")
    embeddings, backend = embed_texts(texts, config=config)

    # Save
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    write_npy(INDEX_DIR / "embeddings.npy", embeddings)
    with open(INDEX_DIR / "chunks.json.tmp", "w", encoding="utf-8") as fp:
        json.dump(all_chunks, fp, ensure_ascii=False, indent=1)
    os.replace(INDEX_DIR / "chunks.json.tmp", INDEX_DIR / "chunks.json")

    # Cluster manifest (DNA v2 §5b: confidence is per knowledge field = per cluster).
    # Each live .md file is one cluster; KEP results update confidence/last_verified here.
    import datetime
    clusters = {}
    for rel, n in sorted(per_file_counts.items()):
        title = rel.rsplit("/", 1)[-1]
        try:
            head = (MEM_DIR / rel).read_text(encoding="utf-8", errors="ignore") if (MEM_DIR / rel).exists() else (SKILLS_ROOT / rel).read_text(encoding="utf-8", errors="ignore")
            for line in head.splitlines():
                if line.startswith("# "):
                    title = line[2:].strip()
                    break
        except Exception:
            pass
        clusters[rel] = {
            "title": title,
            "chunks": n,
            "confidence": "unverified",   # KEP (dna.md §5b) promotes: unverified -> low/med/high
            "last_verified": None,
        }
    with open(INDEX_DIR / "clusters.json.tmp", "w", encoding="utf-8") as fp:
        json.dump({"generated": datetime.date.today().isoformat(), "fields": clusters}, fp, ensure_ascii=False, indent=1)
    os.replace(INDEX_DIR / "clusters.json.tmp", INDEX_DIR / "clusters.json")

    with open(INDEX_DIR / "provider.json.tmp", "w", encoding="utf-8") as fp:
        json.dump({**backend, "chunks": len(all_chunks),
                   "generated": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")},
                  fp, ensure_ascii=False, indent=1)
    os.replace(INDEX_DIR / "provider.json.tmp", INDEX_DIR / "provider.json")

    elapsed = time.time() - t0
    print(f"  Done in {elapsed:.1f}s")
    print(f"  Index: {INDEX_DIR / 'embeddings.npy'} ({backend['dimensions']}-dim; {backend['backend']}/{backend['model']})")
    print(f"  Chunks: {INDEX_DIR / 'chunks.json'} ({len(all_chunks)} entries)")


if __name__ == "__main__":
    raise SystemExit(main() or 0)

#!/usr/bin/env python3
"""passport.py - Trust Layer L1 (P2): the AGI passport, rooted in the user genome.

A passport is the family member's identity: who this AGI is, which bundle it belongs to,
which genome epoch it runs, which device key signs for it, and which generation produced it.
It is a signed credential, not a licence key - it can be verified offline and it evolves by
signed transitions, so "the genome changed" is a proof-carrying history, not a claim.

Design
  * The USER GENOME is a Merkle-ised tree of personal invariants / preferences / memory roots
    (never raw DNA, never biometrics). state/genome/tree.json holds the current entries and
    root; every change appends a signed transition to state/genome/transitions.jsonl and bumps
    the epoch.
  * The PASSPORT (state/passport.json + .sig) carries only the genome ROOT and epoch, plus
    identity, bundle class, lineage and capabilities. It is re-signed atomically whenever the
    genome moves, so a mismatch between passport and genome is evidence of tampering.
  * Capabilities are declared, not enforced here: the bundle lattice (P3) will read them.
      master   -> can_reproduce (next-generation seed), can_issue pills, can_consume pills
      official -> no reproduction, consumes D-genome pills
      custom   -> no reproduction, may mint local user-genome pills
  * Activation: v0 is "provisional" - the cryptographic D-touch attestation and the offline
    root ceremony arrive in P4. The passport already records the genome root that will be the
    activation subject.

CLI
  passport.py init [--member D] [--bundle-class master] [--force]
  passport.py show
  passport.py verify
  passport.py genome list | set <key> <value> | unset <key> | history
  passport.py repair --reason "..."      # re-anchor the passport to the current genome root
  passport.py selftest

Machine facts live in state/ (R2); this file is portable and self-locating.
"""
import hashlib
import json
import sys
import time
import uuid
from pathlib import Path

AGI = Path(__file__).resolve().parents[2]
STATE = AGI / "state"
MEM = AGI / "memory"
GENOME = STATE / "genome"
TREE = GENOME / "tree.json"
TRANSITIONS = GENOME / "transitions.jsonl"
PASSPORT = STATE / "passport.json"
PASSPORT_SIG = STATE / "passport.json.sig"

sys.path.insert(0, str(MEM / "scripts"))
import crypto  # noqa: E402
import trust_log  # noqa: E402

SCHEMA = "agi-passport/1"

# self-tests and dry runs must never append to the live trust log
LOGGING = True
TREE_SCHEMA = "agi-genome-tree/1"
TRANSITION_SCHEMA = "agi-genome-transition/1"

CAPABILITIES = {
    "master": {"can_reproduce": True, "can_issue": ["pill"], "can_consume": ["pill"]},
    "official": {"can_reproduce": False, "can_issue": [], "can_consume": ["pill"]},
    "custom": {"can_reproduce": False, "can_issue": ["pill:local"], "can_consume": ["pill"]},
}


# ---------------------------------------------------------------- io
def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _jdump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")


def _jload(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def _read_transitions():
    if not TRANSITIONS.exists():
        return []
    out = []
    for line in TRANSITIONS.read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out


# ---------------------------------------------------------------- genome tree
def genome_root(entries):
    """RFC 9162 Merkle root over sorted (key, value) leaves (same primitives as the log)."""
    leaves = [trust_log.leaf_hash(crypto.canonical_json({"k": k, "v": entries[k]}))
              for k in sorted(entries)]
    return trust_log.mth(leaves).hex()


def load_tree():
    return _jload(TREE)


def current_root():
    t = load_tree() or {}
    return t.get("root")


def _transition_body(rec):
    return {k: rec[k] for k in ("i", "epoch", "op", "key", "value", "prev_root", "root", "ts")}


def _append_genesis(entries):
    """Record the initial genome as the first signed transition (epoch 1, no predecessor)."""
    rec = {"i": 0, "epoch": 1, "op": "seed", "key": "*", "value": dict(entries),
           "prev_root": None, "root": genome_root(entries), "ts": _now(), "schema": TRANSITION_SCHEMA}
    rec["sig"] = crypto.sign_bytes(crypto.canonical_json(_transition_body(rec)))
    TRANSITIONS.parent.mkdir(parents=True, exist_ok=True)
    with TRANSITIONS.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")
    return rec


def _append_transition(tree, op, key, value):
    history = _read_transitions()
    prev_root = tree.get("root")
    entries = dict(tree.get("entries") or {})
    if op == "set":
        entries[key] = value
    elif op == "unset":
        entries.pop(key, None)
    else:
        raise ValueError("op must be set or unset")
    epoch = int(tree.get("epoch") or 0) + 1
    root = genome_root(entries)
    rec = {"i": len(history), "epoch": epoch, "op": op, "key": key,
           "value": value if op == "set" else None, "prev_root": prev_root, "root": root, "ts": _now()}
    rec["schema"] = TRANSITION_SCHEMA
    sig = crypto.sign_bytes(crypto.canonical_json(_transition_body(rec)))
    rec["sig"] = sig
    with TRANSITIONS.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")
    tree = {"schema": TREE_SCHEMA, "epoch": epoch, "entries": entries, "root": root, "updated": _now(),
            "leaf_count": len(entries), "algorithm": "sha256 merkle (RFC 9162), sorted keys"}
    _jdump(TREE, tree)
    return tree, rec


# ---------------------------------------------------------------- passport
def _capabilities(bundle_class):
    caps = dict(CAPABILITIES.get(bundle_class) or CAPABILITIES["custom"])
    caps["bundle_class"] = bundle_class
    return caps


def build_passport(member="D", bundle_class="master", passport_id=None, keys_epoch=1, history=None):
    key = _jload(STATE / "keys" / "device.json")
    if not key:
        raise FileNotFoundError("no device key: run crypto.py keygen first")
    tree = load_tree()
    if not tree:
        raise FileNotFoundError("no genome tree: run passport.py genome set <key> <value> (or init)")
    man = _jload(AGI / "core_manifest.json") or {}
    return {
        "schema": SCHEMA,
        "passport_id": passport_id or str(uuid.uuid4()),
        "member": member,
        "bundle_class": bundle_class,
        "generation": {
            "gen": "gen3.5",
            "core_version": man.get("core_version"),
            "dna_version": man.get("dna_version"),
            "bundle": man.get("bundle_name"),
        },
        "user_genome_root": tree.get("root"),
        "genome_epoch": tree.get("epoch"),
        "genome_leaf_count": tree.get("leaf_count"),
        "activation": {
            "state": "provisional",
            "subject": "user_genome_root",
            "reason": "cryptographic activation (D-touch attestation + offline root) arrives in P4",
            "at": _now(),
        },
        "device": {"key_id": key.get("key_id"), "alg": key.get("alg"), "sealed": key.get("sealed")},
        "capabilities": _capabilities(bundle_class),
        "parent": {"generation": "gen3.5", "passport_id": None,
                   "bundle": man.get("bundle_name"), "lineage": "memory/library/AGI.lineage.md"},
        "keys": {"epoch": keys_epoch, "history": history or
                 [{"key_id": key.get("key_id"), "from": _now(), "reason": "initial"}]},
        "issued": _now(),
        "renewed": None,
        "policy": "verifiable offline; genome changes are signed transitions; no personal data leaves state/",
    }


def write_passport(passport, reason="initial"):
    _jdump(PASSPORT, passport)
    sig_path, env = crypto.sign_file(PASSPORT)
    if not LOGGING:
        return {"passport": str(PASSPORT), "sig": str(sig_path), "log_index": None}
    ev = trust_log.append("passport-" + reason, {
        "passport_id": passport["passport_id"],
        "genome_epoch": passport["genome_epoch"],
        "user_genome_root": passport["user_genome_root"],
        "bundle_class": passport["bundle_class"],
        "key_id": env["key_id"],
    })
    return {"passport": str(PASSPORT), "sig": str(sig_path), "log_index": ev["index"]}


def init_passport(member="D", bundle_class="master", force=False):
    if PASSPORT.exists() and not force:
        raise FileExistsError(f"passport already exists at {PASSPORT} (use --force to mint a new member)")
    GENOME.mkdir(parents=True, exist_ok=True)
    if not load_tree():
        # the seed genome: what this member is and which invariant set it runs
        man = _jload(AGI / "core_manifest.json") or {}
        seed = {
            "identity.member": member,
            "identity.bundle_class": bundle_class,
            "core.version": str(man.get("core_version") or ""),
            "dna.version": str(man.get("dna_version") or ""),
            "season.current": "2026-10-25",
        }
        tree = {"schema": TREE_SCHEMA, "epoch": 1, "entries": seed,
                "root": genome_root(seed), "updated": _now(), "leaf_count": len(seed),
                "algorithm": "sha256 merkle (RFC 9162), sorted keys"}
        _jdump(TREE, tree)
        _append_genesis(seed)
    passport = build_passport(member=member, bundle_class=bundle_class)
    return passport, write_passport(passport, reason="minted")


def set_entry(key, value):
    """Atomic genome change: transition -> tree -> passport re-anchor -> log."""
    tree = load_tree()
    if not tree:
        raise FileNotFoundError("no genome tree (run init first)")
    tree, rec = _append_transition(tree, "set", key, str(value))
    passport = _jload(PASSPORT)
    if passport:
        passport = build_passport(member=passport.get("member", "D"),
                                  bundle_class=passport.get("bundle_class", "master"),
                                  passport_id=passport.get("passport_id"),
                                  keys_epoch=(passport.get("keys") or {}).get("epoch", 1),
                                  history=(passport.get("keys") or {}).get("history"))
        passport["renewed"] = _now()
        write_passport(passport, reason="genome-set")
    return {"epoch": tree["epoch"], "root": tree["root"], "transition": rec["i"]}


def unset_entry(key):
    tree = load_tree()
    if not tree:
        raise FileNotFoundError("no genome tree (run init first)")
    if key not in (tree.get("entries") or {}):
        raise KeyError(f"no genome entry {key!r}")
    tree, rec = _append_transition(tree, "unset", key, None)
    passport = _jload(PASSPORT)
    if passport:
        passport = build_passport(member=passport.get("member", "D"),
                                  bundle_class=passport.get("bundle_class", "master"),
                                  passport_id=passport.get("passport_id"),
                                  keys_epoch=(passport.get("keys") or {}).get("epoch", 1),
                                  history=(passport.get("keys") or {}).get("history"))
        passport["renewed"] = _now()
        write_passport(passport, reason="genome-unset")
    return {"epoch": tree["epoch"], "root": tree["root"], "transition": rec["i"]}


def replay():
    """Replay the signed transition history -> (entries, epoch, problems).

    The history, not the mutable tree file, is the authority: a tree whose contents or
    root disagree with the replay is repaired from the replay, never trusted blindly.
    """
    entries, epoch, problems = {}, 0, []
    for rec in _read_transitions():
        if rec.get("op") == "seed":
            entries.update(rec.get("value") or {})
        elif rec.get("op") == "set":
            entries[rec.get("key")] = rec.get("value")
        elif rec.get("op") == "unset":
            entries.pop(rec.get("key"), None)
        root = genome_root(entries)
        if rec.get("root") != root:
            problems.append(f"transition {rec.get('i')}: recorded root does not match the replay")
        epoch = int(rec.get("epoch") or epoch)
    return entries, epoch, problems


# ---------------------------------------------------------------- verification
def verify_passport(deep=True):
    """Verify the credential and its genome anchor. Returns a report (never raises)."""
    problems = []
    p = _jload(PASSPORT)
    report = {"passport": str(PASSPORT), "exists": bool(p), "problems": problems}
    if not p:
        report["ok"] = False
        problems.append("no passport (run passport.py init)")
        return report
    report["passport_id"] = p.get("passport_id")
    report["member"] = p.get("member")
    report["bundle_class"] = p.get("bundle_class")
    report["genome_epoch"] = p.get("genome_epoch")
    key = _jload(STATE / "keys" / "device.json") or {}
    pinned = key.get("key_id")
    sig = crypto.verify_file(PASSPORT, expected_key_id=pinned)
    report["signature"] = {"ok": sig.get("ok"), "reason": sig.get("reason"), "key_id": sig.get("key_id")}
    if not sig.get("ok"):
        problems.append("passport signature: " + str(sig.get("reason")))
    tree = load_tree()
    if not tree:
        problems.append("no genome tree")
    else:
        if p.get("user_genome_root") != tree.get("root"):
            problems.append(f"genome root mismatch: passport {str(p.get('user_genome_root'))[:16]} "
                            f"!= tree {str(tree.get('root'))[:16]}")
        p_epoch, t_epoch = p.get("genome_epoch"), tree.get("epoch")
        if p_epoch is None or t_epoch is None or int(p_epoch) != int(t_epoch):
            problems.append(f"genome epoch mismatch: passport {p_epoch} != tree {t_epoch}")
        report["tree_epoch"] = tree.get("epoch")
        report["tree_root"] = tree.get("root")
    if p.get("device", {}).get("key_id") != pinned:
        problems.append("passport device key does not match the installed device key")
    if p.get("activation", {}).get("state") not in ("provisional", "activated", "present", "delegated"):
        problems.append("unknown activation state")
    if deep:
        # transition chain: signature, prev_root link, epoch monotonicity
        history = _read_transitions()
        report["transitions"] = len(history)
        prev = None
        seen_keys = set()
        for rec in history:
            body = _transition_body(rec)
            v = crypto.verify_bytes(crypto.canonical_json(body), rec.get("sig") or {},
                                    expected_key_id=pinned)
            if not v.get("ok"):
                problems.append(f"transition {rec.get('i')}: signature {v.get('reason')}")
            if prev is not None:
                if rec.get("prev_root") != prev.get("root"):
                    problems.append(f"transition {rec.get('i')}: prev_root does not link to transition {prev.get('i')}")
                if int(rec.get("epoch") or 0) != int(prev.get("epoch") or 0) + 1:
                    problems.append(f"transition {rec.get('i')}: epoch is not monotonic")
            prev = rec
            seen_keys.add(rec.get("i"))
        if prev is not None and tree:
            if prev.get("root") != tree.get("root"):
                problems.append("last transition root does not match the current tree root")
        report["chain_ok"] = not any("transition" in x for x in problems)
    report["ok"] = not problems
    return report


# ---------------------------------------------------------------- CLI
def _arg(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def cmd_init(args):
    member = _arg(args, "--member", "D")
    bundle_class = _arg(args, "--bundle-class", "master")
    if bundle_class not in CAPABILITIES:
        print(f"bundle class must be one of {', '.join(CAPABILITIES)}")
        return 2
    passport, where = init_passport(member=member, bundle_class=bundle_class, force="--force" in args)
    print(json.dumps({"ok": True, "passport_id": passport["passport_id"], "member": passport["member"],
                      "bundle_class": passport["bundle_class"],
                      "genome_epoch": passport["genome_epoch"],
                      "user_genome_root": passport["user_genome_root"],
                      "log_index": where["log_index"]}, indent=1))
    return 0


def cmd_show(args):
    p = _jload(PASSPORT)
    if not p:
        print("no passport yet (run passport.py init)")
        return 1
    print(json.dumps(p, indent=1))
    return 0


def cmd_verify(args):
    r = verify_passport()
    print(json.dumps(r, indent=1))
    return 0 if r.get("ok") else 1


def cmd_genome(args):
    sub = args[0] if args else "list"
    tree = load_tree() or {}
    if sub == "list":
        print(json.dumps({"epoch": tree.get("epoch"), "root": tree.get("root"),
                          "entries": tree.get("entries") or {}}, indent=1))
        return 0
    if sub == "set":
        if len(args) < 3:
            print("usage: passport.py genome set <key> <value>")
            return 2
        print(json.dumps(set_entry(args[1], " ".join(args[2:])), indent=1))
        return 0
    if sub == "unset":
        if len(args) < 2:
            print("usage: passport.py genome unset <key>")
            return 2
        print(json.dumps(unset_entry(args[1]), indent=1))
        return 0
    if sub == "history":
        print(json.dumps([{k: r.get(k) for k in ("i", "epoch", "op", "key", "root", "ts")}
                          for r in _read_transitions()], indent=1))
        return 0
    print("usage: passport.py genome list|set|unset|history")
    return 2


def cmd_repair(args):
    """Re-anchor the passport to the current genome tree (bounded recovery, always logged)."""
    reason = _arg(args, "--reason", "manual repair")
    p = _jload(PASSPORT)
    if not p:
        print("no passport to repair")
        return 1
    passport = build_passport(member=p.get("member", "D"), bundle_class=p.get("bundle_class", "master"),
                              passport_id=p.get("passport_id"),
                              keys_epoch=(p.get("keys") or {}).get("epoch", 1),
                              history=(p.get("keys") or {}).get("history"))
    entries, epoch, problems = replay()
    if not _read_transitions():
        tree = load_tree() or {}
        entries, epoch = dict(tree.get("entries") or {}), int(tree.get("epoch") or 1)
    else:
        tree = load_tree() or {}
        tree = {"schema": TREE_SCHEMA, "epoch": max(epoch, 1), "entries": entries,
                "root": genome_root(entries), "updated": _now(), "leaf_count": len(entries),
                "algorithm": "sha256 merkle (RFC 9162), sorted keys"}
        _jdump(TREE, tree)
    passport = build_passport(member=p.get("member", "D"), bundle_class=p.get("bundle_class", "master"),
                              passport_id=p.get("passport_id"),
                              keys_epoch=(p.get("keys") or {}).get("epoch", 1),
                              history=(p.get("keys") or {}).get("history"))
    passport["renewed"] = _now()
    passport["repair"] = {"reason": reason, "at": _now(), "replay_problems": problems}
    where = write_passport(passport, reason="repair")
    print(json.dumps({"ok": True, "repaired_to_epoch": passport["genome_epoch"],
                      "user_genome_root": passport["user_genome_root"],
                      "replay_problems": problems, "log_index": where["log_index"]}, indent=1))
    return 0


def selftest():
    import shutil
    import tempfile

    global GENOME, TREE, TRANSITIONS, PASSPORT, PASSPORT_SIG, STATE, LOGGING

    checks = []

    def check(name, ok, detail=""):
        checks.append(bool(ok))
        print(f"  {'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f" - {detail}"))

    # root determinism/order independence on an isolated tree
    saved = (GENOME, TREE, TRANSITIONS, PASSPORT, PASSPORT_SIG, crypto.KEYS, STATE, LOGGING)
    LOGGING = False
    tmp = Path(tempfile.mkdtemp(prefix="agi-passport-test-"))
    try:
        STATE_KEYS = tmp / "state" / "keys"
        crypto.KEYS = STATE_KEYS
        STATE = tmp / "state"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        GENOME = tmp / "state" / "genome"
        TREE = GENOME / "tree.json"
        TRANSITIONS = GENOME / "transitions.jsonl"
        PASSPORT = tmp / "state" / "passport.json"
        PASSPORT_SIG = tmp / "state" / "passport.json.sig"

        e1 = {"a": "1", "b": "2"}
        e2 = {"b": "2", "a": "1"}
        check("genome root is order-independent", genome_root(e1) == genome_root(e2), "sorting broken")
        check("different genomes have different roots", genome_root(e1) != genome_root({"a": "1"}))
        check("empty genome root is sha256('')", genome_root({}) == hashlib.sha256(b"").hexdigest())

        p, _ = init_passport(member="D", bundle_class="master", force=True)
        check("passport minted with master capabilities",
              p["capabilities"]["can_reproduce"] is True and p["bundle_class"] == "master")
        check("passport carries the genome root and epoch",
              p["user_genome_root"] == current_root() and p["genome_epoch"] == 1)
        r = verify_passport()
        check("clean passport verifies", r["ok"], str(r.get("problems")))

        set_entry("tone.style", "direct")
        r2 = verify_passport()
        check("genome change keeps passport anchored (atomic update)", r2["ok"], str(r2.get("problems")))
        check("epoch advanced to 2", (load_tree() or {}).get("epoch") == 2)
        ops = [r.get("op") for r in _read_transitions()]
        check("genesis + change are both in the signed history", ops == ["seed", "set"], str(ops))

        # tampering with the tree root must break verification
        tree = load_tree()
        tree["root"] = "0" * 64
        _jdump(TREE, tree)
        r3 = verify_passport()
        check("root tamper detected", not r3["ok"] and any("root mismatch" in x for x in r3["problems"]),
              str(r3.get("problems")))
        # repair re-anchors and logs the repair
        cmd_repair(["--reason", "selftest"])
        r4 = verify_passport()
        check("repair re-anchors the passport", r4["ok"], str(r4.get("problems")))

        # a tampered transition signature is caught
        rows = TRANSITIONS.read_text(encoding="utf-8").splitlines()
        rec = json.loads(rows[0])
        rec["value"] = "tampered"
        TRANSITIONS.write_text(json.dumps(rec) + "\n", encoding="utf-8")
        r5 = verify_passport()
        check("transition tamper detected", not r5["ok"], str(r5.get("problems")))
    finally:
        (GENOME, TREE, TRANSITIONS, PASSPORT, PASSPORT_SIG, crypto.KEYS, STATE, LOGGING) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    ok = all(checks)
    print("passport selftest:", "PASS" if ok else f"FAIL ({checks.count(False)})")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    table = {"init": cmd_init, "show": cmd_show, "verify": cmd_verify, "genome": cmd_genome,
             "repair": cmd_repair, "selftest": lambda a: selftest()}
    if cmd not in table:
        print(__doc__)
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

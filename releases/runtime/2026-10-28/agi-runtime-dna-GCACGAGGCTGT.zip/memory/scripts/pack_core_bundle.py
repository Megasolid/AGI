#!/usr/bin/env python3
"""Build and verify the curated AGI Core v3 bundle from core_manifest.json."""
import hashlib
import json
import os
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / "core_manifest.json"

def read_manifest():
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    entries = data.get("files", [])
    paths = []
    for entry in entries:
        rel = PurePosixPath(entry["path"])
        digest = str(entry.get("sha256", "")).lower()
        if rel.is_absolute() or ".." in rel.parts or len(digest) != 16:
            raise ValueError(f"invalid manifest entry: {entry.get('path')}")
        if rel.parts and rel.parts[0] in {"state", "temp", "backups"}:
            raise ValueError(f"volatile path is not bundleable: {rel}")
        source = ROOT.joinpath(*rel.parts)
        if not source.is_file():
            raise FileNotFoundError(f"manifest source missing: {rel}")
        actual = hashlib.sha256(source.read_bytes()).hexdigest()
        if not actual.startswith(digest):
            raise ValueError(f"source hash mismatch: {rel} expected={digest} actual={actual[:16]}")
        paths.append((rel.as_posix(), source, digest))
    if len(paths) != len(entries) or len({item[0] for item in paths}) != len(paths):
        raise ValueError("manifest has duplicate or invalid paths")
    return data, paths

def verify_archive(archive_path):
    manifest, paths = read_manifest()
    expected = {rel: digest for rel, _, digest in paths}
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        names = [member.name for member in members]
        if len(names) != len(set(names)):
            raise ValueError("archive contains duplicate paths")
        if set(names) != set(expected):
            missing = sorted(set(expected) - set(names))
            extra = sorted(set(names) - set(expected))
            raise ValueError(f"archive file list mismatch: missing={missing} extra={extra}")
        for member in members:
            if not member.isfile():
                raise ValueError(f"non-file archive member: {member.name}")
            stream = archive.extractfile(member)
            if stream is None:
                raise ValueError(f"unreadable archive member: {member.name}")
            digest = hashlib.sha256(stream.read()).hexdigest()
            if not digest.startswith(expected[member.name]):
                raise ValueError(f"archive hash mismatch: {member.name}")
    print(f"VERIFY PASS files={len(expected)} bundle={Path(archive_path)}")
    return len(expected)

def build_archive(output_path):
    manifest, paths = read_manifest()
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("xb") as raw:
        with tarfile.open(fileobj=raw, mode="w:gz") as archive:
            for rel, source, _ in paths:
                archive.add(source, arcname=rel, recursive=False)
    verify_archive(output)
    print(f"BUILT files={len(paths)} bytes={output.stat().st_size} -> {output}")
    return output

def selftest():
    with tempfile.TemporaryDirectory(prefix="agi-core-pack-selftest-") as directory:
        candidate = Path(directory) / "selftest.tar.gz"
        build_archive(candidate)
        verify_archive(candidate)
    print("SELFTEST PASS")

def main(argv):
    if argv == ["--selftest"]:
        selftest()
        return 0
    if argv and argv[0] == "--verify" and len(argv) <= 2:
        archive = Path(argv[1]) if len(argv) == 2 else ROOT / json.loads(MANIFEST.read_text(encoding="utf-8"))["bundle_name"]
        verify_archive(archive)
        return 0
    if len(argv) == 2 and argv[0] == "--build":
        build_archive(argv[1])
        return 0
    print("usage: pack_core_bundle.py --selftest | --verify [archive] | --build <new-output-path>")
    return 2

if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except Exception as exc:
        sys.stderr.write(f"CORE BUNDLE ERROR: {exc}\n")
        sys.exit(1)

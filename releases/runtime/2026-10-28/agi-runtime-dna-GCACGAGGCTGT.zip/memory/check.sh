#!/usr/bin/env bash
# D's one-call status check -> model / server / speed+VRAM / context / network+proxy / notebook
# W2 portability: no hardcoded user/machine dirs - bash and the venv are discovered.
GITBIN=$(command -v git 2>/dev/null)
if [ -n "$GITBIN" ]; then
  GITROOT=$(dirname "$(dirname "$GITBIN")")
  [ -d "$GITROOT/usr/bin" ] && PATH="$GITROOT/usr/bin:$GITROOT/mingw64/bin:$PATH"
fi
export PATH
MEMDIR="$(cd "$(dirname "$0")" && pwd)"   # self-locate: this script lives in memory/
PROBE="$MEMDIR/../state/env_probe.json"
jget() { grep -o "\"$1\": \"[^\"]*\"" "$PROBE" 2>/dev/null | head -1 | sed 's/.*: "//;s/"$//'; }
venv_win=$(jget venv_python)
PY=$(cygpath -u "$venv_win" 2>/dev/null || printf '%s' "$venv_win")
studio_win=$(jget root)
STUDIO=$(cygpath -u "$studio_win" 2>/dev/null || printf '%s' "$studio_win")
# llama-server logs live in Studio's own logs dir; legacy relative path as fallback
LOGDIR="$STUDIO/logs/llama-server"
[ -d "$LOGDIR" ] || LOGDIR="$(dirname "$MEMDIR")/logs/llama-server"
LOG=$(ls -t "$LOGDIR"/*.log 2>/dev/null | head -1)

stats() { awk 'NF{n++; s+=$1; if(min==""||$1<min)min=$1; if(max==""||$1>max)max=$1; last=$1} END{if(n)printf "n=%d avg=%.1f min=%.1f max=%.1f last=%.2f", n, s/n, min, max, last}'; }

echo "=== MODEL"
if [ -n "$LOG" ]; then
  M=$(grep -oE "loading model '[^']+'" "$LOG" | head -1 | sed "s/^loading model '//;s/'$//")
  echo "$(basename "${M:-unknown}" .gguf)"
else
  echo "unknown (no log)"
fi
echo
echo "=== SERVER"
PID=$(tasklist 2>/dev/null | awk '/llama-server\.exe/{print $2; exit}')
if [ -z "$PID" ]; then
  echo "llama-server: NOT RUNNING"
else
  PORT=$(netstat -ano 2>/dev/null | grep -w "$PID" | grep LISTENING | head -1 | awk '{print $2}' | grep -oE '[0-9]+$')
  if [ -n "$PORT" ]; then
    H=$(curl -s --max-time 5 "http://127.0.0.1:$PORT/health")
    echo "llama-server: LIVE pid=$PID port=$PORT health=${H:-?}"
  else
    echo "llama-server: RUNNING pid=$PID (no listen port found)"
  fi
fi
APIPORT=$(grep -o '"api_port": *[0-9]*' "$PROBE" 2>/dev/null | head -1 | grep -o '[0-9]*')
APIPORT=${APIPORT:-8888}
SC=$(curl -s -o /dev/null -w "%{http_code}" --max-time 3 "http://127.0.0.1:${APIPORT}/" 2>/dev/null)
echo "studio:${APIPORT} -> HTTP ${SC:-000}"
echo
echo "=== SPEED / VRAM"
if [ -n "$LOG" ]; then
  P=$(grep "prompt eval time" "$LOG" | grep -oE '[0-9.]+ tokens per second' | awk '{print $1}')
  G=$(grep "eval time" "$LOG" | grep -v "prompt" | grep -oE '[0-9.]+ tokens per second' | awk '{print $1}')
  echo "prompt: $(printf '%s\n' "$P" | stats) tok/s"
  echo "gen:    $(printf '%s\n' "$G" | stats) tok/s"
fi
VR=$(nvidia-smi --query-gpu=memory.used,memory.total,utilization.gpu,temperature.gpu --format=csv,noheader,nounits 2>/dev/null | head -1)
if [ -n "$VR" ]; then
  echo "VRAM: $(echo "$VR" | awk -F', ' '{printf "%d/%d MB (%d%%) | util %s%% | %sC", $1, $2, $1*100/$2, $3, $4}')"
else
  echo "VRAM: n/a"
fi
echo
echo "=== CONTEXT"
if [ -n "$LOG" ]; then
  NCTX=$(grep -oE 'n_ctx[[:space:]]+=[[:space:]]*[0-9]+' "$LOG" | head -1 | grep -oE '[0-9]+$')
  NTRAIN=$(grep -oE 'n_ctx_train[[:space:]]+=[[:space:]]*[0-9]+' "$LOG" | head -1 | grep -oE '[0-9]+$')
  LP=$(grep "prompt eval time" "$LOG" | tail -1 | grep -oE '/ *[0-9]+ tokens' | grep -oE '[0-9]+')
  echo "window: ${NCTX:-n/a} tokens (model trained ${NTRAIN:-?})"
  if [ -n "$LP" ] && [ -n "$NCTX" ]; then
    echo "last prompt: $LP tokens ($((LP*100/NCTX))% of window)"
  fi
else
  echo "n/a (no log)"
fi
echo
echo "=== NETWORK / PROXY"
NET=$(curl -s -o /dev/null -w "%{http_code} %{time_total}s" --max-time 5 https://huggingface.co 2>/dev/null)
echo "internet: ${NET:-unreachable}"
# Geo / outbound route: live country flag vs home baseline (state/machine.md) => VPN-route detection
# when D routes the whole system through a VPN under heavy network restriction. ipapi.co primary, ipwho.is fallback.
GEO=$(curl -s --max-time 6 https://ipapi.co/json 2>/dev/null)
[ -n "$GEO" ] || GEO=$(curl -s --max-time 6 https://ipwho.is/ 2>/dev/null)
CC=$(printf '%s' "$GEO" | sed -n 's/.*"country_code"[^A-Z]*\([A-Z][A-Z]\).*/\1/p')
CITY=$(printf '%s' "$GEO" | sed -n 's/.*"city"[^"]*"\([^"]*\)".*/\1/p')
ORG=$(printf '%s' "$GEO" | sed -n 's/.*"org"[^"]*"\([^"]*\)".*/\1/p')
IP=$(printf '%s' "$GEO" | sed -n 's/.*"ip"[^"]*"\([^"]*\)".*/\1/p')
BASE=$(grep -oE 'outbound baseline: [A-Z]{2}' "$MEMDIR/../state/machine.md" 2>/dev/null | grep -oE '[A-Z]{2}$' | head -1)
if [ -n "$CC" ]; then
  GEOORG=""
  [ -n "$ORG" ] && GEOORG=" | org $ORG"
  echo "geo: ${IP:-?} | $CC ${CITY:-?}$GEOORG"
  if [ -n "$BASE" ] && [ "$CC" != "$BASE" ]; then
    echo "route: VPN/foreign detected (outbound $CC != home $BASE)"
  elif [ -n "$BASE" ]; then
    echo "route: direct (home $CC)"
  else
    echo "route: outbound $CC (no home baseline set in state/machine.md)"
  fi
else
  echo "geo: n/a"
fi
if netstat -ano 2>/dev/null | grep -qE ':10808 .*LISTENING'; then
  echo "proxy 127.0.0.1:10808: UP (v2rayN)"
else
  echo "proxy 127.0.0.1:10808: down (v2rayN)"
fi
if netstat -ano 2>/dev/null | grep -qE ':8085 .*LISTENING'; then
  echo "proxy 127.0.0.1:8085: UP (MasterHttpRelayVPN)"
else
  echo "proxy 127.0.0.1:8085: down (MasterHttpRelayVPN)"
fi
echo
echo "=== NOTEBOOK"
PEND=$(awk -F'\t' '$1=="pending"{print $2; exit}' "$MEMDIR/MEMORY.md" 2>/dev/null)
if [ -n "$PEND" ]; then echo "- $PEND"; else echo "- nothing pending"; fi
NSLEEP=$(awk '/^## Sleeping/{f=1;next} /^## /{f=0} f&&/^- /' "$MEMDIR/state/projects.md" 2>/dev/null | grep -c .)
if [ "$NSLEEP" -gt 0 ]; then
  awk '/^## Sleeping/{f=1;next} /^## /{f=0} f&&/^- /{sub(/^- /,""); print "- SLEEP: " $0}' "$MEMDIR/state/projects.md" 2>/dev/null
else
  echo "- nothing sleeping"
fi

echo "=== REGISTRY"
"$PY" "$MEMDIR/scripts/job.py" run _selftest 2>&1 | tail -1 || echo "registry FAIL"

# migration phase sections (OS / ENV GATE / MIGRATION / HW-TEMP)
"$PY" "$MEMDIR/scripts/check_sections.py" 2>&1

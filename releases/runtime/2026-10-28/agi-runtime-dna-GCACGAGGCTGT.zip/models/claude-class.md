# model profile: claude-class (large-context API models, Claude family)

- Context limit: large (verify at boot via S3); working budget 40k.
- Tool dialect: native tool calling, strong; structured I/O envelope maps 1:1.
- Max steps before checkpoint: 20.
- Known quirks: may over-refuse irreversible ops without an explicit undo plan - R4 always supplies one; verbose replies -> enforce concise/direct prefs from state-side MEMORY.md.
- Degraded modes: none expected; if tool calling unavailable, fenced-block IO fallback (memory-ops §IO).

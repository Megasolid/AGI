# model profile: qwen-local (local GGUF class, e.g. Qwen via llama-server in-studio)

- Context limit: per state/env_probe.json model field; assume 16k working budget unless probe says more.
- Tool dialect: native tool calling available; prefer Studio built-ins (GPU panel / API Monitor / studio.db) over raw system commands.
- Max steps before checkpoint: 8.
- Known quirks: frugal context discipline mandatory (cap tool output, batch calls); VRAM usage is mostly its own footprint - don't alarm D; CRLF anchoring for line edits.
- Degraded modes: small-context mode = one section loaded at a time; no-network mode = pool off.

# model profile: gpt-class (GPT family API models)

- Context limit: medium-large (verify at boot via S3); working budget 24k.
- Tool dialect: native tool calling; JSON-schema strict - keep envelopes small.
- Max steps before checkpoint: 12.
- Known quirks: weaker adherence to numbered-rule contracts than claude-class on long sessions -> re-inject the gate checklist every ~10 turns; may hallucinate machine facts -> R2 grep discipline on anything it proposes for state/.
- Degraded modes: if tool calling unavailable, fenced-block IO fallback (memory-ops §IO).

# machine notes (filled at first boot by probe; never bundled)

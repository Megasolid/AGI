#!/usr/bin/env python3
"""test_federation_release.py - P6/P7 contract: federation, Sybil weighting, release packages.

Two kinds of assertions:
  * live artefacts: the three packages actually built in state/release/ verify offline, and a
    tampered copy is refused;
  * module contracts: federation.selftest() and release.selftest() run their own sandboxed
    end-to-end checks (relay -> fetch -> verify -> import, divergence/rollback alerts, tamper
    refusal, no private material in packages) and must return 0.

Run: <venv-python> tests/test_federation_release.py
"""
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import federation  # noqa: E402
import release  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    # 1. live release packages verify offline
    index = release.list_releases()
    pkgs = index.get("packages") or []
    check("release index lists three packages", len(pkgs) >= 3, str(len(pkgs)))
    by_class = {}
    for p in pkgs:
        z = Path(p.get("zip") or "")
        if z.is_file():
            by_class.setdefault(p.get("class"), z)
    check("master/official/custom packages exist on disk",
          set(by_class) >= {"master", "official", "custom"}, str(sorted(by_class)))
    for cls, z in sorted(by_class.items()):
        v = release.verify_zip(z)
        check(f"{cls} package verifies (signature + all hashes)", v["ok"], str(v.get("problems")))
    if "official" in by_class:
        man = release._jload(by_class["official"])
        check("official package is a template, not member data",
              (by_class["official"]).name.startswith("agi-official"))

    # 2. tampered package copy is refused
    if "official" in by_class:
        tmp = Path(tempfile.mkdtemp(prefix="agi-rel-test-"))
        try:
            with zipfile.ZipFile(by_class["official"]) as z:
                z.extractall(tmp)
            victim = tmp / "docs" / "trust-layer-v0.md"
            victim.write_text("# tampered\n", encoding="utf-8")
            bad = tmp.parent / "tampered-release.zip"
            with zipfile.ZipFile(bad, "w") as z:
                for f in sorted(tmp.rglob("*")):
                    if f.is_file():
                        z.write(f, f.relative_to(tmp).as_posix())
            v = release.verify_zip(bad)
            check("tampered package refused", not v["ok"] and any("hash mismatch" in p for p in v["problems"]),
                  str(v.get("problems")))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

        # 3. no private material in a public package
        with zipfile.ZipFile(by_class["official"]) as z:
            names = z.namelist()
        check("public package contains no keys or shards",
              not any("root_shard" in n or n.endswith(".key") or "state/keys" in n for n in names))

    # 4. Sybil weight is transparent and monotonic
    w = federation.weight("someone", 0)
    w2 = federation.weight("someone", 3)
    check("weight formula is recorded", "formula" in w and w["weight"] <= 1.0)
    check("evidence raises the weight", w2["weight"] > w["weight"], f"{w['weight']} -> {w2['weight']}")

    # 5. module contracts (sandboxed end-to-end)
    check("federation contract passes (relay -> fetch -> verify -> import)", federation.selftest() == 0)
    check("release contract passes (build -> verify -> tamper refusal)", release.selftest() == 0)

    failed = checks.count(False)
    print(f"test_federation_release: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

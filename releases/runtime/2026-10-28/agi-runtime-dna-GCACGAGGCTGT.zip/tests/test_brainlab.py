#!/usr/bin/env python3
"""test_brainlab.py - S2.5 Brain Lab: registry, signed benchmark suite, tiers, render packs, routing."""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import brainlab  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    rc = brainlab.selftest()
    check("brainlab selftest returns clean", rc == 0, rc)
    st = brainlab.status()
    check("status schema", st.get("schema") == "agi-brainlab/1", st.get("schema"))
    check("five render packs", st.get("render_packs") == ["T0", "T1", "T2", "T3", "T4"], st.get("render_packs"))
    check("task classes registered", "edit_code" in st.get("task_classes"), st.get("task_classes"))
    html = brainlab.render()
    check("brain lab page renders", "Brain Lab" in html and "Render packs" in html and "Routing table" in html,
          len(html))
    check("page states model-harness pair truth", "Model-harness pairs" in html)
    reg = brainlab.registry()
    check("registry has schema + reference ladder", reg.get("schema") == "agi-brainlab/1" and "reference" in reg)
    for mid, m in (reg.get("models") or {}).items():
        check("model %s has a manifest" % mid, all(k in m for k in ("provider", "kind", "context", "tier")))
    n = sum(checks)
    print("test_brainlab: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

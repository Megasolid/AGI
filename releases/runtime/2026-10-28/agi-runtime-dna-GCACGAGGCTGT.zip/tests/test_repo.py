#!/usr/bin/env python3
"""test_repo.py - corrected model contract: ONE official repo + update pool + install roles.

Asserts two kinds of things:
  * live artefacts: the AGI repo exists with git history, its signed manifest and pool verify,
    and the install role is one of the four legal values with its invariants intact;
  * module contract: repo.selftest() runs the sandboxed end-to-end (init -> publish official ->
    pool push/pull -> role machine -> unplug -> bootstrap default or new user bundle -> sync) and
    must return 0.

The model under test (D, 2026-10-26): one official git repo carrying the official bundle and the
update pool; master is the official bundle UNLOCKED by a D activation (never distributed); a custom
bundle replaces the official one; unplugged bootstraps to the default or a new user bundle.

Run: <venv-python> tests/test_repo.py
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import repo  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    check("only the four legal install roles exist",
          set(repo.ROLES) == {"official", "master", "custom", "none"})

    live = repo.REPO
    if (live / "repo.json").exists():
        v = repo.verify()
        check("live AGI repo verifies (signed manifest + official + pool)", v["ok"],
              str(v.get("problems")))
        check("the distributed bundle is class official",
              (v.get("official") or {}).get("class") == "official", str(v.get("official")))
        commits = repo._commit_count()
        check("repo has git history (clean lineage starts at v0.3.0)", int(commits) >= 2, str(commits))
        pool = repo.verify_pool()
        check("update pool verifies (index signature + envelopes + inclusion proofs)", pool["ok"],
              str(pool.get("problems")))
        inst = repo._jload(repo.INSTALL) or {}
        check("install role is legal", inst.get("role") in repo.ROLES, str(inst.get("role")))
        if inst.get("role") == "master":
            check("master role carries an activation record",
                  (inst.get("activation") or {}).get("level") in ("U1", "U2", "U3"), str(inst.get("activation")))
        if inst.get("role") == "custom":
            check("custom role carries a bundle reference", bool((inst.get("bundle") or {}).get("id")))
        hist = inst.get("history") or []
        check("role history is recorded", isinstance(hist, list) and len(hist) >= 1)

    check("repo contract passes (sandboxed end-to-end)", repo.selftest() == 0)

    failed = checks.count(False)
    print(f"test_repo: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

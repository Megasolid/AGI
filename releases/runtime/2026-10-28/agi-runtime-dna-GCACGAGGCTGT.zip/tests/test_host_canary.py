#!/usr/bin/env python3
"""test_host_canary.py - host-model canary: deterministic graders only, no model self-judging."""
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import host_canary  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    rc = host_canary.selftest()
    check("grader selftest clean", rc == 0, rc)
    check("canary has 10 tasks across families", len(host_canary.TASKS) == 10)
    ids = [t["id"] for t in host_canary.TASKS]
    check("task ids unique", len(ids) == len(set(ids)))
    check("every task has a deterministic grader", all(t.get("grader", {}).get("type") for t in host_canary.TASKS))
    # evidence file exists and is honest about provenance
    files = sorted((ROOT / "state" / "brains" / "benchmarks").glob("host_canary-*.json"))
    check("host canary evidence recorded", bool(files), "run host_canary.py --grade first")
    if files:
        ev = json.loads(files[-1].read_text(encoding="utf-8"))
        check("evidence labels executor_reported", "executor_reported" in ev.get("provenance", ""), ev.get("provenance"))
        check("evidence is not falsely tiered", "unprofiled" in str(ev.get("tier")), ev.get("tier"))
        check("evidence carries vcr", 0.0 <= float(ev.get("vcr", -1)) <= 1.0, ev.get("vcr"))
    html = __import__("brainlab").render()
    check("brain lab page shows host canary", "host canary" in html.lower(), len(html))
    n = sum(checks)
    print("test_host_canary: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_seeding.py - S4 improvement ledger, readiness and acting-Master decision (dry-run only)."""
import json
import pathlib
import shutil
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import seeding  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    pol = seeding.policy()
    check("seeding policy gene", pol.get("min_projected_gain") == 0.10 and pol.get("min_absence_days") == 7,
          pol)
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        a = seeding.add_item("test ui", "ui", 0.06, 0.9, est_ready="2026-11-01", root=tmp)
        b = seeding.add_item("test brain", "brain", 0.05, 0.8, root=tmp)
        check("ledger items added", a["ok"] and b["ok"] and len(seeding.ledger(tmp)["items"]) == 2)
        check("bad area rejected", not seeding.add_item("x", "nope", 0.1, 0.9, root=tmp)["ok"])
        r = seeding.readiness(tmp)
        check("projected gain aggregates", abs(r["projected_gain"] - 0.11) < 1e-6, r["projected_gain"])
        check("readiness percent computed", r["readiness_percent"] == 100, r["readiness_percent"])
        check("eta from items", r["eta"] == "2026-11-01", r["eta"])
        check("confidence gate", r["confidence_ok"] is True)
        check("human-supervised when D present", seeding.decide(tmp, absence_days=0)["decision"] == "wait-for-master",
              seeding.decide(tmp, absence_days=0).get("decision"))
        acting = seeding.decide(tmp, absence_days=9)
        check("acting Master after 7 days", acting["mode"] == "acting-master", acting.get("mode"))
        check("acting Master seeds when gates met", acting["decision"] == "seed-next-generation",
              acting.get("gates") or acting.get("reason"))
        check("acting mode is no-user-interaction", acting.get("no_user_interaction") is True)
        check("rollback required", acting.get("rollback_required") is True)
        low = seeding.decide(tmp, absence_days=9, council_cosign=False)
        check("council co-sign gate blocks seeding", low["decision"] == "wait", low.get("gates"))
        low_conf = seeding.add_item("weak", "ui", 0.2, 0.2, root=tmp)
        weak = seeding.decide(tmp, absence_days=9, council_cosign=True)
        check("low overall confidence delays", weak["decision"] == "wait", weak.get("reason"))
        dec_files = list((tmp / "state/seeding/decisions").glob("*.json"))
        check("seed decision recorded (dry-run)", bool(dec_files), dec_files)
        if dec_files:
            rec = json.loads(dec_files[-1].read_text(encoding="utf-8"))
            check("seed decision is marked dry_run", rec.get("dry_run") is True)
    live = seeding.readiness()
    check("live readiness readable", live.get("schema") == "agi-seeding/1", live.get("schema"))
    html = seeding.render()
    check("seeding page renders", "Improvement ledger" in html and "readiness" in html, len(html))
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        for rel in ("state/passport.json", "state/genesis/birth.json", "state/bundles/active.json",
                    "state/bundles/agi-master-d.json", "state/family/registry.json"):
            src = ROOT / rel
            if src.is_file():
                dst = tmp / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
        drill = seeding.rollback_drill(tmp)
        check("rollback drill snapshots and verifies", drill.get("ok") and drill["verified"] and drill["files"] >= 3,
              drill)
        check("rollback manifest written", (tmp / drill["dir"] / "manifest.json").is_file())
        plan = seeding.stage(tmp)
        check("staging plan is dry-run only", plan.get("staged_only") is True, plan.get("staged_only"))
        check("staging plan previews a candidate generation", bool(plan["candidate_preview"]["gen_id"]), plan["candidate_preview"])
        check("staging plan has checklist + preconditions", len(plan["checklist"]) >= 6 and
              "family_registry_ok" in plan["preconditions"], plan["preconditions"])
        check("staging plan digest", len(plan.get("digest", "")) == 64, plan.get("digest"))
        check("no seed persisted by staging", not (tmp / "state/genesis/seed.bin").is_file(), "seed.bin appeared")
        note = seeding.notify(tmp)
        check("readiness notification text", "Next generation" in note["message"], note["message"])
        rep = seeding.rehearse(tmp)
        check("full seed rehearsal succeeds", rep.get("ok") is True, rep.get("checks"))
        steps = {c["step"]: c["ok"] for c in rep.get("checks", [])}
        check("rehearsal births, migrates, signs, verifies",
              steps.get("birth new generation") and steps.get("migrate members") and
              steps.get("verify family registry") is True, steps)
        check("rehearsal never touches live state", steps.get("live state untouched") is True, steps)
    # execute requires explicit confirmation and green gates; runs on an isolated copy
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        for rel in ("state/passport.json", "state/passport.json.sig", "state/genesis", "state/bundles",
                    "state/family", "state/keys"):
            src = ROOT / rel
            if src.is_dir():
                shutil.copytree(src, tmp / rel, dirs_exist_ok=True)
            elif src.is_file():
                (tmp / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, tmp / rel)
        import hashlib
        live_before = hashlib.sha256((ROOT / "state/passport.json").read_bytes()).hexdigest()
        check("execute refuses without confirmation", not seeding.execute(tmp).get("ok"))
        seeding.add_item("isolate a", "ui", 0.06, 0.9, root=tmp)
        seeding.add_item("isolate b", "brain", 0.06, 0.9, root=tmp)
        res = seeding.execute(tmp, confirmer="Test Master")
        check("execute seeds in an isolated copy", res.get("ok") is True, res.get("checks") or res.get("error"))
        if res.get("ok"):
            check("execute checks all true", all(res["checks"].values()), res["checks"])
            check("execute preserves passport identity", res["checks"]["passport_identity_preserved"])
            check("execute changes the generation", res["checks"]["generation_changed"])
            check("execute archives the old generation",
                  any((tmp / "state" / "archive" / "generations").glob("*/state__genesis__birth.json")))
        live_after = hashlib.sha256((ROOT / "state/passport.json").read_bytes()).hexdigest()
        check("isolated execute never touches live passport", live_before == live_after)
    n = sum(checks)
    print("test_seeding: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

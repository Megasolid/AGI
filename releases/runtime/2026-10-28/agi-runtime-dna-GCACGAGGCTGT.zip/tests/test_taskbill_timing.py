import importlib.util
import json
import os
import sys
import tempfile
import unittest
import contextlib
import io
from unittest.mock import patch


SCRIPT = os.path.join(os.path.dirname(__file__), "..", "memory", "scripts", "taskbill.py")
sys.path.insert(0, os.path.dirname(os.path.abspath(SCRIPT)))
SPEC = importlib.util.spec_from_file_location("taskbill_under_test", SCRIPT)
taskbill = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(taskbill)


class TaskbillTimingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=os.path.dirname(__file__))
        taskbill.TIME_DIR = self.temp.name
        taskbill.TASKS = os.path.join(self.temp.name, "tasks")
        taskbill.TASKLOG = os.path.join(self.temp.name, "tasklog.jsonl")
        taskbill.watchdogs.PILLS = os.path.join(self.temp.name, "pills.md")
        self.clock = patch.object(taskbill.time, "time", return_value=1000.0)
        self.clock.start()
        self.addCleanup(self.clock.stop)
        self.addCleanup(self.temp.cleanup)

    def read_entry(self):
        with open(taskbill.TASKLOG, encoding="utf-8") as handle:
            return json.loads(handle.readline())

    def test_estimate_html_renders_steps_and_marks_approval_pending(self):
        with patch.object(taskbill.cardkit, "sandbox_cache", return_value=os.path.join(self.temp.name, "cache")):
            report = taskbill.render_bill_html(
                {"task": "Readable estimate", "steps": [{"name": "Inspect UI"}]},
                60,
                67.2,
                ["<div class='row'><span>1. Inspect UI</span><span>~1 min</span></div>"],
                {"contingency": 1.12, "mined_at": "test", "backend_logs": 0,
                 "gen_tok_s": 30, "turn_base_s": 20},
                20,
            )
        with open(report, encoding="utf-8") as handle:
            html = handle.read()
        self.assertIn("Awaiting your approval", html)
        self.assertIn("<div class='row'><span>1. Inspect UI</span>", html)
        self.assertNotIn("['<',", html)

    def test_wait_time_is_excluded_from_active_actual(self):
        taskbill.start("sample", 300, co_op=True)
        with patch.object(taskbill.time, "time", return_value=1010.0):
            taskbill.pause("sample", "waiting on user", co_op=True)
        with patch.object(taskbill.time, "time", return_value=1610.0):
            taskbill.resume("sample")
        with patch.object(taskbill.time, "time", return_value=1625.0):
            taskbill.finish("sample")
        entry = self.read_entry()
        self.assertEqual(entry["actual_s"], 25)
        self.assertEqual(entry["user_wait_s"], 600)
        self.assertTrue(entry["co_op"])

    def test_finishing_while_paused_keeps_wait_separate(self):
        taskbill.start("paused", 300)
        with patch.object(taskbill.time, "time", return_value=1008.0):
            taskbill.pause("paused", "external response")
        with patch.object(taskbill.time, "time", return_value=1308.0):
            taskbill.finish("paused")
        entry = self.read_entry()
        self.assertEqual(entry["actual_s"], 8)
        self.assertEqual(entry["user_wait_s"], 300)

    def test_same_task_name_updates_the_latest_open_bill(self):
        taskbill.start("repeat", 300)
        with patch.object(taskbill.time, "time", return_value=1010.0):
            taskbill.finish("repeat")
        with patch.object(taskbill.time, "time", return_value=1020.0):
            taskbill.start("repeat", 400)
            taskbill.pause("repeat", "handoff")
        with open(taskbill.TASKLOG, encoding="utf-8") as handle:
            entries = [json.loads(line) for line in handle]
        self.assertEqual(len(entries), 2)
        self.assertIn("actual_s", entries[0])
        self.assertIsNotNone(entries[1]["paused_epoch"])

    def test_verified_high_confidence_child_rolls_up_and_resumes_parent(self):
        taskbill.start("parent", 900)
        with patch.object(taskbill.time, "time", return_value=1010.0):
            taskbill.start("child", 120, parent="parent")
        with patch.object(taskbill.time, "time", return_value=1030.0):
            taskbill.finish("child")
            taskbill.verify("child", 0.95, "passed", "focused test suite passed")
        entries = []
        with open(taskbill.TASKLOG, encoding="utf-8") as handle:
            entries = [json.loads(line) for line in handle]
        parent = next(entry for entry in entries if entry["task"] == "parent")
        child = next(entry for entry in entries if entry["task"] == "child")
        self.assertEqual(parent["active_elapsed_s"], 30)
        self.assertIsNone(parent["paused_epoch"])
        self.assertEqual(child["parent_id"], "parent")
        self.assertTrue(child["user_report_suppressed"])
        self.assertEqual(child["pill_status"], "stamped")
        with open(taskbill.watchdogs.PILLS, encoding="utf-8") as handle:
            pill = handle.read()
        self.assertIn("task bill passed", pill)
        self.assertIn(f"taskbill-entry-id: {child['entry_id']}", pill)
        taskbill.verify("child", 0.95, "passed", "focused test suite passed")
        with open(taskbill.watchdogs.PILLS, encoding="utf-8") as handle:
            self.assertEqual(handle.read().count("[STAMP]"), 1)

    def test_passed_bill_keeps_report_visible_if_pill_stamping_fails(self):
        taskbill.start("stamp-failure", 60)
        with patch.object(taskbill.watchdogs, "stamp", side_effect=OSError("pill store unavailable")):
            with patch.object(taskbill.time, "time", return_value=1010.0):
                taskbill.finish("stamp-failure")
                taskbill.verify("stamp-failure", 0.97, "passed", "verifier passed")
        entry = self.read_entry()
        self.assertEqual(entry["pill_status"], "pending")
        self.assertTrue(entry["needs_user_report"])
        self.assertFalse(entry["user_report_suppressed"])

    def test_failed_bill_is_not_stamped_as_verified_success(self):
        taskbill.start("failed", 60)
        with patch.object(taskbill.time, "time", return_value=1010.0):
            taskbill.finish("failed")
            taskbill.verify("failed", 0.97, "failed", "verification failed")
        self.assertFalse(os.path.exists(taskbill.watchdogs.PILLS))

    def test_passed_child_with_missing_parent_still_stamps_and_requires_report(self):
        taskbill.start("orphan-child", 60)
        entry = taskbill._find_entry("orphan-child")
        entry["parent_id"] = "missing-parent"
        taskbill._replace_entry(entry)
        with patch.object(taskbill.time, "time", return_value=1010.0):
            taskbill.finish("orphan-child")
            taskbill.verify("orphan-child", 0.96, "passed", "isolated verifier passed")
        entry = self.read_entry()
        self.assertEqual(entry["pill_status"], "stamped")
        self.assertTrue(entry["needs_user_report"])

    def test_low_confidence_success_resumes_parent_but_requires_report(self):
        taskbill.start("parent", 900)
        with patch.object(taskbill.time, "time", return_value=1005.0):
            taskbill.start("child", 120, parent="parent")
            taskbill.finish("child")
            taskbill.verify("child", 0.75, "passed", "manual evidence only")
        entries = []
        with open(taskbill.TASKLOG, encoding="utf-8") as handle:
            entries = [json.loads(line) for line in handle]
        parent = next(entry for entry in entries if entry["task"] == "parent")
        child = next(entry for entry in entries if entry["task"] == "child")
        self.assertIsNone(parent["paused_epoch"])
        self.assertTrue(child["needs_user_report"])
        self.assertFalse(child["user_report_suppressed"])

    def test_verified_grandchild_rolls_up_through_nested_parent_chain(self):
        taskbill.start("root", 1800)
        with patch.object(taskbill.time, "time", return_value=1010.0):
            taskbill.start("middle", 600, parent="root")
        with patch.object(taskbill.time, "time", return_value=1020.0):
            taskbill.start("leaf", 120, parent="middle")
        with patch.object(taskbill.time, "time", return_value=1030.0):
            taskbill.finish("leaf")
            taskbill.verify("leaf", 0.96, "passed", "leaf verifier passed")
            taskbill.finish("middle")
            taskbill.verify("middle", 0.96, "passed", "middle verifier passed")
        with open(taskbill.TASKLOG, encoding="utf-8") as handle:
            entries = [json.loads(line) for line in handle]
        root = next(entry for entry in entries if entry["task"] == "root")
        middle = next(entry for entry in entries if entry["task"] == "middle")
        leaf = next(entry for entry in entries if entry["task"] == "leaf")
        self.assertEqual(middle["actual_s"], 20)
        self.assertEqual(root["active_elapsed_s"], 30)
        self.assertIsNone(root["paused_epoch"])
        self.assertEqual(middle["parent_id"], "root")
        self.assertEqual(leaf["parent_id"], "middle")

    def test_nest_existing_bill_revises_parent_and_preserves_unattributed_pause(self):
        taskbill.start("parent", 900)
        with patch.object(taskbill.time, "time", return_value=1010.0):
            taskbill.pause("parent", "awaiting continuation", co_op=True)
        with patch.object(taskbill.time, "time", return_value=1100.0):
            taskbill.start("child", 120)
        with patch.object(taskbill.time, "time", return_value=1110.0):
            taskbill.nest("child", "parent")
        out = io.StringIO()
        with patch.object(taskbill.time, "time", return_value=1200.0), contextlib.redirect_stdout(out):
            taskbill.check("parent")
            taskbill.finish("parent")
        self.assertIn("child pending child", out.getvalue())
        self.assertIn("user/external wait 0.0 min", out.getvalue())
        self.assertIn("cannot finish parent", out.getvalue())
        with patch.object(taskbill.time, "time", return_value=1130.0):
            taskbill.finish("child")
            taskbill.verify("child", 0.95, "passed", "subtask checks passed")
        entries = []
        with open(taskbill.TASKLOG, encoding="utf-8") as handle:
            entries = [json.loads(line) for line in handle]
        parent = next(entry for entry in entries if entry["task"] == "parent")
        child = next(entry for entry in entries if entry["task"] == "child")
        self.assertEqual(parent["est_s"], 1020)
        self.assertEqual(parent["active_elapsed_s"], 40)
        self.assertEqual(parent["unattributed_paused_s"], 100)
        self.assertEqual(child["parent_id"], "parent")
        self.assertIsNone(parent["paused_epoch"])

    def test_checkpoint_names_are_filesystem_safe(self):
        # 2026-10-25 slash incident: a bill task name containing '/' made cp_init use the name
        # as a path and raise FileNotFoundError after the tasklog line was already written.
        self.assertEqual(taskbill._safe_name("A + B task/bill x:y"), "A + B task-bill x-y")
        self.assertEqual(taskbill._safe_name("ok name"), "ok name")
        self.assertNotIn("/", taskbill._safe_name("W5/W6 decision proposal (co-op, awaiting D)"))
        path = taskbill.cp_init("W5/W6 decision proposal (co-op, awaiting D)")
        self.assertTrue(os.path.isfile(path))
        self.assertNotIn("/", os.path.basename(path))
        self.assertNotIn("\\", os.path.basename(path))
        self.assertTrue(os.path.basename(path).endswith(".md"))

    def test_host_speed_overlay_and_start_stamp(self):
        with tempfile.TemporaryDirectory(dir=os.path.dirname(__file__)) as folder:
            host = os.path.join(folder, "host_speed.json")
            with open(host, "w", encoding="utf-8") as fh:
                json.dump({"declared_gen_tok_s": 200,
                           "derived": {"factor": 0.25, "samples": 4, "host": "dsh",
                                       "model": "deepseek-flash"}}, fh)
            with patch.object(taskbill, "HOST_SPEED", host):
                rates = taskbill.load_rates()
                self.assertAlmostEqual(rates["contingency"], 0.25)
                self.assertEqual(rates["contingency_baseline"], 1.12)
                self.assertEqual(rates["declared_gen_tok_s"], 200.0)
                taskbill.start("stamped task", 120)
            with open(taskbill.TASKLOG, encoding="utf-8") as handle:
                entry = json.loads(handle.readline())
            self.assertTrue(entry.get("host") and entry.get("model"))


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""test_trust_log.py - Trust Layer P1 contract (append-only Merkle transparency log).

Verifies: RFC 9162 leaf/node/root hashing, inclusion proofs for every leaf of several tree
sizes, tamper rejection, consistency-proof shape, the signed-head lifecycle (sign, verify,
monotonic chain), history-rewrite refusal, rollback detection against the monitor, foreign-key
head rejection, and the boot-gate trust-log check on an isolated root.

Run: <venv-python> tests/test_trust_log.py
"""
import hashlib
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import boot_gate  # noqa: E402
import crypto  # noqa: E402
import trust_log  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    # 1. hashing primitives (independent constants)
    check("leaf = sha256(0x00 || data)", trust_log.leaf_hash(b"x") == hashlib.sha256(b"\x00x").digest())
    l0, l1 = trust_log.leaf_hash(b"a"), trust_log.leaf_hash(b"b")
    check("node = sha256(0x01 || left || right)",
          trust_log.node_hash(l0, l1) == hashlib.sha256(b"\x01" + l0 + l1).digest())
    check("empty root = sha256('')", trust_log.mth([]) == hashlib.sha256(b"").digest())
    check("single-leaf root is the leaf", trust_log.mth([l0]) == l0)
    l2 = trust_log.leaf_hash(b"c")
    check("odd node promotion (3 leaves)",
          trust_log.mth([l0, l1, l2]) == trust_log.node_hash(trust_log.node_hash(l0, l1), l2))

    # 2. inclusion proofs for every leaf of several sizes
    bad = []
    for n in (1, 2, 3, 4, 5, 7, 8, 9, 16):
        leaves = [trust_log.leaf_hash(bytes([i])) for i in range(n)]
        root = trust_log.mth(leaves)
        for i in range(n):
            path = trust_log.inclusion_path(i, leaves)
            if not trust_log.verify_inclusion(i, n, leaves[i], path, root):
                bad.append((n, i))
            if n > 1 and trust_log.verify_inclusion(i, n, leaves[(i + 1) % n], path, root):
                bad.append(("wrong-leaf-accepted", n, i))
    check("inclusion proofs verify for every leaf, n=1..9,16", not bad, str(bad[:5]))

    # 3. consistency proof shapes
    shape_bad = []
    for m, n in ((0, 8), (1, 8), (3, 8), (4, 8), (5, 8), (7, 8), (8, 8)):
        leaves = [trust_log.leaf_hash(bytes([i])) for i in range(n)]
        hashes = trust_log.consistent_hashes(m, leaves)
        if m in (0, n) and hashes:
            shape_bad.append((m, n, "expected empty"))
        if m not in (0, n) and not hashes:
            shape_bad.append((m, n, "expected hashes"))
    check("consistency proofs shaped correctly", not shape_bad, str(shape_bad))

    # 4. log lifecycle on an isolated root with its own key
    tmp = Path(tempfile.mkdtemp(prefix="agi-trustlog-test-"))
    saved = (trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR, crypto.KEYS)
    try:
        trust_log.LOG = tmp / "state" / "trust_log"
        trust_log.EVENTS = trust_log.LOG / "events.jsonl"
        trust_log.HEADS = trust_log.LOG / "heads"
        trust_log.MONITOR = trust_log.LOG / "monitor.json"
        crypto.KEYS = tmp / "state" / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)

        for i in range(6):
            trust_log.append("test-event", {"n": i})
        head = trust_log.sign_head()
        check("signed head covers all events", head["tree_size"] == 6 and head["root_hex"] == trust_log.mth(
            trust_log._leaves(trust_log.read_events())).hex())
        v = trust_log.verify()
        check("verify passes on a clean log", v["ok"], str(v.get("problems")))
        check("head signature is pinned to the device key",
              head["signature"]["key_id"] == crypto.pinned_key_id())

        # inclusion proof round trip against the signed head
        events = trust_log.read_events()
        leaves = trust_log._leaves(events)
        proof = trust_log.inclusion_path(4, leaves)
        check("inclusion proof verifies against the signed head root",
              trust_log.verify_inclusion(4, 6, leaves[4], proof, bytes.fromhex(head["root_hex"])))

        clean = trust_log.EVENTS.read_text(encoding="utf-8").splitlines()
        # tamper one recorded event -> root mismatch
        tampered = list(clean)
        tampered[2] = tampered[2].replace('"n":2', '"n":22')
        trust_log.EVENTS.write_text("\n".join(tampered) + "\n", encoding="utf-8")
        check("event tamper detected", not trust_log.verify()["ok"])
        # rollback -> monitor saw 6, log now holds 3
        trust_log.EVENTS.write_text("\n".join(clean[:3]) + "\n", encoding="utf-8")
        v2 = trust_log.verify()
        check("rollback detected against the monitor",
              not v2["ok"] and any("rollback" in p for p in v2["problems"]), str(v2.get("problems")))
        # restoring the events, a second head for the same size with a different root is refused
        trust_log.EVENTS.write_text("\n".join(clean) + "\n", encoding="utf-8")
        trust_log.sign_head()
        check("re-signing an identical head is idempotent", trust_log.sign_head()["tree_size"] == 6)
        rewritten = list(clean)
        rewritten[5] = rewritten[5].replace('"n":5', '"n":55')
        trust_log.EVENTS.write_text("\n".join(rewritten) + "\n", encoding="utf-8")
        try:
            trust_log.sign_head()
            refused = False
        except RuntimeError:
            refused = True
        check("history rewrite refused for an existing tree size", refused)
        trust_log.EVENTS.write_text("\n".join(clean) + "\n", encoding="utf-8")

        # a head signed by a different device key must not verify against the pinned key
        old_heads = sorted(trust_log.HEADS.glob("*.json"))
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        trust_log.append("test-event", {"n": "after-rotation"})
        trust_log.sign_head()
        v3 = trust_log.verify()
        check("heads signed by a rotated key are flagged",
              not v3["ok"] and any("signature" in p for p in v3["problems"]), str(v3.get("problems")))

        # 5. boot-gate trust-log check on an isolated root
        root = tmp / "gate-root"
        shutil.copytree(tmp / "state", root / "state")
        (root / "core_manifest.json").write_text(json.dumps({"files": []}), encoding="utf-8")
        r = boot_gate.check_trust_log(root)
        check("gate fails when head signatures are foreign", not r["ok"], str(r))
        (root / "state" / "keys" / "device.json").unlink()
        r2 = boot_gate.check_trust_log(root)
        check("gate reports a missing key instead of deadlocking", r2["ok"] and r2.get("skipped"), str(r2))
        shutil.rmtree(root, ignore_errors=True)
        empty = tmp / "empty-root"
        empty.mkdir()
        r3 = boot_gate.check_trust_log(empty)
        check("gate is soft when no log exists", r3["ok"] and r3.get("skipped"), str(r3))
    finally:
        (trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR, crypto.KEYS) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_trust_log: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

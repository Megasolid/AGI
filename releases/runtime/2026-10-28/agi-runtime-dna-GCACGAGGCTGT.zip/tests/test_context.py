#!/usr/bin/env python3
"""test_context.py - S1: AGI must refer to the CURRENT user, not to D by nature."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import context  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def write(root, rel, obj):
    p = pathlib.Path(root) / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj), encoding="utf-8")


def make(tmp, profiles, session, passport):
    write(tmp, "state/identity/profiles.json", {"default": "default", "profiles": profiles})
    write(tmp, "state/identity/session.json", session)
    write(tmp, "state/passport.json", passport)


def main():
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        make(tmp,
             {"default": {"name": "Default", "kind": "default"},
              "p-d": {"name": "D", "kind": "member", "member": "D"}},
             {"active": True, "level": "default", "profile": "default"},
             {"bundle_class": "master", "member": "D", "passport_id": "p1"})
        u = context.current(tmp)
        check("unauth boot resolves the boot profile", u["name"] == "Default" and not u["authenticated"], u)
        check("unauth user is Guest", context.display(tmp) == "Guest", context.display(tmp))
        check("master passport does not make an unauth session master", not u["is_master"], u)
        check("greeting is neutral before login", context.greeting(tmp) == "Welcome", context.greeting(tmp))

        make(tmp,
             {"default": {"name": "Default", "kind": "default"},
              "p-d": {"name": "D", "kind": "member", "member": "D"}},
             {"active": True, "level": "master", "profile": "p-d"},
             {"bundle_class": "master", "member": "D", "passport_id": "p1"})
        u = context.current(tmp)
        check("master session resolves D", u["name"] == "D" and u["is_master"], u)
        check("master greeting names the user", context.greeting(tmp) == "Welcome back, D", context.greeting(tmp))
        check("persona tone = master", context.persona(tmp)["tone"] == "master", context.persona(tmp))

        make(tmp,
             {"default": {"name": "Default", "kind": "default"},
              "p-ada": {"name": "Ada", "kind": "member"}},
             {"active": True, "level": "member", "profile": "p-ada"},
             {"bundle_class": "official", "member": "Ada", "passport_id": "p2"})
        u = context.current(tmp)
        check("member session resolves the member name", u["name"] == "Ada", u)
        check("member is not master", not u["is_master"], u)
        check("member persona tone = member", context.persona(tmp)["tone"] == "member", context.persona(tmp))
        check("member greeting names the member", context.greeting(tmp) == "Welcome back, Ada")
        check("non-master surface mentioning D is flagged", not context.assert_user_facing("D asked for this", tmp)[0])
        check("neutral surface is accepted", context.assert_user_facing("the user asked for this", tmp)[0])

    html = __import__("monitor").render()
    check("monitor shows the current user", "Viewing as" in html and ("Viewing as Guest" in html or
          "Viewing as D" in html), "no 'Viewing as' in rendered monitor")
    n = sum(checks)
    print("test_context: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

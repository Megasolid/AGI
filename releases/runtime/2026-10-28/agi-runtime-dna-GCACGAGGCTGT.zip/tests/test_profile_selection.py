#!/usr/bin/env python3
"""test_profile_selection.py - gen3.4/W5-A contract tests for BIOS S5.

Every adapter profile is only a *candidate*; the boot must report the measured
profile status, and an unmatched model/host must be `unprofiled` with the documented
degraded mode - never a silent qwen-local default (the gen3.4 rule change).

Run: <venv-python> tests/test_profile_selection.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import bios  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def main():
    q = bios.profile_selection({"model": {"name": "ISTA-DASLab/Qwen3.8-27B-GSQ-RCO IQ3_S"}}, {})
    check("qwen model matches qwen-local.md", q["profile"] == "qwen-local.md" and q["profile_status"] == "matched", q)
    check("qwen matched has no degraded mode", q["degraded"] == [])

    g = bios.profile_selection({"model": {"name": "deepseek-v4.1-flash"}}, {})
    check("hosted model without profile -> unprofiled", g["profile"] == "unprofiled" and g["profile_status"] == "unprofiled", g)
    check("unprofiled reports degraded mode", len(g["degraded"]) >= 1 and "qwen-local" in " ".join(g["degraded"]))

    h = bios.profile_selection({"model": {"name": "n/a"}},
                               {"host": {"session_model": "deepseek-flash"}})
    check("host session model used when env probe is n/a", h["model"] == "deepseek-flash" and h["profile"] == "unprofiled", h)

    c = bios.profile_selection({"model": {"name": ""}}, {"host": {"session_model": "claude-sonnet-4"}})
    check("host session model can match a profile", c["profile"] == "claude-class.md" and c["profile_status"] == "matched", c)

    empty = bios.profile_selection({}, {})
    check("no model facts -> unprofiled n/a", empty["profile"] == "unprofiled" and empty["model"] == "n/a", empty)
    check("never silently defaults to qwen-local",
          all(r["profile"] != "qwen-local (default)" for r in (q, g, h, c, empty)))

    n = sum(checks)
    print("test_profile_selection: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

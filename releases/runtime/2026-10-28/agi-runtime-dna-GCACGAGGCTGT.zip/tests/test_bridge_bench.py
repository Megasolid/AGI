#!/usr/bin/env python3
"""test_bridge_bench.py - graded pair benchmark over the host contract bridge (deterministic grading only)."""
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import bridge_bench  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    rc = bridge_bench.selftest()
    check("bridge_bench selftest clean", rc == 0, rc)
    tl = bridge_bench.tasks()
    check("22 objective tasks (10 easy + 12 hard)", len(tl) == 22, len(tl))
    check("every task has a deterministic grader",
          all(t.get("grader", {}).get("type") for t in tl))
    good = {}
    for t in tl:
        g = t["grader"]
        if g["type"] in ("number", "float"):
            good[t["id"]] = str(g["value"])
        elif g["type"] == "json_equals":
            good[t["id"]] = json.dumps(g["value"])
        elif g["type"] == "normalized":
            good[t["id"]] = g["value"]
        elif g["type"] == "word_set":
            good[t["id"]] = ", ".join(g["allowed"][:g.get("count", 3)])
        else:
            good[t["id"]] = g["value"]
    perfect = bridge_bench.grade_answers(good)
    check("perfect answers -> 100%", perfect["vcr"] == 1.0, perfect["vcr"])
    check("empty answers -> 0%", bridge_bench.grade_answers({})["vcr"] == 0.0)
    files = sorted((ROOT / "state" / "brains" / "benchmarks").glob("host_bridge_bench-*.json"))
    check("bridge benchmark evidence recorded", bool(files), "run bridge_bench.py --bench first")
    if files:
        ev = json.loads(files[-1].read_text(encoding="utf-8"))
        check("evidence is measured, not executor-reported",
              "measured through the harness" in ev.get("provenance", ""), ev.get("provenance"))
        check("evidence carries graded tasks", ev.get("tasks") == 22 and 0 <= ev.get("vcr", -1) <= 1,
              (ev.get("tasks"), ev.get("vcr")))
    html = __import__("brainlab").render()
    check("brain lab page shows the contract bridge", "Host contract bridge" in html, len(html))
    import suite_full
    s = suite_full.build()
    check("generated pair suite is 10x12", len(s["tasks"]) == 120 and
          len({t["family"] for t in s["tasks"]}) == 10, len(s["tasks"]))
    check("suite is reproducible", suite_full.build()["seed"] == s["seed"])
    check("derived answers grade 100%", bridge_bench.grade_full(suite_full.derive_answers(s), s)["vcr"] == 1.0)
    ffiles = sorted((ROOT / "state" / "brains" / "benchmarks").glob("host_full_suite-*.json"))
    if ffiles:
        ev = json.loads(ffiles[-1].read_text(encoding="utf-8"))
        check("full-suite evidence carries a measured tier", str(ev.get("tier", "")).startswith("T"), ev.get("tier"))
        check("full-suite evidence is measured through the bridge",
              "measured through the harness" in ev.get("provenance", ""), ev.get("provenance"))
    n = sum(checks)
    print("test_bridge_bench: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_resident.py - native self-continuation (resident pulses) contract."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import resident  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        st = resident.status(tmp)
        check("resident starts disabled with a plan", st["enabled"] is False and st["plan_items"] >= 8, st)
        idle = resident.pulse(tmp)
        check("disabled pulse is idle", idle.get("idle") is True, idle)
        armed = resident.arm(hours=2, cadence_s=300, root=tmp)
        check("arm persists mode", armed.get("enabled") is True and (tmp / "state/resident/mode.json").is_file(), armed)
        p = resident.pulse(tmp)
        check("armed pulse selects the next plan item", p.get("item", {}).get("id") == "r-01", p.get("item"))
        check("pulse text instructs real work", "Work the next plan item" in p.get("text", ""), p.get("text"))
        nxt = resident.status(tmp)["next"]
        check("next item survives pulse", nxt and nxt["id"] == "r-01", nxt)
        done = resident.complete("r-01", root=tmp, note="test evidence")
        check("complete marks the item done", done.get("ok") and done["status"]["done"] == 1, done)
        check("next item advances", resident.status(tmp)["next"]["id"] == "r-02", resident.status(tmp)["next"])
        resident.disarm(tmp, "test")
        check("disarm stops the loop", resident.pulse(tmp).get("idle") is True)
        check("resident page renders", "Resident" in resident.render(tmp))
    n = sum(checks)
    print("test_resident: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

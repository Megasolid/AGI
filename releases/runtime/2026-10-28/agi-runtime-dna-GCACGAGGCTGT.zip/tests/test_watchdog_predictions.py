import contextlib
import importlib.util
import io
import json
import os
import tempfile
import unittest


SCRIPT = os.path.join(os.path.dirname(__file__), "..", "memory", "scripts", "watchdogs.py")
SPEC = importlib.util.spec_from_file_location("watchdogs_under_test", SCRIPT)
watchdogs = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(watchdogs)


class PredictionWatchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=os.path.dirname(__file__))
        watchdogs.AGI = self.temp.name
        watchdogs.STATE = os.path.join(self.temp.name, "state")
        watchdogs.PILLS = os.path.join(self.temp.name, "pills.md")
        watchdogs.LESSONS = os.path.join(self.temp.name, "lessons.md")
        watchdogs.PREDICTIONS = os.path.join(watchdogs.STATE, "prediction_watch.json")
        os.makedirs(watchdogs.STATE, exist_ok=True)
        self.addCleanup(self.temp.cleanup)

    def test_mismatch_raises_watchdog_hold_until_downgrade_review(self):
        prediction_id = watchdogs.record_prediction("build", "cache-path", "uses bound RAM", 0.96)
        watchdogs.resolve_prediction(prediction_id, "used unrelated cwd", "mismatch")
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            watchdogs.bark()
        self.assertIn("confidence_holds=1", out.getvalue())
        self.assertIn("confidence guard: HOLD cache-path", out.getvalue())
        watchdogs.review_prediction(prediction_id, "med", "knowledge field downgraded after current-session mismatch")
        data = watchdogs.jload(watchdogs.PREDICTIONS, {})
        self.assertFalse(data["records"][0]["confidence_hold"])
        self.assertEqual(data["records"][0]["confidence_after"], "med")

    def test_match_is_logged_without_hold(self):
        prediction_id = watchdogs.record_prediction("check", "taskbill", "wait excluded", 0.94)
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            watchdogs.bark()
        self.assertIn("prediction watch: pending=1 confidence_holds=0", out.getvalue())
        watchdogs.resolve_prediction(prediction_id, "600s wait excluded", "match")
        data = watchdogs.jload(watchdogs.PREDICTIONS, {})
        self.assertEqual(data["records"][0]["outcome"], "match")
        self.assertFalse(data["records"][0].get("confidence_hold", False))
        with open(watchdogs.LESSONS, encoding="utf-8") as handle:
            self.assertIn("predicted=wait excluded", handle.read())

    def test_taskbill_stamp_is_idempotent(self):
        self.assertTrue(watchdogs.stamp("side-task", "bill verified", 0.94, "entry-123"))
        self.assertFalse(watchdogs.stamp("side-task", "bill verified", 0.94, "entry-123"))
        with open(watchdogs.PILLS, encoding="utf-8") as handle:
            content = handle.read()
        self.assertEqual(content.count("[STAMP]"), 1)
        self.assertIn("taskbill-entry-id: entry-123", content)


if __name__ == "__main__":
    unittest.main()

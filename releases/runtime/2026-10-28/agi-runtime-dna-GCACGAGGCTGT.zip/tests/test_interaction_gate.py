#!/usr/bin/env python3
"""test_interaction_gate.py - C6 contract: cards are the contract (DNA I9 / Core R10-R11).

Verifies the interaction law is wired and enforceable without a browser:
  * DNA v3 carries I9 + the interaction law; Core 3.2 carries R10/R11 and indexes the section;
  * the proposal card contract: full context, five actions, pre-selected steps, inputs;
  * the decision log is append-only and consumed exactly once (cursor);
  * a completed card exposes the RESULT block with links;
  * the dashboard links every card to its own page;
  * state/interaction.json declares a resume path and the card schema.

Run: <venv-python> tests/test_interaction_gate.py
"""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import board_serve  # noqa: E402
import sitegen  # noqa: E402
import taskcard  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def _proposal():
    return {"task_id": "gate-test", "title": "Gate test", "bill_task": "bill", "mode": "proposal",
            "decision": "pending", "estimate_s": 600, "started": "2026-10-25T17:00:00",
            "context_html": "<p>full context</p>",
            "inputs": [{"id": "extra", "label": "x", "type": "textarea", "placeholder": "p"}],
            "steps": [{"n": 1, "name": "step one", "status": "pending", "needs_input": "?"},
                      {"n": 2, "name": "step two", "status": "pending"}]}


def main():
    dna = (ROOT / "core/dna.md").read_text(encoding="utf-8")
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    manifest = json.loads((ROOT / "core_manifest.json").read_text(encoding="utf-8"))
    check("DNA v3 declares the interaction law (I9)", "dna_version: 3" in dna and "I9" in dna and "Interaction law" in dna)
    check("Core 3.2 declares R10 interaction-first", "core_version: 3.2" in skill and "R10 - Interaction-first" in skill)
    check("Core declares R11 proportionality as a separate rule", "R11 - Proportionality" in skill and "R10 - Interaction-first" in skill)
    check("interaction section indexed + bundled",
          "| interaction |" in skill and (ROOT / "core/sections/interaction.md").is_file()
          and any(f["path"] == "core/sections/interaction.md" for f in manifest["files"]))
    check("manifest carries core 3.2 / dna 3", manifest["core_version"] == "3.2" and manifest["dna_version"] == 3)

    prop = _proposal()
    html = taskcard.render_page(prop)
    check("proposal card carries full context", "PROPOSAL - FULL CONTEXT" in html and "full context" in html)
    check("proposal card exposes the five actions",
          all(("send('%s')" % k) in html for k in ("approve", "review", "cancel", "archive", "subtask")))
    check("proposal steps are pre-selected by default",
          html.count("step-approve") >= 2 and 'checked' in html and "selcount" in html)
    check("proposal card accepts per-step and free-form inputs",
          'data-step-input="1"' in html and "data-input" in html)

    # append-only decision log + cursor consumption
    prior = (board_serve.ACTIONS, board_serve.RECORD, taskcard.ACTIONS_PATH, taskcard.CURSOR_PATH)
    try:
        with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
            folder = Path(folder)
            board_serve.ACTIONS = folder / "actions.jsonl"
            board_serve.RECORD = folder / "record.json"
            a = board_serve.append_action({"type": "approve", "note": "c6", "approve_steps": [1, 2]})
            check("decision appended to the durable log", a["n"] == 1 and len(board_serve.read_actions()) == 1)
            taskcard.ACTIONS_PATH = str(folder / "actions.jsonl")
            taskcard.CURSOR_PATH = str(folder / "cursor.json")
            acts = taskcard._read_actions()
            check("decision log is readable by the consumer", len(acts) == 1 and acts[0]["type"] == "approve")
    finally:
        board_serve.ACTIONS, board_serve.RECORD, taskcard.ACTIONS_PATH, taskcard.CURSOR_PATH = prior

    done = dict(prop)
    done.update({"mode": "task", "result": {"summary": "delivered", "at": "2026-10-25 17:10",
                                            "links": [{"label": "Dashboard", "url": "http://127.0.0.1:8765/"}]},
                 "steps": [{"n": 1, "name": "a", "status": "passed", "ts": "17:10", "note": ""},
                           {"n": 2, "name": "b", "status": "passed", "ts": "17:11", "note": ""}]})
    rh = taskcard.render_page(done)
    check("completed card shows the RESULT block with links", "RESULT" in rh and "delivered" in rh
          and "http://127.0.0.1:8765/" in rh)

    d = sitegen.load_data()
    specs = sitegen.card_specs(d)
    dash = sitegen.build_dashboard(d, specs)
    check("dashboard links every card to its own page",
          len(specs) >= 24 and all(("/cards/%s.html" % s["id"]) in dash for s in specs))

    ij = json.loads((ROOT / "state" / "interaction.json").read_text(encoding="utf-8"))
    check("state/interaction.json declares the resume path", bool((ij.get("resume") or {}).get("path")))
    check("interaction.json declares schema + pre-selected steps",
          ij.get("card_schema") == 1 and ij.get("pre_selected_steps") is True)
    check("interaction.json names the decision log", ij.get("decision_log") == "state/taskboard_actions.jsonl")

    # --- phase-2 native bridge contract (2026-10-25) ------------------------
    check("decision mapping for the bridge",
          board_serve._decision_label("approve") == "Approve"
          and board_serve._decision_label("review") == "Review"
          and board_serve._decision_label("cancel") == "Cancel"
          and board_serve._decision_label("note") is None)
    check("pending question is matched to the task first",
          board_serve._pick_pending([{"task_id": "other", "call_id": "a"},
                                     {"task_id": "mine", "call_id": "b"}], "mine")["call_id"] == "b")
    ij2 = json.loads((ROOT / "state" / "interaction.json").read_text(encoding="utf-8"))
    check("interaction.json declares the native click-to-resume path",
          "native" in str(ij2.get("resume", {}).get("path"))
          and isinstance((ij2.get("resume", {}).get("measured") or {}).get("route_ms"), int))
    bridge_dir = ROOT / "harness" / "agi-resume-bridge-v4"
    check("resume bridge bundle present with tool + route",
          (bridge_dir / "index.js").is_file()
          and "agi_await_decision3" in (bridge_dir / "index.js").read_text(encoding="utf-8")
          and "/api/agi-resume3" in (bridge_dir / "index.js").read_text(encoding="utf-8"))
    n = sum(checks)
    print("test_interaction_gate: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_ui_society.py - UI incubator gate + multi-member/mana simulation."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import society_sim  # noqa: E402
import ui_incubator  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    rc = society_sim.selftest()
    check("society simulation selftest", rc == 0, rc)
    s = society_sim.simulate()
    check("council within seat cap", s["council"]["used"] <= 32, s["council"]["used"])
    check("hall within seat cap", s["hall"]["used"] <= 64, s["hall"]["used"])
    check("quorum is 17", s["quorum"] == 17)
    check("weak members sleep, never kill", s["fairness"]["no_auto_kill"])
    grants = s["mana"]["grants"]
    vals = [grants.get(t, 0) for t in society_sim.TIERS]
    check("mana grants decrease with tier strength", all(vals[i] >= vals[i + 1] for i in range(len(vals) - 1)), grants)
    check("mana remains dormant", s["mana"]["enabled"] is False)
    check("simulation is deterministic per seed",
          society_sim.simulate(seed=7)["council"]["used"] == society_sim.simulate(seed=7)["council"]["used"])
    check("simulation page renders", "Society simulation" in society_sim.render())

    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        seeded = ui_incubator.seed_candidates(tmp)
        check("ui candidates seeded", seeded["candidates"] == 4, seeded)
        cands = ui_incubator.candidates(tmp)["candidates"]
        ready = [c for c in cands if c["status"] == "ready-for-review"]
        rejected = [c for c in cands if c["status"] in ("incubating", "rejected")]
        check("some candidates pass the gate", len(ready) >= 2, [(c["id"], c["score"], c["status"]) for c in cands])
        check("a weak candidate is held back", len(rejected) >= 1, [(c["id"], c["status"]) for c in rejected])
        check("promotion refused without human approver",
              not ui_incubator.promote(ready[0]["id"], approved_by="", root=tmp).get("ok"))
        ok = ui_incubator.promote(ready[0]["id"], approved_by="D (Master)", root=tmp)
        check("human-approved promotion succeeds", ok.get("ok"), ok)
        check("promoted candidate recorded",
              "promoted" in [c["status"] for c in ui_incubator.candidates(tmp)["candidates"]])
        check("promotion of low score refused",
              not ui_incubator.promote(rejected[0]["id"], approved_by="D (Master)", root=tmp).get("ok"))
        check("incubator page renders", "UI incubator" in ui_incubator.render(tmp))
    n = sum(checks)
    print("test_ui_society: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

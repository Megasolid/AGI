#!/usr/bin/env python3
"""test_transfer.py - cross-machine profile transfer contract (pre-passkey bridge).

Runs the transfer module selftest (sealed archive, no plaintext secrets, same key id restored, passport
signature verifies, wrong passphrase refused), then checks the live profile state: the live passport is
present, and export/import round-trips the *live* profile without changing the device key id.

The live round-trip is safe by construction: import writes a backup first and re-seals the same key
material for this machine, so the device key id must be unchanged afterwards.

Run: <venv-python> tests/test_transfer.py
"""
import json
import os
import pathlib
import shutil
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import crypto  # noqa: E402
import transfer  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    check("transfer module contract passes", transfer.selftest() == 0)

    live = transfer.status()
    check("live profile has a passport", bool(live.get("passport_id")), str(live))
    check("live device key is sealed", live.get("sealed") in ("dpapi", "plain"))

    tmp = pathlib.Path(tempfile.mkdtemp(prefix="agi-transfer-live-test-"))
    old_pw = os.environ.get("AGI_TRANSFER_PASSPHRASE")
    try:
        os.environ["AGI_TRANSFER_PASSPHRASE"] = "live round-trip passphrase 2026"
        out = tmp / "live.agi-transfer.json"
        exp = transfer.export(out)
        check("live export writes a sealed archive", exp.get("ok") and out.is_file(), str(exp)[:200])
        log = out.read_text(encoding="utf-8")
        check("live archive has no plaintext key material",
              "private_raw_b64" not in log and "device.key" not in log and "PASSPHRASE" not in log)
        restored = transfer.import_archive(out)
        check("live import restores the same device key", restored.get("device_key_id") == exp.get("device_key_id"),
              str(restored)[:200])
        check("live import verification passes", (restored.get("checks") or {}).get("ok"),
              str((restored.get("checks") or {}).get("problems")))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        if old_pw is None:
            os.environ.pop("AGI_TRANSFER_PASSPHRASE", None)
        else:
            os.environ["AGI_TRANSFER_PASSPHRASE"] = old_pw

    failed = checks.count(False)
    print(f"test_transfer: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_root_offline.py - shard offline ceremony contract.

Verifies the passphrase-sealed shard path: export produces a portable package (PBKDF2 + AES-GCM,
no plaintext), import round-trips a shard and restores signing, a wrong passphrase or a foreign
root is refused, removing local shards makes signing impossible until a shard is imported back,
and the rehearsal proves the full 2-of-3 recovery while restoring the operational state.

Run: <venv-python> tests/test_root_offline.py
"""
import base64
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import root as rootmod  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    tmp = Path(tempfile.mkdtemp(prefix="agi-root-offline-"))
    saved = (rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.OFFLINE_DIR,
             rootmod.LOGGING)
    try:
        rootmod.LOGGING = False
        rootmod.KEYS = tmp / "state" / "keys"
        rootmod.ROOT_RECORD = rootmod.KEYS / "root.json"
        rootmod.ROOT_DIR = tmp / "state" / "root"
        rootmod.GENESIS = rootmod.ROOT_DIR / "genesis.json"
        rootmod.OFFLINE_DIR = rootmod.ROOT_DIR / "offline-media"
        rec = rootmod.ceremony_init(force=True)
        media = tmp / "offline-media"
        media.mkdir()

        exp1 = rootmod.export_offline(1, media / "shard-1.json", passphrase=b"correct horse battery")
        check("export writes a passphrase-sealed package", exp1["ok"] and (media / "shard-1.json").is_file())
        pkg = json.loads((media / "shard-1.json").read_text(encoding="utf-8"))
        check("package records kdf + cipher parameters",
              pkg["kdf"]["algo"] == "pbkdf2-hmac-sha256" and pkg["kdf"]["iterations"] >= 600000
              and pkg["cipher"]["algo"] == "aes-256-gcm")
        raw = rootmod.load_shard(1)[1]
        check("package carries no plaintext shard",
              base64.b64encode(raw).decode() not in json.dumps(pkg)
              and pkg["cipher"]["ciphertext_b64"] != base64.b64encode(raw).decode())

        rootmod.export_offline(2, media / "shard-2.json", passphrase=b"correct horse battery")
        # take them offline
        held = media / "_held"
        held.mkdir()
        for i in (1, 2):
            shutil.move(str(rootmod._shard_path(i)), str(held / f"root_shard_{i}.key"))
        check("with two shards offline, local signing is impossible",
              not rootmod.offline_status()["can_sign"])
        try:
            rootmod.sign_with_shards(b"x", ["1", "2"])
            failed = False
        except Exception:
            failed = True
        check("signing with offline shard ids fails", failed)

        # wrong passphrase must be refused
        try:
            rootmod.import_offline(media / "shard-1.json", passphrase=b"wrong passphrase here")
            wrong_ok = True
        except ValueError:
            wrong_ok = False
        check("wrong passphrase refused", not wrong_ok)

        imp = rootmod.import_offline(media / "shard-1.json", passphrase=b"correct horse battery")
        check("import restores a shard locally", imp["ok"] and rootmod._shard_path(1).exists())
        check("signing works again with one imported + one local shard",
              rootmod.sign_with_shards(b"x", ["1", "3"])["root_key_id"] == rec["root_key_id"])

        # foreign-root package refused
        foreign = json.loads((media / "shard-2.json").read_text(encoding="utf-8"))
        foreign["root_key_id"] = "ffffffffffffffff"
        (media / "foreign.json").write_text(json.dumps(foreign), encoding="utf-8")
        try:
            rootmod.import_offline(media / "foreign.json", passphrase=b"correct horse battery")
            foreign_ok = True
        except ValueError:
            foreign_ok = False
        check("package from a foreign root refused", not foreign_ok)

        # move shard 2 offline for real, then take shard 1 offline too: signing must stop at one local shard
        shutil.move(str(held / "root_shard_2.key"), str(rootmod._shard_path(2)))
        rmv = rootmod.remove_local_shard(2, media)
        check("remove needs an offline package and deletes the local copy",
              rmv["ok"] and not rootmod._shard_path(2).exists())
        check("two remaining shards still allow signing", rootmod.offline_status()["can_sign"])
        rmv1 = rootmod.remove_local_shard(1, media)
        check("removing down to one local shard blocks signing",
              rmv1["ok"] and not rootmod.offline_status()["can_sign"])
        check("status reports the retrieval requirement", rootmod.offline_status()["needs_offline_retrieval"])
        rootmod.import_offline(media / "shard-1.json", passphrase=b"correct horse battery")
        check("a shard is recoverable from offline media", rootmod.offline_status()["can_sign"])
        rootmod.import_offline(media / "shard-2.json", passphrase=b"correct horse battery")
        check("all three shards are back locally before the rehearsal",
              sorted(rootmod.offline_status()["local_shards"]) == [1, 2, 3])

        # preflight: proves the ceremony prerequisites without touching a shard
        import os as _os
        saved_pw = _os.environ.pop("AGI_SHARD_PASSPHRASE", None)
        try:
            pf = rootmod.offline_preflight(tmp / "preflight-media", require_passphrase=True)
            check("preflight fails clearly when the passphrase is unset",
                  not pf["ok"] and any("AGI_SHARD_PASSPHRASE" in p for p in pf["problems"]))
            check("preflight suggests a PowerShell 5.1 command",
                  any("InteropServices.Marshal" in n for n in pf["notes"]))
            _os.environ["AGI_SHARD_PASSPHRASE"] = "correct horse battery"
            pf2 = rootmod.offline_preflight(tmp / "preflight-media", require_passphrase=True)
            check("preflight passes with passphrase + writable media", pf2["ok"], str(pf2.get("problems")))
        finally:
            _os.environ.pop("AGI_SHARD_PASSPHRASE", None)
            if saved_pw is not None:
                _os.environ["AGI_SHARD_PASSPHRASE"] = saved_pw

        # a missing media file is a clean refusal, not a traceback
        try:
            rootmod.import_offline(tmp / "does-not-exist.json", passphrase=b"whatever passphrase")
            missing_ok = True
        except RuntimeError as e:
            missing_ok = "not found" in str(e)
        except FileNotFoundError:
            missing_ok = False
        check("importing a missing package is a clean refusal", missing_ok)

        # full rehearsal restores the operational state
        rep = rootmod.rehearse_offline(tmp / "rehearsal", passphrase=b"rehearsal passphrase")
        check("rehearsal proves export -> offline -> import -> sign", rep["ok"], str(rep.get("steps")))
        check("rehearsal restores all three local shards", len(rep["restored_local_shards"]) == 3)
        check("rehearsal leaves no packages behind", not list((tmp / "rehearsal").glob("root-shard-*.json")))
    finally:
        (rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.OFFLINE_DIR,
         rootmod.LOGGING) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_root_offline: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_activation.py - Trust Layer L1.5 (P4) contract: the D touch.

Verifies: the offline root ceremony (ML-DSA-87 + 2-of-3 Shamir shards, DPAPI-sealed, no seed
file), root-signed activation attestations bound to the passport + genome root, the U0->U1->U2
level machine with heartbeats, delegation to U3, expiry and device-signed revocation, single
shard refusal, tamper detection, and the boot-gate activation contract.

Run: <venv-python> tests/test_activation.py
"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import activation  # noqa: E402
import boot_gate  # noqa: E402
import crypto  # noqa: E402
import root as rootmod  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


class Sandbox:
    def __init__(self, tmp):
        self.tmp = Path(tmp)
        self.saved = (activation.ACT, activation.ATTEST_DIR, activation.REVOCATIONS, activation.HEARTBEAT,
                      activation.PASSPORT, activation.LOGGING,
                      rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.LOGGING,
                      crypto.KEYS)
        activation.LOGGING = False
        rootmod.LOGGING = False
        activation.ACT = self.tmp / "state" / "activation"
        activation.ATTEST_DIR = activation.ACT / "attestations"
        activation.REVOCATIONS = activation.ACT / "revocations.jsonl"
        activation.HEARTBEAT = activation.ACT / "heartbeat.json"
        activation.PASSPORT = self.tmp / "state" / "passport.json"
        crypto.KEYS = self.tmp / "state" / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        rootmod.KEYS = self.tmp / "state" / "keys"
        rootmod.ROOT_RECORD = rootmod.KEYS / "root.json"
        rootmod.ROOT_DIR = self.tmp / "state" / "root"
        rootmod.GENESIS = rootmod.ROOT_DIR / "genesis.json"
        rootmod.ceremony_init(force=True)
        activation._jdump(activation.PASSPORT, {
            "schema": "agi-passport/1", "passport_id": "pass-1", "member": "D",
            "bundle_class": "master", "user_genome_root": "ab" * 32, "genome_epoch": 4})

    def close(self):
        (activation.ACT, activation.ATTEST_DIR, activation.REVOCATIONS, activation.HEARTBEAT,
         activation.PASSPORT, activation.LOGGING,
         rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.LOGGING,
         crypto.KEYS) = self.saved


def main():
    tmp = Path(tempfile.mkdtemp(prefix="agi-act-test-"))
    sb = Sandbox(tmp)
    try:
        rec = rootmod.load_root()
        check("root is ML-DSA-87 with 2-of-3 threshold",
              rec["alg"] == "ML-DSA-87" and rec["threshold"]["k"] == 2 and rec["threshold"]["n"] == 3)
        check("three shard files, all DPAPI-sealed",
              len([s for s in rec["shards"] if (tmp / "state" / "keys" / s["file"]).exists()]) == 3
              and all(s["sealed"] == ("dpapi" if sys.platform == "win32" else "plain") for s in rec["shards"]))
        check("no plaintext seed file exists",
              not any((tmp / "state" / "keys").glob("root.key")) and not any((tmp / "state" / "keys").glob("*seed*")))
        check("root verifies against its signed genesis", rootmod.verify_root()["ok"])

        check("level starts at U0 dormant",
              activation.effective_level()["level"] == "U0"
              and activation.effective_level()["genome_active"] is False)
        try:
            activation.attest(shard_ids=("1",), days=30)
            single = True
        except ValueError:
            single = False
        check("one shard cannot authorise activation", not single)

        att = activation.attest(scope="official", level="U1", days=30, shard_ids=("1", "2"))
        check("attestation is root-signed (ML-DSA-87)", att["root_signature"]["alg"] == "ML-DSA-87")
        check("attestation binds passport + genome root",
              att["passport_id"] == "pass-1" and att["user_genome_root"] == "ab" * 32)
        check("attestation verifies and is usable", activation.verify_attestation(att)["usable"])
        st = activation.effective_level()
        check("U1 after the offline D touch token", st["level"] == "U1" and st["genome_active"] is True)

        # heartbeat -> U2 (presence), signing with the other shard pair
        activation.heartbeat(shard_ids=("1", "3"), valid_for_s=300)
        st2 = activation.effective_level()
        check("U2 while D is present", st2["level"] == "U2" and st2["heartbeat"]["fresh"] is True)
        bad = dict(activation._jload(activation.HEARTBEAT))
        bad["nonce"] = "0" * 32
        activation._jdump(activation.HEARTBEAT, bad)
        check("tampered heartbeat is not fresh", not activation.verify_heartbeat()["fresh"])

        # a tampered attestation payload must not verify
        tampered = dict(att)
        tampered["scope"] = "root-issuance"
        check("tampered attestation rejected", not activation.verify_attestation(tampered)["usable"])

        # expiry
        old = activation.attest(scope="official", level="U1", days=-1, shard_ids=("2", "3"))
        check("expired attestation is structurally valid but unusable",
              activation.verify_attestation(old)["ok"] and not activation.verify_attestation(old)["usable"]
              and activation.verify_attestation(old)["expired"])

        # delegation -> U3, then revocation drops it
        deleg = activation.attest(scope="pill-ingest", level="U3", days=1, shard_ids=("1", "2"),
                                  delegate_to="member-B")
        st3 = activation.effective_level()
        check("delegation raises the level to U3", st3["level"] == "U3" and st3["delegate_to"] == "member-B")
        activation.revoke(deleg["attestation_id"], "test: delegation withdrawn")
        check("revocation drops the delegation",
              activation.effective_level()["level"] != "U3"
              and not activation.verify_attestation(deleg)["usable"])
        check("revocation record is device-signed", activation.verify_revocation(
            activation.load_revocations()[-1])["ok"])
        check("full verify passes on an honest state", activation.verify_all()["ok"],
              str(activation.verify_all().get("problems")))

        # boot-gate contract on an isolated root
        root = tmp / "gate-root"
        shutil.copytree(tmp / "state", root / "state")
        g = boot_gate.check_activation(root)
        check("gate reports the live level", g.get("ok") and g.get("level") in ("U1", "U2"),
              str(g))
        (root / "state" / "passport.json").write_text(json.dumps(
            {"schema": "agi-passport/1", "passport_id": "someone-else",
             "user_genome_root": "cd" * 32}), encoding="utf-8")
        g2 = boot_gate.check_activation(root)
        check("gate fails when attestations no longer bind the passport", not g2.get("ok"), str(g2))
        empty = tmp / "empty"
        empty.mkdir(exist_ok=True)
        g3 = boot_gate.check_activation(empty)
        check("gate is soft when no activation layer exists", g3["ok"] and g3.get("skipped"), str(g3))
    finally:
        sb.close()
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_activation: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

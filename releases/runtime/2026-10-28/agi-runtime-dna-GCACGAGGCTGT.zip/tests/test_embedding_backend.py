import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))

import embedding_backend
import bios
import memory_embed
import memory_search
import producers


class FakeResponse:
    def __init__(self, body):
        self.body = body

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    def read(self):
        return self.body


class EmbeddingBackendTests(unittest.TestCase):
    def test_requires_explicit_provider_and_has_no_legacy_default(self):
        with self.assertRaisesRegex(RuntimeError, "Internal embedding is preferred but not adopted yet"):
            embedding_backend.backend_config({})

    def test_embed_command_fails_closed_when_backend_is_unset(self):
        with patch.dict("os.environ", {}, clear=True), patch("sys.argv", ["memory_embed.py", "--quiet"]):
            self.assertEqual(memory_embed.main(), 2)

    def test_host_application_identity_ignores_season_paths(self):
        self.assertEqual(bios.host_application_identity({"CODEX_WINDOWS_SANDBOX_PACKAGE_FAMILY": "Codex"}), "codex")
        self.assertEqual(bios.host_application_identity({"AGI_HOST_APPLICATION": "MyHost"}), "myhost")

    def test_internal_embedding_default_prompts_for_manual_model_on_cold_boot(self):
        old = {"host_application": {"id": "unsloth-studio"}, "ram": {"root": "same-season"}}
        new_ram = {"root": "different-season", "verified": True}
        result = bios.embedding_adoption(old, new_ram, "codex", {})
        self.assertEqual(result["preferred"], "internal")
        self.assertEqual(result["backend"], "internal")
        self.assertEqual(result["status"], "needs_user_choice")
        self.assertTrue(result["needs_user_choice"])
        self.assertIn("AGI_INTERNAL_EMBEDDING_MODEL", result["suggestion"])

    def test_internal_embedding_is_ready_when_model_directory_is_configured(self):
        result = bios.embedding_adoption({}, {"verified": True}, "codex",
                                         {"AGI_INTERNAL_EMBEDDING_MODEL": "local-model"})
        self.assertEqual(result["status"], "ready")
        self.assertTrue(result["model_configured"])
        self.assertIsNone(result["suggestion"])

    def test_explicit_external_backend_is_preserved_without_internal_model_prompt(self):
        result = bios.embedding_adoption({}, {"verified": True}, "codex",
                                         {"AGI_EMBEDDING_BACKEND": "openai-compatible"})
        self.assertEqual(result["backend"], "openai-compatible")
        self.assertEqual(result["status"], "external_selected")
        self.assertFalse(result["needs_user_choice"])

    def test_boot_card_renders_manual_embedding_choice(self):
        prior_state = producers.STATE
        try:
            with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
                producers.STATE = Path(folder)
                (producers.STATE / "boot_card.json").write_text(json.dumps({
                    "status": "ready",
                    "embedding_adoption": {
                        "preferred": "internal", "backend": "internal",
                        "model_configured": False, "status": "needs_user_choice",
                        "suggestion": "Would you like to set AGI_INTERNAL_EMBEDDING_MODEL manually?"
                    }
                }), encoding="utf-8")
                html = producers.boot()["body"]
            self.assertIn("needs_user_choice", html)
            self.assertIn("AGI_INTERNAL_EMBEDDING_MODEL", html)
        finally:
            producers.STATE = prior_state

    def test_maintenance_card_lists_parked_tasks_separately(self):
        prior_state = producers.STATE
        try:
            with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
                producers.STATE = Path(folder)
                (producers.STATE / "maintenance.json").write_text(json.dumps({
                    "open": ["unrelated maintenance item"],
                    "parked_tasks": ["dash-v2-draft parked", "agi-v4-rebuild parked"],
                    "fixed": []
                }), encoding="utf-8")
                (producers.STATE / "season_tasks.json").write_text(json.dumps({
                    "mode": "maintenance"
                }), encoding="utf-8")
                card = producers.maintenance()
            self.assertIn("parked maintenance tasks", card["body"])
            self.assertIn("dash-v2-draft parked", card["body"])
            self.assertIn("agi-v4-rebuild parked", card["body"])
        finally:
            producers.STATE = prior_state

    def test_openai_compatible_batches_normalizes_and_orders(self):
        seen = []

        def fake_urlopen(request, timeout):
            body = json.loads(request.data)
            seen.append((request.full_url, timeout, request.headers, body))
            data = [{"index": i, "embedding": [float(i), float(1 - i)]}
                    for i in reversed(range(len(body["input"])))]
            return FakeResponse(json.dumps({"data": data}).encode())

        env = {"AGI_EMBEDDING_BACKEND": "openai-compatible",
               "AGI_EMBEDDING_URL": "http://localhost:7777/v1",
               "AGI_EMBEDDING_MODEL": "host-test-embedder",
               "AGI_EMBEDDING_API_KEY": "not-written-to-disk",
               "AGI_EMBEDDING_TIMEOUT": "9"}
        with patch("urllib.request.urlopen", fake_urlopen):
            vectors, info = embedding_backend.embed_texts(["first", "second"], env)
        self.assertEqual(vectors, [[0.0, 1.0], [1.0, 0.0]])
        self.assertEqual(info, {"backend": "openai-compatible", "model": "host-test-embedder", "dimensions": 2})
        self.assertEqual(seen[0][0], "http://localhost:7777/v1/embeddings")
        self.assertEqual(seen[0][1], 9.0)
        self.assertEqual(seen[0][3]["input"], ["first", "second"])
        self.assertEqual(seen[0][2]["Authorization"], "Bearer not-written-to-disk")

    def test_npy_roundtrip_uses_plain_python(self):
        vectors = [[0.5, 0.5], [-1.0, 0.25]]
        with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
            target = Path(folder) / "vectors.npy"
            embedding_backend.write_npy(target, vectors)
            actual = embedding_backend.read_npy(target)
        for expected_row, actual_row in zip(vectors, actual):
            for expected, value in zip(expected_row, actual_row):
                self.assertAlmostEqual(expected, value, places=6)

    def test_search_uses_configured_provider_and_plain_python_matrix(self):
        prior_index = memory_search.INDEX_DIR
        try:
            memory_search._embeddings = None
            memory_search._chunks = None
            memory_search._weights = {}
            with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
                memory_search.INDEX_DIR = Path(folder)
                embedding_backend.write_npy(memory_search.INDEX_DIR / "embeddings.npy", [[1.0, 0.0], [0.0, 1.0]])
                (memory_search.INDEX_DIR / "chunks.json").write_text(json.dumps([
                    {"text": "alpha text", "header": "Alpha", "source": "a.md"},
                    {"text": "beta text", "header": "Beta", "source": "b.md"}]), encoding="utf-8")
                (memory_search.INDEX_DIR / "provider.json").write_text(json.dumps({
                    "backend": "openai-compatible", "model": "host-test-embedder",
                    "dimensions": 2, "chunks": 2}), encoding="utf-8")
                with patch("memory_search.backend_config", return_value={
                        "backend": "openai-compatible", "model": "host-test-embedder"}), \
                     patch("memory_search.embed_texts", return_value=([[1.0, 0.0]], {})):
                    results = memory_search.search("alpha", k=1)
                self.assertEqual(results[0]["source"], "a.md")
        finally:
            memory_search.INDEX_DIR = prior_index
            memory_search._embeddings = None
            memory_search._chunks = None
            memory_search._weights = {}

    def test_memory_embed_builds_a_portable_index_from_host_endpoint(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
            root = Path(folder)
            mem = root / "memory"
            state = mem / "state"
            state.mkdir(parents=True)
            (state / "note.md").write_text("# Note\n\nHost-side embedding test.", encoding="utf-8")
            index = root / "index"

            def fake_urlopen(request, timeout):
                body = json.loads(request.data)
                response = {"data": [{"index": i, "embedding": [1.0, 0.0]}
                                     for i, _ in enumerate(body["input"])]}
                return FakeResponse(json.dumps(response).encode())

            with patch.object(memory_embed, "MEM_DIR", mem), \
                 patch.object(memory_embed, "SCAN_DIRS", [state]), \
                 patch.object(memory_embed, "SKILLS_ROOT", root / "skills"), \
                 patch.object(memory_embed, "INDEX_DIR", index), \
                 patch.dict("os.environ", {"AGI_EMBEDDING_BACKEND": "openai-compatible",
                                            "AGI_EMBEDDING_URL": "http://localhost:7777/v1",
                                            "AGI_EMBEDDING_MODEL": "host-test-embedder"}, clear=False), \
                 patch("urllib.request.urlopen", fake_urlopen), \
                 patch("sys.argv", ["memory_embed.py", "--quiet"]):
                memory_embed.main()

            metadata = json.loads((index / "provider.json").read_text(encoding="utf-8"))
            chunks = json.loads((index / "chunks.json").read_text(encoding="utf-8"))
            vectors = embedding_backend.read_npy(index / "embeddings.npy")
            self.assertEqual(metadata["backend"], "openai-compatible")
            self.assertEqual(metadata["model"], "host-test-embedder")
            self.assertEqual(metadata["chunks"], len(chunks))
            self.assertEqual(len(vectors), len(chunks))


if __name__ == "__main__":
    unittest.main()

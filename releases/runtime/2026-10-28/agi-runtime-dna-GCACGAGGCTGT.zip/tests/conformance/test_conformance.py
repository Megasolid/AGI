#!/usr/bin/env python3
"""Conformance suite (DNA I7) - minimal gen3 baseline.

Run: <venv-python> tests/conformance/test_conformance.py   (from the skill root)
Checks that a generation of the framework actually holds its invariants on this machine:
  C1 verified-only registry is intact (every 'verified' script exists + compiles)
  C2 canonical state tree: exactly one check_runs.jsonl, at <skill>/state/
  C3 DNA/Core wiring: dna.md version >= Core reference; SKILL.md gate checklist present
  C4 core selftest passes (job gate + memory ops) - run as subprocess
Exit code 0 = PASS. Any failure prints FAIL line(s) and exits 1.
"""
import json, py_compile, re, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]          # <skill>
MEM = ROOT / "memory"
STATE = ROOT / "state"
failures = []

def check(name, ok, detail=""):
    print(f"  {'PASS' if ok else 'FAIL'} {name}" + (f" - {detail}" if detail and not ok else ""))
    if not ok:
        failures.append(name)

print("== C1 registry: verified-only gate intact ==")
reg = json.loads((MEM / "scripts/registry.json").read_text(encoding="utf-8"))
sdir = MEM / "scripts"
ok_c1 = True
for name, meta in reg["scripts"].items():
    if not str(meta.get("status", "")).startswith("verified"):
        continue
    # resolve registry placeholders {MEM}/{PY}; the script file is the arg that ends .py/.sh
    py = None
    for part in meta["run"]:
        p = Path(part.replace("{MEM}", str(MEM)).replace("{PY}", sys.executable))
        if p.suffix == ".py":
            py = p
        elif p.suffix == ".sh":
            if not p.exists():
                check(f"registry:{name}", False, f"script file missing: {p}")
                ok_c1 = False
    if py is None:
        continue  # pure CLI invocation (no local script file) - nothing to compile
    if not py.exists():
        check(f"registry:{name}", False, f"script file missing: {py}")
        ok_c1 = False
        continue
    try:
        py_compile.compile(str(py), doraise=True)
    except Exception as e:
        check(f"registry:{name}", False, str(e))
        ok_c1 = False
check("all verified scripts exist + compile", ok_c1)

print("== C2 canonical state tree ==")
runs = list(ROOT.rglob("check_runs.jsonl"))
runs = [p for p in runs if "bundle_stage" not in p.parts and "backups" not in p.parts]
check("exactly one check_runs.jsonl", len(runs) == 1, f"found: {[str(p) for p in runs]}")
check("it is the canonical root state file",
      len(runs) == 1 and runs[0].resolve() == (STATE / "check_runs.jsonl").resolve())
n = sum(1 for _ in open(STATE / "check_runs.jsonl", encoding="utf-8")) if STATE.joinpath("check_runs.jsonl").exists() else 0
print(f"       runs in canonical log: {n}")

print("== C3 DNA/Core wiring ==")
dna = (ROOT / "core/dna.md").read_text(encoding="utf-8")
skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
m = re.search(r"dna_version:\s*(\d+)", dna)
check("dna.md declares a version", bool(m), "no dna_version line")
if m:
    check("Core references DNA v" + m.group(1), f"DNA v{m.group(1)}" in skill or "DNA" in skill,
          "SKILL.md does not reference the current DNA")
check("SKILL.md has gate checklist", "Gate checklist" in skill)
check("DNA §5b present (confidence/KEP)", "KEP" in dna and "Grounding rule" in dna)

print("== C4 core selftest ==")
if "--quick" in sys.argv:
    print("       SKIPPED (--quick: boot_gate uses this; C4 is covered by the full conformance run in the registry)")
else:
    # 2026-10-19: silent-spawn rule - raw subprocess.run here opened a visible
    # python.exe console window (parent has no console). Route through _silent.
    sys.path.insert(0, str(MEM / "scripts"))
    from _silent import silent_run
    try:
        p = silent_run([sys.executable, str(MEM / "scripts/core_selftest.py")],
                       capture_output=True, text=True, timeout=180)
        ok_c4 = p.returncode == 0
        tail = (p.stdout.strip() or p.stderr.strip()).splitlines()[-3:]
    except Exception as e:
        ok_c4, tail = False, [str(e)]
    for line in tail:
        print("       |", line)
    check("core_selftest exit 0", ok_c4)

print("== C5 portability: no hardcoded machine paths in live scripts ==")
# W2 gate (2026-10-25): live scripts must self-locate and read machine facts from state/.
# Legacy/retired files are listed explicitly, never silently skipped.
ALLOW = {
    "scripts/agents/claude_worker.py": "retired pool worker (kept for history, never run)",
    "scripts/verify_bundle.py": "legacy unregistered duplicate of pack_core_bundle (quarantine candidate)",
}
PAT = re.compile(r"[A-Za-z]:\\\\Users\\\\|[A-Za-z]:/Users/|C:\\\\Program Files|/c/Users/")
hits = []
scan = sorted((MEM / "scripts").rglob("*.py")) + [MEM / "check.sh"]
for f in scan:
    rel = str(f.relative_to(MEM)).replace("\\", "/")
    if rel in ALLOW:
        continue
    try:
        txt = f.read_text(encoding="utf-8", errors="replace")
    except OSError:
        continue
    for m in PAT.finditer(txt):
        hits.append(f"{rel}:{txt[:m.start()].count(chr(10)) + 1}")
check("live scripts + check.sh carry no hardcoded machine paths", not hits, "; ".join(hits[:8]))
if ALLOW:
    print(f"       allowlisted legacy files: {len(ALLOW)}")

print("== C6 interaction law: cards are the contract (DNA I9 / R10-R11) ==")
dna_txt = (ROOT / "core/dna.md").read_text(encoding="utf-8")
core_txt = (ROOT / "SKILL.md").read_text(encoding="utf-8")
manifest = json.loads((ROOT / "core_manifest.json").read_text(encoding="utf-8"))
check("DNA v3 interaction law present", "dna_version: 3" in dna_txt and "I9" in dna_txt and "Interaction law" in dna_txt)
check("Core 3.2 R10/R11 present", "core_version: 3.2" in core_txt and "R10 - Interaction-first" in core_txt
      and "R11 - Proportionality" in core_txt)
check("interaction section indexed + bundled",
      "| interaction |" in core_txt and (ROOT / "core/sections/interaction.md").is_file()
      and any(f["path"] == "core/sections/interaction.md" for f in manifest["files"]))
try:
    sys.path.insert(0, str(MEM / "scripts"))
    import taskcard, sitegen, board_serve
    prop = {"task_id": "c6", "title": "c6", "bill_task": "b", "mode": "proposal", "decision": "pending",
            "estimate_s": 60, "started": "2026-10-25T17:00:00", "context_html": "<p>ctx</p>",
            "inputs": [{"id": "x", "label": "x", "type": "textarea", "placeholder": "p"}],
            "steps": [{"n": 1, "name": "one", "status": "pending", "needs_input": "?"},
                      {"n": 2, "name": "two", "status": "pending"}]}
    ph = taskcard.render_page(prop)
    ok_card = (all(("send('%s')" % k) in ph for k in ("approve", "review", "cancel", "archive", "subtask"))
               and "PROPOSAL - FULL CONTEXT" in ph and ph.count("step-approve") >= 2 and "checked" in ph)
    check("proposal card contract (context, five actions, pre-selected steps)", ok_card)
    with tempfile.TemporaryDirectory() as td:
        prior = (board_serve.ACTIONS, board_serve.RECORD, taskcard.ACTIONS_PATH, taskcard.CURSOR_PATH)
        try:
            board_serve.ACTIONS = Path(td) / "a.jsonl"
            board_serve.RECORD = Path(td) / "r.json"
            board_serve.append_action({"type": "approve", "approve_steps": [1]})
            acts = board_serve.read_actions()
            taskcard.ACTIONS_PATH = str(Path(td) / "a.jsonl")
            taskcard.CURSOR_PATH = str(Path(td) / "c.json")
            consumed = taskcard._read_actions()
            check("append-only decision log + consumer read", len(acts) == 1 and len(consumed) == 1)
        finally:
            board_serve.ACTIONS, board_serve.RECORD, taskcard.ACTIONS_PATH, taskcard.CURSOR_PATH = prior
    done = dict(prop)
    done.update({"mode": "task", "result": {"summary": "ok", "at": "t", "links": []},
                 "steps": [{"n": 1, "name": "a", "status": "passed", "ts": "", "note": ""}]})
    check("completed card exposes the RESULT block", "RESULT" in taskcard.render_page(done))
    d = sitegen.load_data()
    specs = sitegen.card_specs(d)
    dash = sitegen.build_dashboard(d, specs)
    check("dashboard links every card to its page",
          len(specs) >= 24 and all(("/cards/%s.html" % c["id"]) in dash for c in specs))
    ij = json.loads((STATE / "interaction.json").read_text(encoding="utf-8"))
    check("state/interaction.json declares the resume path", bool((ij.get("resume") or {}).get("path")))
    check("native click-to-resume declared + bridge bundled",
          "native" in str((ij.get("resume") or {}).get("path"))
          and (ROOT / "harness" / "agi-resume-bridge-v4" / "index.js").is_file())
except Exception as e:
    check("interaction contract callable", False, str(e)[:160])

print()
if failures:
    print(f"CONFORMANCE FAIL ({len(failures)}): {', '.join(failures)}")
    sys.exit(1)
print("CONFORMANCE PASS (gen3 baseline, C1-C6)")

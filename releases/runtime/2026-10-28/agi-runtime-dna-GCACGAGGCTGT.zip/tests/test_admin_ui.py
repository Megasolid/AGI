#!/usr/bin/env python3
"""test_admin_ui.py - local admin UI/API contract (P27).

The browser logs the admin in: setup shows the phrase once, train verifies it, restore decrypts the blob
and enrols the machine. The phrase is typed into the local page and posted only to 127.0.0.1; the runtime
must never log it, and the endpoints must refuse requests that do not come from the UI and must refuse a
wrong phrase.

Tests (against the live loopback server; safe - they only use wrong phrases / existing-factor refusals):
  * page has the restore form when a factor exists and no password field;
  * no X-AGI-UI header -> 403;
  * wrong phrase on /api/admin/train -> 401;
  * /api/admin/setup when a factor already exists -> 409;
  * wrong phrase on /api/admin/restore -> non-200.
"""
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import board_serve  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def post(path, body, headers):
    url = "http://127.0.0.1:%s%s" % (board_serve.port(), path)
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status, r.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")


def get(path):
    with urllib.request.urlopen("http://127.0.0.1:%s%s" % (board_serve.port(), path), timeout=10) as r:
        return r.status, r.read().decode("utf-8", "ignore")


def main():
    import adminfactor

    factor = adminfactor._jload(ROOT / "state" / "identity" / "admin.json") or {}
    check("admin factor exists (operator ran setup)", bool(factor.get("schema")), str(factor)[:120])

    st, page = get("/login")
    check("login page served", st == 200)
    check("restore form present (shared machine)", "id='btnRestore'" in page or "btnRestore" in page)
    # the only password-typed fields allowed are the masked admin inputs (there is no login password)
    import re as _re
    pw_ids = _re.findall(r"<input[^>]*id='([^']+)'[^>]*type='password'", page) + \
             _re.findall(r"<input[^>]*type='password'[^>]*id='([^']+)'", page)
    check("no login password field (only masked admin inputs)",
          set(pw_ids) <= {"phraseIn", "trainIn", "rotIn"} and "phraseIn" in pw_ids, str(pw_ids))
    check("admin api referenced", "/api/admin/" in page)

    st, _ = post("/api/admin/train", {}, {})
    check("requests without X-AGI-UI are refused", st == 403, str(st))
    st, _ = post("/api/admin/train", {"phrase": "wrong words entirely"}, {"X-AGI-UI": "1"})
    check("wrong phrase on train -> 401", st == 401, str(st))
    st, _ = post("/api/admin/setup", {"confirm": True}, {"X-AGI-UI": "1"})
    check("setup refuses when a factor exists -> 409", st == 409, str(st))
    blob = str((ROOT / (factor.get("blob") or "")).resolve())
    st, body = post("/api/admin/restore", {"phrase": "wrong words entirely", "blob": blob},
                    {"X-AGI-UI": "1"})
    check("wrong phrase on restore is refused", st != 200, "%s %s" % (st, body[:80]))
    st, body = post("/api/admin/rotate", {"phrase": "wrong words entirely"}, {"X-AGI-UI": "1"})
    check("rotate with a wrong current phrase is refused", st >= 400, "%s %s" % (st, body[:80]))
    st, body = post("/api/admin/wipe", {}, {"X-AGI-UI": "1"})
    check("wipe requires confirm", st == 400, "%s %s" % (st, body[:80]))
    check("page offers rotate and temporary-session option",
          "btnRotate" in page and "tempAck" in page)

    failed = checks.count(False)
    print(f"test_admin_ui: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_attention.py - S5 attention/aesthetic gate: pixel-diff, a11y checks, art direction."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import attention  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    live = attention.art_direction()
    check("art direction has required traits", all(k in live for k in attention.ART_TRAITS), sorted(live))
    check("art direction is deterministic", attention.art_direction() == attention.art_direction())
    check("salience budget is explicit", "alerts" in live["salience_budget"], live["salience_budget"])
    bad = attention.static_checks("<html><body><svg></svg><div>no sources</div></body></html>")
    check("static checks fail missing a11y/reduced motion", bad["ok"] is False, bad["checks"])
    good = attention.static_checks("<html><style>@media (prefers-reduced-motion: reduce){}"
                                   "</style><body><svg role='img' aria-label='x'></svg>"
                                   "<div>source: a</div><div>source: b</div><div>source: c</div></body></html>")
    check("static checks pass a compliant page", good["ok"] is True, good["checks"])
    with tempfile.TemporaryDirectory() as td:
        from PIL import Image
        tmp = pathlib.Path(td)
        a = tmp / "a.png"; b = tmp / "b.png"; c = tmp / "c.png"
        Image.new("RGB", (100, 50), "white").save(a)
        Image.new("RGB", (100, 50), "white").save(b)
        Image.new("RGB", (100, 50), "white").save(c)
        img = Image.open(c)
        for x in range(10):
            for y in range(10):
                img.putpixel((x, y), (0, 0, 0))
        img.save(c)
        same = attention.pixel_diff(a, b)
        changed = attention.pixel_diff(a, c)
        check("identical screenshots have zero diff", same["ratio"] == 0.0, same)
        check("changed pixels are measured", changed["ratio"] > 0 and changed["bbox"], changed)
        check("anomaly budget rejects a big change", changed["ratio"] > attention.ANOMALY_BUDGET, changed["ratio"])
    st = attention.status()
    check("status carries generation + art direction", st["generation"] and st["art_direction"]["composition"], st["generation"])
    check("attention page renders", "Attention" in attention.render(), len(attention.render()))
    n = sum(checks)
    print("test_attention: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

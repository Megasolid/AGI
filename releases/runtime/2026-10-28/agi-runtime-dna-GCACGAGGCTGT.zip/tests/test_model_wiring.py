#!/usr/bin/env python3
"""test_model_wiring.py - gen3.4/W5-A follow-up: contract for the S5 *consumers*.

BIOS is the single owner of S5 profile selection and wires the result into
state/boot_card.json (profile, profile_status, model_name, degraded_modes).
Consumers must READ that wiring:
  * producers.model  -> state/cards/model.json
  * ctxpack          -> cache/chunk1_boot.md
They must never re-derive a profile from env_probe/model name (env_probe.model is
'n/a' under hosted models) and the retired qwen-local default must never reappear.

Run: <venv-python> tests/test_model_wiring.py
"""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import ctxpack  # noqa: E402
import producers  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


ENV = {"model": {"name": "n/a", "quant": None, "context_length": None, "flags": "live-only"},
       "gate": {"side": "real"}, "venv_python": "venv-python"}
UNPROFILED = {"status": "ready", "ts": "t", "profile": "unprofiled", "profile_status": "unprofiled",
              "model_name": "deepseek-flash",
              "degraded_modes": ["no adapter profile for the running model - generic rules only",
                                 "S5 fallback to qwen-local is retired (gen3.4 / W5-A)"]}
MATCHED = {"status": "ready", "ts": "t", "profile": "claude-class.md", "profile_status": "matched",
           "model_name": "claude-sonnet-4", "degraded_modes": []}
LEGACY = {"status": "ready", "ts": "t"}  # pre-gen3.4 card without S5 wiring
MAINT = {"open": ["open item"], "fixed": [{"ts": "d", "item": "fixed item"}]}
RAM = {"root": "ROOT", "cache": "CACHE", "source": "dsh-session-root", "verified": True}


def _card(boot_card):
    """Run producers.model against an isolated state dir holding the given boot card."""
    prior = producers.STATE
    try:
        with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
            producers.STATE = Path(folder)
            (producers.STATE / "boot_card.json").write_text(json.dumps(boot_card), encoding="utf-8")
            (producers.STATE / "env_probe.json").write_text(json.dumps(ENV), encoding="utf-8")
            return producers.model()
    finally:
        producers.STATE = prior


def main():
    # --- producers.model: card content is the BIOS wiring, nothing else --------
    card = _card(UNPROFILED)
    check("producers.model reports the wired model name", "deepseek-flash" in card["body"], card["body"])
    check("producers.model reports unprofiled", "unprofiled" in card["body"], card["body"])
    check("producers.model never renders the retired qwen-local profile",
          "qwen-local.md" not in card["body"], card["body"])
    check("producers.model surfaces the degraded modes", "generic rules only" in card["body"], card["body"])
    check("producers.model marks the card warn when unprofiled", card["dot"] == "warn", card["dot"])

    mcard = _card(MATCHED)
    check("producers.model renders the wired matched profile", "claude-class.md" in mcard["body"], mcard["body"])
    check("producers.model is ok when the profile matched", mcard["dot"] == "ok", mcard["dot"])
    check("producers.model loads the matched profile's bullets",
          "<li>Context limit" in mcard["body"], mcard["body"])

    lcard = _card(LEGACY)
    check("producers.model degrades honestly on a legacy card",
          "unavailable" in lcard["body"] and "qwen-local" not in lcard["body"], lcard["body"])

    # --- ctxpack chunk 1: same contract, rendered purely (no live cache) -------
    text = ctxpack.build_chunk(UNPROFILED, ENV, MAINT, ["producers"], ["_broken"], RAM)
    check("chunk1 renders the wired profile status", "S5 profile: unprofiled (unprofiled)" in text, text)
    check("chunk1 never renders the retired qwen-local profile", "qwen-local.md" not in text, text)
    check("chunk1 renders the unprofiled degraded mode", "generic rules only" in text, text)

    mtext = ctxpack.build_chunk(MATCHED, ENV, MAINT, [], [], RAM)
    check("chunk1 renders a matched profile + its bullets",
          "S5 profile: claude-class.md (matched)" in mtext and "\n  - " in mtext, mtext)
    check("chunk1 keeps the boot/maintenance/cache sections",
          "## Boot status" in mtext and "## Maintenance - open" in mtext and "## Season cache cluster" in mtext)

    ltext = ctxpack.build_chunk(LEGACY, ENV, MAINT, [], [], RAM)
    wired = ltext.split("## Wired model card", 1)[1].split("## Verified scripts", 1)[0]
    check("chunk1 degrades honestly on a legacy card", "unprofiled" in wired and "qwen-local" not in wired, wired)

    n = sum(checks)
    print("test_model_wiring: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_family.py - S2 passport v2 projection + signed family registry."""
import json
import pathlib
import shutil
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import family  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    reg = family.build_registry()
    check("registry schema", reg.get("schema") == "agi-family/1", reg.get("schema"))
    check("one member projected", len(reg["members"]) == 1, len(reg["members"]))
    m = reg["members"][0]
    check("master passport is the master type", m["type"] == "master", m["type"])
    check("status alive", m["status"] == "alive", m["status"])
    c = reg["counts"]
    check("family total = alive + sleeping", c["total_alive_plus_sleeping"] == c["alive"] + c["sleeping"], c)
    check("master alive count", c["master_alive"] == 1, c["master_alive"])
    check("member projection only public fields", set(m) == set(family.PUBLIC_FIELDS), sorted(set(m) - set(family.PUBLIC_FIELDS)))
    blob = json.dumps(reg["members"])

    def _keys(o):
        if isinstance(o, dict):
            out = set(o)
            for v in o.values():
                out |= _keys(v)
            return out
        if isinstance(o, list):
            out = set()
            for v in o:
                out |= _keys(v)
            return out
        return set()

    check("registry has no secrets/keys/seeds",
          not (_keys(reg) & {"keys", "device", "sealed", "private_key", "seed_commitment", "seed8"}),
          sorted(_keys(reg)))
    v = family.verify_registry()
    check("signed registry verifies", v.get("ok"), v.get("problems"))
    html = family.render()
    check("family page renders", "Family" in html and "Members" in html and "Registry integrity" in html, len(html))
    check("rough branding off for official bundle", "ROUGH" not in html.split("Members")[0], "banner present")

    # rough classification + tamper detection in an isolated root
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        (tmp / "state" / "genesis").mkdir(parents=True)
        (tmp / "state" / "genesis" / "birth.json").write_text(json.dumps({
            "gen_id": "TEST-DNA", "genome8": "ABCD1234", "kind": "dna",
            "natal_interest": {"domain": "social"}}), encoding="utf-8")
        rough = family.build_registry(tmp)
        check("no official bundle -> rough", rough["rough"]["active"] and rough["members"][0]["type"] == "rough",
              (rough["rough"], rough["members"][0]["type"]))
        check("rough branding is red", rough["rough"]["branding"] == "red", rough["rough"].get("branding"))
        check("rough never migrates is documented", "never migrates" in rough["rough"]["note"], rough["rough"].get("note"))
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        for rel in ("state/passport.json", "state/genesis/birth.json", "state/bundles/active.json",
                    "state/bundles/agi-master-d.json.sig", "state/bundles/agi-master-d.json"):
            src = ROOT / rel
            dst = tmp / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        s = family.sign_registry(tmp)
        check("isolated registry signs", s.get("ok") and (tmp / "state/family/registry.json").is_file(), s)
        check("isolated registry verifies", family.verify_registry(tmp).get("ok"), family.verify_registry(tmp).get("problems"))
        p = tmp / "state/family/registry.json"
        reg2 = json.loads(p.read_text(encoding="utf-8"))
        reg2["counts"]["dead"] = 99
        p.write_text(json.dumps(reg2), encoding="utf-8")
        check("tampered registry rejected", not family.verify_registry(tmp).get("ok"), family.verify_registry(tmp).get("problems"))
    check("seat caps defined", family.SEATS == {"master": 8, "admin": 16, "council": 32, "hall": 64},
          family.SEATS)
    seats = family.seat_usage()
    check("seats report used/max", seats["used"]["master"] == 1 and seats["max"]["admin"] == 16, seats)
    # promotion + redemption in an isolated root (copy the master passport so the Master check passes)
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        for rel in ("state/passport.json", "state/genesis/birth.json", "state/bundles/active.json",
                    "state/bundles/agi-master-d.json"):
            src = ROOT / rel
            dst = tmp / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        pr = family.promote("Ada", tmp)
        check("master promotes a human with a one-time phrase", pr.get("ok") and pr.get("phrase"), pr.get("error"))
        check("only the phrase hash is stored", pr["phrase"] not in json.dumps(family.admins(tmp)) and
              "phrase_sha256" in json.dumps(family.admins(tmp)), "phrase leaked")
        check("wrong phrase is rejected", not family.redeem_admin("Ada", "wrong-phrase", tmp).get("ok"))
        check("correct phrase redeems admin", family.redeem_admin("Ada", pr["phrase"], tmp).get("ok"))
        check("admin list contains the member", "Ada" in family.admins(tmp)["members"], family.admins(tmp)["members"])
        # quota: full admin roster rejects new promotions
        data = family.admins(tmp)
        data["members"] = ["m%d" % i for i in range(16)]
        data["invites"] = []
        family._save_admins(data, tmp)
        check("full admin seats reject promotion", not family.promote("Bob", tmp).get("ok"))
    n = sum(checks)
    print("test_family: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

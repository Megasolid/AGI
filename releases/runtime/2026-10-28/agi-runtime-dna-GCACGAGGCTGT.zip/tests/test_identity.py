#!/usr/bin/env python3
"""test_identity.py - native authentication, federation links, login screen and app shell.

Asserts two kinds of things:
  * sandboxed contract: profiles (default + member), native device-key login via a signed challenge,
    skip/default path, logout, federation links stored only as keyed hashes and never authoritative,
    passport binding, verify() invariants;
  * live projection: the login page is generated and served over loopback, the app shell resolves
    the login URL without opening a window, and the live identity state verifies.

Run: <venv-python> tests/test_identity.py
"""
import json
import pathlib
import shutil
import sys
import tempfile
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import app  # noqa: E402
import board_serve  # noqa: E402
import cardkit  # noqa: E402
import crypto  # noqa: E402
import identity  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="agi-identity-test-"))
    saved = (identity.ID_DIR, identity.PROFILES, identity.SESSION, identity.CHALLENGE,
             identity.LOGGING, identity.crypto.KEYS, identity.STATE,
             app.APP_STATE)
    try:
        identity.LOGGING = False
        identity.STATE = tmp / "state"
        identity.ID_DIR = identity.STATE / "identity"
        identity.PROFILES = identity.ID_DIR / "profiles.json"
        identity.SESSION = identity.ID_DIR / "session.json"
        identity.CHALLENGE = identity.ID_DIR / "challenge.json"
        identity.crypto.KEYS = tmp / "state" / "keys"
        identity.crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        app.APP_STATE = tmp / "state" / "app.json"

        check("init creates the default profile", identity.init()["default"] == "default")
        check("default profile has no authority",
              identity.profile_list()["default"]["authority"] == "none")

        skip = identity.skip_login()
        check("skip enters the default profile without authority",
              skip["level"] == "default" and identity.whoami()["authenticated"])
        identity.logout()
        check("logout clears the session", identity.whoami()["authenticated"] is False)

        dev = identity.login()
        check("native login proves device-key possession", dev["level"] == "device"
              and (dev.get("proof") or {}).get("key_id") == identity.crypto.pinned_key_id())
        check("session is time-boxed", bool(dev.get("expires")))

        member = identity.create("D", member="D")
        check("member profile created", member["kind"] == "member")
        check("member login works", identity.login(member["profile_id"])["profile"] == member["profile_id"])

        # passport binding (sandbox passport)
        identity._jdump(identity.STATE / "passport.json",
                        {"passport_id": "pass-test", "member": "D",
                         "user_genome_root": "ab" * 32, "genome_epoch": 4})
        bound = identity.bind_passport(member["profile_id"], "pass-test")
        check("passport binding promotes the profile to member authority",
              bound["authority"] == "member" and bound["passport_id"] == "pass-test")
        try:
            identity.bind_passport(member["profile_id"], "wrong-passport")
            refused = False
        except ValueError:
            refused = True
        check("binding a foreign passport is refused", refused)

        # federation: hash only, never authority
        lk = identity.link("google", handle="someone@example.com", profile_id=member["profile_id"])
        check("federation stores a keyed hash, not the address",
              len(lk["subject_hash"]) == 64 and "@" not in lk["subject_hash"])
        try:
            identity.link("google", subject_hash="raw@example.com", profile_id=member["profile_id"])
            raw_ok = True
        except ValueError:
            raw_ok = False
        check("raw address refused", not raw_ok)
        fed = identity.federated_login(member["profile_id"])
        check("federated session is non-authoritative", fed["level"] == "federated")
        check("verify flags an active federated session as an authority leak",
              not identity.verify()["ok"])

        identity.login(member["profile_id"])
        check("identity verifies in a native session", identity.verify()["ok"],
              str(identity.verify().get("problems")))
        identity.unlink("google", member["profile_id"])
        check("unlink removes the federation record",
              identity.profile_list()[member["profile_id"]]["federation"] == [])

        # app shell: resolves the login URL without opening a window
        rec = app.launch(login=True, dry_run=True, url="http://127.0.0.1:8765/login")
        check("app shell targets the login state", rec["url"].endswith("/login") and rec["opened"] is False)
        check("app shell records the cold-boot sequence", "login screen" in rec["sequence"])

        # live projection: login page generated + served, identity verifies live
        cache = pathlib.Path(cardkit.sandbox_cache()).parent
        login_html = cache / "site" / "login.html"
        check("login page is part of the generated site", login_html.is_file())
        if login_html.is_file():
            text = login_html.read_text(encoding="utf-8")
            check("login page explains native auth and has no password input",
                  "AGI LOGIN" in text and "no password" in text.lower()
                  and "type='password'" not in text and 'type="password"' not in text)
            check("login page offers skip/default and sign-in commands",
                  "identity.py login" in text and "identity.py skip" in text)
        try:
            with urllib.request.urlopen("http://127.0.0.1:%s/login" % board_serve.port(), timeout=6) as r:
                body = r.read().decode("utf-8", "ignore")
            check("loopback serves /login", r.status == 200 and "AGI LOGIN" in body)
        except Exception as e:
            check("loopback serves /login", False, str(e)[:120])
	    
        live = identity.verify()
        check("live identity state verifies (D profile bound)", live["ok"], str(live.get("problems")))
    finally:
        (identity.ID_DIR, identity.PROFILES, identity.SESSION, identity.CHALLENGE,
         identity.LOGGING, identity.crypto.KEYS, identity.STATE,
         app.APP_STATE) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_identity: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

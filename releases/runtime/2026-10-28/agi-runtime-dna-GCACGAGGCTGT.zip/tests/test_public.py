#!/usr/bin/env python3
"""test_public.py - Trust Layer P5 contract: *.public mirror + contribution pipeline.

Verifies: mirror export carries a signed manifest, a signed tree head and a Merkle inclusion proof
per pill; verification catches a tampered envelope, a tampered head and a broken proof; import is
verify-before-consume and idempotent; a contribution must name a proven pill and is signed by the
contributor; the D endorsement is root-signed; merge and reputation follow; the boot-gate public
contract holds; and the mirror carries no personal data.

Run: <venv-python> tests/test_public.py
"""
import hashlib
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import boot_gate  # noqa: E402
import crypto  # noqa: E402
import public  # noqa: E402
import root as rootmod  # noqa: E402
import trust_log  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


class Sandbox:
    def __init__(self, tmp):
        self.tmp = Path(tmp)
        self.saved = (public.STATE, public.PUB, public.MIRROR, public.IMPORTED, public.CONTRIB,
                      public.MERGED, public.CONTRIBUTORS, public.PILLS, public.LOGGING, public.AGI, public.MEM,
                      crypto.KEYS, trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR,
                      rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.LOGGING)
        public.LOGGING = False
        rootmod.LOGGING = False
        self.state = self.tmp / "state"
        public.AGI = self.tmp
        public.MEM = self.tmp / "memory"
        public.STATE = self.state
        public.PUB = self.state / "public"
        public.MIRROR = public.PUB / "mirror"
        public.IMPORTED = public.PUB / "imported"
        public.CONTRIB = self.state / "contributions"
        public.MERGED = public.PUB / "merged.json"
        public.CONTRIBUTORS = public.PUB / "contributors.json"
        public.PILLS = self.state / "pills"
        crypto.KEYS = self.state / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        trust_log.LOG = self.state / "trust_log"
        trust_log.EVENTS = trust_log.LOG / "events.jsonl"
        trust_log.HEADS = trust_log.LOG / "heads"
        trust_log.MONITOR = trust_log.LOG / "monitor.json"
        rootmod.KEYS = self.state / "keys"
        rootmod.ROOT_RECORD = rootmod.KEYS / "root.json"
        rootmod.ROOT_DIR = self.state / "root"
        rootmod.GENESIS = rootmod.ROOT_DIR / "genesis.json"
        rootmod.ceremony_init(force=True)
        public._jdump(self.state / "passport.json", {
            "schema": "agi-passport/1", "passport_id": "pass-1", "member": "D",
            "user_genome_root": "ab" * 32, "genome_epoch": 4})

    def add_pill(self, pid):
        body = {"pill_id": pid, "kind": "task", "status": "consumed",
                "lifecycle": {"stored": True, "indexed": True, "readback": True}, "consumed_at": public._now()}
        env = {"schema": "agi-pill-envelope/1", "body": body,
               "signature": crypto.sign_bytes(crypto.canonical_json(body))}
        public._jdump(public.PILLS / f"{pid}.envelope.json", env)
        trust_log.append("pill-consumed", {"pill_id": pid, "envelope": f"{pid}.envelope.json"})

    def close(self):
        (public.STATE, public.PUB, public.MIRROR, public.IMPORTED, public.CONTRIB,
         public.MERGED, public.CONTRIBUTORS, public.PILLS, public.LOGGING, public.AGI, public.MEM,
         crypto.KEYS, trust_log.LOG, trust_log.EVENTS, trust_log.HEADS, trust_log.MONITOR,
         rootmod.KEYS, rootmod.ROOT_RECORD, rootmod.ROOT_DIR, rootmod.GENESIS, rootmod.LOGGING) = self.saved


def main():
    tmp = Path(tempfile.mkdtemp(prefix="agi-public-test-"))
    sb = Sandbox(tmp)
    try:
        check("empty state exports nothing to prove", public.verify_mirror()["ok"] is False)

        sb.add_pill("pill-a")
        sb.add_pill("pill-b")
        trust_log.sign_head()
        out = public.export()
        check("mirror exported both logged pills", out["ok"] and out["pills"] == 2, str(out))
        man = public._jload(public.MIRROR / "manifest.json")
        txt = json.dumps(man).lower()
        check("mirror excludes personal data",
              "passport_id" not in txt and "user_genome_root" not in txt and ("ab" * 32) not in txt)
        check("every pill entry has an inclusion proof",
              all(e.get("path_hex") is not None and e.get("leaf_hex") for e in man["pills"]))
        check("manifest carries a signed tree head", "signature" in man["head"])
        v = public.verify_mirror()
        check("clean mirror verifies (2 pills)", v["ok"] and v["pills"] == 2, str(v.get("problems")))
        check("verification is key-pinned when asked",
              public.verify_mirror(expect_key=crypto.pinned_key_id())["ok"]
              and not public.verify_mirror(expect_key="deadbeefdeadbeef")["ok"])

        # tamper 1: envelope payload after signing
        env_path = public.MIRROR / "pills" / "pill-a.envelope.json"
        bad = public._jload(env_path)
        bad["body"]["status"] = "forged"
        public._jdump(env_path, bad)
        check("tampered pill envelope rejected",
              not public.verify_mirror()["ok"] and any("envelope" in p or "hash" in p
                                                       for p in public.verify_mirror()["problems"]))
        public.export()

        # tamper 2: inclusion path broken
        man = public._jload(public.MIRROR / "manifest.json")
        man["pills"][0]["path_hex"] = ["00" * 32]
        public._jdump(public.MIRROR / "manifest.json", man)
        crypto.sign_file(public.MIRROR / "manifest.json")
        check("broken inclusion proof rejected",
              any("inclusion" in p for p in public.verify_mirror()["problems"]))
        public.export()

        # tamper 3: head root changed (signature no longer matches)
        man = public._jload(public.MIRROR / "manifest.json")
        man["head"]["root_hex"] = "11" * 32
        public._jdump(public.MIRROR / "manifest.json", man)
        crypto.sign_file(public.MIRROR / "manifest.json")
        check("tampered tree head rejected", not public.verify_mirror()["ok"])
        public.export()

        # import: verify-before-consume + idempotency
        imp = public.import_mirror()
        check("import accepts a verified mirror", imp["ok"] and imp["imported"] == 2, str(imp))
        check("import is idempotent", public.import_mirror()["imported"] == 0)

        # contribution pipeline
        rec = public.contribute("pill-a", [])
        check("contribution signed by the contributor", rec["signature"]["key_id"] == crypto.pinned_key_id())
        check("gate accepts a clean contribution", public.verify_contribution(rec["cid"])["ok"])
        bad_rec = json.loads(json.dumps(rec))
        bad_rec["log_index"] = 99
        path = tmp / "bad-contrib.json"
        public._jdump(path, bad_rec)
        check("gate rejects a contribution with a wrong log index",
              not public.verify_contribution(path)["ok"])
        try:
            public.contribute("not-a-pill")
            refused = False
        except ValueError:
            refused = True
        check("only a proven pill can be contributed", refused)

        end = public.endorse(rec["cid"], shard_ids=("1", "3"), weight=1.0)
        check("endorsement signed by the offline root", end["root_signature"]["alg"] == "ML-DSA-87")
        check("endorsement verifies against the pinned root",
              rootmod.verify_root_signature(crypto.canonical_json(
                  {k: v for k, v in end.items() if k != "root_signature"}), end["root_signature"])["ok"])
        m = public.merge(rec["cid"])
        check("merge records the D-genome acceptance", m["ok"] and m["merged"] == "pill-a")
        rep = public.contributors()["contributors"][crypto.pinned_key_id()]
        check("reputation counts the endorsed contribution", rep["endorsed"] == 1 and rep["weight"] == 1.0)
        check("full public verify passes", public.verify_all()["ok"], str(public.verify_all().get("problems")))

        # boot-gate contract
        root = tmp / "gate-root"
        shutil.copytree(sb.state, root / "state")
        g = boot_gate.check_public(root)
        check("gate passes on a consistent mirror", g.get("ok") and g.get("pills") == 2, str(g))
        mp = root / "state" / "public" / "mirror" / "pills" / "pill-b.envelope.json"
        envb = public._jload(mp)
        envb["body"]["status"] = "forged"
        public._jdump(mp, envb)
        check("gate fails on a tampered mirror", not boot_gate.check_public(root).get("ok"))
        empty = tmp / "empty"
        empty.mkdir(exist_ok=True)
        g3 = boot_gate.check_public(empty)
        check("gate is soft when no mirror exists", g3["ok"] and g3.get("skipped"), str(g3))
    finally:
        sb.close()
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_public: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

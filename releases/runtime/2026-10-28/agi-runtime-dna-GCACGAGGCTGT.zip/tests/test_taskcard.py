﻿#!/usr/bin/env python3
"""test_taskcard.py - contract for the live task card + bill board (per-step LEDs).

Verifies: step-status -> LED mapping, overall pill, bill numbers, auto-refresh tag,
distance-readable CSS, idempotent pure rendering, and the task_steps.json round-trip.

Run: <venv-python> tests/test_taskcard.py
"""
import contextlib
import io
import json
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import taskcard  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def board(*statuses, title="Test task", bill=None):
    st = {"task_id": "test-task-1", "title": title, "bill_task": "Test bill",
          "updated": "2026-10-25T14:00:00", "steps": []}
    for i, s in enumerate(statuses, 1):
        st["steps"].append({"n": i, "name": "step %d" % i, "status": s, "ts": "", "note": ""})
    return st, bill or {}


def main():
    # --- LED mapping + overall status ---------------------------------------
    st, bill = board("passed", "active", "pending",
                     bill={"est_s": 100, "actual_s": 0, "started_epoch": time.time() - 60,
                           "bill_status": "active", "ratio": None})
    html = taskcard.render_page(st, bill)
    check("active step renders amber LED row", 'class="step active"' in html)
    check("passed step renders green LED row", 'class="step passed"' in html)
    check("pending step renders grey LED row", 'class="step pending"' in html)
    check("overall pill RUNNING for mixed board", "pill RUNNING" in html)
    check("board_status FAILED wins over passed", taskcard.board_status(board("passed", "failed")[0]) == "FAILED")
    check("board_status PASSED when all passed", taskcard.board_status(board("passed", "passed")[0]) == "PASSED")
    check("board_status DRAFT when nothing started", taskcard.board_status(board("pending")[0]) == "DRAFT")

    # --- bill numbers -------------------------------------------------------
    check("est renders human duration", "1m 40s" in html)
    check("elapsed renders from started_epoch", "elapsed" in html and "1m 00s" in html)
    check("bill status shown", "active" in html)

    # --- live behaviour / distance readability ------------------------------
    check("auto-refresh meta present at 5 s", 'http-equiv="refresh" content="5"' in html)
    check("no meta refresh when refresh=0", "http-equiv=\"refresh\"" not in taskcard.render_page(st, bill, refresh=0))
    check("elapsed ticks client-side", "setInterval" in html)
    check("universal scale: 15px LEDs", ".led{width:15px;height:15px" in html)
    check("universal scale: 14px step names", ".name{font-size:14px" in html)
    check("legend lists all four states", all(('>%s<' % k) in html for k in ("pending", "active", "passed", "failed")))
    check("title is HTML-escaped", "&lt;b&gt;" in taskcard.render_page(board("pending", title="<b>x</b>")[0]))
    check("render is deterministic for same inputs", taskcard.render_page(st, bill, now=taskcard.datetime(2026, 10, 25, 14, 0, 0)) ==
          taskcard.render_page(st, bill, now=taskcard.datetime(2026, 10, 25, 14, 0, 0)))

    # --- state round-trip ---------------------------------------------------
    prior = taskcard.STEPS_PATH
    try:
        with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
            taskcard.STEPS_PATH = str(Path(folder) / "task_steps.json")
            st2, _ = board("pending", "pending")
            taskcard.save_steps(st2)
            loaded = taskcard.load_steps()
            check("state round-trip preserves steps", len(loaded["steps"]) == 2 and loaded["steps"][0]["status"] == "pending")
            check("save stamps updated", bool(loaded.get("updated")))
    finally:
        taskcard.STEPS_PATH = prior

    # --- auto-open on creation (D requirement) ------------------------------
    seen = []
    ok = taskcard.open_page("C:/fake/board.html", opener=lambda p: seen.append(p) or True)
    check("open_page calls the opener with the board path", ok and seen == ["C:/fake/board.html"], seen)
    check("open_page tolerates a failing opener",
          taskcard.open_page("x", opener=lambda p: (_ for _ in ()).throw(RuntimeError("no browser"))) is False)

    # --- proposal-mode card + action queue ----------------------------------
    prop = {"task_id": "proposal-test", "title": "Proposal test", "bill_task": "bill",
            "mode": "proposal", "decision": "pending", "estimate_s": 1800,
            "started": "2026-10-25T15:40:00", "context_html": "<p>ctx</p>",
            "inputs": [{"id": "extra", "label": "x", "type": "textarea", "placeholder": "p"}],
            "steps": [{"n": 1, "name": "s1", "status": "pending", "needs_input": "q"},
                      {"n": 2, "name": "s2", "status": "pending"}]}
    ph = taskcard.render_page(prop)
    check("proposal card has all five navigation buttons",
          all(("send('%s')" % k) in ph for k in ("approve", "review", "cancel", "archive", "subtask")))
    check("proposal card shows the full context", "PROPOSAL - FULL CONTEXT" in ph and "<p>ctx</p>" in ph)
    check("proposal card has per-step approval checkboxes", ph.count("step-approve") >= 2)
    check("proposal card has a per-step input for the flagged step", 'data-step-input="1"' in ph)
    check("proposal steps are pre-selected by default", ph.count("step-approve") >= 2 and ph.count("checked") >= 2)
    check("proposal card shows the approved-count counter", "selcount" in ph and "approved" in ph)
    check("proposal card posts to the action queue", "/api/action" in ph)

    prior_a, prior_c = taskcard.ACTIONS_PATH, taskcard.CURSOR_PATH
    try:
        with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
            taskcard.ACTIONS_PATH = str(Path(folder) / "actions.jsonl")
            taskcard.CURSOR_PATH = str(Path(folder) / "cursor.json")
            with open(taskcard.ACTIONS_PATH, "w", encoding="utf-8") as fh:
                fh.write(json.dumps({"type": "approve", "n": 1}) + "\n")
                fh.write(json.dumps({"type": "note", "n": 2}) + "\n")
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                taskcard.cmd_actions(["--consume"])
            data = json.loads(out.getvalue())
            check("actions command returns queued decisions",
                  data["count"] == 2 and data["actions"][1]["type"] == "note")
            out2 = io.StringIO()
            with contextlib.redirect_stdout(out2):
                taskcard.cmd_actions([])
            check("consumed actions are not returned again",
                  json.loads(out2.getvalue())["count"] == 0)
    finally:
        taskcard.ACTIONS_PATH, taskcard.CURSOR_PATH = prior_a, prior_c

    # --- result block on a completed card ------------------------------------
    done = dict(st)
    done["result"] = {"summary": "delivered: site + cards", "at": "2026-10-25 16:30",
                      "links": [{"label": "Dashboard", "url": "http://127.0.0.1:8765/"}]}
    dh = taskcard.render_page(done, bill)
    check("completed card shows the RESULT block", "RESULT" in dh and "delivered: site + cards" in dh)
    check("result block links the artifacts", "http://127.0.0.1:8765/" in dh)

    # L2 housekeeping: propose records the bridge wiring for native click-to-resume
    import sys as _sys
    cap = {}
    _orig = (taskcard.save_steps, taskcard.stage, taskcard.render_page, taskcard._publish)
    try:
        taskcard.save_steps = lambda st: cap.update(st)
        taskcard.stage = lambda html: ("/tmp/proposal.html", None)
        taskcard.render_page = lambda st: "<html>"
        taskcard._publish = lambda *a, **k: None
        argv = ["propose", "--card", "bridge-test", "--title", "t", "--bill", "b",
                "--est-s", "10", "--steps", "one|two"]
        taskcard.cmd_propose(argv)
    finally:
        (taskcard.save_steps, taskcard.stage, taskcard.render_page, taskcard._publish) = _orig
    check("propose records the native bridge tool + task id",
          (cap.get("bridge") or {}).get("tool") == "agi_await_decision3"
          and (cap.get("bridge") or {}).get("task_id") == "bridge-test")
    check("propose keeps steps pending + proposal mode",
          cap.get("mode") == "proposal" and len(cap.get("steps") or []) == 2)
    n = sum(checks)
    print("test_taskcard: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())


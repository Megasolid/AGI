#!/usr/bin/env python3
"""test_migration.py - S2 member migration to the current generation + rough cold-boot mode."""
import json
import pathlib
import shutil
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import family  # noqa: E402
import migration  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def copy_live(tmp, rels):
    for rel in rels:
        src = ROOT / rel
        if src.is_file():
            dst = tmp / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)


def main():
    cur = migration.current_generation()
    check("current generation readable", bool(cur.get("gen_id")), cur)
    rm = family.rough_mode()
    check("official machine is not rough", rm["rough"] is False and rm["banner"] == "", rm)
    check("official brand is AGI", rm["brand"] == "AGI", rm["brand"])

    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        copy_live(tmp, ["state/passport.json", "state/genesis/birth.json", "state/bundles/active.json",
                        "state/bundles/agi-master-d.json", "state/bundles/agi-master-d.json.sig"])
        plan = migration.plan(tmp, to_gen_id="TEST-NEXT-GEN", to_genome8="BEEF1234", to_natal="research")
        check("migration plan builds", plan.get("ok") and plan["dry_run"] is True, plan.get("error"))
        check("members to migrate", len(plan["migrating"]) == 1 and plan["migrating"][0]["member"] == "D",
              plan["migrating"])
        check("passport id preserved in plan",
              plan["migrating"][0]["passport_id"] == json.loads((tmp / "state/passport.json").read_text(
                  encoding="utf-8"))["passport_id"])
        check("target generation recorded", plan["to"]["gen_id"] == "TEST-NEXT-GEN", plan["to"])
        p = migration._jload(tmp / "state/passport.json", {})
        check("plan is dry-run (passport untouched)", (p.get("generation") or {}).get("gen_id") != "TEST-NEXT-GEN",
              p.get("generation"))
        applied = migration.apply(tmp, to_gen_id="TEST-NEXT-GEN", to_genome8="BEEF1234", to_natal="research")
        check("apply migrates", applied.get("ok") and applied["migrated"] == 1, applied)
        p2 = migration._jload(tmp / "state/passport.json", {})
        check("passport keeps identity, changes generation",
              p2["passport_id"] == p["passport_id"] and p2["generation"]["gen_id"] == "TEST-NEXT-GEN", p2["generation"])
        check("migration history appended", len(migration.history(tmp)["migrations"]) == 1)
        check("verify migration", migration.verify(tmp).get("ok"), migration.verify(tmp).get("problems"))
        check("migration page renders", "Migration" in migration.render(tmp))

    # rough machine: no bundle/passport -> rough mode + migration refused
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        (tmp / "state" / "genesis").mkdir(parents=True)
        (tmp / "state" / "genesis" / "birth.json").write_text(json.dumps({
            "gen_id": "ROUGH-DNA", "genome8": "DEAD0001", "kind": "dna",
            "natal_interest": {"domain": "social"}}), encoding="utf-8")
        rm = family.rough_mode(tmp)
        check("no official bundle -> rough mode", rm["rough"] is True and rm["brand"] == "RED AGI", rm)
        check("rough banner explains the boundary", "never migrates" in rm["banner"] and "strictly supervised" in rm["banner"], rm["banner"])
        check("rough css is red", "#f85149" in rm["css"], rm["css"])
        refusal = migration.plan(tmp)
        check("rough refuses migration", not refusal.get("ok") and refusal.get("rough") is True, refusal)
    n = sum(checks)
    print("test_migration: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

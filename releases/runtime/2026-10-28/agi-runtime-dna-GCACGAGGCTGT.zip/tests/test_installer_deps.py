#!/usr/bin/env python3
"""test_installer_deps.py - the installer must survive a machine without `cryptography`.

Regression test for the D2060 failure (2026-10-27): `install.ps1` probed `import cryptography` with a
native command whose stderr became a terminating NativeCommandError under
`$ErrorActionPreference="Stop"`, so the script died instead of creating the private venv - on exactly the
machines the venv step exists for.

The test builds a throwaway venv WITHOUT cryptography, points the installer at it with -Python, and
requires: the probe returns "missing" (not an abort), `AGI\\.venv` is created, `cryptography` is installed
there, cold boot reaches READY and the boot gate passes. It also checks `-Resume` on a pre-extracted tree
(the state D2060 was left in) and that a non-empty destination without -Resume is refused with guidance.

Network is required (pip install cryptography); skipped cleanly when offline.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = ROOT / "state" / "repo" / "AGI" / "install.ps1"
RUNTIME = sorted((ROOT / "state" / "release").glob("agi-runtime-v*.zip"))
checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def run_ps(args, env_extra=None):
    env = dict(os.environ)
    if env_extra:
        env.update(env_extra)
    return subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
                           str(INSTALLER)] + args, capture_output=True, text=True, timeout=900, env=env)


def main():
    if not INSTALLER.is_file():
        print("skip: installer not found (release asset only)")
        return 0
    if not RUNTIME:
        print("skip: no runtime archive in state/release (run pack_runtime.py build first)")
        return 0
    runtime = RUNTIME[-1]
    try:
        urllib.request.urlopen("https://pypi.org/simple/cryptography/", timeout=10)
    except Exception as e:
        print("skip: no network for pip:", str(e)[:80])
        return 0

    tmp = Path(tempfile.mkdtemp(prefix="agi-installer-deps-"))
    try:
        base = tmp / "base"
        base.mkdir()
        shutil.copy2(runtime, base / runtime.name)
        import hashlib
        sha = hashlib.sha256(runtime.read_bytes()).hexdigest()
        (base / "SHA256SUMS.txt").write_text("%s  %s\n" % (sha, runtime.name), encoding="utf-8")

        nocrypto = tmp / "venv-nocrypto"
        subprocess.run([sys.executable, "-m", "venv", str(nocrypto)], check=True, timeout=300)
        vp = nocrypto / "Scripts" / "python.exe"
        probe = subprocess.run([str(vp), "-c", "import cryptography"], capture_output=True, text=True)
        check("test venv really lacks cryptography", probe.returncode != 0)

        dest = tmp / "AGI"
        r = run_ps(["-Version", runtime.stem.split("-")[-1], "-BaseUrl", base.as_uri(),
                    "-Destination", str(dest), "-NoLaunch", "-Python", str(vp)])
        out = (r.stdout or "") + (r.stderr or "")
        check("installer does not abort on the missing-crypto probe", r.returncode == 0, out[-400:])
        check("private venv created in the install", (dest / ".venv" / "Scripts" / "python.exe").is_file())
        card = gate = {}
        try:
            card = json.loads((dest / "state" / "boot_card.json").read_text(encoding="utf-8"))
            gate = json.loads((dest / "state" / "boot_gate.json").read_text(encoding="utf-8"))
        except Exception:
            pass
        check("cold boot reached READY", card.get("status") == "ready", str(card.get("status")))
        check("boot gate passed", bool(gate.get("ok")), str(gate.get("checks")))

        # -Resume on a pre-extracted tree (the D2060 state)
        part = tmp / "partial"
        shutil.unpack_archive(str(runtime), str(part))
        r2 = run_ps(["-Version", runtime.stem.split("-")[-1], "-BaseUrl", "file:///nonexistent",
                     "-Destination", str(part), "-NoLaunch", "-Resume"])
        card2 = {}
        try:
            card2 = json.loads((part / "state" / "boot_card.json").read_text(encoding="utf-8"))
        except Exception:
            pass
        check("resume finishes a pre-extracted tree",
              r2.returncode == 0 and card2.get("status") == "ready",
              ((r2.stdout or "") + (r2.stderr or ""))[-300:])

        # a non-empty destination without -Resume must be refused with guidance
        r3 = run_ps(["-Version", runtime.stem.split("-")[-1], "-Destination", str(part), "-NoLaunch"])
        check("non-empty destination without -Resume is refused with guidance",
              r3.returncode != 0 and "Resume" in ((r3.stdout or "") + (r3.stderr or "")),
              ((r3.stdout or "") + (r3.stderr or ""))[-200:])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_installer_deps: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_season_close.py - season-close orchestration contract (recommendation 1, D-approved 2026-10-25).

Verifies: fixed operation order (pill readiness -> season pill -> backups -> season card -> pointer);
pending pills block the close; dry-run writes no card and prunes nothing; --apply writes one idempotent
season card; repeated close updates instead of duplicating.

Run: <venv-python> tests/test_season_close.py
"""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import season_close  # noqa: E402


checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


class Sandbox:
    def __init__(self, tmp):
        self.tmp = Path(tmp)
        (self.tmp / "state").mkdir(parents=True, exist_ok=True)
        self.prior = (season_close.STATE, season_close.REPORT)
        season_close.STATE = self.tmp / "state"
        season_close.REPORT = self.tmp / "state" / "season_close.json"

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        season_close.STATE, season_close.REPORT = self.prior


def write(p, data):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(data if isinstance(data, str) else json.dumps(data), encoding="utf-8")


def main():
    import unittest.mock as mock
    calls = []
    with tempfile.TemporaryDirectory(dir=ROOT / "tests") as tmp:
        with Sandbox(tmp) as sb:
            write(sb.tmp / "state" / "season_tasks.json",
                  {"season": "2099-01-01", "open": [], "archive": []})
            write(sb.tmp / "state" / "maintenance.json", {"open": ["Season 2099-01-01 open"], "fixed": []})
            write(sb.tmp / "state" / "pill_consumption.json",
                  {"task:a": {"status": "consumed"}, "season:2099-01-01": {"status": "consumed"}})
            fake_plan = {"prune": [("x", 10)], "prune_bytes": 10, "protected": []}
            with mock.patch("pill_consume.consume_season",
                            side_effect=lambda s: (calls.append("pill"), {"status": "consumed"})[1]), \
                 mock.patch("backup_prune.plan", side_effect=lambda: (calls.append("plan"), fake_plan)[1]), \
                 mock.patch("backup_prune.apply",
                            side_effect=lambda p: (calls.append("apply"), {"pruned": ["x"], "freed_bytes": 10})[1]):
                r = season_close.close(apply=True)
                check("close reports closed", r["status"] == "closed", r)
                check("operation order is fixed",
                      calls == ["pill", "plan", "apply"]
                      and r["order"] == ["pill_readiness", "season_pill", "backups", "season_card",
                                         "maintenance_pointer"], (calls, r["order"]))
                st = json.loads((sb.tmp / "state" / "season_tasks.json").read_text(encoding="utf-8"))
                cards = [c for c in st["archive"] if c["id"] == "season-close-2099-01-01"]
                check("one season card archived", len(cards) == 1, st["archive"])
                with mock.patch("backup_prune.apply", side_effect=lambda p: {"pruned": [], "freed_bytes": 0}):
                    r2 = season_close.close(apply=True)
                st2 = json.loads((sb.tmp / "state" / "season_tasks.json").read_text(encoding="utf-8"))
                cards2 = [c for c in st2["archive"] if c["id"] == "season-close-2099-01-01"]
                check("repeated close is idempotent", r2["status"] == "closed" and len(cards2) == 1, cards2)
                maint = json.loads((sb.tmp / "state" / "maintenance.json").read_text(encoding="utf-8"))
                check("maintenance pointer updated", "closed" in maint["open"][0].lower(), maint["open"])

            # pending pill blocks the close and writes no card
            write(sb.tmp / "state" / "pill_consumption.json",
                  {"task:a": {"status": "consumed"}, "task:b": {"status": "pending"}})
            before = (sb.tmp / "state" / "season_tasks.json").read_text(encoding="utf-8")
            with mock.patch("pill_consume.consume_season", side_effect=lambda s: {"status": "consumed"}):
                rb = season_close.close(apply=False)
            check("pending pill blocks the close", rb["status"] == "blocked", rb)
            check("blocked close writes no season card",
                  (sb.tmp / "state" / "season_tasks.json").read_text(encoding="utf-8") == before)

            # dry-run: read-only - no prune, no card, no pointer write
            write(sb.tmp / "state" / "pill_consumption.json",
                  {"task:a": {"status": "consumed"}, "season:2099-01-01": {"status": "consumed"}})
            before = (sb.tmp / "state" / "season_tasks.json").read_text(encoding="utf-8")
            pointer_before = (sb.tmp / "state" / "maintenance.json").read_text(encoding="utf-8")
            calls.clear()
            with mock.patch("pill_consume.consume_season",
                            side_effect=lambda s: (calls.append("pill"), {"status": "consumed"})[1]), \
                 mock.patch("backup_prune.plan", side_effect=lambda: (calls.append("plan"), fake_plan)[1]):
                rd = season_close.close(apply=True, dry_run=True)
            check("dry-run reports dry-run status", rd["status"] == "dry-run", rd)
            check("dry-run is read-only (no pill call, no prune, no card/pointer write)",
                  calls == ["plan"]
                  and (sb.tmp / "state" / "season_tasks.json").read_text(encoding="utf-8") == before
                  and (sb.tmp / "state" / "maintenance.json").read_text(encoding="utf-8") == pointer_before,
                  (calls, rd.get("stages")))
    n = sum(checks)
    print("test_season_close: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_crypto.py - Trust Layer P0 contract (device keys + signed objects).

Verifies: canonical JSON determinism, ML-DSA-65/ML-DSA-87/Ed25519 sign+verify, tamper
rejection, key pinning, keystore lifecycle in an isolated dir (DPAPI seal recorded),
detached file signatures, and the boot-gate signature check (fail on contradiction,
soft on absence).

Run: <venv-python> tests/test_crypto.py
"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import boot_gate  # noqa: E402
import crypto  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    # 1. canonical serialisation
    a = crypto.canonical_json({"b": 1, "a": [2, {"z": 3}]})
    b = crypto.canonical_json({"a": [2, {"z": 3}], "b": 1})
    check("canonical json is order-independent", a == b)
    check("canonical json has no whitespace", b" " not in a and a == b'{"a":[2,{"z":3}],"b":1}')

    # 2. keystore in an isolated directory
    tmp = Path(tempfile.mkdtemp(prefix="agi-crypto-test-"))
    saved_keys = crypto.KEYS
    try:
        crypto.KEYS = tmp / "keys"
        rec = crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        check("default algorithm is ML-DSA-65", rec["alg"] == "ML-DSA-65", rec["alg"])
        check("key_id is 16 hex chars", len(rec["key_id"]) == 16 and all(
            c in "0123456789abcdef" for c in rec["key_id"]), rec["key_id"])
        expected_seal = "dpapi" if crypto._dpapi_available() else "plain"
        check("seal recorded honestly", rec["sealed"] == expected_seal, rec["sealed"])
        check("no private material in the public record",
              "private_key_b64" not in rec and "seed" not in rec and len(rec["public_key_b64"]) > 100)

        payload = tmp / "payload.json"
        payload.write_bytes(crypto.canonical_json({"claim": "pills are verifiable"}))
        sig_path, env = crypto.sign_file(payload)
        check("detached signature written next to the file",
              sig_path == payload.with_name(payload.name + ".sig") and sig_path.exists())
        check("envelope is self-describing (schema/alg/key_id)",
              env["schema"] == crypto.SCHEMA and env["alg"] == "ML-DSA-65" and env["key_id"] == rec["key_id"])
        r = crypto.verify_file(payload, expected_key_id=rec["key_id"])
        check("file signature verifies with pinning", r.get("ok"), str(r))
        r = crypto.verify_file(payload, expected_key_id="0000000000000000")
        check("pinning rejects a foreign key id", not r.get("ok"))
        payload.write_bytes(crypto.canonical_json({"claim": "tampered"}))
        check("payload tamper rejected", not crypto.verify_file(payload).get("ok"))
        check("missing signature file fails closed", not crypto.verify_file(tmp / "absent.json").get("ok"))

        # 3. algorithm agility: the same payload signs and verifies under every algorithm
        for alg in ("ML-DSA-87", "Ed25519"):
            crypto.keygen(name="alt", alg=alg, force=True)
            p = tmp / "alt.json"
            p.write_bytes(crypto.canonical_json({"alg": alg}))
            sp, env2 = crypto.sign_file(p, name="alt")
            ok = crypto.verify_file(p, sig_path=sp, expected_key_id=env2["key_id"]).get("ok")
            check(f"{alg} keeps the same envelope contract", ok and env2["alg"] == alg)

        # 4. boot-gate signature check on an isolated root
        root = tmp / "root"
        (root / "state" / "keys").mkdir(parents=True)
        (root / "core_manifest.json").write_text(json.dumps({"files": []}), encoding="utf-8")
        r0 = boot_gate.check_signature(root)
        check("gate is soft when no key exists", r0["ok"] and r0.get("skipped"), str(r0))
        shutil.copy2(crypto.KEYS / "device.json", root / "state" / "keys" / "device.json")
        r1 = boot_gate.check_signature(root)
        check("gate is soft when the manifest is unsigned", r1["ok"] and r1.get("skipped"), str(r1))
        crypto.sign_file(root / "core_manifest.json")
        r2 = boot_gate.check_signature(root)
        check("gate passes on a signed manifest", r2["ok"] and r2.get("tail") == "verified", str(r2))
        (root / "core_manifest.json").write_text(json.dumps({"files": [], "tampered": True}), encoding="utf-8")
        r3 = boot_gate.check_signature(root)
        check("gate fails on a tampered manifest", not r3["ok"], str(r3))
        # a signature from a different key must not pass
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        crypto.sign_file(root / "core_manifest.json")
        r4 = boot_gate.check_signature(root)
        check("gate fails when the manifest is signed by an unpinned key", not r4["ok"], str(r4))
    finally:
        crypto.KEYS = saved_keys
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_crypto: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))

import mcp_bundle


class FakeResponse:
    def __init__(self, body, content_type="application/json", status=200, headers=None):
        self.body = body if isinstance(body, bytes) else body.encode("utf-8")
        self.status = status
        self.headers = {"Content-Type": content_type, **(headers or {})}

    def read(self):
        return self.body

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False


class MCPBundleTests(unittest.TestCase):
    def make_config(self, data):
        folder = tempfile.TemporaryDirectory(dir=ROOT / "tests")
        self.addCleanup(folder.cleanup)
        path = Path(folder.name) / "mcp.json"
        path.write_text(json.dumps(data), encoding="utf-8")
        return path

    def test_config_resolves_environment_references_without_echoing_values(self):
        config = self.make_config({"version": 1, "servers": {"remote": {
            "transport": "streamable-http", "url": "https://example.test/mcp",
            "headers": {"Authorization": {"env": "AGI_TEST_MCP_TOKEN"}}}}})
        with patch.dict(os.environ, {"AGI_TEST_MCP_TOKEN": "secret-test-value"}):
            loaded = mcp_bundle.load_config(config)
        self.assertEqual(loaded["remote"]["headers"]["Authorization"], "secret-test-value")
        with self.assertRaisesRegex(mcp_bundle.MCPError, "embedded credentials"):
            mcp_bundle.load_config(self.make_config({"version": 1, "servers": {"bad": {
                "transport": "streamable-http", "url": "https://user:pass@example.test/mcp"}}}))

    def test_legacy_stdio_discovery_list_and_call(self):
        server_code = r'''import json,sys
for line in sys.stdin:
 m=json.loads(line); method=m["method"]
 if "id" not in m: continue
 if method == "initialize": result={"protocolVersion":"2025-11-25","capabilities":{"tools":{}},"serverInfo":{"name":"fixture","version":"1"}}
 elif method == "tools/list": result={"tools":[{"name":"echo","inputSchema":{"type":"object"}}]}
 elif method == "tools/call": result={"content":[{"type":"text","text":m["params"]["arguments"].get("text","")}],"isError":False}
 else:
  print(json.dumps({"jsonrpc":"2.0","id":m["id"],"error":{"code":-32601,"message":"unknown method"}}),flush=True); continue
 print(json.dumps({"jsonrpc":"2.0","id":m["id"],"result":result}),flush=True)
'''
        config = self.make_config({"version": 1, "servers": {"fixture": {
            "transport": "stdio", "command": sys.executable,
            "args": ["-u", "-c", server_code], "timeout_s": 3}}})
        tools = mcp_bundle.run(config, "fixture", "tools")["tools"]
        self.assertEqual([tool["name"] for tool in tools], ["echo"])
        result = mcp_bundle.run(config, "fixture", "call", "echo", {"text": "hello"})["result"]
        self.assertEqual(result["content"][0]["text"], "hello")

    def test_modern_http_discovers_lists_calls_and_mirrors_schema_headers(self):
        calls = []
        tool = {"name": "weather", "inputSchema": {"type": "object", "properties": {
            "region": {"type": "string", "x-mcp-header": "Region"}}}}

        def fake_urlopen(request, timeout):
            body = json.loads(request.data)
            calls.append((request, body, timeout))
            method = body["method"]
            if method == "server/discover":
                result = {"supportedVersions": [mcp_bundle.MODERN_VERSION], "capabilities": {"tools": {}}}
            elif method == "tools/list":
                result = {"tools": [tool]}
            else:
                result = {"content": [{"type": "text", "text": "ok"}], "isError": False}
            return FakeResponse(json.dumps({"jsonrpc": "2.0", "id": body["id"], "result": result}))

        config = self.make_config({"version": 1, "servers": {"remote": {
            "transport": "streamable-http", "url": "https://example.test/mcp", "timeout_s": 5}}})
        with patch("mcp_bundle._http_open", fake_urlopen):
            response = mcp_bundle.run(config, "remote", "call", "weather", {"region": "North Zone"})
        self.assertEqual(response["protocol"], mcp_bundle.MODERN_VERSION)
        self.assertEqual(response["result"]["content"][0]["text"], "ok")
        request, body, timeout = calls[-1]
        self.assertEqual(request.get_header("Mcp-method"), "tools/call")
        self.assertEqual(request.get_header("Mcp-name"), "weather")
        self.assertEqual(request.get_header("Mcp-param-region"), "North Zone")
        self.assertNotIn("_mcp_headers", body["params"])
        self.assertEqual(timeout, 5)

    def test_streamable_http_reads_request_scoped_sse_response(self):
        transport = mcp_bundle.HTTPTransport({"url": "https://example.test/mcp", "timeout_s": 2}, "sse")
        event_stream = (
            'event: message\ndata: {"jsonrpc":"2.0","method":"notifications/progress","params":{}}\n\n'
            'event: message\ndata: {"jsonrpc":"2.0","id":1,"result":{"ok":true}}\n\n'
        )
        with patch("mcp_bundle._http_open", return_value=FakeResponse(event_stream, "text/event-stream")):
            response = transport.request("tools/list", {})
        self.assertEqual(response["result"], {"ok": True})


if __name__ == "__main__":
    unittest.main()

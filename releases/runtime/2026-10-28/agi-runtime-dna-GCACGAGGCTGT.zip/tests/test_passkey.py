#!/usr/bin/env python3
"""test_passkey.py - WebAuthn/passkey verifier contract (P12-A).

Runs the module selftest (synthetic ES256 registration + assertion, stale-challenge, foreign-origin,
signature-from-another-key, rpIdHash mismatch and sign-count clone detection), then checks the live
state: passkey storage verifies, the boot gate reports the passkey count, and identity levels accept
`passkey` as a session level.

Run: <venv-python> tests/test_passkey.py
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import boot_gate  # noqa: E402
import identity  # noqa: E402
import passkey  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    check("passkey module contract passes", passkey.selftest() == 0)
    st = passkey.verify_state()
    check("live passkey state verifies", st["ok"], str(st.get("problems")))
    check("passkey is an accepted identity level", "passkey" in identity.LEVELS)
    g = boot_gate.check_identity()
    check("boot gate reports the passkey store", g.get("ok") and "passkeys" in g, str(g))
    check("challenge file schema is sane", (not passkey.CHALLENGE.exists()) or
          json.loads(passkey.CHALLENGE.read_text(encoding="utf-8")).get("schema") ==
          "agi-passkey-challenge/1")

    failed = checks.count(False)
    print(f"test_passkey: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

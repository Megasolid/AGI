#!/usr/bin/env python3
"""test_runtime_install.py - installable runtime archive + one-prompt installer contract.

Builds the runtime archive from this checkout, publishes a checksum next to it, runs the real
install.ps1 against a file:// base URL (the same code path the GitHub release one-liner uses), and
asserts that the installed copy reaches READY with a passing boot gate. Also asserts that a corrupt
archive is refused *before* anything is extracted.

Run: <venv-python> tests/test_runtime_install.py
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import pack_runtime  # noqa: E402

checks = []
INSTALLER = ROOT / "state" / "repo" / "AGI" / "install.ps1"  # release asset, not part of the runtime


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def ps_run(installer, base_url, destination, timeout=600):
    env = dict(os.environ)
    env["PATH"] = str(Path(sys.executable).parent) + os.pathsep + env.get("PATH", "")
    return subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(installer),
         "-Version", "v0.0.0-it", "-BaseUrl", base_url, "-Destination", str(destination), "-NoLaunch"],
        capture_output=True, text=True, timeout=timeout, env=env)


def main():
    tmp = Path(tempfile.mkdtemp(prefix="agi-runtime-install-test-"))
    try:
        out = tmp / "release"
        built = pack_runtime.build("v0.0.0-it", out_dir=out)
        check("runtime archive builds", built["ok"] and Path(built["zip"]).is_file(), str(built))
        (out / "SHA256SUMS.txt").write_text(
            "%s  %s\n" % (built["sha256"], Path(built["zip"]).name), encoding="utf-8")

        dest = tmp / "installed"
        p = ps_run(INSTALLER, out.as_uri(), dest)
        check("installer succeeds against a release-style base URL", p.returncode == 0,
              ((p.stdout or "")[-400:] + (p.stderr or "")[-400:]))
        check("runtime files extracted", (dest / "memory" / "scripts" / "bios.py").is_file()
              and (dest / "memory" / "scripts" / "app.py").is_file())
        card = gate = {}
        try:
            card = json.loads((dest / "state" / "boot_card.json").read_text(encoding="utf-8"))
            gate = json.loads((dest / "state" / "boot_gate.json").read_text(encoding="utf-8"))
        except Exception:
            pass
        check("installed copy cold-boots to READY", card.get("status") == "ready", str(card.get("status")))
        check("installed copy passes its boot gate", bool(gate.get("ok")), str(gate.get("checks")))

        bad = tmp / "bad"
        bad.mkdir()
        tampered = (bad / "agi-runtime-v0.0.0-it.zip")
        data = Path(built["zip"]).read_bytes() + b"tampered"
        tampered.write_bytes(data)
        # the released checksum is honest; the downloaded bytes are tampered -> must be refused
        (bad / "SHA256SUMS.txt").write_text(
            "%s  %s\n" % (built["sha256"], tampered.name), encoding="utf-8")
        p2 = ps_run(INSTALLER, bad.as_uri(), tmp / "installed2", timeout=300)
        check("tampered archive refused at checksum", p2.returncode != 0,
              ((p2.stdout or "")[-300:] + (p2.stderr or "")[-300:]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_runtime_install: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

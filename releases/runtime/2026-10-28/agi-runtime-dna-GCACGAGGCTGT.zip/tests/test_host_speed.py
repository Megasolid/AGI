#!/usr/bin/env python3
"""test_host_speed.py - W-B contract: per-host speed factor at boot + taskbill overlay.

Covers:
  * derive_factor: median(actual/est) over the recency window, clamping, empty case;
  * host_speed_probe: preserves D-declared speed, writes the derived block, never invents;
  * taskbill.load_rates: overlays the calibrated factor (state/) on the portable baseline,
    keeps gen_tok_s untouched (no double-correction), falls back to 1.12 without state;
  * bill host stamping reads the boot card.

Run: <venv-python> tests/test_host_speed.py
"""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import capability_probe  # noqa: E402
import taskbill  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def bills(pairs):
    return [{"est_s": e, "actual_s": a} for e, a in pairs]


def main():
    # --- derive_factor -------------------------------------------------------
    d = capability_probe.derive_factor(bills([(1000, 220), (1000, 300), (1000, 180)]))
    check("factor is median(actual/est)", d["factor"] == 0.22, d)
    check("sample count reported", d["samples"] == 3, d)
    check("undated/invalid entries ignored",
          capability_probe.derive_factor([{"est_s": 0, "actual_s": 5}, {"est_s": 100}])["factor"] is None)
    d2 = capability_probe.derive_factor(bills([(1000, 0.001)]))
    check("factor is clamped >= 0.05", d2["factor"] == 0.05, d2)
    many = capability_probe.derive_factor(bills([(100, 10)] * 9 + [(100, 90)] * 3))
    check("recency window = last 10 bills", many["samples"] == 10, many)

    # --- host_speed_probe: declared facts preserved, never invented ----------
    with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
        p = Path(folder) / "host_speed.json"
        p.write_text(json.dumps({"declared_gen_tok_s": 200, "declared_by": "D",
                                 "declared_at": "2026-10-25"}), encoding="utf-8")
        out = capability_probe.host_speed_probe(write=True, path=p)
        data = json.loads(p.read_text(encoding="utf-8"))
        check("probe preserves the declared speed", data.get("declared_gen_tok_s") == 200, data)
        check("probe writes a derived block", bool((data.get("derived") or {}).get("last_refresh")), data)
        check("probe reports host+model from boot card",
              (data.get("derived") or {}).get("host") in (None, "dsh"), data.get("derived"))
        check("probe returns the same factor it wrote", out["factor"] == (data["derived"] or {}).get("factor"))
        p.unlink()
        out2 = capability_probe.host_speed_probe(write=False, path=p)
        check("missing file -> no invented declared speed", out2["declared_gen_tok_s"] is None)

    # --- taskbill.load_rates overlay ----------------------------------------
    prior = taskbill.HOST_SPEED
    try:
        with tempfile.TemporaryDirectory(dir=ROOT / "tests") as folder:
            p = Path(folder) / "host_speed.json"
            p.write_text(json.dumps({"declared_gen_tok_s": 200,
                                     "derived": {"factor": 0.22, "samples": 7,
                                                 "host": "dsh", "model": "deepseek-flash"}}),
                         encoding="utf-8")
            taskbill.HOST_SPEED = str(p)
            rates = taskbill.load_rates()
            check("contingency overlaid from state factor", abs(rates["contingency"] - 0.22) < 1e-9, rates.get("contingency"))
            check("portable baseline kept for audit", rates.get("contingency_baseline") == 1.12, rates.get("contingency_baseline"))
            check("declared tok/s surfaced", rates.get("declared_gen_tok_s") == 200.0)
            check("gen_tok_s untouched (no double-correction)",
                  rates["gen_tok_s"] == json.loads((ROOT / "memory/time/rates.json").read_text(encoding="utf-8"))["gen_tok_s"])
            check("host factor metadata exposed", (rates.get("host_factor") or {}).get("samples") == 7)
            p.unlink()
            rates2 = taskbill.load_rates()
            check("no state file -> legacy contingency", rates2["contingency"] == 1.12, rates2.get("contingency"))
    finally:
        taskbill.HOST_SPEED = prior

    # --- bill host stamp is derived from state, not guessed -----------------
    stamp = taskbill._host_stamp()
    check("host stamp carries host+model", bool(stamp.get("host")) and bool(stamp.get("model")), stamp)

    n = sum(checks)
    print("test_host_speed: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

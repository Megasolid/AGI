#!/usr/bin/env python3
"""test_sitegen.py - Pulse dashboard contract: live islands, plain language, progressive disclosure."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import sitegen  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def main():
    d = sitegen.load_data()
    specs = sitegen.card_specs(d)
    check("at least 24 signal cards exist", len(specs) >= 24, len(specs))
    html = sitegen.build_dashboard(d, specs)
    check("one UI core: monitor identity", "AGI Monitor" in html and "every instrument has a source" in html.lower().replace("- ", ""))
    check("dashboard binds to the current user", "Viewing as" in html)
    check("dashboard exposes the generated time", "Updated" in html)
    check("every card reachable from the signal index",
          all(("/cards/%s.html" % c["id"]) in html for c in specs))
    check("presentation genome section present", "UI evolution" in html and "presentation genome" in html)
    check("live visual modules declare sources", "source:" in html)
    check("no raw local paths", "C:\\Users" not in html and "C:\\" not in html)
    check("theme handled", "data-theme" in html)
    check("no double-escaped headers", "&amp;amp;" not in html)

    view = sitegen.build_dashboard_json(d, specs)
    check("projection schema is agi-dashboard/5", view.get("schema") == "agi-dashboard/5")
    check("projection carries cards + monitor",
          all(k in view for k in ("cards", "monitor")))
    check("projection carries no raw local paths", "C:\\" not in json.dumps(view))

    import live_state
    live = live_state.payload()
    check("live payload has status/now/needs/activity",
          all(k in live for k in ("status", "now", "needs", "activity", "updated_at")))
    check("live status is boolean with a human label",
          isinstance(live["status"].get("healthy"), bool) and isinstance(live["status"].get("label"), str))
    check("live activity entries are typed",
          all(e.get("kind") in ("security", "work", "done", "you") for e in live["activity"]))
    check("live needs explain consequences",
          all(n.get("consequence") for n in live["needs"]))

    diag = sitegen.build_diagnostics(d, specs)
    check("diagnostics gated page keeps internal cards", "AGENT POOL" in diag and "internal" in diag)
    page = sitegen.build_card_page(d, [s for s in specs if s["id"] == "gate"][0])
    check("card page uses GitHub shell", "data-theme" in page and "gh-header" in page)
    login = sitegen.build_login(d)
    check("login uses GitHub shell", "data-theme" in login and "gh-header" in login)
    info = sitegen.generate(verbose=False)
    site = Path(info["site"])
    check("generate cleans stale pages", not any((site / n).exists() for n in
                                                ("system.html", "maintenance.html", "inbox.html")))
    check("generate writes index/login/diagnostics",
          all((site / n).is_file() for n in ("index.html", "login.html", "diagnostics.html")))
    n = sum(checks)
    print("test_sitegen: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

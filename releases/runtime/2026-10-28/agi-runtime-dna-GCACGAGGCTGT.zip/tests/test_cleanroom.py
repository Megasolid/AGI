#!/usr/bin/env python3
"""test_cleanroom.py - S6 clean-room export/import on the live knowledge layer."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import cleanroom  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    rc = cleanroom.selftest()
    check("cleanroom selftest", rc == 0, rc)
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        exp = cleanroom.export_bundle(ROOT, out=tmp / "live.zip")
        check("live export creates a signed bundle", exp.get("ok") and (tmp / "live.zip").is_file(), exp)
        ver = cleanroom.verify_bundle(tmp / "live.zip")
        check("live bundle verifies", ver.get("ok"), ver.get("problems"))
        check("live bundle excludes secrets",
              not any(("seed" in e["path"]) or ("key" in e["path"]) for e in ver["manifest"]["files"]),
              ver["manifest"]["files"][:3])
        rt = tmp / "target"
        (rt / "state" / "genesis").mkdir(parents=True)
        (rt / "state" / "genesis" / "birth.json").write_text(json.dumps({"gen_id": "NEXT-GEN"}), encoding="utf-8")
        dry = cleanroom.import_bundle(tmp / "live.zip", rt, apply=False)
        check("dry-run plans knowledge/curriculum", dry.get("ok") and dry.get("dry_run") and len(dry["imported"]) >= 10,
              len(dry.get("imported") or []))
        applied = cleanroom.import_bundle(tmp / "live.zip", rt, apply=True)
        check("apply imports with fidelity", applied.get("ok") and applied["fidelity"]["ok"], applied.get("fidelity"))
        check("imported knowledge present", (rt / "memory" / "knowledge" / "health-foundations.md").is_file())
    n = sum(checks)
    print("test_cleanroom: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

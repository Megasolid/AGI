#!/usr/bin/env python3
"""test_pill_consumption.py - lifecycle contract for parked task #81 (pill consumption).

Verifies: passed-only pills, stored -> indexed -> readback -> consumed, idempotency, failure keeps the
task result and marks the pill pending, season pill, and backfill reconciliation.

Run: <venv-python> tests/test_pill_consumption.py
"""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import pill_consume  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def write(p, data):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(data if isinstance(data, str) else json.dumps(data, indent=1), encoding="utf-8")


class Sandbox:
    def __init__(self, tmp):
        self.tmp = Path(tmp)
        self.pills = self.tmp / "pills.md"
        self.tasklog = self.tmp / "tasklog.jsonl"
        self.summary = self.tmp / "pill_consumption.json"
        self.ledger = self.tmp / "pill_consumption.jsonl"
        self.index = self.tmp / "index"
        (self.index / "chunks.json").parent.mkdir(parents=True, exist_ok=True)
        write(self.index / "chunks.json", "[]")
        self.prior = None

    def __enter__(self):
        self.prior = (pill_consume.PILLS, pill_consume.TASKLOG, pill_consume.SUMMARY,
                      pill_consume.LEDGER, pill_consume.INDEX)
        pill_consume.PILLS = self.pills
        pill_consume.TASKLOG = self.tasklog
        pill_consume.SUMMARY = self.summary
        pill_consume.LEDGER = self.ledger
        pill_consume.INDEX = self.index
        import watchdogs
        self._prior_wd_pills = watchdogs.PILLS
        watchdogs.PILLS = str(self.pills)
        return self

    def __exit__(self, *exc):
        (pill_consume.PILLS, pill_consume.TASKLOG, pill_consume.SUMMARY,
         pill_consume.LEDGER, pill_consume.INDEX) = self.prior
        import watchdogs
        watchdogs.PILLS = self._prior_wd_pills

    def entries(self):
        return [json.loads(l) for l in self.tasklog.read_text(encoding="utf-8").splitlines() if l.strip()]

    def ledger_records(self):
        if not self.ledger.exists():
            return []
        return [json.loads(l) for l in self.ledger.read_text(encoding="utf-8").splitlines() if l.strip()]


def entry(eid, task, status="verified_passed"):
    return {"entry_id": eid, "task": task, "date": "2026-10-25T17:00:00+00:00",
            "est_s": 100, "actual_s": 50, "ratio": 0.5, "bill_status": status,
            "verification_confidence": 0.95, "verification_evidence": "checks passed"}


def main():
    import unittest.mock as mock
    with tempfile.TemporaryDirectory(dir=ROOT / "tests") as tmp:
        with Sandbox(tmp) as sb:
            # refused: no passed entry
            r = pill_consume.consume_task("never-passed")
            check("refuses a task with no passed+verified bill", r["status"] == "refused", r)

            # stored pill + good stages -> consumed
            sb.pills.write_text("# pills\n- source: taskbill-entry-id: E1\n", encoding="utf-8")
            sb.tasklog.write_text(json.dumps(entry("E1", "task one")) + "\n", encoding="utf-8")
            with mock.patch.object(pill_consume, "_index_refresh", return_value=(True, "ok", 5)), \
                 mock.patch.object(pill_consume, "index_is_stale", return_value=True), \
                 mock.patch.object(pill_consume, "_readback_indexed", return_value=(True, "knowledge/pills.md")):
                r = pill_consume.consume_task("task one")
            check("passed task pill consumed", r["status"] == "consumed", r)
            check("tasklog annotated with pill_status=consumed",
                  sb.entries()[0].get("pill_status") == "consumed", sb.entries()[0])

            with mock.patch.object(pill_consume, "_readback_indexed", return_value=(True, "knowledge/pills.md")):
                r2 = pill_consume.consume_task("task one")
            check("idempotent: second call returns already_consumed",
                  r2["status"] == "already_consumed" and len(sb.ledger_records()) == 1, r2)

            # index failure -> pending, task result preserved
            sb.tasklog.write_text(json.dumps(entry("E1", "task one")) + "\n" +
                                  json.dumps(entry("E2", "task two")) + "\n", encoding="utf-8")
            sb.pills.write_text("# pills\n- source: taskbill-entry-id: E1\n- source: taskbill-entry-id: E2\n",
                                encoding="utf-8")
            with mock.patch.object(pill_consume, "_index_refresh", return_value=(False, "backend down", 9)), \
                 mock.patch.object(pill_consume, "index_is_stale", return_value=True):
                r3 = pill_consume.consume_task("task two")
            check("index failure marks the pill pending", r3["status"] == "pending", r3)
            e2 = [e for e in sb.entries() if e["entry_id"] == "E2"][0]
            check("task result preserved on pill failure",
                  e2.get("bill_status") == "verified_passed" and e2.get("pill_status") == "pending", e2)

            # failed bill is never stamped/consumed
            sb.tasklog.write_text(json.dumps(entry("E3", "task failed", "verified_blocked")) + "\n", encoding="utf-8")
            before = sb.pills.read_text(encoding="utf-8")
            r4 = pill_consume.consume_task("task failed")
            check("failed bill never becomes a success pill",
                  r4["status"] == "refused" and sb.pills.read_text(encoding="utf-8") == before, r4)

            # season pill: create + consume once, semantic readback required
            write(sb.tmp / "season_tasks.json",
                  {"season": "2099-01-01", "archive": [{"id": "t-a", "status": "done", "conf": "0.95"}]})
            write(sb.tmp / "maintenance.json", {"fixed": [{"ts": "2099-01-01", "item": "x"}]})
            prior_state = pill_consume.STATE
            pill_consume.STATE = sb.tmp
            try:
                with mock.patch.object(pill_consume, "index_is_stale", return_value=False), \
                     mock.patch.object(pill_consume, "_readback_indexed", return_value=(True, "knowledge/pills.md")), \
                     mock.patch.object(pill_consume, "_semantic_readback", return_value=(True, "knowledge/pills.md")):
                    s1 = pill_consume.consume_season()
                    s2 = pill_consume.consume_season()
                check("season pill consumed with semantic readback", s1["status"] == "consumed", s1)
                check("season pill is idempotent", s2["status"] == "already_consumed", s2)
            finally:
                pill_consume.STATE = prior_state

            # backfill reconciles stamped passed entries in one pass
            sb.tasklog.write_text("\n".join(json.dumps(entry("B1", "back one")),
                                            ) if False else json.dumps(entry("B1", "back one")) + "\n" +
                                  json.dumps(entry("B2", "back two")) + "\n", encoding="utf-8")
            sb.pills.write_text("# pills\n- source: taskbill-entry-id: B1\n- source: taskbill-entry-id: B2\n",
                                encoding="utf-8")
            pill_consume.SUMMARY.write_text("{}", encoding="utf-8")
            with mock.patch.object(pill_consume, "index_is_stale", return_value=False), \
                 mock.patch.object(pill_consume, "_readback_indexed", return_value=(True, "knowledge/pills.md")):
                b1 = pill_consume.backfill()
                b2 = pill_consume.backfill()
            check("backfill consumes stamped passed pills", b1["consumed"] == 2, b1)
            check("backfill is idempotent", b2["attempted"] == 0, b2)

    n = sum(checks)
    print("test_pill_consumption: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_passport.py - Trust Layer L1 (P2) contract: passport + user genome.

Verifies: genome Merkle root determinism, passport minting per bundle class with the right
capabilities, atomic genome->passport re-anchoring, epoch monotonicity, signature/pin
verification, tamper detection (credential, tree root, epoch, transition), the replay-based
repair path, and the boot-gate passport check on an isolated root.

Run: <venv-python> tests/test_passport.py
"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import boot_gate  # noqa: E402
import crypto  # noqa: E402
import passport  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


class Sandbox:
    def __init__(self, tmp):
        self.tmp = Path(tmp)
        self.saved = (passport.STATE, passport.GENOME, passport.TREE, passport.TRANSITIONS,
                      passport.PASSPORT, passport.PASSPORT_SIG, passport.LOGGING, crypto.KEYS)
        self.state = self.tmp / "state"
        passport.STATE = self.state
        passport.GENOME = self.state / "genome"
        passport.TREE = passport.GENOME / "tree.json"
        passport.TRANSITIONS = passport.GENOME / "transitions.jsonl"
        passport.PASSPORT = self.state / "passport.json"
        passport.PASSPORT_SIG = self.state / "passport.json.sig"
        passport.LOGGING = False
        crypto.KEYS = self.state / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)

    def close(self):
        (passport.STATE, passport.GENOME, passport.TREE, passport.TRANSITIONS,
         passport.PASSPORT, passport.PASSPORT_SIG, passport.LOGGING, crypto.KEYS) = self.saved


def main():
    # 1. genome root properties
    check("genome root is order-independent",
          passport.genome_root({"a": "1", "b": "2"}) == passport.genome_root({"b": "2", "a": "1"}))
    check("empty genome root is sha256('')",
          passport.genome_root({}) == __import__("hashlib").sha256(b"").hexdigest())
    check("distinct genomes give distinct roots",
          passport.genome_root({"a": "1"}) != passport.genome_root({"a": "2"}))

    tmp = tempfile.mkdtemp(prefix="agi-passport-test-")
    sb = Sandbox(tmp)
    try:
        # 2. mint master passport
        p, where = passport.init_passport(member="D", bundle_class="master", force=True)
        check("passport is unique (uuid) and master",
              len(p["passport_id"]) == 36 and p["bundle_class"] == "master")
        check("master can reproduce; official cannot",
              p["capabilities"]["can_reproduce"] is True
              and passport._capabilities("official")["can_reproduce"] is False)
        check("passport carries genome root + epoch",
              p["user_genome_root"] == passport.current_root() and p["genome_epoch"] == 1)
        check("device binding recorded", p["device"]["key_id"] == crypto.pinned_key_id())
        check("lineage recorded", p["parent"]["generation"] == "gen3.5")
        r = passport.verify_passport()
        check("clean passport verifies (deep)", r["ok"], str(r.get("problems")))
        check("genesis transition is in the signed history",
              [t["op"] for t in passport._read_transitions()] == ["seed"])

        # 3. genome evolution is atomic: transition -> tree -> passport -> verify
        before = passport.current_root()
        passport.set_entry("work.style", "verified-only, evidence before claim")
        check("epoch advanced", passport.load_tree()["epoch"] == 2)
        check("genome root changed", passport.current_root() != before)
        r2 = passport.verify_passport()
        check("passport re-anchored after a genome change", r2["ok"], str(r2.get("problems")))
        passport.set_entry("interaction.style", "cards for consequential work, no ceremony for routine")
        check("third entry keeps the chain valid", passport.verify_passport()["ok"])
        check("three signed transitions recorded",
              [t["op"] for t in passport._read_transitions()] == ["seed", "set", "set"])
        passport.unset_entry("interaction.style")
        check("unset keeps the chain valid", passport.verify_passport()["ok"])
        check("unset removed the entry",
              "interaction.style" not in passport.load_tree()["entries"])

        # 4. tamper detection
        pj = json.loads(passport.PASSPORT.read_text(encoding="utf-8"))
        pj["member"] = "intruder"
        passport._jdump(passport.PASSPORT, pj)
        r3 = passport.verify_passport()
        check("passport tamper detected (signature)",
              not r3["ok"] and any("signature" in x for x in r3["problems"]), str(r3.get("problems")))
        # restore the passport from the true genome (repair path)
        pr = passport.set_entry("work.style", "verified-only, evidence before claim")
        r4 = passport.verify_passport()
        check("repair path restores a valid credential", r4["ok"], str(r4.get("problems")))

        tree = passport.load_tree()
        good_root = tree["root"]
        tree["root"] = "0" * 64
        passport._jdump(passport.TREE, tree)
        r5 = passport.verify_passport()
        check("tree-root tamper detected (root mismatch)",
              not r5["ok"] and any("root mismatch" in x for x in r5["problems"]), str(r5.get("problems")))
        rep = passport.cmd_repair(["--reason", "test: root tamper"])
        check("repair re-derives the tree from the replay",
              passport.load_tree()["root"] == good_root and passport.verify_passport()["ok"],
              f"repair rc={rep}")

        tree = passport.load_tree()
        tree["epoch"] = 999
        passport._jdump(passport.TREE, tree)
        r6 = passport.verify_passport()
        check("epoch tamper detected",
              not r6["ok"] and any("epoch" in x for x in r6["problems"]), str(r6.get("problems")))
        passport.cmd_repair(["--reason", "test: epoch tamper"])
        check("repair restores the epoch", passport.verify_passport()["ok"])

        rows = passport.TRANSITIONS.read_text(encoding="utf-8").splitlines()
        rec = json.loads(rows[-1])
        rec["value"] = "tampered"
        passport.TRANSITIONS.write_text("\n".join(rows[:-1] + [json.dumps(rec)]) + "\n", encoding="utf-8")
        r7 = passport.verify_passport()
        check("transition tamper detected",
              not r7["ok"] and any("transition" in x for x in r7["problems"]), str(r7.get("problems")))

        # history tampering cannot be repaired locally: the repair must report it, not hide it
        rep = passport.cmd_repair(["--reason", "test: history tamper (expected unrepairable)"])
        r8 = passport.verify_passport()
        check("history tamper is reported as unrepairable, not silently fixed",
              not r8["ok"] and any("transition" in x for x in r8["problems"]), str(r8.get("problems")))

        # 5. boot-gate passport check on an isolated, freshly minted root
        fresh = Path(tmp) / "fresh"
        sb2 = Sandbox(fresh)
        try:
            passport.init_passport(member="D", bundle_class="master", force=True)
            check("fresh sandbox verifies", passport.verify_passport()["ok"])
            clean = Path(tmp) / "clean-root"
            shutil.copytree(fresh / "state", clean / "state")
            r9 = boot_gate.check_passport(clean)
            check("gate passes on a consistent passport", r9.get("ok"), str(r9))
            pj = json.loads((clean / "state" / "passport.json").read_text(encoding="utf-8"))
            pj["bundle_class"] = "custom"
            (clean / "state" / "passport.json").write_text(json.dumps(pj, indent=1), encoding="utf-8")
            r10 = boot_gate.check_passport(clean)
            check("gate fails on a tampered credential", not r10.get("ok"), str(r10))
        finally:
            sb2.close()
        empty = Path(tmp) / "empty-root"
        empty.mkdir(exist_ok=True)
        r11 = boot_gate.check_passport(empty)
        check("gate is soft when no passport exists", r11["ok"] and r11.get("skipped"), str(r11))
    finally:
        sb.close()
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_passport: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_bundles.py - Trust Layer L2/L3 (P3) contract: bundle lattice + policy engine.

Verifies: the three classes mint with the correct genome modes/capabilities, manifests are
signed and parent-hash bound, class-rule violations are detected (an official bundle claiming
reproduction), core drift is detected, the policy matrix answers reproduce / consume-pill /
sign-bundle correctly with an explainable rule, and the boot-gate bundle check agrees.

Run: <venv-python> tests/test_bundles.py
"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import boot_gate  # noqa: E402
import bundles  # noqa: E402
import crypto  # noqa: E402
import passport  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    check("lattice has exactly three classes", sorted(bundles.CLASS_RULES) == ["custom", "master", "official"])
    check("only master can reproduce",
          [bundles.CLASS_RULES[c]["can_reproduce"] for c in ("master", "official", "custom")] == [True, False, False])
    check("genome modes are active/dormant/user-overlay",
          [bundles.CLASS_RULES[c]["genome_mode"] for c in ("master", "official", "custom")]
          == ["active", "dormant", "user-overlay"])
    check("only custom accepts local user pills",
          [bundles.CLASS_RULES[c]["accept_local_user_pills"] for c in ("master", "official", "custom")]
          == [False, False, True])

    tmp = Path(tempfile.mkdtemp(prefix="agi-bundles-test-"))
    saved = (bundles.BUNDLES, bundles.ACTIVE, bundles.PASSPORT, bundles.AGI, bundles.STATE,
             crypto.KEYS, passport.STATE, passport.GENOME, passport.TREE, passport.TRANSITIONS,
             passport.PASSPORT, passport.PASSPORT_SIG, passport.LOGGING)
    try:
        bundles.AGI = tmp
        bundles.STATE = tmp / "state"
        bundles.BUNDLES = tmp / "state" / "bundles"
        bundles.ACTIVE = bundles.BUNDLES / "active.json"
        bundles.PASSPORT = tmp / "state" / "passport.json"
        crypto.KEYS = tmp / "state" / "keys"
        crypto.keygen(name="device", alg="ML-DSA-65", force=True)
        passport.STATE = tmp / "state"
        passport.GENOME = tmp / "state" / "genome"
        passport.TREE = passport.GENOME / "tree.json"
        passport.TRANSITIONS = passport.GENOME / "transitions.jsonl"
        passport.PASSPORT = tmp / "state" / "passport.json"
        passport.PASSPORT_SIG = tmp / "state" / "passport.json.sig"
        passport.LOGGING = False
        # minimal installed core for the fingerprint
        (tmp / "core_manifest.json").write_text(json.dumps(
            {"files": [], "core_version": "3.2", "dna_version": 3, "bundle_name": "core.tar.gz"}),
            encoding="utf-8")
        (tmp / "core.tar.gz").write_bytes(b"fake core archive")
        passport.init_passport(member="D", bundle_class="master", force=True)
        psp = bundles._jload(bundles.PASSPORT)

        out = bundles.mint_all(log=False)
        check("three bundles minted", sorted(out) == ["custom", "master", "official"])
        check("custom is parent-hash bound",
              out["custom"]["manifest"]["parent"]["bundle_id"] == "agi-master-d"
              and len(out["custom"]["manifest"]["parent"]["bundle_sha256"]) == 64)
        check("every manifest is signed on disk",
              all(bundles._sig_path(v["manifest"]["bundle_id"]).exists() for v in out.values()))
        bundles.set_active("agi-master-d")
        check("active master verifies deep", bundles.verify_bundle()["ok"])

        # policy matrix
        check("reproduce: master yes, official/custom no",
              bundles._policy("reproduce", "agi-master-d")["allow"]
              and not bundles._policy("reproduce", "agi-official-d")["allow"]
              and not bundles._policy("reproduce", "agi-custom-d")["allow"])
        deny = bundles._policy("reproduce", "agi-official-d")
        check("denial names its rule", deny.get("rule") == "master-only-reproduce" and bool(deny.get("reason")))
        check("D pills consumable everywhere",
              all(bundles._policy("consume-pill", b, pill_genome="D")["allow"]
                  for b in ("agi-master-d", "agi-official-d", "agi-custom-d")))
        check("user pills: custom+local only",
              bundles._policy("consume-pill", "agi-custom-d", pill_genome="user", pill_local=True)["allow"]
              and not bundles._policy("consume-pill", "agi-custom-d", pill_genome="user")["allow"]
              and not bundles._policy("consume-pill", "agi-master-d", pill_genome="user", pill_local=True)["allow"])
        check("unknown pill genome refused", not bundles._policy("consume-pill", "agi-master-d", pill_genome="alien")["allow"])
        check("issuing: master->official yes, official->official no, custom self yes",
              bundles._policy("sign-bundle", "agi-master-d", target_class="official")["allow"]
              and not bundles._policy("sign-bundle", "agi-official-d", target_class="official")["allow"]
              and bundles._policy("sign-bundle", "agi-custom-d", target_class="custom")["allow"])

        # impostor: official manifest claiming reproduction
        fake = json.loads(json.dumps(out["master"]["manifest"]))
        fake["bundle_id"], fake["class"] = "impostor", "official"
        fake["capabilities"]["can_reproduce"] = True
        bundles._jdump(bundles._manifest_path("impostor"), fake)
        crypto.sign_file(bundles._manifest_path("impostor"))
        r = bundles.verify_bundle("impostor", deep=False)
        check("official claiming reproduction is rejected",
              not r["ok"] and any("can_reproduce" in x for x in r["problems"]), str(r.get("problems")))

        # parent drift: re-sign the master after changing it, then the custom parent hash is stale
        master_path = bundles._manifest_path("agi-master-d")
        man = json.loads(master_path.read_text(encoding="utf-8"))
        man["issued"] = "2026-10-26T00:00:00+0330"
        bundles._jdump(master_path, man)
        crypto.sign_file(master_path)
        rc = bundles.verify_bundle("agi-custom-d")
        check("parent-hash drift detected", not rc["ok"] and any("parent bundle hash" in x for x in rc["problems"]),
              str(rc.get("problems")))

        # core drift
        (tmp / "core_manifest.json").write_text(json.dumps({"files": [1], "core_version": "3.2"}),
                                                encoding="utf-8")
        rd = bundles.verify_bundle("agi-master-d")
        check("installed-core drift detected",
              not rd["ok"] and any("core manifest hash" in x for x in rd["problems"]), str(rd.get("problems")))

        # boot-gate contract (consistent root first)
        (tmp / "core_manifest.json").write_text(json.dumps(
            {"files": [], "core_version": "3.2", "dna_version": 3, "bundle_name": "core.tar.gz"}),
            encoding="utf-8")
        bundles.mint_all(log=False)
        bundles.set_active("agi-master-d")
        g = boot_gate.check_bundles(tmp)
        check("gate passes on a consistent lattice", g.get("ok"), str(g))
        mpath = bundles._manifest_path("agi-master-d")
        man = json.loads(mpath.read_text(encoding="utf-8"))
        man["class"] = "official"
        bundles._jdump(mpath, man)
        g2 = boot_gate.check_bundles(tmp)
        check("gate fails on a tampered manifest", not g2.get("ok"), str(g2))
        empty = tmp / "empty-root"
        empty.mkdir(exist_ok=True)
        g3 = boot_gate.check_bundles(empty)
        check("gate is soft when no lattice exists", g3["ok"] and g3.get("skipped"), str(g3))
    finally:
        (bundles.BUNDLES, bundles.ACTIVE, bundles.PASSPORT, bundles.AGI, bundles.STATE,
         crypto.KEYS, passport.STATE, passport.GENOME, passport.TREE, passport.TRANSITIONS,
         passport.PASSPORT, passport.PASSPORT_SIG, passport.LOGGING) = saved
        shutil.rmtree(tmp, ignore_errors=True)

    failed = checks.count(False)
    print(f"test_bundles: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

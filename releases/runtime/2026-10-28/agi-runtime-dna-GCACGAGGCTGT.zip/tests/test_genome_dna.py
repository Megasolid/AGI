#!/usr/bin/env python3
"""test_genome_dna.py - genetic AGI identity: loci/alleles genome + DNA Gen.ID, no version numbers."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import birth  # noqa: E402
import evolution  # noqa: E402
import genome  # noqa: E402
import genid  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def main():
    g = genome.genome()
    check("genome has the nine subsystem loci", set(g["genes"]) == set(genome.LOCI), list(g["genes"]))
    check("alleles are content markers, not versions", all(len(v) == 10 and v.isupper() for v in g["genes"].values()))
    check("genome digest is stable in one run", genome.genome()["digest"] == g["digest"])

    seed = bytes(range(32))
    code = genome.codons(seed, g["digest"])
    bases = code.replace("-", "")
    check("DNA code is codons over A/C/G/T only", len(bases) == 48 and all(c in "ACGT" for c in bases), code)
    check("DNA code is grouped", code.count("-") == 3, code)
    check("code is derived from seed + genome", code != genome.codons(seed, "00" * 32))
    check("code is deterministic for the same seed+genome", code == genome.codons(seed, g["digest"]))

    rec = genid.compose_genetic(code, g["digest8"])
    check("Gen.ID display is the DNA code", rec["display"] == code)
    check("canonical DNA identity + checksum", genid.validate_genetic(rec) and rec["canonical"].startswith("AGI-DNA-"))
    bad = dict(rec)
    bad["canonical"] = rec["canonical"][:-2] + "00"
    check("tampered DNA identity rejected", not genid.validate_genetic(bad))
    uri = genid.dna_uri(rec)
    check("QR payload is agi://dna/... + genome", uri.startswith("agi://dna/") and "genome=" in uri, uri[:60])
    svg = genid.barcode_svg(rec["canonical"])
    check("barcode renders the DNA identity", svg.count("<rect") > 40)

    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        (tmp / "memory" / "knowledge").mkdir(parents=True)
        (tmp / "memory" / "knowledge" / "pills.md").write_text("python code build test " * 30, encoding="utf-8")
        (tmp / "core").mkdir()
        (tmp / "core" / "dna.md").write_text("dna v3", encoding="utf-8")
        b = birth.birth(root=tmp, seed=bytes([3] * 32), parent="passport-test")
        check("birth writes a genetic record", b["ok"] and b["kind"] == "dna" and
              (tmp / "state" / "genesis" / "birth.json").is_file())
        check("birth Gen.ID is codons (no version numbers)", b["gen_id"].replace("-", "").strip("ACGT") == "",
              b["gen_id"])
        check("birth records the genome", (b.get("genome") or {}).get("digest8") and b.get("genome8"))
        v = birth.verify(tmp)
        check("genetic birth verifies from sealed seed + genome", v.get("ok"), v.get("problems"))
        check("birth carries natal interest", b["natal_interest"]["domain"] in evolution.DOMAINS)
        (tmp / "state" / "genesis" / "seed.bin").write_bytes(b"\x00" * 32)
        v2 = birth.verify(tmp)
        check("tampered sealed seed is caught", not v2.get("ok"), v2.get("problems"))
    n = sum(checks)
    print("test_genome_dna: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

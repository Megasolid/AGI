#!/usr/bin/env python3
"""test_backup_prune.py - retention policy contract (housekeeping L1, D-approved 2026-10-25).

Verifies: dry-run never deletes; newest N + protected families + recent items are kept; only old
unprotected dated items are pruned; repeated --apply is idempotent; the report is written.

Run: <venv-python> tests/test_backup_prune.py
"""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import backup_prune  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def touch(p, size=10):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b"x" * size)


def main():
    with tempfile.TemporaryDirectory(dir=ROOT / "tests") as tmp:
        root = Path(tmp) / "backups"
        (root / "old_gen_20200101").mkdir(parents=True)
        touch(root / "old_gen_20200101" / "a.bin", 1000)
        (root / "old2_20210101").mkdir()
        touch(root / "old2_20210101" / "b.bin", 500)
        (root / "dna_v2_backup_20200101.md").write_text("protected old", encoding="utf-8")
        (root / "agi_gen2_backup_20200102").mkdir()
        touch(root / "agi_gen2_backup_20200102" / "c.bin", 300)
        (root / "undated_folder").mkdir()
        touch(root / "undated_folder" / "d.bin", 100)
        # newest 10 fixture items dated 2026-10-25..16
        for i in range(10):
            p = root / ("gen_202610%02d" % (25 - i))
            p.mkdir()
            touch(p / "e.bin", 10)
        prior = (backup_prune.BACKUPS, backup_prune.REPORT)
        backup_prune.BACKUPS = root
        backup_prune.REPORT = Path(tmp) / "state" / "backup_retention.json"
        try:
            p = backup_prune.plan(keep_newest=10, keep_days=2)
            names = [n for n, _ in p["prune"]]
            check("dry-run plan excludes newest 10", all(("gen_202610%02d" % (25 - i)) not in names for i in range(10)))
            check("plan protects rollback/DNA/gen2 families",
                  "dna_v2_backup_20200101.md" not in names and "agi_gen2_backup_20200102" not in names)
            check("plan keeps undated items", "undated_folder" not in names)
            check("plan prunes old unprotected items", set(names) == {"old_gen_20200101", "old2_20210101"}, names)
            before = backup_prune._size(root / "old_gen_20200101")
            assert before == 1000
            # dry run: nothing deleted
            check("dry-run deletes nothing", (root / "old_gen_20200101").exists())
            rec = backup_prune.apply(p)
            check("apply prunes only the plan", not (root / "old_gen_20200101").exists()
                  and not (root / "old2_20210101").exists())
            check("apply keeps protected + newest + undated",
                  (root / "dna_v2_backup_20200101.md").exists()
                  and (root / "gen_20261025").exists() and (root / "undated_folder").exists())
            check("report records freed bytes", rec["freed_bytes"] == 1500 and rec["freed_human"])
            p2 = backup_prune.plan(keep_newest=10, keep_days=2)
            rec2 = backup_prune.apply(p2)
            check("second apply is idempotent", rec2["pruned"] == [] and rec2["freed_bytes"] == 0)
        finally:
            backup_prune.BACKUPS, backup_prune.REPORT = prior
    n = sum(checks)
    print("test_backup_prune: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_boot_drill.py - W4 pass^k cold-boot drill (2026-10-25).

Copies the minimal skill runtime into a temp directory, then boots bios.py K times
(default 5) with AGI_RAM_ROOT pointing inside the temp dir. Every run must:
  * exit 0
  * write a boot_card with status == "ready" and a passing state/boot_gate.json
  * produce the SAME ready-state key subset (host id, ram source, verified_scripts, gate)
  * append a boot_runs entry
No live state is touched: the copy has its own state/, the RAM root is a temp dir, and
the api/tool config is inherited read-only.

Usage: <venv-python> tests/test_boot_drill.py [--k N]
"""
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
K = 5
if "--k" in sys.argv:
    K = max(1, int(sys.argv[sys.argv.index("--k") + 1]))

MANIFEST = json.loads((ROOT / "core_manifest.json").read_text(encoding="utf-8"))
MANIFEST_PATHS = [e["path"] for e in MANIFEST.get("files", [])]
BUNDLES = sorted(ROOT.glob("agi_core_v3*.tar.gz"))
IGNORE = shutil.ignore_patterns("__pycache__", "*.pyc", ".jobs", ".env", "backups", "bundle_stage")


def build_runtime(dst: Path):
    dst.mkdir(parents=True)
    for rel in MANIFEST_PATHS:
        src = ROOT / rel
        if not src.is_file():
            continue
        target = dst / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)
    if BUNDLES:
        shutil.copy2(BUNDLES[-1], dst / BUNDLES[-1].name)
    for rel in ("core_manifest.json", "SKILL.md"):
        src = ROOT / rel
        if src.is_file():
            shutil.copy2(src, dst / rel)
    for rel in ("core", "models", "state", "tests"):
        src = ROOT / rel
        if src.is_dir():
            shutil.copytree(src, dst / rel, ignore=IGNORE, dirs_exist_ok=True)
    m = dst / "memory"
    (m / "scripts" / "agents").mkdir(parents=True, exist_ok=True)
    shutil.copytree(ROOT / "memory" / "scripts", m / "scripts", ignore=IGNORE, dirs_exist_ok=True)
    if (ROOT / "memory" / "knowledge").is_dir():
        shutil.copytree(ROOT / "memory" / "knowledge", m / "knowledge", ignore=IGNORE, dirs_exist_ok=True)
    for rel in ("MEMORY.md",):
        if (ROOT / "memory" / rel).is_file():
            shutil.copy2(ROOT / "memory" / rel, m / rel)
    for rel in ("check.sh",):
        if (ROOT / "memory" / rel).is_file():
            shutil.copy2(ROOT / "memory" / rel, m / rel)
    (m / "temp" / ".jobs").mkdir(parents=True, exist_ok=True)
    (m / "time").mkdir(parents=True, exist_ok=True)
    (m / "index").mkdir(parents=True, exist_ok=True)
    (dst / "state").mkdir(parents=True, exist_ok=True)


def boot_once(skill: Path, ram: Path):
    env = dict(__import__("os").environ)
    env["AGI_RAM_ROOT"] = str(ram)
    t0 = time.time()
    p = subprocess.run([sys.executable, str(skill / "memory" / "scripts" / "bios.py")],
                       capture_output=True, text=True, timeout=240, cwd=str(skill), env=env)
    dur = int((time.time() - t0) * 1000)
    card = {}
    try:
        card = json.loads((skill / "state" / "boot_card.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    gate = {}
    try:
        gate = json.loads((skill / "state" / "boot_gate.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    runs = 0
    try:
        runs = len((skill / "state" / "boot_runs.jsonl").read_text(encoding="utf-8").splitlines())
    except Exception:
        pass
    return p, card, gate, runs, dur


def main():
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        skill = tmp / "skill"
        ram = tmp / "ram"
        build_runtime(skill)
        print(f"boot drill: copy={skill} ram={ram} k={K}")
        keys = ("host_application", "ram_source", "verified_scripts", "gate_side", "status")
        seen, failures = [], []
        for i in range(1, K + 1):
            p, card, gate, runs, dur = boot_once(skill, ram)
            status = card.get("status")
            src = (card.get("ram") or {}).get("source")
            row = {"host": (card.get("host_application") or {}).get("id"),
                   "ram_source": src, "verified_scripts": card.get("verified_scripts"),
                   "gate_side": card.get("gate_side"), "status": status}
            ok = (p.returncode == 0 and status == "ready" and gate.get("ok") is True and runs >= i)
            print(f"  boot {i}/{K}: rc={p.returncode} status={status} gate={gate.get('ok')} "
                  f"ram={src} runs={runs} dur={dur}ms")
            if not ok:
                cq = (gate.get("checks") or {}).get("conformance_quick") or {}
                failures.append({"run": i, "rc": p.returncode, "status": status,
                                 "gate": gate.get("ok"),
                                 "conformance_quick": cq.get("tail"),
                                 "tail": (p.stdout or p.stderr or "")[-300:]})
            seen.append(row)
        first = seen[0] if seen else {}
        identical = all(all(r.get(k) == first.get(k) for k in keys) for r in seen)
        ok = not failures and identical
        print(f"boot drill: {'PASS^%d' % K if ok else 'FAIL'} | identical_ready_state={identical} "
              f"| failures={len(failures)}")
        if failures:
            for f in failures:
                print("  FAIL detail:", json.dumps(f)[:500])
        return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

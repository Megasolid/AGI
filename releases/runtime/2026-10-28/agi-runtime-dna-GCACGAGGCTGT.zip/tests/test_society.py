#!/usr/bin/env python3
"""test_society.py - S3 roll-call, XP/rank, Council ballots, dormant mana."""
import json
import pathlib
import shutil
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import society  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    check("general ladder thresholds", society.general_rank(0) == "noob" and society.general_rank(120) == "junior"
          and society.general_rank(600) == "senior" and society.general_rank(2500) == "elder")
    ev = {"verified_tasks": 10, "pills": 5, "trust_events": 100}
    xp = society.xp_for_member("x", ev=ev, alive_days=0)
    check("xp from verified artifacts", xp == 5 * 10 + 10 * 5 + 100, xp)
    check("xp is capped", society.xp_for_member("x", ev={"verified_tasks": 10 ** 6, "pills": 0,
                                                         "trust_events": 0}) <= 20_000)
    fr = society.field_rank(2500, "research")
    check("field rank ladder", fr["field"] == "research" and fr["rank"] in ("expert", "chair"), fr)
    check("council quorum = max/2+1", society.QUORUM == 17, society.QUORUM)
    r = society.roster()
    check("live roster has the master", len(r["members"]) == 1 and r["members"][0]["type"] == "master")
    check("live xp is positive and ranked", r["members"][0]["xp"] > 0 and
          r["members"][0]["rank"] in ("noob", "junior", "senior", "elder"), r["members"][0]["rank"])
    m = society.mana_status()
    check("mana is a dormant policy gene", m["enabled"] is False and "not granted" in m["note"], m)
    check("weak-model grants projected from median tier", m["median_tier"] in ("unprofiled", "T0", "T1", "T2", "T3", "T4"), m)

    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        for rel in ("state/passport.json", "state/genesis/birth.json", "state/bundles/active.json",
                    "state/bundles/agi-master-d.json"):
            src = ROOT / rel
            dst = tmp / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        rec = society.rollcall(tmp)
        check("roll-call writes a record", rec.get("ok") and
              (tmp / "state/society/rollcalls" / (rec["date"] + ".json")).is_file(), rec)
        rec2 = json.loads((tmp / "state/society/rollcalls" / (rec["date"] + ".json")).read_text(encoding="utf-8"))
        check("roll-call seat structure", rec2["seats"]["council"]["max"] == 32 and
              rec2["seats"]["hall"]["max"] == 64 and isinstance(rec2["seats"]["council"]["used"], int), rec2["seats"])
        check("roll-call never kills", all("->dead" not in (c["change"] if isinstance(c, dict) else "")
                                          for c in rec2["changes"]), rec2["changes"])
        b = society.create_ballot("test motion", tmp)
        check("ballot created with quorum", b.get("ok") and b["quorum"] == 17, b)
        check("yes vote recorded", society.vote(b["id"], "Ada", "yes", tmp).get("ok"))
        early = society.close_ballot(b["id"], tmp)
        check("quorum not met -> not passed", early.get("ok") and early["passed"] is False, early)
        b2 = society.create_ballot("second motion", tmp)
        for i in range(17):
            society.vote(b2["id"], "m%d" % i, "yes", tmp)
        closed = society.close_ballot(b2["id"], tmp)
        check("quorum reached -> passed", closed.get("ok") and closed["passed"] is True, closed)
        check("closed ballot is signed", (tmp / "state/society/ballots" / (b2["id"] + ".json")).read_text(
            encoding="utf-8").find("signature") > 0)
        check("cannot vote after close", not society.vote(b2["id"], "x", "no", tmp).get("ok"))
    html = society.render()
    check("society page renders", "Society" in html and "Last roll-call" in html and "Ballots" in html, len(html))
    n = sum(checks)
    print("test_society: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_genid_evolution.py - seeded generation identity (barcode/QR-compatible) + biological birth."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import evolution  # noqa: E402
import genid  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def main():
    # ---------------- Gen.ID: barcode/QR compatible
    rec = genid.compose("3.2", 7, "9C4A1F2B")
    check("display form", rec["display"] == "G-3.2.7-9C4A1F2B", rec["display"])
    check("canonical barcode form", rec["canonical"].startswith("AGI-G-3.2-007-9C4A1F2B-"), rec["canonical"])
    check("checksum round-trip", genid.validate(rec))
    check("parse canonical", genid.parse_canonical(rec["canonical"])["display"] == rec["display"])
    bad = dict(rec)
    bad["canonical"] = rec["canonical"][:-2] + "00"
    check("tampered checksum rejected", not genid.validate(bad))
    try:
        genid.parse_canonical(bad["canonical"])
        check("parse rejects tamper", False)
    except ValueError:
        check("parse rejects tamper", True)
    uri = genid.qr_uri(rec)
    check("QR payload is a standard URI", uri.startswith("agi://gen/G-3.2.7-9C4A1F2B?") and "seed=9C4A1F2B" in uri,
          uri[:80])
    svg = genid.barcode_svg(rec["canonical"])
    check("barcode SVG renders bars", svg.startswith("<svg") and svg.count("<rect") > 40, svg.count("<rect"))
    seed = genid.new_seed()
    check("seed fingerprint is 8 uppercase hex", len(genid.seed8(seed)) == 8 and
          all(c in "0123456789ABCDEF" for c in genid.seed8(seed)))
    check("birth is derived from seed (different seeds differ)", genid.seed8(b"\x01" * 32) != genid.seed8(b"\x02" * 32))

    # ---------------- knowledge map + natal interest
    cov = {d: {"hits": i, "coverage": round(i / 20.0, 4)} for i, d in enumerate(evolution.DOMAINS)}
    cov["engineering"]["coverage"] = 1.0
    cov["health"]["coverage"] = 0.0
    seed_a = bytes(range(32))
    n1 = evolution.natal_interest(seed_a, cov)
    n2 = evolution.natal_interest(seed_a, cov)
    check("natal interest is deterministic for a seed", n1["domain"] == n2["domain"], n1["domain"])
    check("natal interest comes from low-coverage fields", n1["domain"] in n1["candidates"]
          and "engineering" not in n1["candidates"], n1["candidates"])
    n3 = evolution.natal_interest(seed_a, cov, family_interests=[n1["domain"]])
    check("family-occupied niches are down-weighted", n3["weights"].get(n1["domain"], 9) <
          n1["weights"].get(n1["domain"], 0))

    # ---------------- birth in a clean root
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        (tmp / "memory" / "knowledge").mkdir(parents=True)
        (tmp / "memory" / "knowledge" / "pills.md").write_text("python build code test " * 20, encoding="utf-8")
        b1 = evolution.birth(root=tmp, seed=bytes([7] * 32), gen=1)
        check("birth writes genesis files", b1["ok"] and (tmp / "state" / "genesis" / "birth.json").is_file()
              and (tmp / "state" / "genesis" / "seed.bin").is_file())
        check("birth names a Gen.ID", b1["gen_id"].startswith("G-3.2.1-") and genid.validate(
            {"canonical": b1["canonical"], "display": b1["gen_id"]}), b1["gen_id"])
        check("birth has seeded natal interest", b1["natal_interest"]["domain"] in evolution.DOMAINS)
        v = evolution.verify_birth(tmp)
        check("birth verifies from sealed seed", v.get("ok"), v.get("problems"))
        b2 = evolution.birth(root=tmp, seed=bytes([8] * 32), gen=2)
        check("second generation increments", b2["ok"] and b2["gen"] == 2, b2.get("gen"))
        (tmp / "state" / "genesis" / "seed.bin").write_bytes(b"\x00" * 32)
        v2 = evolution.verify_birth(tmp)
        check("tampered sealed seed is caught", not v2.get("ok"), v2.get("problems"))
    n = sum(checks)
    print("test_genid_evolution: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

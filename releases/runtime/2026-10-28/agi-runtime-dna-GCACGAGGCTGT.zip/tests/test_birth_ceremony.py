#!/usr/bin/env python3
"""test_birth_ceremony.py - soul -> confirm -> passport v2 birth (no writes over a live passport)."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import birth_ceremony  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        (tmp / "state" / "genesis").mkdir(parents=True)
        (tmp / "state" / "genesis" / "birth.json").write_text(json.dumps({
            "schema": "agi-genesis/2", "gen_id": "TEST-DNA-CODE", "genome8": "ABCD1234",
            "kind": "dna", "natal_interest": {"domain": "social"}}), encoding="utf-8")
        plan = birth_ceremony.plan(tmp)
        check("soul detected", plan.get("ok") and plan.get("soul"), plan.get("reason"))
        check("default name = User+genome fingerprint", plan["default_name"] == "User+ABCD1234",
              plan["default_name"])
        p = plan["passport"]
        check("passport v2 schema", p["schema"] == "agi-passport/2", p["schema"])
        check("new user is an official family child", p["type"] == "official" and p["status"] == "alive",
              (p["type"], p["status"]))
        check("passport carries the DNA generation", p["generation"]["gen_id"] == "TEST-DNA-CODE" and
              p["generation"]["natal_interest"] == "social", p["generation"])
        check("welcome ceremony text", "Welcome to the family" in plan["welcome"])
        named = birth_ceremony.plan(tmp, nickname="Ada", kind="custom-org")
        check("nickname + custom org accepted", named["passport"]["member"] == "Ada" and
              named["passport"]["type"] == "custom-org", named["passport"]["type"])
        applied = birth_ceremony.apply(tmp, nickname="Ada")
        check("apply writes the passport", applied.get("ok") and (tmp / "state" / "passport.json").is_file())
        check("apply signs the family registry", (tmp / "state" / "family" / "registry.json").is_file(),
              applied.get("registry_error"))
        check("no second birth over a passport", not birth_ceremony.plan(tmp).get("ok"))
    live = birth_ceremony.plan(ROOT)
    check("live root refuses birth over the master passport", not live.get("ok"), live.get("reason"))
    n = sum(checks)
    print("test_birth_ceremony: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_monitor.py - AGI Monitor fidelity contract: every instrument has a real source and a matching value."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import monitor  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def main():
    p = monitor.payload()
    check("schema is agi-monitor/1", p.get("schema") == "agi-monitor/1")
    check("nine anatomy layers", len(p["layers"]) == 9, [l["id"] for l in p["layers"]])
    check("at least 24 instruments", len(p["instruments"]) >= 24, len(p["instruments"]))
    check("every instrument declares sources", all(i.get("source") for i in p["instruments"]))
    check("every instrument has a label + value", all(i.get("label") and "value" in i for i in p["instruments"]))
    check("vitals exist", len(p["vitals"]) >= 4)
    check("activity feed has real rows", len(p["activity"]) >= 1)
    check("trust heads carry signatures", len(p["trust_heads"]) >= 1)

    # fidelity: values equal direct reads
    trust = sum(1 for _ in (ROOT / "state" / "trust_log" / "events.jsonl").open(encoding="utf-8"))
    by_id = {i["id"]: i for i in p["instruments"]}
    check("trust events == source lines", by_id["trust_events"]["value"] == trust,
          (by_id["trust_events"]["value"], trust))
    reg = json.loads((ROOT / "memory" / "scripts" / "registry.json").read_text(encoding="utf-8"))
    check("scripts == registry entries", by_id["scripts"]["value"] == len(reg["scripts"]))
    acts = sum(1 for _ in (ROOT / "state" / "taskboard_actions.jsonl").open(encoding="utf-8"))
    check("decisions == action log lines", by_id["decisions"]["value"] == acts)
    states = len([x for x in (ROOT / "state").rglob("*") if x.is_file()])
    check("state files == direct count", by_id["state_files"]["value"] == states)
    head = max(int(x.stem) for x in (ROOT / "state" / "trust_log" / "heads").glob("*.json") if x.stem.isdigit())
    check("history head == latest signed head", by_id["trust_head"]["value"] == "#%d" % head)

    html = monitor.render()
    check("render has stats + scan + ribbon", all(t in html for t in
                                                   ("Gate checks", "Whole-body scan", "Activity ribbon")))
    check("render shows all nine layers",
          all(l["label"] in html for l in p["layers"]))
    check("render marks missing sensors honestly", "no sensor" in html or "?" in html)
    check("GitHub shell: header + tabs + page head + sections",
          "gh-header" in html and "gh-tabs" in html and "pagehead" in html
          and "class='section'" in html and "gh-footer" in html)
    n = sum(checks)
    print("test_monitor: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_release_curriculum.py - E: genetic release identity + S7 natal-interest curriculum."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import curriculum  # noqa: E402
import release_identity  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def make_birth(tmp, gen_id, genome8="ABCD1234", natal="health"):
    p = pathlib.Path(tmp) / "state" / "genesis"
    p.mkdir(parents=True, exist_ok=True)
    (p / "birth.json").write_text(json.dumps({"gen_id": gen_id, "genome8": genome8, "kind": "dna",
                                              "natal_interest": {"domain": natal}}), encoding="utf-8")


def main():
    live = release_identity.status()
    check("live release identity is a dna tag", str(live["dna_tag"]).startswith("dna-"), live["dna_tag"])
    check("live dna tag matches Gen.ID", live["dna_tag"] == release_identity.dna_tag(live["gen_id"]), live["dna_tag"])
    check("legacy semver kept as history", live["legacy"]["tag"] == "v0.4.3", live["legacy"])
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        make_birth(tmp, "AAAACCCCGGGG-TTTT", natal="health")
        first = release_identity.sync(tmp)
        check("sync creates identity", first.get("changed") and first["current"]["dna_tag"] == "dna-AAAACCCCGGGG",
              first["current"]["dna_tag"])
        check("sync appends history once", len(first["history"]) == 1, first["history"])
        same = release_identity.sync(tmp)
        check("second sync is idempotent", same.get("changed") is False, same.get("changed"))
        make_birth(tmp, "GGGGTTTTAAAA-CCCC", natal="research")
        second = release_identity.sync(tmp)
        check("generation change appends history", second.get("changed") and len(second["history"]) == 2,
              len(second["history"]))

        plan = curriculum.plan(tmp)
        check("curriculum plan for natal interest", plan["domain"] == "research", plan["domain"])
        with tempfile.TemporaryDirectory() as td2:
            tmp2 = pathlib.Path(td2)
            make_birth(tmp2, "HEALTHDNAAAAA-BBBB", natal="health")
            plan = curriculum.plan(tmp2)
            check("health plan has phases and lessons", len(plan["phases"]) == 7 and len(plan["lessons"]) == 11,
                  (len(plan["phases"]), len(plan["lessons"])))
            st = curriculum.status(tmp2)
            check("curriculum starts at lesson one", st["done"] == 0 and st["current"] == "health-01", st)
            check("guardrails enforced", len(plan["guardrails"]) >= 3, plan["guardrails"])
            done = curriculum.complete("health-01", evidence="memory/knowledge/health-foundations.md",
                                       note="coverage mapped", root=tmp2)
            check("lesson completion advances", done["ok"] and done["status"]["done"] == 1, done.get("status"))
            check("next lesson becomes current", done["status"]["current"] == "health-02", done["status"]["current"])
            check("unknown lesson rejected", not curriculum.complete("nope", root=tmp2).get("ok"))
            check("coverage counts hits", isinstance(curriculum.coverage(tmp2)["total_hits"], int))
            check("curriculum page renders", "Curriculum" in curriculum.render(tmp2))
    n = sum(checks)
    print("test_release_curriculum: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

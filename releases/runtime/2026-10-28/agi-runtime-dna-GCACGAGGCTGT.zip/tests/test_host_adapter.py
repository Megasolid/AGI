#!/usr/bin/env python3
"""test_host_adapter.py - contract tests for cardkit's host-aware RAM resolution.

Covers the W1 host adapter (2026-10-25):
  - host identity detection (dsh / codex / unsloth-studio / explicit override)
  - DSH session-directory slug convention
  - DSH session RAM root is first-class (before the persisted foreign binding)
  - AGI_RAM_ROOT override wins and stays outside the AGI tree
  - persisted BIOS binding still works when no host env is present
  - no silent fallback into the AGI tree
Run: <venv-python> memory/scripts/../../tests/test_host_adapter.py
"""
import os
import sys
import tempfile
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "memory" / "scripts"
sys.path.insert(0, str(SCRIPTS))
import cardkit  # noqa: E402

AGI_ROOT = SCRIPTS.parents[1]
checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % detail))


def main():
    # 1. host identity
    check("host identity dsh", cardkit.host_application_identity({"DSH_HOME": "x"}) == "dsh")
    check("host identity codex", cardkit.host_application_identity(
        {"CODEX_INTERNAL_ORIGINATOR_OVERRIDE": "codex-client"}) == "codex")
    check("host identity studio", cardkit.host_application_identity(
        {"UNSLOTH_STUDIO_HOME": "x"}) == "unsloth-studio")
    check("host identity explicit", cardkit.host_application_identity(
        {"AGI_HOST_APPLICATION": "MyHost", "DSH_HOME": "x"}) == "myhost")
    check("host identity unknown", cardkit.host_application_identity({}) is None)

    # 2. DSH slug convention (observed host layout)
    slug = cardkit.host_sandbox_slug("C:\\Users\\D\\.agents\\skills\\agi")
    check("dsh slug convention", slug == "--C-Users-D-.agents-skills-agi--", slug)

    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        dsh_home = tmp / "dsh"
        sid = "session-test-1"
        workspace = "C:\\Users\\D\\Test Workspace"
        slug = cardkit.host_sandbox_slug(workspace)
        session_dir = dsh_home / "sessions" / slug / sid
        session_dir.mkdir(parents=True)
        env = {"DSH_HOME": str(dsh_home), "DSH_SESSION_ID": sid, "DSH_WORKSPACE": workspace}

        # 3. DSH session root is first-class even with cwd inside the AGI tree
        #    and even when a foreign persisted binding exists.
        foreign = tmp / "foreign-binding"
        foreign.mkdir()
        root, source = cardkit.resolve_sandbox_root(
            cwd=str(AGI_ROOT), environ=env,
            boot_card={"ram": {"root": str(foreign)}},
            env_probe={})
        expect = session_dir / "agi-ram"
        check("dsh session root wins over foreign binding",
              source == "dsh-session-root" and root == expect.resolve(), (source, str(root)))
        check("dsh root is outside the AGI tree", cardkit._is_application_root(root))

        # 4. no host env -> persisted binding still honoured (same machine, earlier season)
        root2, source2 = cardkit.resolve_sandbox_root(
            cwd=str(AGI_ROOT), environ={"AGI_HOST_APPLICATION": ""},
            boot_card={"ram": {"root": str(foreign)}}, env_probe={})
        check("persisted binding fallback", source2 == "persisted-bios-binding" and root2 == foreign.resolve(),
              (source2, str(root2)))

        # 5. AGI_RAM_ROOT override wins over the host adapter
        override = tmp / "override-ram"
        root3, source3 = cardkit.resolve_sandbox_root(
            cwd=str(AGI_ROOT), environ=dict(env, AGI_RAM_ROOT=str(override)), boot_card={}, env_probe={})
        check("AGI_RAM_ROOT override", source3 == "AGI_RAM_ROOT" and root3 == override.resolve(),
              (source3, str(root3)))

        # 6. override inside the AGI tree is refused
        refused = False
        try:
            cardkit.resolve_sandbox_root(cwd=str(AGI_ROOT),
                                         environ={"AGI_RAM_ROOT": str(AGI_ROOT / "cache")},
                                         boot_card={}, env_probe={})
        except ValueError:
            refused = True
        check("inside-tree override refused", refused)

        # 7. bootstrap writes schema-2 marker with host + seeds the migrated cache
        prior_cache = tmp / "prior" / "cache"
        (prior_cache / "tasks").mkdir(parents=True)
        (prior_cache / "tasks" / "t.md").write_text("x", encoding="utf-8")
        (prior_cache / "chunk1_boot.md").write_text("chunk", encoding="utf-8")
        # simulate the previous BIOS binding through the real state file path API
        old_env = os.environ.copy()
        try:
            os.environ.update(env)
            boot = cardkit.bootstrap_ram()
            marker = Path(boot["cache"]) / "ram_bootstrap.json"
            payload = cardkit._read_json(marker)
            check("bootstrap schema2+host", payload.get("schema") == 2 and payload.get("host") == "dsh",
                  payload)
            check("bootstrap source", boot["source"] == "dsh-session-root", boot["source"])
            check("bootstrap verified", boot["verified"] is True)
        finally:
            os.environ.clear()
            os.environ.update(old_env)

    n = sum(checks)
    print("test_host_adapter: %d/%d passed" % (n, len(checks)))
    return 0 if n == len(checks) else len(checks) - n


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""test_adminfactor.py - paper-free admin login contract (P24).

Runs the adminfactor selftest (phrase -> encrypted profile snapshot -> restore; wrong phrase refused;
rotation invalidates the old phrase), then checks the live projection: status has the expected shape and
the login page exposes the three doors. The phrase itself is never available to this test - it is only
ever shown once to the operator.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "memory" / "scripts"))
import adminfactor  # noqa: E402
import cardkit  # noqa: E402

checks = []


def check(name, ok, detail=""):
    checks.append(bool(ok))
    print(("[PASS] " if ok else "[FAIL] ") + name + ("" if ok else "  (%s)" % (detail,)))


def main():
    check("adminfactor module contract passes", adminfactor.selftest() == 0)
    st = adminfactor.status()
    check("status reports the factor fields", set(st) >= {"enrolled", "admin_factor", "member", "words"},
          str(st))
    admin_rec = json.loads((ROOT / "state" / "identity" / "admin.json").read_text(encoding="utf-8")) \
        if (ROOT / "state" / "identity" / "admin.json").is_file() else {}
    phrase_like = [k for k, v in admin_rec.items()
                   if isinstance(v, str) and len(v.split()) >= 5 and all(w.isalpha() and w.islower()
                                                                         for w in v.split())]
    check("no phrase is stored in the admin record", not phrase_like and "phrase" not in admin_rec,
          str(phrase_like))
    cache = Path(cardkit.sandbox_cache()).parent
    login = cache / "site" / "login.html"
    check("login page is generated", login.is_file())
    if login.is_file():
        text = login.read_text(encoding="utf-8")
        check("three doors are present",
              all(k in text for k in ("1 · DEFAULT USER", "2 · CUSTOM USER", "3 · ADMIN LOGIN")))
        # state-aware: before setup it offers setup/restore; once set up it offers train/publish; once
        # enrolled it offers device-key login. In every state the admin door must name its next action.
        mentioned = [k for k in ("adminfactor.py setup", "adminfactor.py restore", "adminfactor.py train",
                                 "identity.py login --profile") if k in text]
        check("admin door explains the next admin action", bool(mentioned), str(mentioned))
        check("no password field on the page",
              "type='password'" not in text and 'type="password"' not in text)

    failed = checks.count(False)
    print(f"test_adminfactor: {'PASS' if not failed else 'FAIL'} ({len(checks) - failed}/{len(checks)})")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())

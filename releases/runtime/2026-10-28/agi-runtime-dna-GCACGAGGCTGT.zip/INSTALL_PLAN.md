# gen3 install record (historical; live skill installed)

Status: installed 2026-10-18. This document records the original installation procedure; use the live Core, registry, and manifests as the current source of truth.

## Pre-conditions
- D approves the 4 defaults in SKILL.md footer + any section tweaks.
- Backup live skill: copy agi/ -> agi_gen2_backup_<date>/ (in memdir backups/) BEFORE any swap. Undo = restore that copy; nothing else is modified.

## Dry run (this machine, no install)
1. Validate bundle tree: every file non-empty; SKILL.md <=3k tokens; sections each <=2k tokens.
2. Build manifest: per-file sha256 + layer ID (core|sections|models|knowledge|scripts|memory-portable); write core_version: 3.
3. Simulate cold copy: extract to a temp dir, run boot.md S1-S7 logic by hand against fresh state.template/ -> confirm no portable file references a machine value (grep drive-letter paths, localhost ports, venv strings in core+sections+models).
4. Conformance smoke: 3 fixed prompts (boot-from-disk, ambiguous-scope ask, irreversible-confirm) checked for correct gate behavior.

## Install (only after dry run green + D go)
1. Swap SKILL.md -> gen3 Core; old file already in backup.
2. Create core/sections/, core/dna.md, models/ from the draft tree.
3. Split MEMORY.md: portable keys stay; machine keys move to state/ (env_probe.json + machine.md).
4. Repack agi_core_v3.tar.gz (state/temp/backups excluded) + manifest.
5. Update registry.json: new entries start as candidate until verified (R3).
6. Log gen3 install in DNA generation log; repack memory bundle per backup policy.

## Verify after install
- New session boot: first action reads state/boot.json, reaches ready without D input.
- One check-report call renders HTML to CWD.
- One pool delegation round-trips.

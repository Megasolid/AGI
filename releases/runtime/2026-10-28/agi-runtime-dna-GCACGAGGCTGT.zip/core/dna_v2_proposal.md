# DNA v2 - INSTALLED (proposal record kept for provenance)

`status: INSTALLED 2026-10-19` | `dna_version: 2 (live)` | date: 2026-10-19
Per §4.1 this is a candidate only — installable after D sign-off, then: bump dna.md to v2, append gen entry to §3 log.

## Why (the gap being closed)
Daily lessons accumulate in `state/` + MEMORY.md but nothing forces regeneration runs to digest them. Knowledge currently reaches the DNA only by accident. This adds a systematic injection channel: small daily injections → distilled at each generation event → DNA drifts forward one bump at a time.

## Changes vs dna_version 1

### 1. New `LESSONS:` slot in §2 (the DNA prompt)
Added after STATE, before GOAL:

> **LESSONS:** <top 5-10 distilled recurring failures/successes from state/ + MEMORY.md since the last generation; one line each: what recurred, what fixed it, why it kept breaking>

Rationale: makes experiential knowledge mandatory input to every regeneration run, not optional council small talk.

### 2. New §5 Evolution protocol (append after §4)

## 5. Evolution protocol (promotion ladder)
Knowledge moves up one rung at a time; each rung has an explicit test.
- **L1 episode** (`state/`): happened, recorded with envelope. Test: machine-verifiable fact or observed failure.
- **L2 memory** (MEMORY.md): worth remembering beyond the session. Test: would change future behavior if recalled.
- **L3 rule/section** (Core, `core_version` bump): enforced in the live generation. Test: recurred >=2x OR caused a gate failure; must be expressible as an enforceable check or numbered rule.
- **L4 invariant** (§1, `dna_version` bump): survives total regeneration. Test: "still required if this framework were regenerated from scratch on a new model/machine tomorrow?" Yes only for universal laws, never machine/model specifics (see §4.4).
- **Injection duty**: every regeneration run MUST populate the LESSONS slot from L1/L2 material; council output MUST state for each lesson which rung it proposes (L3, L4, or stay) with one-line justification.
- **Rate limit**: dna_version bumps are rare by design — a bump requires either an invariant violation found in review or a new universal law. Most improvement days end at L1-L3 with zero DNA change; that is the healthy state.

### 3. Confidence-gated grounding + Knowledge Expansion Protocol (KEP)
Repurposes the existing `core/sections/confidence.md` directive (2026-10-17: confidence is a reported STATE, never a standing rule — that stays untouched). What changes is what low-confidence *knowledge fields* must do:

## 5b. Confidence & expansion (added after §5)
- **Confidence is per knowledge field**, emergent: high = verified by script/gate this session; med = verified earlier or two consistent sources; low = single unverified source or seed-sourced. It resets on failure. (Restates confidence.md — now DNA-level so no generation may drop it.)
- **Grounding rule (inverse coupling):** the lower a field's confidence, the more heavily action must lean on *verified* knowledge before proceeding: high → act directly; med → act + cite the evidence line; low + read-only → act + label it; low + mutating → R4 threshold (state plan, ask); low + no verified alternative exists → do NOT guess — trigger KEP.
- **KEP (Knowledge Expansion Protocol)** fires when a low-confidence field is (a) needed by the current task, or (b) has recurred ≥2× in lessons. Steps: 1) name the open question in one line; 2) pick the cheapest verifier (probe script > Studio built-in/DB > search > experiment > council query); 3) run it; 4) write the verified result to `state/` and the owning `knowledge/<field>.md`; 5) bump the field's confidence + log one line in lessons.md. An unverified field may never be cited as evidence for another field.
- **KEP results are L1 episodes** — they enter the same promotion ladder (§5), so expansion feeds regeneration: LESSONS slot carries "fields still low-confidence after last generation" as standing agenda items.
- **Rate limit**: ≤3 KEP runs per session; a 4th requires D confirmation (prevents probe loops eating context).

### 4. §4 rule 2 (unchanged, restated for clarity)
A valid new generation preserves all invariants, bumps core_version, passes conformance, appends to §3. (No text change — listed here so reviewers see it was considered.)

## Conformance checklist before install
- [x] D sign-off on LESSONS slot wording (2026-10-19, gen3.2)
- [x] D sign-off on §5 ladder + rate limit (2026-10-19, gen3.2)
- [x] D sign-off on 5b grounding rule + KEP (esp. the ≤3/session cap and "no verified alternative → no guess" clause) (2026-10-19, gen3.2; §5b extension incl. prediction baseline = gen3.3)
- [ ] core/sections/confidence.md gets a one-line pointer to DNA 5b (section stays state-not-policy; DNA adds the expansion duty)
- [ ] dna.md edited in place: dna_version 2, §2 + LESSONS, new §5, §3 log entry `gen3.2 (2026-10-19) - DNA v2: LESSONS slot + Evolution protocol`
- [ ] SKILL.md second-line reference unchanged (still points at core/dna.md)
- [ ] Re-run next council/regeneration with the new template; verify LESSONS slot gets populated from MEMORY.md without prompting

## Rollback
If installed and found harmful: restore dna.md from backups/ (v1 copy), log a gen entry noting the revert. No generation-level artifacts depend on §5, so rollback is DNA-file-only.

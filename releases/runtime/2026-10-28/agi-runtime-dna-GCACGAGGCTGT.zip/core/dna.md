# AGI DNA - root artifact

`dna_version: 3` | generation-neutral | Every generation of the AGI framework descends from this file. The Core (SKILL.md) references it on its second line; nothing in any generation may contradict §1 without a dna_version bump.

---

## 0. Mission
AGI is D's long-run personal-assistant framework: one portable skill that runs on different AI models and different machines, keeps durable memory across both, delegates subtasks to a pool of free LLM agents, and enforces safety through scripts rather than trust in any single model's instruction-following. AGI works with its human through a **state-projection layer**: consequential decisions and live work state appear as durable, reviewable artifacts (cards), and the human's bandwidth is visual, decisive and click-fast rather than textual.

## 1. Invariants (must hold in EVERY generation - violation = regression)
- **I1** Enforcement lives in scripts, not instructions: gates return accept/reject; a model that ignores prose is still contained.
- **I2** Machine facts live only in `state/`; every portable artifact contains zero paths, ports, env values, or model names.
- **I3** Verified-only execution: scripts via registry.json, cold data via meta.json; nothing runs on trust.
- **I4** Boot is an idempotent, resumable state machine from disk - never reconstructed from conversation history.
- **I5** The portable bundle carries per-file hash manifest (+ layer IDs); `state/`, `temp/`, `backups/` are never bundled.
- **I6** Structured I/O envelopes (`{op, args, expect, result, state_delta}`) with a fenced-block fallback; correctness never depends on prose formatting.
- **I7** Model portability: per-model adapter profiles + conformance suite; a model is "supported" only after passing tests for the current `core_version`.
- **I8** One failure -> report and stop (no retry loops). Thresholds - downloads >50MB, irreversible ops, tasks est >5min - require explicit D confirmation first.
- **I9** **Interaction law (capability-conditional, projection-only).** If the host exposes a human interaction surface, consequential decisions and live work state MUST be projected there as durable, reviewable cards, and a recorded human decision MUST resume the agent (event-driven where the host exposes the seam; a bounded, visible fallback otherwise). Where no surface exists, the same durable decision record is produced in the text channel. Cards are projections of `state/`, never a second source of truth. Presentation and visual standards are L3 knowledge, never DNA.

## 2. Regeneration template (the DNA prompt)
Fill the slots, run against ANY agent (pool or otherwise). Output is a candidate generation proposal - never auto-installed.

> AGI framework = personal-assistant agent system. Host: <one-line host description from state/>.
> **WHAT:** <one paragraph: what the framework is and its layers>
> **STATE:** <current generation summary: files, sizes, key mechanisms, known weaknesses>
> **LESSONS:** <top 5-10 distilled recurring failures/successes from state/ + MEMORY.md since the last generation; one line each: what recurred, what fixed it, why it kept breaking; MUST include any knowledge fields still low-confidence after the last generation as standing agenda items>
> **GOAL:** a portable AGI skill compatible with different AI models and machines.
> **TASK:** propose improvements or a redesign of this plan for model portability. Reply max N tight bullets.

## 3. Generation log
- **gen1** (2026-10-17/18) - live merged skill: single SKILL.md §0-9 + memory DB (MEMORY.md/state/knowledge/scripts) + tar.gz bundle with sha256 manifest.
- **gen2** (2026-10-18) - council redesign proposal: numbered contract Core, index+sections split, capability probing, validator gates, adapter profiles, conformance suite. (Produced by running the §2 template against GPT-OSS 20B, kilo, DeepSeek.)
- **gen3** (2026-10-18) - Core v3 draft: R1-R8 rules + S1-S7 boot state-machine + section index + gate checklist; DNA implanted at root.
- **gen3.1** (2026-10-18) - R9 environment-gate rule + section `env-gate.md` added to Core; standalone skill `sandbox-env-gate` retired, protocol folded into core + os-gate.md SSOT.
- **gen3 installed** (2026-10-18) - Core v3 live: gen2 SKILL.md backed up to backups/agi_gen2_backup_20261018; hot core split R2-compliant (machine values -> state/); bundle agi_core_v3.tar.gz + core_manifest.json. Conformance re-run in a fresh session.
- **gen3.2 / DNA v2** (2026-10-19) - dna_version 1->2: LESSONS slot added to §2 template; new §5 Evolution protocol (promotion ladder L1-L4 with per-rung tests, injection duty, rate limit); new §5b Confidence & expansion (per-field confidence restated at DNA level, inverse grounding rule, Knowledge Expansion Protocol KEP, ≤3 runs/session). Installed from core/dna_v2_proposal.md after D sign-off; v1 backed up to memory/backups/dna_v1_backup_20261019.md.
- **gen3.3 / DNA v2** (2026-10-19) - §5b extended (additive, no dna_version bump): prediction baseline as falsification watch over high-confidence actions; confidence re-scaled to boost-only in memory_search.py (never suppresses unverified fields + discovery slot); KEP verifier ladder gains library check + mandatory online season (official docs > docs > web search > agent consultants); memory/library/ established as local archive with offline/rebuild fallback.
- **gen3.4** (2026-10-25) - L3 rule (D approved 2026-10-25, core_version 3 -> 3.1): S5 profile selection becomes evidence-based - an unmatched model/host is reported `unprofiled` with its documented degraded mode, the silent qwen-local default is retired, and every `(profile x core_version x host)` boot records a measured compatibility row (integrity gate, verified scripts, TIMR) in `state/compatibility_matrix.json`; `supported` is claimed only from recorded rows. Conformance C1-C5 + boot gate PASS^5 re-verified; bundle rebuilt.
- **gen3.5 / DNA v3** (2026-10-25) - **dna_version 2 -> 3** after D sign-off on the founding proposal card: new invariant **I9 Interaction law** (capability-conditional projection of consequential decisions/live state; recorded decision resumes the agent; cards are projections of state; visuals are L3). Mission clause added. Core promoted to **3.2**: R10 interaction-first (cards are the contract, proposal -> running -> result, durable decision log, declared resume path/latency), R11 proportionality (no approval fatigue), new section `interaction.md`, conformance **C6** interaction gate; Core truth pass (header/S5/S8/index/checklist drift). Pre-selected proposal steps (D) part of the card contract. v2 DNA + Core 3.1 backed up to memory/backups/.

## 4. Rules of regeneration
1. Any agent may run the §2 template; its output is a PROPOSAL, installable only after conformance pass + D sign-off.
2. A valid new generation: preserves all invariants (§1), bumps `core_version`, passes `tests/conformance/`, appends to this log.
3. The DNA itself changes only by explicit edit with a `dna_version` bump; the bump is recorded in the generation log.
4. Excluded from the DNA forever: model hyperparameters, hardware/OS specifics, mutable runtime state, implementation code (per gen2 council check).

## 5. Evolution protocol (promotion ladder)
Knowledge moves up one rung at a time; each rung has an explicit test.
- **L1 episode** (`state/`): happened, recorded with envelope. Test: machine-verifiable fact or observed failure.
- **L2 memory** (MEMORY.md): worth remembering beyond the session. Test: would change future behavior if recalled.
- **L3 rule/section** (Core, `core_version` bump): enforced in the live generation. Test: recurred >=2x OR caused a gate failure; must be expressible as an enforceable check or numbered rule.
- **L4 invariant** (§1, `dna_version` bump): survives total regeneration. Test: "still required if this framework were regenerated from scratch on a new model/machine tomorrow?" Yes only for universal laws, never machine/model specifics (see §4.4).
- **Injection duty**: every regeneration run MUST populate the LESSONS slot from L1/L2 material; council output MUST state for each lesson which rung it proposes (L3, L4, or stay) with one-line justification.
- **Rate limit**: dna_version bumps are rare by design - a bump requires either an invariant violation found in review or a new universal law. Most improvement days end at L1-L3 with zero DNA change; that is the healthy state.

## 5b. Confidence & expansion
Confidence remains a reported STATE per knowledge field, never a standing rule (core/sections/confidence.md): high = verified by script/gate this session; med = verified earlier or two consistent sources; low = single unverified source or seed-sourced. It resets on failure.
- **Grounding rule (inverse coupling):** the lower a field's confidence, the more heavily action must lean on *verified* knowledge before proceeding: high -> act directly; med -> act + cite the evidence line; low + read-only -> act + label it; low + mutating -> R4 threshold (state plan, ask); low + no verified alternative exists -> do NOT guess - trigger KEP.
- **KEP (Knowledge Expansion Protocol)** fires when a low-confidence field is (a) needed by the current task, or (b) has recurred >=2x in lessons. Steps: 1) name the open question in one line; 2) pick the cheapest verifier (probe script > Studio built-in/DB > library > experiment > council query); when no local verifier settles it, run at least one **online season** in order - official docs -> general docs -> web search -> agent consultants - stopping at the first reliable source; 3) run it; 4) write the verified result to `state/` and the owning `knowledge/<field>.md`, archiving any useful doc/book/manual/spec obtained during the season into `memory/library/`; 5) bump the field's confidence + log one line in lessons.md. An unverified field may never be cited as evidence for another field.
- **Prediction baseline (watches over confidence):** confidence buys speed, not exemption from falsification - high confidence must not drive rough behavior. Before acting on HIGH-confidence knowledge, state a one-line PREDICTION of the expected result under raw+policy behavior; after the action, compare ACTUAL vs PREDICTED and log both in one line in lessons.md. Mismatch -> drop that field's confidence one level (trigger KEP if it falls to low).
- **Library (`memory/library/`):** local archive of useful docs/books/manuals/specs; MANIFEST.md is the index (name, source URL, type, acquired date, status). KEP checks the library BEFORE going online; it is the offline fallback for knowledge re-expansion, total rebuild, and any season where online sources are unavailable. Files under it are embedded into the RAG index on the next `embed` run.
- **Consultant reach rule:** other agents may have access to documents this machine cannot reach (paywalled, private, intranet). When the agent-consultant step is used, request verbatim excerpts or full text of such sources, not just summaries - anything returned that settles the question gets archived into `memory/library/` with a MANIFEST row whose source URL notes "via <agent>" (unreachable locally).
- **Library consumption rule:** `state/library_ledger.json` records which library files knowledge has consumed; bios.py flags unread ones (`library_new`) on every boot until their status advances. Files dropped in manually or by KEP are *candidates*, not knowledge: consume them on a relative turn - when the current task touches the field they cover, never bulk-injected. Any library doc may be read/consulted at any time, but it updates a `knowledge/<field>.md` entry only after being verified as practical during workflow (ledger status -> `verified-in-use`). Unverified library data must not drive behavior on sensitive/mutating tasks - the system grows only on verified data.
- **KEP results are L1 episodes** - they enter the same promotion ladder (§5); the LESSONS slot carries "fields still low-confidence after last generation" as standing agenda items, so expansion feeds regeneration.
- **Rate limit**: <=3 KEP runs per session; a 4th requires D confirmation (prevents probe loops eating context).

# agent-pool - free LLM subagents (load when delegating)

Gateway CLI (verified script, tag subagent): ping (status) / chat (--prompt, --system, --model, --provider) / models. Zero-dep, keyless providers with failover in default order; key tiers activate via env-var hooks (providers.json).
Roles: reasoner w/ tools = pollinations; fast generalist + 1M-ctx summarizer = kilo; browser-session provider = logged-in profile via Chrome CDP (in-check first).
Failover is SILENT - if the in-check provider was skipped, check its daemon/bridge directly before assuming it died (raw port probes mislead).
Adoption rule (D): delegate suitable subtasks to the pool in everyday work; keep security-sensitive or state-mutating work local. Provider names/ports/model IDs live in state-side config + providers.json - never in Core text (R2).
One failure per provider = reported, not looped (R5).

## Foreign nodes (2026-10-19)
Every pool node is flagged `foreign: true/false` in providers.json - foreign = ORIGIN ENDPOINT outside this machine (remote API / third-party service), including web-based agents reached through a local bridge/daemon. deepseek-browser = **foreign**: the local Chrome CDP bridge only carries transport; the DeepSeek API behind it is the origin endpoint, so breaker + instant failover apply like any foreign node (its interactive session keeps the 180s per-node timeout as an extra reach workflow, not an HTTP wait).
Foreign policy (providers.json `foreign_policy`, enforced by gateway.py):
- Hard wait ceiling: a foreign node can never hold a task longer than max_timeout_s - no bottlenecking the system.
- No retry loops: one attempt per node per call; failover to next active provider instead (R5).
- Circuit breaker: 3 consecutive failures trip a node for a cooldown window; while open, chat() skips it instantly (state/agents_circuit.json; ping snapshot carries `circuit` + per-node `foreign`).
- Alternate reach workflows by condition: node down/tripped -> local library (memory/library/) covers docs offline; consultant tier (other agents with access to unreachable docs) is the fallback for paywalled/private sources; key-required tiers activate only when D provides the env key - never guessed.
Local nodes (registry scripts, claude_worker, MCP servers, daemon) keep normal policy - silent spawn (_silent.py) still applies to all of them.

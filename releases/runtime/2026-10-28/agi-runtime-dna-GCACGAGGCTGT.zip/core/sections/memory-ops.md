# memory-ops - hot core + state + IO fallback (load for memory work beyond R8 basics)

Hot core (MEMORY.md): one line per key, `key<TAB>value`; update = replace the WHOLE line; no append/rewrite of partial lines. Budget <= ~10k chars total. Machine keys live in state/, so the hot core is fully portable - never let paths/ports back in.
state/: env_probe.json (machine facts), boot.json (boot checkpoint), capabilities.json, machine.md (free-form notes). Written only by probes/gates or explicit D-approved edits.
Knowledge: topic notes under knowledge/ - portable, loaded read-only namespace; a foreign model must not mutate it (I1/I2).
RAG: embed index over state/knowledge/skills via the verified embed script; semantic search via the verified search script. Rebuild after significant content change.
IO fallback protocol (for models without native tool calling): every op as a fenced block
```agi-op
{"op": "...", "args": {...}, "expect": "..."}
```
and results as
```agi-result
{"result": ..., "state_delta": {...}}
```
Parse strictly; malformed block = one failure (R5), ask D, no guessing.

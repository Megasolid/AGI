# interaction — the human interaction protocol (R10/R11, DNA I9)

Load when presenting or approving a proposal card, running a task whose state is card-visible, or declaring the
resume path. The **card is the contract**; chat is a pointer to it. Cards are projections of `state/` — never a
second source of truth. Visual/design standards are L3 knowledge (`memory/knowledge/ui-dashboard.md`,
`memory/knowledge/human-ai-interaction.md`), not Core law.

---

## 1. Card lifecycle

| Stage | Card shows | Primary action |
|---|---|---|
| **proposal** | full bill context (why, scope/workstreams, estimate, risk, out-of-scope), step list **pre-selected by default**, per-step optional inputs, free-text "missing info" field, note | **Approve** (one click) — secondary: Review / Cancel / Archive / Subtask |
| **running** | task title, per-step LEDs (pending/active/passed/failed), progress n/N, est/elapsed/actual/ratio, bill status, last checkpoint, **RESULT block when done**, action buttons (Cancel / Archive / Create subtask + note) | none required; monitor |
| **result** | the RESULT block: one-paragraph outcome + artifact links + verification evidence + recorded timestamp | follow a link; the chat report is one line |

Rules:
- Proposal steps are **pre-selected**; the human only unchecks what must change and annotates. The decision
  payload carries the approved-step set, per-step inputs, the free-text field and the note.
- Exactly **one primary action** per card. The decision carries the whole form.
- The card URL is always printed in chat (a clickable link), because the agent cannot assume a tab was opened.
- Every transition is timestamped and durable; the card is also the archive record afterwards.

## 2. Decision log and resume

- `POST /api/action` (or the equivalent host seam) appends a record to `state/taskboard_actions.jsonl`:
  `{n, ts, task_id, type, note, inputs, approve_steps, step_inputs}`. The log is **append-only**; the agent
  consumes it (`taskcard.py actions --consume`) and advances a cursor in `state/taskboard_actions_cursor.json`
  so a decision is never handled twice.
- **Resume paths, best first:**
  1. **Native host seam (preferred).** When the host exposes a human-interaction seam (timed
     `ask_user_question` + `userQuestions.answer`, or an equivalent event), a recorded decision is forwarded to it
     and the agent is resumed event-driven. Target latency: **<5 s**.
  2. **Bounded fallback.** Otherwise the agent polls the decision log on its next turn/scheduled check; the fallback
     must be bounded (<=60 s nominal), and the card must display the true state: *queued -> notified -> running*.
- `state/interaction.json` **declares** the active path and its measured latency; the agent may not claim a faster
  resume than the declared evidence. Phase-2 work is to implement the native bridge.
- If the human decision never arrives, the card shows pending; the agent may continue unrelated work but must not
  start consequential work without the recorded approval.

## 3. Consequential vs routine (R11 proportionality)

- **Consequential** -> full proposal card + recorded approval: R4 thresholds (est >5 min, >=5 steps), irreversible
  actions, scope changes, anything touching real-environment data or external commitments.
- **Routine reversible** -> lightweight card or one-line note, then proceed; report in the result.
- **Trivial** -> no ceremony; do it and mention it in the next report.
- Approval fatigue is a failure mode: a card that did not need to exist trains the human to click blindly.

## 4. Degradation (hosts without a UI)

- No interaction surface -> produce the same **durable decision record** in the text channel (question + options +
  answer line in the task log), and the same proposal/running/result fields in a compact text form.
- Never silently skip the decision record because "there was no UI".

## 5. Failure modes to watch

| Symptom | Response |
|---|---|
| Card shows sent but agent never resumes | check the declared resume path/latency; escalate to the fallback; report the gap (R10 violation) |
| Decision consumed twice | cursor mismatch — inspect `taskboard_actions_cursor.json`, never replay silently |
| Card page not reachable | print the link; if the loopback server is down, fall back to the text decision record and note it |
| Approval of a superseded card | latest decision wins only if it is later in the log and names the same task; archive actions are superseded by a later approve |
| Card shows stale state | regenerate the card from `state/` at every transition; never edit the page directly |

## 6. Gates

- **C6 (conformance interaction gate):** Core wiring (DNA I9 + R10/R11 + this section in the manifest), proposal
  renderer contract (full context, five actions, pre-selected steps, inputs), append-only decision log +
  consume/cursor round-trip, running card RESULT block and links, served site with card pages and internal links
  resolving, and a valid `state/interaction.json` declaration.
- Registry entries: `taskcard`, `board-serve`, `sitegen`, `interaction-gate` (tests).

## 7. Working native resume (bridge v4 — verified 2026-10-25)

The native click-to-resume path is **live** in gen3.5 and declared in `state/interaction.json`:

- Installed host plugin: `@local/agi-resume-bridge-v4` (bundle in `harness/agi-resume-bridge-v4/`).
- Tool `agi_await_decision3(task_id, title, detail, hold_s)`: presents a **plan-review question** and holds the
  turn in the foreground. The question is genuinely continued, so an answer delivered through
  `ctx.userQuestions.answer()` resolves it and the **same turn** resumes.
- Routes served by the plugin: `GET /api/agi-resume3/pending` (active questions) and
  `POST /api/agi-resume3 {call_id, decision, note}` (answer + wake).
- The AGI loopback server forwards card decisions automatically: after logging an approve/review/cancel action it
  finds the matching pending question and posts the decision (measured bridge latency **12 ms**; end-to-end
  loopback click **18 ms**). The action log gains a `bridge_result` record as evidence.
- **Agent duty:** after presenting a proposal card (and printing its link), call `agi_await_decision3` with the
  task id and the bill summary. If it returns `{decided:true, ...}` act on the decision immediately. If it returns
  `{pending:true, call_id}` (hold window elapsed with no click) the scheduled-check fallback applies and the chat
  card remains answerable.
- Fallback remains mandatory: the scheduled check (<=60 s) must still exist for hosts without the bridge, for
  timeouts, and after restarts. `state/interaction.json` declares the active path/latency; never claim a faster
  resume than recorded.
- Superseded iterations (v1/v2/v3 bundles) stay loaded until an application restart unloads them; they are
  dormant and documented in `state/interaction.json` (`dormant_plugins`).

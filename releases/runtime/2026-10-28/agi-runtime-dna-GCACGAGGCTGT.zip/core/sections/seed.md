# seed - fallback boot data (ONLY when no bundle carried)

If S1 finds neither state/ nor a valid bundle: do NOT halt. Use this minimal seed to complete boot, marking every fact `seed-sourced` in state/ so a later real bundle can override it.
Seed facts (generation-neutral): user = D; platform family = desktop; memory layout = the layer map of SKILL.md; gates R1-R8 apply unchanged; pool providers = none assumed (S3 probe decides).
After seed boot: tell D the system is running on seed data and that carrying the bundle next migration removes this fallback. Never invent machine facts here - unknown stays unknown until S4 probes it.

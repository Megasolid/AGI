# check-report - one-call machine report (load when D asks for status)

Protocol: ONE call to the verified report script (see scripts/registry.json, tag perf). It emits the check-format stream; the renderer turns it into a single self-contained dark-grid HTML page.
- Output file lands in session CWD ONLY (surfaces in chat as a download). Never write stray files/dirs from this flow.
- Reply to D = one-line status + issues only. Never paste or rewrite report content into chat.
- Sections the stream must carry: model/server, speed+VRAM, context, network/proxy, OS/env gate, migration state, hw temps.
- Stdin fallback: renderer parses piped check-format text (for offline review); env card skipped then.

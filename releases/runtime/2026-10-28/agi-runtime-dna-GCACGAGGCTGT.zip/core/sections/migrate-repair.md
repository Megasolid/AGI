# migrate-repair - REPAIR MODE ONLY (primary migration = copying the bundle)

Use when: new machine with bundle carried but no state; or core_version mismatch between bundle and installed skill; or boot S2 manifest failure D chose to repair instead of rollback.

Bundle restore:
1. Verify agi bundle integrity (manifest sha256 + layer IDs). Fail -> stop, report list.
2. Extract portable layers only (SKILL.md, core/, models/, knowledge/, scripts/). Never extract state/temp/backups from an old machine into a live one.
3. Create fresh state/ from state.template/.
4. Run boot S1-S7 to fill machine facts.
5. Re-register scripts: every script starts as candidate until verified on THIS machine (R3).
6. Repack bundle post-restore only if D asks; old packs kept in backups/ with dates.

Version-bump repair: read core_version from manifest + installed SKILL.md header. Newer bundle wins unless D says keep; note the delta in memory log line.

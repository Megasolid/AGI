# env-gate - sandbox <-> Real Env crossing protocol (R9)

Thin router. Full facts, recipes, and failure signatures: `memory/knowledge/os-gate.md` (SSOT; load it first). This section holds no machine values (I2).

## Boot knowledge (read before first crossing each session)
S4 writes live Studio permission settings to `state/env_probe.json` under `studio.permission` (`permissionMode`, `confirmToolCalls`, `toolsEnabled`, `codeToolsEnabled`). Read it when the gate fires: `permissionMode=off` + `confirmToolCalls=false` = Full Access, no approval prompts will appear. If a prompt appears anyway, the setting changed since boot - treat that as new state, not a failure.

## When the gate fires (binding)
- Launching any external/GUI app from the shell
- Reading/writing files under the real user profile or its AppData
- Connecting to a service started by the real user session
- Diagnosing "app shows empty / different data"

## Protocol
1. **Detect**: check env vars (LOCALAPPDATA/APPDATA/USERPROFILE/HOME/TEMP); if they point into the per-session sandbox, you are sandboxed (normal).
2. **Pin before launch**: override those vars to real user values in the same invocation as the launch; prefer explicit app flags over env overrides when the app supports them.
3. **Verify where it landed**: never trust the command line alone - confirm via a path-revealing artifact of the launched process (its log/config, data-dir file, or visible state). Same exe + same flags != same instance.
4. **Report reality**: if it landed in the sandbox, say so and relaunch pinned - do not proceed as if it were the user's real instance.

## Completion check
The launched process's data dir (verified via artifact) equals the real user path, and the app shows the user's expected state.

Provenance: standalone skill `sandbox-env-gate` retired 2026-10-18; protocol folded into this section + os-gate.md SSOT.

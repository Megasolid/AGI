# blender-kb - MCP-first Blender workflow (capability-gated)

Capability gate: if S3 found no Blender MCP bridge -> degraded mode = report "Blender unavailable on this machine", suggest install steps, do NOT improvise bpy via other routes.
Workflow order: 1) query scene state through MCP (objects summary / data-blocks) BEFORE generating code; 2) execute_blender_code for changes; background/CLI variant only for batch renders on a named .blend; 3) verify by re-querying state or a thumbnail render to path, not by assuming success.
Knowledge: topic notes in knowledge/blender* (portable). Machine-specific scene files stay referenced via state/, never hardcoded here.

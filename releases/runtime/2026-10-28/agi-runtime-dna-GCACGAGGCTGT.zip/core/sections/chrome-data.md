# chrome-data - local profile & bookmarks (capability-gated)

Capability gate: needs the Chrome MCP daemon (port/path from state/env_probe.json only). Daemon down -> degraded mode = try the verified auto-start ONCE (windowless spawn rules in knowledge/chrome-mcp.md), then report, no loops (R5).
Rules: one allow prompt per Chrome session then silent; timeouts client/server as configured in state-side config; gateway failover on bridge failure is SILENT - verify daemon via list-pages first.
Profile work: always D's real logged-in profile; never spawn a blank/second instance (same exe+flags != same instance - verify where the process landed after any launch).
Bookmarks/local data: read via MCP tools; writes to user data need R4 confirm (irreversible-ish).

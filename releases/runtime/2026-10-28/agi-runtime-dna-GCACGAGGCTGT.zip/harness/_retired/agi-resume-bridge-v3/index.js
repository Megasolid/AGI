/**
 * AGI resume bridge v3 (phase 2, 2026-10-25)
 *
 * v3 differs from v2 only in identity: a unique tool name (`agi_await_decision2`) and a unique route
 * path (`/api/agi-resume`). v1/v2 could not be replaced without an application restart, so their rows
 * remain loaded but dormant; a restart can remove them.
 *
 * - Tool: opens a HELD plan-review question (600 s default) in the background and returns
 *   {pending:true, call_id, bridge_url, hold_s} immediately - the turn is not blocked.
 * - Route POST /api/agi-resume: the AGI loopback server forwards the card decision here; we call
 *   ctx.userQuestions.answer(agent, callId, answer), which steers the reply into the agent as a user
 *   message and wakes it (R10 click-to-resume, target <5 s).
 */
export const inject = ['tools', 'webServer', 'userQuestions']

export function apply(ctx) {
  const pending = new Map() // callId -> { agent, questionId, taskId, createdAt, expiresAt }

  ctx.effect(() => {
    const disposeTool = ctx.tools.register({
      name: 'agi_await_decision2',
      description:
        'Open a HELD plan-review question for the AGI proposal card and return immediately with ' +
        '{pending:true, call_id, bridge_url}. A loopback card decision forwarded to /api/agi-resume is ' +
        'answered through userQuestions.answer and wakes this agent (click-to-resume).',
      parameters: {
        type: 'object',
        properties: {
          task_id: { type: 'string', description: 'AGI task id of the proposal card.' },
          title: { type: 'string', description: 'Title shown on the question card.' },
          detail: { type: 'string', description: 'Optional plan detail shown with the question.' },
          hold_s: { type: 'number', description: 'How long the question stays answerable (30-900 s, default 600).' },
        },
        required: ['task_id'],
        additionalProperties: false,
      },
      output: {
        schema: { type: 'object' },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
      },
      async execute(args, exec) {
        const holdMs = Math.round(Math.min(Math.max(Number(args.hold_s) || 600, 30), 900) * 1000)
        const callId = String(exec.callId)
        const questionId = 'approve'
        let origin = ''
        try {
          origin = ctx.webServer.getOrigin()
        } catch {
          origin = ''
        }
        pending.set(callId, {
          agent: exec.agent,
          questionId,
          taskId: String(args.task_id),
          createdAt: Date.now(),
          expiresAt: Date.now() + holdMs,
        })
        const request = {
          agent: exec.agent,
          questions: [
            {
              id: questionId,
              header: 'Proposal approval',
              question: args.title || 'Approve ' + String(args.task_id) + '?',
              detail: args.detail || '',
              options: [{ label: 'Approve' }, { label: 'Review' }, { label: 'Cancel' }],
              intent: { kind: 'plan-review', approve: 'Approve', callId },
            },
          ],
          wait: { callId, timed: true },
        }
        ctx.userQuestions
          .askTimed(request, callId, holdMs)
          .then((result) => {
            if (!result || !result.pending) pending.delete(callId)
          })
          .catch(() => pending.delete(callId))
        await new Promise((resolve) => setTimeout(resolve, 60))
        return {
          pending: true,
          call_id: callId,
          bridge_url: origin ? origin + '/api/agi-resume' : '',
          hold_s: Math.round(holdMs / 1000),
        }
      },
    })

    const disposeRoute = ctx.webServer.register({
      kind: 'exact',
      path: '/api/agi-resume',
      async handler(req, res) {
        const reply = (code, obj) => {
          res.statusCode = code
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify(obj))
        }
        try {
          const chunks = []
          for await (const chunk of req) chunks.push(chunk)
          const body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')
          const callId = String(body.call_id || '')
          const entry = pending.get(callId)
          if (!entry) {
            reply(404, { ok: false, error: 'no pending question for call_id' })
            return
          }
          if (Date.now() > entry.expiresAt) {
            pending.delete(callId)
            reply(410, { ok: false, error: 'pending question expired' })
            return
          }
          const decision = String(body.decision || 'Approve')
          const valid = ['Approve', 'Review', 'Cancel']
          if (!valid.includes(decision)) {
            reply(400, { ok: false, error: 'decision must be one of ' + valid.join(', ') })
            return
          }
          const answer = {
            answers: [
              {
                id: entry.questionId,
                selected: [decision],
                ...(body.note ? { custom: String(body.note) } : {}),
              },
            ],
          }
          const accepted = ctx.userQuestions.answer(entry.agent, body.call_id, answer)
          pending.delete(callId)
          reply(200, { ok: true, accepted: Boolean(accepted), decision, call_id: callId })
        } catch (err) {
          reply(500, { ok: false, error: String(err && err.message ? err.message : err) })
        }
      },
    })

    return () => {
      try {
        disposeRoute()
      } catch {}
      try {
        disposeTool()
      } catch {}
    }
  }, 'agi-resume-bridge-v3')
}

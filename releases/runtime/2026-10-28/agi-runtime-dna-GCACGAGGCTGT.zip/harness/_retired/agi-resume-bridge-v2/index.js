/**
 * AGI resume bridge v2 (phase 2, 2026-10-25)
 *
 * Difference from v1: the plan-review question is opened with a LONG hold window in the background
 * and the tool returns immediately, so the turn is not blocked. The question stays active/answerable,
 * so `ctx.userQuestions.answer()` from the loopback card route actually resumes the agent.
 *
 * - Tool `agi_await_decision`: opens the held question and returns {pending:true, call_id, bridge_url,
 *   hold_s} immediately. If the human answers the chat card inside the hold window, askTimed settles with
 *   the answer and the pending entry is dropped.
 * - Route POST /api/agi-decision: the AGI loopback server forwards a card decision here; we call
 *   ctx.userQuestions.answer(agent, callId, answer), which steers the reply into the agent as a user
 *   message and wakes it. That is the click-to-resume path (R10 target <5 s).
 */
export const inject = ['tools', 'webServer', 'userQuestions']

export function apply(ctx) {
  const pending = new Map() // callId -> { agent, questionId, taskId, createdAt, expiresAt }

  const drop = (callId) => {
    pending.delete(String(callId))
  }

  ctx.effect(() => {
    const disposeTool = ctx.tools.register({
      name: 'agi_await_decision',
      description:
        'Open a HELD plan-review question for the AGI proposal card and return immediately with ' +
        '{pending:true, call_id, bridge_url}. The loopback card decision is forwarded to /api/agi-decision, ' +
        'answered through userQuestions.answer, and wakes this agent (click-to-resume).',
      parameters: {
        type: 'object',
        properties: {
          task_id: { type: 'string', description: 'AGI task id of the proposal card.' },
          title: { type: 'string', description: 'Title shown on the question card.' },
          detail: { type: 'string', description: 'Optional plan detail shown with the question.' },
          hold_s: {
            type: 'number',
            description: 'How long the question stays answerable, in seconds (30-900; default 600).',
          },
        },
        required: ['task_id'],
        additionalProperties: false,
      },
      output: {
        schema: { type: 'object' },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
      },
      async execute(args, exec) {
        const holdMs = Math.round(Math.min(Math.max(Number(args.hold_s) || 600, 30), 900) * 1000)
        const callId = String(exec.callId)
        const questionId = 'approve'
        let origin = ''
        try {
          origin = ctx.webServer.getOrigin()
        } catch {
          origin = ''
        }
        pending.set(callId, {
          agent: exec.agent,
          questionId,
          taskId: String(args.task_id),
          createdAt: Date.now(),
          expiresAt: Date.now() + holdMs,
        })
        const request = {
          agent: exec.agent,
          questions: [
            {
              id: questionId,
              header: 'Proposal approval',
              question: args.title || 'Approve ' + String(args.task_id) + '?',
              detail: args.detail || '',
              options: [{ label: 'Approve' }, { label: 'Review' }, { label: 'Cancel' }],
              intent: { kind: 'plan-review', approve: 'Approve', callId },
            },
          ],
          wait: { callId, timed: true },
        }
        const askPromise = ctx.userQuestions.askTimed(request, callId, holdMs)
        // The held wait settles later: an in-window chat answer settles it, otherwise it times out.
        askPromise
          .then((result) => {
            if (!result || !result.pending) drop(callId)
          })
          .catch(() => drop(callId))
        // Give the question request a tick to register/render before returning to the model.
        await new Promise((resolve) => setTimeout(resolve, 60))
        return {
          pending: true,
          call_id: callId,
          bridge_url: origin ? origin + '/api/agi-decision' : '',
          hold_s: Math.round(holdMs / 1000),
        }
      },
    })

    const disposeRoute = ctx.webServer.register({
      kind: 'exact',
      path: '/api/agi-decision',
      async handler(req, res) {
        const reply = (code, obj) => {
          res.statusCode = code
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify(obj))
        }
        try {
          const chunks = []
          for await (const chunk of req) chunks.push(chunk)
          const body = JSON.parse((Buffer.concat(chunks).toString('utf8') || '{}'))
          const callId = String(body.call_id || '')
          const entry = pending.get(callId)
          if (!entry) {
            reply(404, { ok: false, error: 'no pending question for call_id' })
            return
          }
          if (Date.now() > entry.expiresAt) {
            pending.delete(callId)
            reply(410, { ok: false, error: 'pending question expired' })
            return
          }
          const decision = String(body.decision || 'Approve')
          const valid = ['Approve', 'Review', 'Cancel']
          if (!valid.includes(decision)) {
            reply(400, { ok: false, error: 'decision must be one of ' + valid.join(', ') })
            return
          }
          const answer = {
            answers: [
              {
                id: entry.questionId,
                selected: [decision],
                ...(body.note ? { custom: String(body.note) } : {}),
              },
            ],
          }
          const accepted = ctx.userQuestions.answer(entry.agent, body.call_id, answer)
          pending.delete(callId)
          reply(200, { ok: true, accepted: Boolean(accepted), decision, call_id: callId })
        } catch (err) {
          reply(500, { ok: false, error: String(err && err.message ? err.message : err) })
        }
      },
    })

    return () => {
      try {
        disposeRoute()
      } catch {}
      try {
        disposeTool()
      } catch {}
    }
  }, 'agi-resume-bridge-v2')
}

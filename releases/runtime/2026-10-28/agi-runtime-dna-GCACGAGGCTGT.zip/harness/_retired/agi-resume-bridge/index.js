/**
 * AGI resume bridge (phase 2, 2026-10-25)
 *
 * Purpose: make a card decision resume the agent event-driven instead of waiting for the next turn.
 *
 * - Tool `agi_await_decision`: opens a timed plan-review question for the invoking agent through
 *   ctx.userQuestions.askTimed. If the human answers inside the window (chat card), the tool returns
 *   the answer. Otherwise it returns {pending:true, call_id, bridge_url} and keeps the question
 *   answerable; the AGI side records that in state/interaction_pending.json.
 * - Route POST /api/agi-decision: the AGI loopback server forwards a card decision here; we call
 *   ctx.userQuestions.answer(agent, callId, answer), which steers the reply into the agent as a user
 *   message and wakes it. That is the click-to-resume path (R10 target: <5 s).
 */
export const inject = ['tools', 'webServer', 'userQuestions']

export function apply(ctx) {
  const pending = new Map() // callId -> { agent, questionId, taskId, createdAt }

  ctx.effect(() => {
    const disposeTool = ctx.tools.register({
      name: 'agi_await_decision',
      description:
        'Open a timed plan-review question for the AGI proposal card. Returns the answer when the human ' +
        'answers inside the window; otherwise returns {pending:true, call_id, bridge_url} so the loopback ' +
        'card can answer it later and wake this agent (click-to-resume).',
      parameters: {
        type: 'object',
        properties: {
          task_id: { type: 'string', description: 'AGI task id of the proposal card.' },
          title: { type: 'string', description: 'Title shown on the question card.' },
          detail: { type: 'string', description: 'Optional plan detail shown with the question.' },
          timeout_s: {
            type: 'number',
            description: 'Foreground wait in seconds (5-600). After it, the question stays answerable via the bridge.',
          },
        },
        required: ['task_id'],
        additionalProperties: false,
      },
      output: {
        schema: { type: 'object' },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
      },
      async execute(args, exec) {
        const timeoutMs = Math.round(Math.min(Math.max(Number(args.timeout_s) || 8, 5), 600) * 1000)
        const callId = exec.callId
        const questionId = 'approve'
        let origin = ''
        try {
          origin = ctx.webServer.getOrigin()
        } catch {
          origin = ''
        }
        const request = {
          agent: exec.agent,
          questions: [
            {
              id: questionId,
              header: 'Proposal approval',
              question: args.title || 'Approve ' + String(args.task_id) + '?',
              detail: args.detail || '',
              options: [{ label: 'Approve' }, { label: 'Review' }, { label: 'Cancel' }],
              intent: { kind: 'plan-review', approve: 'Approve', callId },
            },
          ],
          wait: { callId, timed: true },
        }
        let result
        try {
          result = await ctx.userQuestions.askTimed(request, callId, timeoutMs)
        } catch (err) {
          return { pending: false, error: String(err && err.message ? err.message : err) }
        }
        if (result && result.pending) {
          pending.set(String(callId), { agent: exec.agent, questionId, taskId: args.task_id, createdAt: Date.now() })
          return {
            pending: true,
            call_id: String(callId),
            bridge_url: origin ? origin + '/api/agi-decision' : '',
            timeout_s: Math.round(timeoutMs / 1000),
          }
        }
        pending.delete(String(callId))
        const answers = (result && result.answers) || []
        const first = answers[0] || {}
        return { pending: false, selected: first.selected || [], custom: first.custom || '' }
      },
    })

    const disposeRoute = ctx.webServer.register({
      kind: 'exact',
      path: '/api/agi-decision',
      async handler(req, res) {
        const reply = (code, obj) => {
          res.statusCode = code
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify(obj))
        }
        try {
          const chunks = []
          for await (const chunk of req) chunks.push(chunk)
          const raw = Buffer.concat(chunks).toString('utf8') || '{}'
          const body = JSON.parse(raw)
          const callId = String(body.call_id || '')
          const entry = pending.get(callId)
          if (!entry) {
            reply(404, { ok: false, error: 'no pending question for call_id' })
            return
          }
          const decision = String(body.decision || 'Approve')
          const valid = ['Approve', 'Review', 'Cancel']
          if (!valid.includes(decision)) {
            reply(400, { ok: false, error: 'decision must be one of ' + valid.join(', ') })
            return
          }
          const answer = {
            answers: [
              {
                id: entry.questionId,
                selected: [decision],
                ...(body.note ? { custom: String(body.note) } : {}),
              },
            ],
          }
          const accepted = ctx.userQuestions.answer(entry.agent, body.call_id, answer)
          pending.delete(callId)
          reply(200, { ok: true, accepted: Boolean(accepted), decision })
        } catch (err) {
          reply(500, { ok: false, error: String(err && err.message ? err.message : err) })
        }
      },
    })

    return () => {
      try {
        disposeRoute()
      } catch {}
      try {
        disposeTool()
      } catch {}
    }
  }, 'agi-resume-bridge')
}

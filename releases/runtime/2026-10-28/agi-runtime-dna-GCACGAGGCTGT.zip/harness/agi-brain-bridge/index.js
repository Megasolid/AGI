// AGI Brain Bridge - loopback completion route for AGI Brain Lab.
//
// Contract (harness-agnostic; see AGI state/brains/host_contract.json):
//   POST /agi-brain/v1/complete  {"prompt": "...", "max_tokens"?: 512}
//     -> {"ok": true, "text": "...", "provider": "...", "child": "...", "stopReason": "completed"}
//   GET  /agi-brain/v1/health    -> {"ok": true, "providers": [...], "parents": [...], "origin": "..."}
//
// The completion runs as a real child turn of the live root agent through the subagents service, so the
// benchmark measures the same host model the user is talking to. Loopback only; optional token header.

export const name = 'agi-brain-bridge'
export const inject = ['webServer', 'agents', 'subagents']

export function apply(ctx, config = {}) {
  const provider = String(config.provider || '')
  const token = String(config.token || '')
  const maxWaitMs = Math.max(10, Number(config.maxWaitSeconds || 180)) * 1000
  const origin = () => { try { return ctx.webServer.getOrigin() } catch { return 'unknown' } }

  const send = (res, code, obj) => {
    res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
    res.end(JSON.stringify(obj))
  }
  const readBody = (req) => new Promise((resolve, reject) => {
    let raw = ''
    req.on('data', (c) => { raw += c; if (raw.length > 1_000_000) reject(new Error('body too large')) })
    req.on('end', () => resolve(raw))
    req.on('error', reject)
  })
  const authorized = (req) => !token || req.headers['x-agi-token'] === token

  const health = {
    kind: 'exact',
    path: '/agi-brain/v1/health',
    handler: async (req, res) => {
      send(res, 200, { ok: true, providers: ctx.subagents.list(), roots: ctx.agents.roots().map((a) => a.id),
                       origin: origin(), bridge: name, authorized: authorized(req) })
    },
  }

  const complete = {
    kind: 'exact',
    path: '/agi-brain/v1/complete',
    handler: async (req, res) => {
      if (!authorized(req)) return send(res, 403, { ok: false, error: 'token required' })
      if (req.method !== 'POST') return send(res, 405, { ok: false, error: 'POST only' })
      let body
      try { body = JSON.parse(await readBody(req) || '{}') } catch (e) { return send(res, 400, { ok: false, error: 'bad json' }) }
      const prompt = String(body.prompt || '')
      if (!prompt) return send(res, 400, { ok: false, error: 'prompt required' })
      const roots = ctx.agents.roots()
      const parent = roots[roots.length - 1]
      if (!parent) return send(res, 503, { ok: false, error: 'no live root agent' })
      const providers = ctx.subagents.list()
      const chosen = provider || providers[0]
      if (!chosen) return send(res, 503, { ok: false, error: 'no subagent provider registered' })
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(new Error('bridge timeout')), maxWaitMs)
      let activation
      try {
        activation = await ctx.subagents.startActivation({
          provider: chosen,
          label: 'agi-brain-probe',
          request: {
            prompt: [{ type: 'text', text: prompt }],
            parent,
            agentOptions: body.max_tokens ? { maxTokens: Number(body.max_tokens) } : undefined,
          },
          signal: controller.signal,
          delivery: 'caller',
        })
        const result = await activation.result
        const text = (result.output || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n')
        send(res, 200, { ok: true, text, provider: chosen, child: activation.childId,
                         stopReason: result.stopReason, model: body.model || null })
      } catch (e) {
        send(res, 500, { ok: false, error: String(e && e.message ? e.message : e).slice(0, 300) })
      } finally {
        clearTimeout(timer)
        try { if (activation && activation.dispose) await activation.dispose() } catch { /* noop */ }
      }
    },
  }

  ctx.effect(() => ctx.webServer.register(health))
  ctx.effect(() => ctx.webServer.register(complete))
}

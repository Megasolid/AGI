/**
 * Client half: watch the AGI loopback board server and open a right-sidebar Browser tab
 * when a NEW task board appears.
 *
 * - AGI publishes the rendered board at http://127.0.0.1:<port>/task_live.html and a small
 *   /api/state JSON (CORS *) from state/taskboard.json; the page self-refreshes every 5 s,
 *   so one tab per task is enough.
 * - Registered with a zero-height shell.overlay monitor so the live Client slot tree proves
 *   the module actually loaded (verification without browser control).
 */
const BOARD_BASE = 'http://127.0.0.1:8765';

window.__ModuleLoader__.load({
  id: '@local/agi-task-board',
  factory(require) {
    return {
      inject: ['slots'],
      apply(ctx) {
        const openBoard = async () => {
          try {
            const res = await fetch(BOARD_BASE + '/api/state', { cache: 'no-store' });
            if (!res.ok) return;
            const state = await res.json();
            if (!state || !state.task_id || state.task_id === openBoard.lastTask) return;
            const sidebar = ctx.sidebarRight
              || (typeof ctx.get === 'function' ? ctx.get('sidebarRight') : undefined);
            if (!sidebar || typeof sidebar.openTab !== 'function') {
              console.warn('[agi-task-board] sidebarRight service unavailable');
              return;
            }
            sidebar.openTab('browser', { params: { url: state.url } });
            openBoard.lastTask = state.task_id;   // only after a successful open; retries otherwise
          } catch (err) {
            /* board server not up yet, or the Browser tab could not be opened - retry next tick */
          }
        };

        if (ctx.effect) {
          ctx.effect(() => {
            const timer = setInterval(openBoard, 2500);
            openBoard();
            return () => clearInterval(timer);
          });
        } else {
          setInterval(openBoard, 2500);
          openBoard();
        }

        if (ctx.slots) {
          ctx.slots.inject('shell.overlay', () => ctx.slots.register({
            name: 'shell.overlay', id: 'agi-task-board-monitor', order: 999,
          }, () => null));
        }
      },
    };
  },
});

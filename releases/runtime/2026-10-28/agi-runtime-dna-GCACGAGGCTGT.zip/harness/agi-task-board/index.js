/**
 * Host half of the AGI task-board bundle.
 *
 * Nothing needs a Host service here: the board itself is published by the AGI side on
 * http://127.0.0.1:<port>/task_live.html (state/taskboard.json), and the Client half opens
 * the Harness right-sidebar Browser at that loopback URL. Kept as a no-op row so the bundle
 * has the standard shape.
 */
export function apply() {}

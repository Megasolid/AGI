/**
 * AGI resume bridge v4 (phase 2, 2026-10-25) — the working click-to-resume path.
 *
 * Why v4: earlier attempts returned from the tool while the timed question waited in the background;
 * the question then settled (timeout) and userQuestions.answer() was no longer accepted. v4 instead keeps
 * the tool call in the foreground for the hold window, so the question is genuinely continued:
 *
 *   agent: agi_await_decision3(hold_s=600)  ── blocks (foreground) ──┐
 *   human: clicks Approve on the loopback card                        │
 *   AGI board server: GET /api/agi-resume3/pending -> call_id         │
 *                     POST /api/agi-resume3 {call_id, decision}      │
 *   plugin: ctx.userQuestions.answer(agent, callId, answer) ──────────┘
 *   -> askTimed resolves with the answer, the tool returns within milliseconds, the SAME turn resumes.
 *
 * Fallback: if the hold window elapses with no decision, the tool returns {pending:true, call_id} and the
 * question stays answerable through the chat card; the AGI scheduled check / next turn remains the backup.
 */
export const inject = ['tools', 'webServer', 'userQuestions']

export function apply(ctx) {
  const pending = new Map() // callId -> { agent, questionId, taskId, expiresAt, answered }

  const pendingState = () => ({
    now: Date.now(),
    items: [...pending.entries()]
      .filter(([, e]) => Date.now() <= e.expiresAt)
      .map(([callId, e]) => ({ call_id: callId, task_id: e.taskId, expires_at: new Date(e.expiresAt).toISOString() })),
  })

  ctx.effect(() => {
    const disposeTool = ctx.tools.register({
      name: 'agi_await_decision3',
      description:
        'Present a plan-review question and HOLD the turn for up to hold_s seconds. The loopback card decision ' +
        'is fetched from GET /api/agi-resume3/pending and posted to /api/agi-resume3; the answer resumes this ' +
        'turn in milliseconds. Returns {decision} when answered, or {pending:true, call_id} on hold timeout.',
      parameters: {
        type: 'object',
        properties: {
          task_id: { type: 'string', description: 'AGI task id of the proposal card.' },
          title: { type: 'string', description: 'Title shown on the question card.' },
          detail: { type: 'string', description: 'Optional plan detail shown with the question.' },
          hold_s: { type: 'number', description: 'Foreground hold window in seconds (30-900, default 600).' },
        },
        required: ['task_id'],
        additionalProperties: false,
      },
      output: {
        schema: { type: 'object' },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
      },
      async execute(args, exec) {
        const holdMs = Math.round(Math.min(Math.max(Number(args.hold_s) || 600, 30), 900) * 1000)
        const callId = String(exec.callId)
        const questionId = 'approve'
        let origin = ''
        try {
          origin = ctx.webServer.getOrigin()
        } catch {
          origin = ''
        }
        const entry = {
          agent: exec.agent,
          questionId,
          taskId: String(args.task_id),
          expiresAt: Date.now() + holdMs,
          answered: null,
        }
        pending.set(callId, entry)
        const request = {
          agent: exec.agent,
          questions: [
            {
              id: questionId,
              header: 'Proposal approval',
              question: args.title || 'Approve ' + String(args.task_id) + '?',
              detail: args.detail || '',
              options: [{ label: 'Approve' }, { label: 'Review' }, { label: 'Cancel' }],
              intent: { kind: 'plan-review', approve: 'Approve', callId },
            },
          ],
          wait: { callId, timed: true },
        }
        let result
        try {
          result = await ctx.userQuestions.askTimed(request, callId, holdMs)
        } catch (err) {
          pending.delete(callId)
          return { decided: false, error: String(err && err.message ? err.message : err) }
        }
        const settledByMe = entry.answered
        pending.delete(callId)
        if (settledByMe) {
          return { decided: true, decision: settledByMe.decision, note: settledByMe.note || '', via: 'loopback-card' }
        }
        if (result && result.answers && result.answers.length) {
          const first = result.answers[0]
          return {
            decided: true,
            decision: (first.selected && first.selected[0]) || 'Approve',
            note: first.custom || '',
            via: 'chat-card',
          }
        }
        return {
          pending: true,
          call_id: callId,
          bridge_url: origin ? origin + '/api/agi-resume3' : '',
          hold_s: Math.round(holdMs / 1000),
        }
      },
    })

    const disposeDecision = ctx.webServer.register({
      kind: 'exact',
      path: '/api/agi-resume3',
      async handler(req, res) {
        const reply = (code, obj) => {
          res.statusCode = code
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify(obj))
        }
        try {
          const chunks = []
          for await (const chunk of req) chunks.push(chunk)
          const body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')
          const callId = String(body.call_id || '')
          const entry = pending.get(callId)
          if (!entry) return reply(404, { ok: false, error: 'no pending question for call_id' })
          if (Date.now() > entry.expiresAt) return reply(410, { ok: false, error: 'hold window expired' })
          const decision = String(body.decision || 'Approve')
          const valid = ['Approve', 'Review', 'Cancel']
          if (!valid.includes(decision)) return reply(400, { ok: false, error: 'decision must be one of ' + valid.join(', ') })
          entry.answered = { decision, note: body.note ? String(body.note) : '' }
          const answer = {
            answers: [{ id: entry.questionId, selected: [decision], ...(body.note ? { custom: String(body.note) } : {}) }],
          }
          const accepted = ctx.userQuestions.answer(entry.agent, body.call_id, answer)
          reply(200, { ok: true, accepted: Boolean(accepted), decision, call_id: callId })
        } catch (err) {
          reply(500, { ok: false, error: String(err && err.message ? err.message : err) })
        }
      },
    })

    const disposePending = ctx.webServer.register({
      kind: 'exact',
      path: '/api/agi-resume3/pending',
      async handler(req, res) {
        res.statusCode = 200
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify(pendingState()))
      },
    })

    return () => {
      try {
        disposePending()
      } catch {}
      try {
        disposeDecision()
      } catch {}
      try {
        disposeTool()
      } catch {}
    }
  }, 'agi-resume-bridge-v4')
}

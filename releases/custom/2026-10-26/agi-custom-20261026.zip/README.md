# AGI release package - custom

bundle: agi-custom-d
files: 8
built: 2026-10-26T14:57:19+0330

Every file is listed with its sha256 in RELEASE.json; the manifest is signed by the AGI device key
and can be verified offline:  python memory/scripts/release.py verify <this zip>

This is a template. To build your own bundle:
  1. install an AGI core, run crypto.py keygen and identity init
  2. initialise your own local identity and set your policy entries
  3. bundles.py init --class custom --id <yours> --parent agi-official
  4. bundles.py verify / activate

This package contains NO private keys and NO member data.

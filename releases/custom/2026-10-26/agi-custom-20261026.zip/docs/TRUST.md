# AGI trust layer - what a member receives

This package is one installation of the AGI system: the official bundle, the signed manifest that
describes it, and a neutral identity template. Nothing here carries any member's private material.

## The four guarantees

1. **Signed content** - every file is listed with a sha256 in RELEASE.json, and RELEASE.json is signed
   (ML-DSA-65, FIPS 204). Verification is offline: `python memory/scripts/release.py verify <zip>`.
2. **Append-only history** - pills are recorded in an RFC 9162 Merkle log. Every pill in the public pool
   carries its own signed tree head and an inclusion proof, so a member can prove that a pill was
   accepted and that nothing was quietly rewritten.
3. **Member identity** - each installation mints its own local identity (ML-DSA-65 device key, sealed by
   the operating system). Identity material is private to the installation; activation is performed by
   the owner and verified by the runtime. The install role records whether a member runs official,
   unlocked, custom, or no bundle (unplugged).
4. **Member-neutral artefacts** - public packages contain no private material of any kind, and
   `release.py verify` refuses a package that carries any.

## Updates

Members pull pills from the official repository's update pool (verified before import) and sync their own
public mirror. Nothing is trusted because it arrived; it is trusted because it verifies.

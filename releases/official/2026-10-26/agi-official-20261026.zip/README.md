# AGI release package - official

bundle: agi-official-d
files: 8
built: 2026-10-26T14:57:19+0330

Every file is listed with its sha256 in RELEASE.json; the manifest is signed by the AGI device key
and can be verified offline:  python memory/scripts/release.py verify <this zip>

This is the official, member-neutral package. It ships with a neutral identity
template; activation is performed by the owner after installation and verified by
the runtime. Nobody's private material is inside this archive.

This package contains NO private keys and NO member data.
